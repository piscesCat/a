/**
 * Bookmark System
 *
 * This module handles bookmarks, using localStorage for client-side storage
 * and syncing with server when available.
 */
const ClientBookmark = {
    /**
     * Initialize the bookmark system
     */
    init: function() {
        // Check if localStorage is available
        if (!this.isLocalStorageAvailable()) {
            console.warn('localStorage is not available. Bookmarks will not be saved locally.');
            return;
        }

        // Initialize localStorage if needed
        if (!localStorage.getItem('bookmarks')) {
            localStorage.setItem('bookmarks', JSON.stringify({}));
        }

        // Get user ID from cookie for server-side storage
        this.userId = this.getUserId();

        // Sync with server if we have a user ID
        if (this.userId) {
            this.syncWithServer();
        }

        // Cleanup old bookmarks to prevent localStorage from getting too full
        this.cleanupOldBookmarks();
    },

    /**
     * Add or toggle a bookmark
     *
     * @param {number} storyId - The ID of the story to bookmark
     * @param {object} storyData - Additional story data (title, etc)
     * @param {number|null} chapterId - The chapter ID if applicable
     * @returns {object} Status of the operation
     */
    toggle: function(storyId, storyData, chapterId = null) {
        let bookmarks = this.getAll();
        let action = '';
        let message = '';

        if (bookmarks[storyId]) {
            // Remove bookmark if it exists
            delete bookmarks[storyId];
            action = 'removed';
            message = 'Đã xóa khỏi danh sách bookmark';
        } else {
            // Add new bookmark
            bookmarks[storyId] = {
                id: storyId,
                title: storyData.title || '',
                slug: storyData.slug || '',
                cover_image: storyData.cover_image || '',
                author_name: storyData.author_name || '',
                chapter_id: chapterId,
                time: new Date().toISOString()
            };
            action = 'added';
            message = 'Đã thêm vào danh sách bookmark';
        }

        // Save to localStorage
        this.saveAll(bookmarks);

        // Sync with server if possible
        this.syncToServer(storyId, chapterId);

        return {
            action: action,
            message: message
        };
    },

    /**
     * Update chapter information for a bookmarked story
     *
     * @param {number} storyId - The story ID
     * @param {number} chapterId - The chapter ID
     * @returns {boolean} Success status
     */
    updateChapter: function(storyId, chapterId) {
        let bookmarks = this.getAll();

        if (!bookmarks[storyId]) {
            // If story isn't bookmarked yet, add it with minimal info
            bookmarks[storyId] = {
                id: storyId,
                chapter_id: chapterId,
                time: new Date().toISOString()
            };
            this.saveAll(bookmarks);
            this.syncToServer(storyId, chapterId, true);
            return true;
        }

        // Update chapter ID and timestamp
        bookmarks[storyId].chapter_id = chapterId;
        bookmarks[storyId].time = new Date().toISOString();

        // Save to localStorage
        this.saveAll(bookmarks);

        // Sync with server
        this.syncToServer(storyId, chapterId, true);

        return true;
    },

    /**
     * Check if a story is bookmarked
     *
     * @param {number} storyId - The story ID to check
     * @returns {boolean} True if bookmarked
     */
    isBookmarked: function(storyId) {
        const bookmarks = this.getAll();
        return !!bookmarks[storyId];
    },

    /**
     * Get a specific bookmark
     *
     * @param {number} storyId - The story ID
     * @returns {object|null} The bookmark data or null
     */
    get: function(storyId) {
        const bookmarks = this.getAll();
        return bookmarks[storyId] || null;
    },

    /**
     * Get all bookmarks as an object
     *
     * @returns {object} All bookmarks
     */
    getAll: function() {
        const data = localStorage.getItem('bookmarks');
        return data ? JSON.parse(data) : {};
    },

    /**
     * Get all bookmarks as an array (for display)
     *
     * @returns {array} Array of bookmark objects
     */
    getAllAsArray: function() {
        const bookmarks = this.getAll();
        return Object.values(bookmarks).sort((a, b) => {
            return new Date(b.time) - new Date(a.time);
        });
    },

    /**
     * Save all bookmarks to localStorage
     *
     * @param {object} bookmarks - The bookmarks object
     */
    saveAll: function(bookmarks) {
        localStorage.setItem('bookmarks', JSON.stringify(bookmarks));
    },

    /**
     * Clear all bookmarks
     */
    clearAll: function() {
        localStorage.setItem('bookmarks', JSON.stringify({}));
        // Also clear server-side bookmarks
        if (this.userId) {
            fetch('/bookmarks/clear-all', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                }
            }).catch(error => {
                console.error('Error clearing server bookmarks:', error);
            });
        }
    },

    /**
     * Export bookmarks to a JSON file
     */
    exportBookmarks: function() {
        const bookmarks = this.getAll();
        const dataStr = JSON.stringify(bookmarks, null, 2);
        const dataUri = 'data:application/json;charset=utf-8,' + encodeURIComponent(dataStr);

        const exportFileDefaultName = 'bookmarks-' + new Date().toISOString().slice(0, 10) + '.json';

        const linkElement = document.createElement('a');
        linkElement.setAttribute('href', dataUri);
        linkElement.setAttribute('download', exportFileDefaultName);
        linkElement.click();
    },

    /**
     * Import bookmarks from a JSON file
     *
     * @param {File} file - The JSON file to import
     * @returns {Promise} Promise object with result
     */
    importBookmarks: function(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();

            reader.onload = (e) => {
                try {
                    const data = JSON.parse(e.target.result);
                    if (typeof data !== 'object') {
                        throw new Error('Invalid data format');
                    }

                    const currentBookmarks = this.getAll();
                    const mergedBookmarks = {...currentBookmarks, ...data};

                    this.saveAll(mergedBookmarks);

                    // Sync with server
                    for (const storyId in data) {
                        if (data.hasOwnProperty(storyId)) {
                            this.syncToServer(parseInt(storyId), data[storyId].chapter_id);
                        }
                    }

                    resolve({
                        success: true,
                        count: Object.keys(data).length
                    });
                } catch (error) {
                    reject({
                        success: false,
                        error: 'Lỗi khi nhập dữ liệu: ' + error.message
                    });
                }
            };

            reader.onerror = () => {
                reject({
                    success: false,
                    error: 'Không thể đọc tệp dữ liệu'
                });
            };

            reader.readAsText(file);
        });
    },

    /**
     * Cleanup old bookmarks to prevent localStorage from getting too full
     * Keeps only the 50 most recent bookmarks
     */
    cleanupOldBookmarks: function() {
        const bookmarks = this.getAll();
        const bookmarksArray = this.getAllAsArray();

        // If we have more than 50 bookmarks, keep only the 50 most recent
        if (bookmarksArray.length > 50) {
            const recentBookmarks = {};

            // Keep only the 50 most recent bookmarks
            bookmarksArray.slice(0, 50).forEach(bookmark => {
                recentBookmarks[bookmark.id] = bookmark;
            });

            this.saveAll(recentBookmarks);

            console.log(`Cleaned up old bookmarks. Kept ${Object.keys(recentBookmarks).length} of ${bookmarksArray.length}.`);
        }
    },

    /**
     * Sync a bookmark change to the server
     *
     * @param {number} storyId - The story ID
     * @param {number|null} chapterId - The chapter ID
     * @param {boolean} isUpdate - Whether this is an update (not a toggle)
     */
    syncToServer: function(storyId, chapterId = null, isUpdate = false) {
        if (!this.userId) return;

        const endpoint = isUpdate ? '/bookmarks/update-chapter' : '/bookmarks/toggle';

        fetch(endpoint, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: JSON.stringify({
                story_id: storyId,
                chapter_id: chapterId
            })
        }).catch(error => {
            console.error('Error syncing bookmark to server:', error);
        });
    },

    /**
     * Sync all bookmarks with the server
     * This reconciles local and server bookmarks
     */
    syncWithServer: function() {
        if (!this.userId) return;

        // Get server bookmarks first
        fetch('/bookmarks?format=json', {
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (!data.success) return;

            const serverBookmarks = data.data || [];
            const localBookmarks = this.getAll();
            const mergedBookmarks = {...localBookmarks};

            // Add server bookmarks to local storage
            serverBookmarks.forEach(bookmark => {
                // Only add/update if not exists or server is newer
                if (!localBookmarks[bookmark.story_id] ||
                    new Date(bookmark.updated_at) > new Date(localBookmarks[bookmark.story_id].time)) {
                    mergedBookmarks[bookmark.story_id] = {
                        id: parseInt(bookmark.story_id),
                        title: bookmark.title || '',
                        slug: bookmark.slug || '',
                        cover_image: bookmark.cover_image || '',
                        author_name: bookmark.author_name || '',
                        chapter_id: bookmark.chapter_id ? parseInt(bookmark.chapter_id) : null,
                        time: bookmark.updated_at
                    };
                }
            });

            // Save the merged bookmarks
            this.saveAll(mergedBookmarks);
        })
        .catch(error => {
            console.error('Error syncing bookmarks with server:', error);
        });
    },

    /**
     * Get or create a user ID for server-side storage
     *
     * @returns {string} User ID
     */
    getUserId: function() {
        // Check for existing user ID in cookie
        const cookies = document.cookie.split(';');
        let userId = null;

        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            if (cookie.startsWith('user_id=')) {
                userId = cookie.substring('user_id='.length, cookie.length);
                break;
            }
        }

        // If no user ID exists, we'll get one from the server on first bookmark action
        return userId;
    },

    /**
     * Check if localStorage is available
     *
     * @returns {boolean} True if localStorage is available
     */
    isLocalStorageAvailable: function() {
        try {
            const test = 'test';
            localStorage.setItem(test, test);
            localStorage.removeItem(test);
            return true;
        } catch (e) {
            return false;
        }
    }
};

// Initialize the bookmark system when the page loads
document.addEventListener('DOMContentLoaded', function() {
    ClientBookmark.init();

    // Add event listeners to bookmark buttons if they exist
    const bookmarkButtons = document.querySelectorAll('.bookmark-button, .js-bookmark-btn');

    bookmarkButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();

            const storyId = parseInt(this.dataset.storyId);
            const chapterId = this.dataset.chapterId ? parseInt(this.dataset.chapterId) : null;
            const storyTitle = this.dataset.storyTitle || '';
            const storySlug = this.dataset.storySlug || '';
            const coverImage = this.dataset.coverImage || '';
            const authorName = this.dataset.authorName || '';

            const result = ClientBookmark.toggle(storyId, {
                title: storyTitle,
                slug: storySlug,
                cover_image: coverImage,
                author_name: authorName
            }, chapterId);

            // Update UI based on result
            if (result.action === 'added') {
                this.classList.add('active');
                this.title = 'Đã lưu vào tủ truyện';
                if (this.querySelector('.bookmark-text')) {
                    this.querySelector('.bookmark-text').textContent = 'Đã lưu';
                }
            } else {
                this.classList.remove('active');
                this.title = 'Lưu vào tủ truyện';
                if (this.querySelector('.bookmark-text')) {
                    this.querySelector('.bookmark-text').textContent = 'Lưu truyện';
                }
            }

            // Show notification if available
            if (window.showNotification) {
                window.showNotification(result.message);
            }
        });
    });

    // Initialize bookmark button states
    bookmarkButtons.forEach(button => {
        const storyId = parseInt(button.dataset.storyId);
        if (ClientBookmark.isBookmarked(storyId)) {
            button.classList.add('active');
            button.title = 'Đã lưu vào tủ truyện';
            if (button.querySelector('.bookmark-text')) {
                button.querySelector('.bookmark-text').textContent = 'Đã lưu';
            }
        }
    });
});
