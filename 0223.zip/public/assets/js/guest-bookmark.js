/**
 * Guest Bookmark System
 *
 * This module handles bookmarks for users who are not logged in,
 * using localStorage for client-side storage and syncing with server when available.
 */
const GuestBookmark = {
    /**
     * Initialize the bookmark system
     */
    init: function() {
        // Check if localStorage is available
        if (!this.isLocalStorageAvailable()) {
            console.warn('localStorage is not available. Guest bookmarks will not be saved locally.');
            return;
        }

        // Initialize localStorage if needed
        if (!localStorage.getItem('guest_bookmarks')) {
            localStorage.setItem('guest_bookmarks', JSON.stringify({}));
        }

        // Get guest ID from cookie for server-side storage
        this.guestId = this.getGuestId();

        // Sync with server if we have a guest ID
        if (this.guestId) {
            this.syncWithServer();
        }
    },

    /**
     * Add or toggle a bookmark
     *
     * @param {number} storyId - The ID of the story to bookmark
     * @param {object} storyData - Additional story data (title, etc)
     * @param {number|null} chapterId - The chapter ID if applicable
     * @returns {object} Status of the operation
     */
    toggle: function(storyId, storyData, chapterId = null) {
        let bookmarks = this.getAll();
        let action = '';
        let message = '';

        if (bookmarks[storyId]) {
            // Remove bookmark if it exists
            delete bookmarks[storyId];
            action = 'removed';
            message = 'Đã xóa khỏi danh sách bookmark';
        } else {
            // Add new bookmark
            bookmarks[storyId] = {
                id: storyId,
                title: storyData.title || '',
                slug: storyData.slug || '',
                cover_image: storyData.cover_image || '',
                chapter_id: chapterId,
                time: new Date().toISOString()
            };
            action = 'added';
            message = 'Đã thêm vào danh sách bookmark';
        }

        // Save to localStorage
        this.saveAll(bookmarks);

        // Sync with server if possible
        this.syncToServer(storyId, chapterId);

        return {
            action: action,
            message: message
        };
    },

    /**
     * Update chapter information for a bookmarked story
     *
     * @param {number} storyId - The story ID
     * @param {number} chapterId - The chapter ID
     * @returns {boolean} Success status
     */
    updateChapter: function(storyId, chapterId) {
        let bookmarks = this.getAll();

        if (!bookmarks[storyId]) {
            // If story isn't bookmarked yet, add it
            return false;
        }

        // Update chapter ID and timestamp
        bookmarks[storyId].chapter_id = chapterId;
        bookmarks[storyId].time = new Date().toISOString();

        // Save to localStorage
        this.saveAll(bookmarks);

        // Sync with server
        this.syncToServer(storyId, chapterId, true);

        return true;
    },

    /**
     * Check if a story is bookmarked
     *
     * @param {number} storyId - The story ID to check
     * @returns {boolean} True if bookmarked
     */
    isBookmarked: function(storyId) {
        const bookmarks = this.getAll();
        return !!bookmarks[storyId];
    },

    /**
     * Get a specific bookmark
     *
     * @param {number} storyId - The story ID
     * @returns {object|null} The bookmark data or null
     */
    get: function(storyId) {
        const bookmarks = this.getAll();
        return bookmarks[storyId] || null;
    },

    /**
     * Get all bookmarks as an object
     *
     * @returns {object} All bookmarks
     */
    getAll: function() {
        const data = localStorage.getItem('guest_bookmarks');
        return data ? JSON.parse(data) : {};
    },

    /**
     * Get all bookmarks as an array (for display)
     *
     * @returns {array} Array of bookmark objects
     */
    getAllAsArray: function() {
        const bookmarks = this.getAll();
        return Object.values(bookmarks).sort((a, b) => {
            return new Date(b.time) - new Date(a.time);
        });
    },

    /**
     * Save all bookmarks to localStorage
     *
     * @param {object} bookmarks - The bookmarks object
     */
    saveAll: function(bookmarks) {
        localStorage.setItem('guest_bookmarks', JSON.stringify(bookmarks));
    },

    /**
     * Clear all bookmarks
     */
    clearAll: function() {
        localStorage.setItem('guest_bookmarks', JSON.stringify({}));
    },

    /**
     * Sync a bookmark change to the server
     *
     * @param {number} storyId - The story ID
     * @param {number|null} chapterId - The chapter ID
     * @param {boolean} isUpdate - Whether this is an update (not a toggle)
     */
    syncToServer: function(storyId, chapterId = null, isUpdate = false) {
        if (!this.guestId) return;

        const endpoint = isUpdate ? '/bookmarks/update-chapter' : '/bookmarks/toggle';

        fetch(endpoint, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: JSON.stringify({
                story_id: storyId,
                chapter_id: chapterId
            })
        }).catch(error => {
            console.error('Error syncing bookmark to server:', error);
        });
    },

    /**
     * Sync all bookmarks with the server
     * This reconciles local and server bookmarks
     */
    syncWithServer: function() {
        if (!this.guestId) return;

        // Get server bookmarks first
        fetch('/bookmarks?format=json', {
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (!data.success) return;

            const serverBookmarks = data.data || [];
            const localBookmarks = this.getAll();
            const mergedBookmarks = {...localBookmarks};

            // Add server bookmarks to local storage
            serverBookmarks.forEach(bookmark => {
                // Only add/update if not exists or server is newer
                if (!localBookmarks[bookmark.story_id] ||
                    new Date(bookmark.updated_at) > new Date(localBookmarks[bookmark.story_id].time)) {
                    mergedBookmarks[bookmark.story_id] = {
                        id: parseInt(bookmark.story_id),
                        title: bookmark.title || '',
                        slug: bookmark.slug || '',
                        cover_image: bookmark.cover_image || '',
                        chapter_id: bookmark.chapter_id ? parseInt(bookmark.chapter_id) : null,
                        time: bookmark.updated_at
                    };
                }
            });

            // Save the merged bookmarks
            this.saveAll(mergedBookmarks);
        })
        .catch(error => {
            console.error('Error syncing bookmarks with server:', error);
        });
    },

    /**
     * Get or create a guest ID for server-side storage
     *
     * @returns {string} Guest ID
     */
    getGuestId: function() {
        // Check for existing guest ID in cookie
        const cookies = document.cookie.split(';');
        let guestId = null;

        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            if (cookie.startsWith('guest_id=')) {
                guestId = cookie.substring('guest_id='.length, cookie.length);
                break;
            }
        }

        // If no guest ID exists, we'll get one from the server on first bookmark action
        return guestId;
    },

    /**
     * Check if localStorage is available
     *
     * @returns {boolean} True if localStorage is available
     */
    isLocalStorageAvailable: function() {
        try {
            const test = 'test';
            localStorage.setItem(test, test);
            localStorage.removeItem(test);
            return true;
        } catch (e) {
            return false;
        }
    }
};

// Initialize the guest bookmark system when the page loads
document.addEventListener('DOMContentLoaded', function() {
    GuestBookmark.init();

    // Add event listeners to bookmark buttons if they exist
    const bookmarkButtons = document.querySelectorAll('.bookmark-button, .js-bookmark-btn');

    bookmarkButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();

            const storyId = parseInt(this.dataset.storyId);
            const chapterId = this.dataset.chapterId ? parseInt(this.dataset.chapterId) : null;
            const storyTitle = this.dataset.storyTitle || '';
            const storySlug = this.dataset.storySlug || '';
            const coverImage = this.dataset.coverImage || '';

            const result = GuestBookmark.toggle(storyId, {
                title: storyTitle,
                slug: storySlug,
                cover_image: coverImage
            }, chapterId);

            // Update UI based on result
            if (result.action === 'added') {
                this.classList.add('active');
                this.title = 'Đã lưu vào tủ truyện';
                if (this.querySelector('.bookmark-text')) {
                    this.querySelector('.bookmark-text').textContent = 'Đã lưu';
                }
            } else {
                this.classList.remove('active');
                this.title = 'Lưu vào tủ truyện';
                if (this.querySelector('.bookmark-text')) {
                    this.querySelector('.bookmark-text').textContent = 'Lưu truyện';
                }
            }

            // Show notification if available
            if (window.showNotification) {
                window.showNotification(result.message);
            }
        });
    });

    // Initialize bookmark button states
    bookmarkButtons.forEach(button => {
        const storyId = parseInt(button.dataset.storyId);
        if (GuestBookmark.isBookmarked(storyId)) {
            button.classList.add('active');
            button.title = 'Đã lưu vào tủ truyện';
            if (button.querySelector('.bookmark-text')) {
                button.querySelector('.bookmark-text').textContent = 'Đã lưu';
            }
        }
    });
});
