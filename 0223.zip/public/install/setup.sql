1|-- UNIFIED DATABASE SETUP SCRIPT
2|-- Combines: unified_schema.sql, remove_unused_db_elements.sql, cleanup.sql
3|
4|-- =========================================
5|-- DATABASE SCHEMA (unified_schema.sql)
6|-- =========================================
7|
8|-- CORE TABLES
9|-- =========================================
10|
11|-- Users table
12|CREATE TABLE users (
13|    id SERIAL PRIMARY KEY,
14|    username VARCHAR(50) NOT NULL UNIQUE,
15|    email VARCHAR(100) NOT NULL UNIQUE,
16|    password VARCHAR(255) NOT NULL,
17|    role SMALLINT NOT NULL DEFAULT 1, -- 1: Cộng tác viên, 2: Admin, 3: Người sáng lập
18|    status VARCHAR(20) NOT NULL DEFAULT 'active',
19|    avatar VARCHAR(255),
20|    bio TEXT,
21|    last_login TIMESTAMP,
22|    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
23|    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
24|);
25|
26|-- Categories table
27|CREATE TABLE categories (
28|    id SERIAL PRIMARY KEY,
29|    name VARCHAR(50) NOT NULL,
30|    slug VARCHAR(50) NOT NULL UNIQUE,
31|    description TEXT,
32|    parent_id INTEGER REFERENCES categories(id) ON DELETE SET NULL,
33|    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
34|    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
35|);
36|
37|-- Stories table - Đổi tên từ novels để phù hợp với bối cảnh
38|CREATE TABLE stories (
39|    id SERIAL PRIMARY KEY,
40|    title VARCHAR(200) NOT NULL,
41|    slug VARCHAR(200) NOT NULL UNIQUE,
42|    description TEXT,
43|    cover_image VARCHAR(255),
44|    author_name VARCHAR(100), -- Tên tác giả thật của tác phẩm
45|    publisher_id INTEGER REFERENCES users(id) ON DELETE SET NULL, -- Người đăng/xuất bản truyện lên hệ thống
46|    status VARCHAR(20) NOT NULL DEFAULT 'draft',
47|    views INTEGER DEFAULT 0,
48|    views_day INTEGER DEFAULT 0, -- Lượt xem trong ngày
49|    views_week INTEGER DEFAULT 0, -- Lượt xem trong tuần
50|    views_month INTEGER DEFAULT 0, -- Lượt xem trong tháng
51|    rating DECIMAL(3,2) DEFAULT 0,
52|    total_ratings INTEGER DEFAULT 0, -- Tổng số đánh giá
53|    total_favorites INTEGER DEFAULT 0, -- Tổng số yêu thích
54|    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
55|    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
56|    type VARCHAR(50), -- Loại truyện (phim lẻ, phim bộ, review)
57|    country VARCHAR(100), -- Quốc gia (thay thế cho country_id)
58|    release_year INTEGER, -- Năm phát hành
59|    is_featured BOOLEAN DEFAULT FALSE, -- Nổi bật
60|    is_recommended BOOLEAN DEFAULT FALSE, -- Đề xuất (thay thế cho is_hot)
61|    is_completed BOOLEAN DEFAULT FALSE, -- Hoàn thành
62|    search_vector TSVECTOR -- Vector tìm kiếm full-text
63|);
64|
65|-- Story categories relationship
66|CREATE TABLE story_categories (
67|    story_id INTEGER REFERENCES stories(id) ON DELETE CASCADE,
68|    category_id INTEGER REFERENCES categories(id) ON DELETE CASCADE,
69|    PRIMARY KEY (story_id, category_id)
70|);
71|
72|-- Chapters table
73|CREATE TABLE chapters (
74|    id SERIAL PRIMARY KEY,
75|    story_id INTEGER REFERENCES stories(id) ON DELETE CASCADE,
76|    chapter_number INTEGER NOT NULL,
77|    title VARCHAR(200) NOT NULL,
78|    content TEXT NOT NULL,
79|    views INTEGER DEFAULT 0,
80|    status VARCHAR(20) NOT NULL DEFAULT 'draft',
81|    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
82|    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
83|    UNIQUE (story_id, chapter_number)
84|);
85|
86|-- =========================================
87|-- USER INTERACTION TABLES
88|-- =========================================
89|
90|-- Bookmarks table
91|CREATE TABLE bookmarks (
92|    id SERIAL PRIMARY KEY,
93|    user_id VARCHAR(100) NOT NULL,
94|    story_id INTEGER NOT NULL REFERENCES stories(id) ON DELETE CASCADE,
95|    chapter_id INTEGER REFERENCES chapters(id) ON DELETE SET NULL,
96|    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
97|    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
98|    CONSTRAINT bookmarks_user_story_unique UNIQUE (user_id, story_id)
99|);
100|
101|-- Reading progress table
102|CREATE TABLE reading_progress (
103|    id SERIAL PRIMARY KEY,
104|    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
105|    story_id INTEGER REFERENCES stories(id) ON DELETE CASCADE,
106|    chapter_id INTEGER REFERENCES chapters(id) ON DELETE CASCADE,
107|    last_read TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
108|    UNIQUE (user_id, story_id)
109|);
110|
111|-- Ratings table
112|CREATE TABLE ratings (
113|    id SERIAL PRIMARY KEY,
114|    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
115|    story_id INTEGER REFERENCES stories(id) ON DELETE CASCADE,
116|    rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
117|    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
118|    UNIQUE (user_id, story_id)
119|);
120|
121|-- Comments table
122|CREATE TABLE comments (
123|    id SERIAL PRIMARY KEY,
124|    user_id INTEGER REFERENCES users(id) ON DELETE SET NULL, -- Cho phép bình luận không cần đăng nhập (NULL)
125|    story_id INTEGER REFERENCES stories(id) ON DELETE CASCADE,
126|    chapter_id INTEGER REFERENCES chapters(id) ON DELETE CASCADE,
127|    content TEXT NOT NULL,
128|    guest_name VARCHAR(100), -- Tên người bình luận khách
129|    guest_email VARCHAR(100), -- Email người bình luận khách
130|    parent_id INTEGER REFERENCES comments(id) ON DELETE CASCADE, -- ID bình luận cha (nếu là reply)
131|    is_admin_reply BOOLEAN DEFAULT FALSE, -- Đánh dấu nếu là reply từ admin
132|    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
133|    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
134|);
135|
136|-- User activities table
137|CREATE TABLE activities (
138|    id SERIAL PRIMARY KEY,
139|    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
140|    action VARCHAR(100) NOT NULL,
141|    details JSONB,
142|    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
143|);
144|
145|-- =========================================
146|-- SYSTEM TABLES
147|-- =========================================
148|
149|-- Site settings table - Thêm bảng cài đặt cho trang web
150|CREATE TABLE settings (
151|    id VARCHAR(50) PRIMARY KEY,
152|    value TEXT NOT NULL,
153|    description TEXT,
154|    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
155|);
156|
157|-- Tokens table - Bảng lưu trữ tokens xác thực API
158|CREATE TABLE tokens (
159|    id SERIAL PRIMARY KEY,
160|    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
161|    token VARCHAR(255) NOT NULL UNIQUE,
162|    expires_at TIMESTAMP NOT NULL,
163|    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
164|);
165|
166|-- Media table - Quản lý tệp đa phương tiện
167|CREATE TABLE media (
168|    id SERIAL PRIMARY KEY,
169|    file_name VARCHAR(255) NOT NULL,
170|    file_path VARCHAR(255) NOT NULL,
171|    file_type VARCHAR(50) NOT NULL,
172|    file_size INTEGER NOT NULL,
173|    user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
174|    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
175|);
176|
177|-- Backups table - Quản lý các bản sao lưu
178|CREATE TABLE backups (
179|    id SERIAL PRIMARY KEY,
180|    file_name VARCHAR(255) NOT NULL,
181|    file_path VARCHAR(255) NOT NULL,
182|    file_size INTEGER NOT NULL,
183|    description TEXT,
184|    user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
185|    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
186|);
187|
188|-- System logs table - Nhật ký hệ thống
189|CREATE TABLE logs (
190|    id SERIAL PRIMARY KEY,
191|    level VARCHAR(20) NOT NULL,
192|    message TEXT NOT NULL,
193|    context JSONB,
194|    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
195|);
196|
197|-- System changes table - Theo dõi các thay đổi hệ thống
198|CREATE TABLE system_changes (
199|    id SERIAL PRIMARY KEY,
200|    change_type VARCHAR(50) NOT NULL,
201|    description TEXT NOT NULL,
202|    sql_query TEXT,
203|    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
204|);
205|
206|-- =========================================
207|-- INDEXES
208|-- =========================================
209|
210|-- Indexes for stories table
211|CREATE INDEX idx_stories_slug ON stories(slug);
212|CREATE INDEX idx_stories_publisher_id ON stories(publisher_id);
213|CREATE INDEX idx_stories_is_recommended ON stories(is_recommended);
214|CREATE INDEX idx_stories_country ON stories(country);
215|
216|-- Indexes for chapters table
217|CREATE INDEX idx_chapters_story ON chapters(story_id);
218|
219|-- Indexes for categories table
220|CREATE INDEX idx_categories_slug ON categories(slug);
221|
222|-- Indexes for bookmarks table
223|CREATE INDEX idx_bookmarks_user_id ON bookmarks(user_id);
224|CREATE INDEX idx_bookmarks_story_id ON bookmarks(story_id);
225|CREATE INDEX idx_bookmarks_chapter_id ON bookmarks(chapter_id);
226|
227|-- Indexes for guest_bookmarks table
228|CREATE INDEX idx_guest_bookmarks_guest_id ON guest_bookmarks(guest_id);
229|CREATE INDEX idx_guest_bookmarks_story_id ON guest_bookmarks(story_id);
230|CREATE INDEX idx_guest_bookmarks_chapter_id ON guest_bookmarks(chapter_id);
231|
232|-- Indexes for reading_progress table
233|CREATE INDEX idx_reading_progress_user ON reading_progress(user_id);
234|
235|-- Indexes for comments table
236|CREATE INDEX idx_comments_story ON comments(story_id);
237|CREATE INDEX idx_comments_chapter ON comments(chapter_id);
238|CREATE INDEX idx_comments_parent ON comments(parent_id);
239|
240|-- Indexes for activities table
241|CREATE INDEX idx_activities_user ON activities(user_id);
242|
243|-- Indexes for tokens table
244|CREATE INDEX idx_tokens_user_id ON tokens(user_id);
245|
246|-- =========================================
247|-- TRIGGERS
248|-- =========================================
249|
250|-- Trigger function to update updated_at timestamp
251|CREATE OR REPLACE FUNCTION update_updated_at_column()
252|RETURNS TRIGGER AS $$
253|BEGIN
254|    NEW.updated_at = CURRENT_TIMESTAMP;
255|    RETURN NEW;
256|END;
257|$$ LANGUAGE plpgsql;
258|
259|-- Trigger function for search vector
260|CREATE OR REPLACE FUNCTION stories_vector_update() RETURNS TRIGGER AS $$
261|BEGIN
262|    NEW.search_vector := to_tsvector('english',
263|        coalesce(NEW.title, '') || ' ' ||
264|        coalesce(NEW.description, '') || ' ' ||
265|        coalesce(NEW.author_name, '')
266|    );
267|    RETURN NEW;
268|END
269|$$ LANGUAGE plpgsql;
270|
271|-- Apply trigger to stories table for updated_at
272|CREATE TRIGGER update_stories_updated_at
273|    BEFORE UPDATE ON stories
274|    FOR EACH ROW
275|    EXECUTE FUNCTION update_updated_at_column();
276|
277|-- Apply trigger to stories table for search_vector
278|CREATE TRIGGER stories_vector_update
279|    BEFORE INSERT OR UPDATE ON stories
280|    FOR EACH ROW
281|    EXECUTE FUNCTION stories_vector_update();
282|
283|-- Apply triggers to other tables for updated_at
284|CREATE TRIGGER update_chapters_updated_at
285|    BEFORE UPDATE ON chapters
286|    FOR EACH ROW
287|    EXECUTE FUNCTION update_updated_at_column();
288|
289|CREATE TRIGGER update_users_updated_at
290|    BEFORE UPDATE ON users
291|    FOR EACH ROW
292|    EXECUTE FUNCTION update_updated_at_column();
293|
294|CREATE TRIGGER update_bookmarks_updated_at
295|    BEFORE UPDATE ON bookmarks
296|    FOR EACH ROW
297|    EXECUTE FUNCTION update_updated_at_column();
298|
299|CREATE TRIGGER update_guest_bookmarks_updated_at
300|    BEFORE UPDATE ON guest_bookmarks
301|    FOR EACH ROW
302|    EXECUTE FUNCTION update_updated_at_column();
303|
304|CREATE TRIGGER update_comments_updated_at
305|    BEFORE UPDATE ON comments
306|    FOR EACH ROW
307|    EXECUTE FUNCTION update_updated_at_column();
308|
309|-- =========================================
310|-- DEFAULT DATA
311|-- =========================================
312|
313|-- Insert default admin user (password: admin123) with role=3 (Founder)
314|INSERT INTO users (username, email, password, role, status)
315|VALUES ('admin', 'admin@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 3, 'active');
316|
317|-- Insert some default categories
318|INSERT INTO categories (name, slug, description)
319|VALUES
320|    ('Hành Động', 'hanh-dong', 'Truyện hành động'),
321|    ('Võ Thuật', 'vo-thuat', 'Truyện võ thuật'),
322|    ('Tình Cảm', 'tinh-cam', 'Truyện tình cảm'),
323|    ('Hoạt Hình', 'hoat-hinh', 'Truyện hoạt hình'),
324|    ('Viễn Tưởng', 'vien-tuong', 'Truyện viễn tưởng'),
325|    ('Khoa Học', 'khoa-hoc', 'Truyện khoa học'),
326|    ('Phiêu Lưu', 'phieu-luu', 'Truyện phiêu lưu'),
327|    ('Hài Hước', 'hai-huoc', 'Truyện hài hước'),
328|    ('Kinh Dị', 'kinh-di', 'Truyện kinh dị'),
329|    ('Tâm Lý', 'tam-ly', 'Truyện tâm lý'),
330|    ('Chiến Tranh', 'chien-tranh', 'Truyện chiến tranh'),
331|    ('Cổ Trang', 'co-trang', 'Truyện cổ trang'),
332|    ('Hình Sự', 'hinh-su', 'Truyện hình sự');
333|
334|-- Insert default settings
335|INSERT INTO settings (id, value, description)
336|VALUES
337|    ('site_name', 'Web Truyện', 'Tên trang web'),
338|    ('site_description', 'Trang web truyện hay, cập nhật thông tin truyện mới nhất', 'Mô tả trang web'),
339|    ('site_keywords', 'truyện, truyện hay, truyện mới', 'Từ khóa trang web'),
340|    ('site_logo', '/assets/images/logo.png', 'Logo trang web'),
341|    ('site_favicon', '/assets/images/favicon.ico', 'Favicon trang web'),
342|    ('site_header', '<h1>Web Truyện</h1>', 'Tiêu đề header mặc định'),
343|    ('site_footer', '© 2025 Web Truyện - Tất cả quyền được bảo lưu', 'Nội dung footer mặc định'),
344|    ('story_title_template', '[title] - [year] | [country]', 'Mẫu tiêu đề mặc định cho truyện'),
345|    ('story_description_template', 'Truyện [title] [year] - [country] thuộc thể loại [categories]. Truyện do [author] đánh giá.', 'Mẫu mô tả mặc định cho truyện'),
346|    ('chapter_title_template', 'Chương [number]: [title] - [story_title]', 'Mẫu tiêu đề mặc định cho chương'),
347|    ('chapter_description_template', 'Đọc chương [number]: [title] của truyện [story_title]', 'Mẫu mô tả mặc định cho chương'),
348|    ('max_featured_stories', '6', 'Số lượng truyện nổi bật hiển thị trên trang chủ'),
349|    ('max_latest_stories', '12', 'Số lượng truyện mới nhất hiển thị trên trang chủ'),
350|    ('max_popular_stories', '5', 'Số lượng truyện phổ biến hiển thị trên trang chủ'),
351|    ('max_completed_stories', '6', 'Số lượng truyện đã hoàn thành hiển thị trên trang chủ'),
352|    ('max_guest_bookmarks', '50', 'Số lượng bookmark tối đa cho khách'),
353|    ('smtp_host', '', 'SMTP host'),
354|    ('smtp_port', '587', 'SMTP port'),
355|    ('smtp_user', '', 'SMTP username'),
356|    ('smtp_pass', '', 'SMTP password'),
357|    ('smtp_from', '', 'SMTP from email'),
358|    ('maintenance_mode', 'off', 'Chế độ bảo trì'),
359|    ('register_enabled', 'off', 'Cho phép đăng ký tài khoản mới'),
360|    ('comments_enabled', 'on', 'Cho phép bình luận'),
361|    ('guest_comments_enabled', 'on', 'Cho phép bình luận không cần đăng nhập'),
362|    ('analytics_code', '', 'Mã Google Analytics'),
363|    ('recaptcha_site_key', '', 'Google reCAPTCHA site key'),
364|    ('recaptcha_secret_key', '', 'Google reCAPTCHA secret key'),
365|    ('social_facebook', '', 'Đường dẫn Facebook'),
366|    ('social_twitter', '', 'Đường dẫn Twitter'),
367|    ('social_youtube', '', 'Đường dẫn YouTube'),
368|    ('social_instagram', '', 'Đường dẫn Instagram'),
369|    ('imgur_client_id', '', 'Imgur Client ID');
370|
371|-- Ghi nhận việc tạo schema thống nhất
372|INSERT INTO system_changes (change_type, description, sql_query, created_at)
373|VALUES ('structure', 'Unified database schema created', 'Created unified schema with install script', CURRENT_TIMESTAMP);
374|
375|-- =========================================
376|-- CLEANUP PROCEDURES (From cleanup.sql)
377|-- =========================================
378|
379|-- Create a procedure for database cleanup to be used with cron jobs
380|CREATE OR REPLACE PROCEDURE cleanup_database()
381|LANGUAGE plpgsql
382|AS $$
383|BEGIN
384|    -- 1. Remove bookmarks older than 3 months (90 days)
385|    DELETE FROM bookmarks
386|    WHERE updated_at < CURRENT_TIMESTAMP - INTERVAL '90 days';
387|
388|    -- 2. Remove expired tokens
389|    DELETE FROM tokens
390|    WHERE expires_at < CURRENT_TIMESTAMP;
391|
392|    -- 3. Remove old system logs (older than 30 days, except 'error' level logs which we keep for 90 days)
393|    DELETE FROM logs
394|    WHERE (level != 'error' AND created_at < CURRENT_TIMESTAMP - INTERVAL '30 days')
395|       OR (level = 'error' AND created_at < CURRENT_TIMESTAMP - INTERVAL '90 days');
396|
397|    -- 4. Remove old system changes records (older than 1 year)
398|    DELETE FROM system_changes
399|    WHERE created_at < CURRENT_TIMESTAMP - INTERVAL '1 year';
400|
401|    -- 5. Remove old backups (keep only the 10 most recent ones)
402|    DELETE FROM backups
403|    WHERE id NOT IN (
404|        SELECT id FROM backups
405|        ORDER BY created_at DESC
406|        LIMIT 10
407|    );
408|
409|    -- 6. Remove old user activities (older than 60 days)
410|    DELETE FROM activities
411|    WHERE created_at < CURRENT_TIMESTAMP - INTERVAL '60 days';
412|
413|    -- 7. Clean up orphaned comments (comments on deleted stories/chapters)
414|    DELETE FROM comments
415|    WHERE (story_id IS NOT NULL AND story_id NOT IN (SELECT id FROM stories))
416|       OR (chapter_id IS NOT NULL AND chapter_id NOT IN (SELECT id FROM chapters));
417|
418|    -- 8. Remove unused/orphaned media files
419|    DELETE FROM media
420|    WHERE (user_id IS NULL OR user_id NOT IN (SELECT id FROM users))
421|      AND created_at < CURRENT_TIMESTAMP - INTERVAL '30 days';
422|
423|    -- 9. Limit bookmarks per user_id to respect max_guest_bookmarks setting
424|    DECLARE
425|        max_bookmarks INTEGER;
426|    BEGIN
427|        SELECT CAST(value AS INTEGER) INTO max_bookmarks FROM settings WHERE id = 'max_guest_bookmarks';
428|        IF max_bookmarks IS NULL THEN
429|            max_bookmarks := 50; -- Default if setting not found
430|        END IF;
431|
432|        -- For each user with more than max_bookmarks bookmarks, delete the oldest ones
433|        FOR user_record IN SELECT DISTINCT user_id FROM bookmarks LOOP
434|            DELETE FROM bookmarks
435|            WHERE id IN (
436|                SELECT id FROM bookmarks
437|                WHERE user_id = user_record.user_id
438|                ORDER BY updated_at ASC
439|                OFFSET max_bookmarks
440|            );
441|        END LOOP;
442|    END;
443|
444|    -- 10. Remove stories that are in draft status for more than 6 months and have no chapters
445|    DELETE FROM stories
446|    WHERE status = 'draft'
447|      AND created_at < CURRENT_TIMESTAMP - INTERVAL '180 days'
448|      AND NOT EXISTS (SELECT 1 FROM chapters WHERE chapters.story_id = stories.id);
449|
450|    -- Log the cleanup action
451|    INSERT INTO logs (level, message, context, created_at)
452|    VALUES ('info', 'Database cleanup procedure executed', '{\"automatic\": true}', CURRENT_TIMESTAMP);
453|
454|END;
455|$$;
