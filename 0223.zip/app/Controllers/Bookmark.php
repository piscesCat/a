<?php

namespace App\Controllers;

use App\Models\BookmarkModel;
use App\Models\StoryModel;
use App\Models\ChapterModel;

class Bookmark extends BaseController
{
    protected $bookmarkModel;
    protected $storyModel;
    protected $chapterModel;

    public function __construct()
    {
        $this->bookmarkModel = new BookmarkModel();
        $this->storyModel = new StoryModel();
        $this->chapterModel = new ChapterModel();
    }

    /**
     * Hiển thị trang danh sách bookmark
     * Lưu ý: Bookmark giờ đây được hoàn toàn xử lý ở client-side,
     * không có tương tác với database.
     */
    public function index()
    {
        return view('bookmark/index.html');
    }

    /**
     * Endpoint API để thêm/xóa bookmark cho truyện
     */
    public function toggle()
    {
        $storyId = $this->request->getPost('story_id');
        $chapterId = $this->request->getPost('chapter_id');

        if (!$storyId) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Thiếu thông tin truyện'
            ]);
        }

        // Kiểm tra truyện tồn tại
        $story = $this->storyModel->find($storyId);
        if (!$story) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Không tìm thấy truyện'
            ]);
        }

        // Xử lý bookmark cho người dùng
        $userId = $this->getUserId();
        $result = $this->bookmarkModel->toggleBookmark($userId, $storyId, $chapterId);

        return $this->response->setJSON([
            'success' => true,
            'data' => $result
        ]);
    }

    /**
     * Endpoint API để thêm/xóa bookmark cho chương cụ thể
     */
    public function toggleChapterBookmark()
    {
        $storyId = $this->request->getPost('story_id');
        $chapterId = $this->request->getPost('chapter_id');

        if (!$storyId || !$chapterId) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Thiếu thông tin truyện hoặc chương'
            ]);
        }

        // Kiểm tra chương tồn tại
        $chapter = $this->chapterModel->find($chapterId);
        if (!$chapter) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Không tìm thấy chương'
            ]);
        }

        // Xử lý bookmark cho người dùng
        $userId = $this->getUserId();

        // Kiểm tra nếu đã bookmark rồi thì cập nhật chương, nếu chưa thì thêm mới
        if ($this->bookmarkModel->isBookmarked($userId, $storyId)) {
            $updated = $this->bookmarkModel->updateChapter($userId, $storyId, $chapterId);
            $result = [
                'action' => 'updated',
                'message' => 'Đã cập nhật chương đánh dấu'
            ];
        } else {
            $result = $this->bookmarkModel->toggleBookmark($userId, $storyId, $chapterId);
        }

        return $this->response->setJSON([
            'success' => true,
            'data' => $result
        ]);
    }

    /**
     * Kiểm tra trạng thái bookmark của truyện
     */
    public function checkStatus()
    {
        $storyId = $this->request->getGet('story_id');

        if (!$storyId) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Thiếu thông tin truyện'
            ]);
        }

        $userId = $this->getUserId();
        $isBookmarked = false;
        $currentChapter = null;

        $isBookmarked = $this->bookmarkModel->isBookmarked($userId, $storyId);
        if ($isBookmarked) {
            $bookmark = $this->bookmarkModel->where('user_id', $userId)
                                            ->where('story_id', $storyId)
                                            ->first();
            $currentChapter = $bookmark['chapter_id'] ?? null;
        }

        return $this->response->setJSON([
            'success' => true,
            'data' => [
                'is_bookmarked' => $isBookmarked,
                'chapter_id' => $currentChapter
            ]
        ]);
    }

    /**
     * Kiểm tra trạng thái bookmark của chương cụ thể
     */
    public function checkChapterBookmarkStatus()
    {
        $storyId = $this->request->getGet('story_id');
        $chapterId = $this->request->getGet('chapter_id');

        if (!$storyId || !$chapterId) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Thiếu thông tin truyện hoặc chương'
            ]);
        }

        $userId = $this->getUserId();
        $isBookmarked = false;
        $isCurrentChapter = false;

        $bookmark = $this->bookmarkModel->where('user_id', $userId)
                                        ->where('story_id', $storyId)
                                        ->first();
        if ($bookmark) {
            $isBookmarked = true;
            $isCurrentChapter = ($bookmark['chapter_id'] == $chapterId);
        }

        return $this->response->setJSON([
            'success' => true,
            'data' => [
                'is_bookmarked' => $isBookmarked,
                'is_current_chapter' => $isCurrentChapter
            ]
        ]);
    }

    /**
     * Cập nhật thông tin chương đang đọc
     */
    public function updateChapter()
    {
        $storyId = $this->request->getPost('story_id');
        $chapterId = $this->request->getPost('chapter_id');

        if (!$storyId || !$chapterId) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Thiếu thông tin truyện hoặc chương'
            ]);
        }

        $userId = $this->getUserId();
        $updated = false;

        // Kiểm tra nếu đã bookmark rồi thì cập nhật, không thì tạo mới
        if ($this->bookmarkModel->isBookmarked($userId, $storyId)) {
            $updated = $this->bookmarkModel->updateChapter($userId, $storyId, $chapterId);
        } else {
            $result = $this->bookmarkModel->toggleBookmark($userId, $storyId, $chapterId);
            $updated = ($result['action'] === 'added');
        }

        return $this->response->setJSON([
            'success' => $updated,
            'message' => $updated ? 'Đã cập nhật tiến trình đọc' : 'Không thể cập nhật tiến trình đọc'
        ]);
    }

    /**
     * Xóa tất cả bookmark của người dùng
     */
    public function clearAll()
    {
        $userId = $this->getUserId();
        $this->bookmarkModel->where('user_id', $userId)->delete();

        return $this->response->setJSON([
            'success' => true,
            'message' => 'Đã xóa tất cả bookmark'
        ]);
    }

    /**
     * Tạo hoặc lấy ID người dùng từ cookie
     */
    protected function getUserId()
    {
        $userId = $this->request->getCookie('user_id');

        if (!$userId) {
            $userId = md5(uniqid() . $_SERVER['REMOTE_ADDR'] . time());
            $cookieOptions = [
                'expires' => time() + (86400 * 365), // 1 năm
                'path' => '/',
                'secure' => false,
                'httponly' => true
            ];

            setCookie('user_id', $userId, $cookieOptions);

            // Lưu vào session hiện tại để dùng ngay lập tức
            $_COOKIE['user_id'] = $userId;
        }

        return $userId;
    }
}
