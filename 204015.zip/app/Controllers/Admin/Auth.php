<?php
namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\UserModel;
use App\Models\GuestBookmarkModel;

class Auth extends BaseController
{
    protected $userModel;
    protected $guestBookmarkModel;

    public function __construct()
    {
        $this->userModel = new UserModel();
        $this->guestBookmarkModel = new GuestBookmarkModel();
    }

    /**
     * Hiển thị trang đăng nhập
     */
    public function login()
    {
        if (session()->get('isLoggedIn')) {
            return redirect()->to('/admin');
        }
        return view('admin/auth/login.html');
    }

    /**
     * Xử lý đăng nhập
     */
    public function attemptLogin()
    {
        $email = $this->request->getPost('email');
        $password = $this->request->getPost('password');

        $user = $this->userModel->attemptLogin($email, $password);

        if (!$user) {
            return redirect()->back()
                ->with('error', 'Email hoặc mật khẩu không chính xác');
        }

        // Kiểm tra xem người dùng có quyền truy cập admin không (role >= 1)
        if ($user['role'] < 1) {
            return redirect()->back()
                ->with('error', 'Bạn không có quyền truy cập khu vực quản trị');
        }

        session()->set([
            'isLoggedIn' => true,
            'user' => $user
        ]);

        // Xử lý chuyển bookmark từ guest sang user (nếu có)
        $guestId = $this->request->getCookie('guest_id');
        if ($guestId) {
            $bookmarksMigrated = $this->guestBookmarkModel->migrateToUser($guestId, $user['id']);
            if ($bookmarksMigrated > 0) {
                session()->setFlashdata('bookmark_message', 'Đã chuyển ' . $bookmarksMigrated . ' bookmark từ phiên khách vào tài khoản của bạn.');
            }
        }

        // Chuyển hướng dựa trên tham số redirect trong URL (nếu có)
        $redirectURL = $this->request->getGet('redirect');
        if ($redirectURL) {
            return redirect()->to($redirectURL)->with('success', 'Đăng nhập thành công');
        }

        // Chuyển hướng đến trang quản trị
        return redirect()->to('/admin')->with('success', 'Đăng nhập thành công');
    }

    /**
     * Xử lý đăng xuất
     */
    public function logout()
    {
        session()->destroy();
        return redirect()->to('/admin/auth/login')->with('success', 'Đã đăng xuất thành công');
    }

    /**
     * Hiển thị form quên mật khẩu
     */
    public function forgotPassword()
    {
        return view('admin/auth/forgot_password.html');
    }

    /**
     * Xử lý yêu cầu quên mật khẩu
     */
    public function processForgotPassword()
    {
        $email = $this->request->getPost('email');

        if (!$email) {
            return redirect()->back()
                ->with('error', 'Vui lòng nhập địa chỉ email');
        }

        // Kiểm tra email tồn tại
        $user = $this->userModel->where('email', $email)->first();

        if (!$user) {
            // Không thông báo email không tồn tại để tránh lộ thông tin
            return redirect()->back()
                ->with('success', 'Nếu email tồn tại trong hệ thống, bạn sẽ nhận được email hướng dẫn đặt lại mật khẩu.');
        }

        // Tạo token đặt lại mật khẩu (có hiệu lực 1 giờ)
        $token = bin2hex(random_bytes(32));
        $expiry = date('Y-m-d H:i:s', time() + 3600); // 1 giờ từ hiện tại

        // Lưu token vào database
        $this->userModel->updateResetToken($user['id'], $token, $expiry);

        // Tạo URL đặt lại mật khẩu
        $resetUrl = site_url("admin/auth/reset-password?token={$token}");

        // Lấy cài đặt email từ database
        $settings = model('SettingsModel')->getSettingsByGroup('email');
        $siteSettings = model('SettingsModel')->getSettingsByGroup('site');
        $siteName = $siteSettings['site_name'] ?? 'Web Truyện';

        // Nội dung email
        $subject = "Đặt lại mật khẩu - {$siteName}";
        $message = "
            <html>
            <head>
                <title>Đặt lại mật khẩu</title>
            </head>
            <body>
                <h2>Yêu cầu đặt lại mật khẩu</h2>
                <p>Chúng tôi nhận được yêu cầu đặt lại mật khẩu cho tài khoản của bạn tại {$siteName}.</p>
                <p>Vui lòng nhấp vào liên kết dưới đây để đặt lại mật khẩu:</p>
                <p><a href='{$resetUrl}'>{$resetUrl}</a></p>
                <p>Liên kết này sẽ hết hạn sau 1 giờ.</p>
                <p>Nếu bạn không thực hiện yêu cầu này, vui lòng bỏ qua email này và mật khẩu của bạn sẽ không thay đổi.</p>
                <p>Trân trọng,<br>{$siteName}</p>
            </body>
            </html>
        ";

        // Gửi email (sử dụng dịch vụ email của CI4)
        $email = \Config\Services::email();

        $config = [
            'protocol' => $settings['mail_protocol'] ?? 'smtp',
            'SMTPHost' => $settings['smtp_host'] ?? '',
            'SMTPUser' => $settings['smtp_user'] ?? '',
            'SMTPPass' => $settings['smtp_pass'] ?? '',
            'SMTPPort' => $settings['smtp_port'] ?? 25,
            'SMTPCrypto' => $settings['smtp_crypto'] ?? 'tls',
            'mailType' => 'html',
            'charset' => 'utf-8',
            'newline' => "\r\n"
        ];

        $email->initialize($config);
        $email->setFrom($settings['mail_from'] ?? 'noreply@example.com', $settings['mail_from_name'] ?? $siteName);
        $email->setTo($user['email']);
        $email->setSubject($subject);
        $email->setMessage($message);

        // Thử gửi email
        $emailSent = false;
        try {
            $emailSent = $email->send();
        } catch (\Exception $e) {
            log_message('error', 'Email sending failed: ' . $e->getMessage());
        }

        // Ghi log
        $this->logModel->info('Password reset requested', [
            'user_id' => $user['id'],
            'email' => $user['email'],
            'ip_address' => $this->request->getIPAddress(),
            'success' => $emailSent
        ]);

        if (!$emailSent) {
            // Bắt đầu giả lập email nếu không thể gửi email thật
            // Lưu email vào session để hiển thị trên trang web (chỉ dùng cho môi trường dev)
            session()->setFlashdata('reset_link', $resetUrl);
        }

        // Luôn trả về thông báo thành công bất kể có gửi được email hay không
        // để tránh tiết lộ thông tin về email tồn tại
        return redirect()->back()
            ->with('success', 'Nếu email tồn tại trong hệ thống, bạn sẽ nhận được email hướng dẫn đặt lại mật khẩu.');
    }

    /**
     * Hiển thị form đặt lại mật khẩu
     */
    public function resetPassword()
    {
        $token = $this->request->getGet('token');

        if (!$token) {
            return redirect()->to('/admin/auth/forgot-password')
                ->with('error', 'Token đặt lại mật khẩu không hợp lệ');
        }

        // Kiểm tra token hợp lệ
        $user = $this->userModel->getUserByResetToken($token);

        if (!$user) {
            return redirect()->to('/admin/auth/forgot-password')
                ->with('error', 'Token đặt lại mật khẩu không hợp lệ hoặc đã hết hạn');
        }

        return view('admin/auth/reset_password.html', [
            'token' => $token
        ]);
    }

    /**
     * Xử lý đặt lại mật khẩu
     */
    public function processResetPassword()
    {
        $token = $this->request->getPost('token');
        $password = $this->request->getPost('password');
        $confirmPassword = $this->request->getPost('confirm_password');

        // Validate input
        if (!$token || !$password || !$confirmPassword) {
            return redirect()->back()
                ->with('error', 'Vui lòng nhập đầy đủ thông tin');
        }

        if ($password !== $confirmPassword) {
            return redirect()->back()
                ->with('error', 'Mật khẩu xác nhận không khớp');
        }

        if (strlen($password) < 6) {
            return redirect()->back()
                ->with('error', 'Mật khẩu phải có ít nhất 6 ký tự');
        }

        // Kiểm tra token hợp lệ
        $user = $this->userModel->getUserByResetToken($token);

        if (!$user) {
            return redirect()->to('/admin/auth/forgot-password')
                ->with('error', 'Token đặt lại mật khẩu không hợp lệ hoặc đã hết hạn');
        }

        // Cập nhật mật khẩu và xóa token
        $this->userModel->resetPassword($user['id'], $password);

        // Ghi log
        $this->logModel->info('Password reset successful', [
            'user_id' => $user['id'],
            'email' => $user['email'],
            'ip_address' => $this->request->getIPAddress()
        ]);

        return redirect()->to('/admin/auth/login')
            ->with('success', 'Mật khẩu đã được đặt lại thành công. Vui lòng đăng nhập bằng mật khẩu mới.');
    }

    /**
     * Xử lý đặt lại mật khẩu (chỉ dùng cho admin)
     */
    public function adminResetPassword()
    {
        // Kiểm tra người dùng đã đăng nhập và có quyền admin
        if (!session()->get('isLoggedIn') || session()->get('user')['role'] < 2) {
            return redirect()->to('/admin')
                ->with('error', 'Bạn không có quyền thực hiện chức năng này');
        }

        $userId = $this->request->getPost('user_id');
        $newPassword = $this->request->getPost('new_password');
        $confirmPassword = $this->request->getPost('confirm_password');

        // Validate
        if (!$userId || !$newPassword || !$confirmPassword) {
            return redirect()->back()
                ->with('error', 'Vui lòng nhập đầy đủ thông tin');
        }

        if ($newPassword !== $confirmPassword) {
            return redirect()->back()
                ->with('error', 'Mật khẩu xác nhận không khớp');
        }

        if (strlen($newPassword) < 6) {
            return redirect()->back()
                ->with('error', 'Mật khẩu phải có ít nhất 6 ký tự');
        }

        // Cập nhật mật khẩu
        $result = $this->userModel->updateUserPassword($userId, $newPassword);

        if (!$result) {
            return redirect()->back()
                ->with('error', 'Không thể cập nhật mật khẩu');
        }

        // Ghi log
        $this->logModel->info('Admin reset password', [
            'admin_id' => session()->get('user')['id'],
            'target_user_id' => $userId,
            'ip_address' => $this->request->getIPAddress()
        ]);

        return redirect()->to('/admin/users')
            ->with('success', 'Đã đặt lại mật khẩu thành công');
    }
}
