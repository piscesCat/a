<?php
namespace App\Models;

use CodeIgniter\Model;

class ChapterModel extends Model
{
    protected $table = 'chapters';
    protected $primaryKey = 'id';
    protected $returnType = 'array';
    protected $allowedFields = [
        'story_id', 'chapter_number', 'title', 'content',
        'views', 'status', 'created_at', 'updated_at'
    ];

    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    /**
     * Get chapters by story
     */
    public function getChaptersByStory($storyId, $limit = 50, $offset = 0)
    {
        return $this->where('story_id', $storyId)
                    ->where('status', 'active')
                    ->orderBy('chapter_number', 'DESC')
                    ->findAll($limit, $offset);
    }

    /**
     * Count chapters by story
     */
    public function getChaptersCountByStory($storyId)
    {
        return $this->where('story_id', $storyId)
                    ->where('status', 'active')
                    ->countAllResults();
    }

    /**
     * Get a specific chapter
     */
    public function getChapter($storyId, $chapterNumber)
    {
        return $this->where('story_id', $storyId)
                    ->where('chapter_number', $chapterNumber)
                    ->where('status', 'active')
                    ->first();
    }

    /**
     * Get next chapter
     */
    public function getNextChapter($storyId, $currentChapter)
    {
        return $this->where('story_id', $storyId)
                    ->where('chapter_number >', $currentChapter)
                    ->where('status', 'active')
                    ->orderBy('chapter_number', 'ASC')
                    ->first();
    }

    /**
     * Get previous chapter
     */
    public function getPreviousChapter($storyId, $currentChapter)
    {
        return $this->where('story_id', $storyId)
                    ->where('chapter_number <', $currentChapter)
                    ->where('status', 'active')
                    ->orderBy('chapter_number', 'DESC')
                    ->first();
    }

    /**
     * Get latest chapter for a story
     */
    public function getLatestChapterByStory($storyId)
    {
        return $this->where('story_id', $storyId)
                    ->where('status', 'active')
                    ->orderBy('chapter_number', 'DESC')
                    ->first();
    }

    /**
     * Get latest chapters across all stories
     */
    public function getLatestChapters($limit = 20)
    {
        return $this->select('chapters.*, stories.title as story_title, stories.slug as story_slug')
                    ->join('stories', 'stories.id = chapters.story_id')
                    ->where('chapters.status', 'active')
                    ->where('stories.status', 'active')
                    ->orderBy('chapters.created_at', 'DESC')
                    ->findAll($limit);
    }

    /**
     * Increment chapter views
     */
    public function incrementViews($chapterId)
    {
        return $this->set('views', 'views + 1', false)
                    ->where('id', $chapterId)
                    ->update();
    }

    /**
     * Get chapter navigational data for lists
     */
    public function getChapterNavigationData($storyId)
    {
        return $this->select('id, chapter_number, title')
                    ->where('story_id', $storyId)
                    ->where('status', 'active')
                    ->orderBy('chapter_number', 'ASC')
                    ->findAll();
    }

    /**
     * Get first chapter of a story
     */
    public function getFirstChapter($storyId)
    {
        return $this->where('story_id', $storyId)
                    ->where('status', 'active')
                    ->orderBy('chapter_number', 'ASC')
                    ->first();
    }

    /**
     * Get latest updated stories with their latest chapter
     */
    public function getLatestUpdatedStories($limit = 12)
    {
        $db = \Config\Database::connect();

        $subquery = $db->table('chapters')
                     ->select('story_id, MAX(created_at) as latest_update')
                     ->where('status', 'active')
                     ->groupBy('story_id');

        $query = $db->table('stories as s')
                    ->select('s.*, u.username as author_name, c.chapter_number as latest_chapter')
                    ->join('(' . $subquery->getCompiledSelect() . ') as lc', 'lc.story_id = s.id')
                    ->join('chapters as c', 'c.story_id = s.id AND c.created_at = lc.latest_update', 'left')
                    ->join('users as u', 'u.id = s.user_id', 'left')
                    ->where('s.status', 'active')
                    ->orderBy('lc.latest_update', 'DESC')
                    ->limit($limit);

        return $query->get()->getResultArray();
    }

    /**
     * Get chapters for admin panel with pagination and filters
     */
    public function getAdminChaptersList($limit = 20, $offset = 0, $filters = [])
    {
        $db = \Config\Database::connect();

        $builder = $db->table('chapters as c')
                     ->select('c.*, s.title as story_title, s.slug as story_slug')
                     ->join('stories as s', 's.id = c.story_id')
                     ->orderBy('c.id', 'DESC');

        // Apply filters
        if (!empty($filters['story_id'])) {
            $builder->where('c.story_id', $filters['story_id']);
        }

        if (!empty($filters['search'])) {
            $builder->groupStart()
                    ->like('c.title', $filters['search'])
                    ->orLike('c.content', $filters['search'])
                    ->orLike('s.title', $filters['search'])
                    ->groupEnd();
        }

        return $builder->limit($limit, $offset)
                      ->get()
                      ->getResultArray();
    }

    /**
     * Get total count of chapters for admin panel
     */
    public function getAdminChaptersCount($filters = [])
    {
        $db = \Config\Database::connect();

        $builder = $db->table('chapters as c')
                     ->join('stories as s', 's.id = c.story_id');

        // Apply filters
        if (!empty($filters['story_id'])) {
            $builder->where('c.story_id', $filters['story_id']);
        }

        if (!empty($filters['search'])) {
            $builder->groupStart()
                    ->like('c.title', $filters['search'])
                    ->orLike('c.content', $filters['search'])
                    ->orLike('s.title', $filters['search'])
                    ->groupEnd();
        }

        return $builder->countAllResults();
    }

    /**
     * Update chapter count for a story
     */
    public function updateChapterCount($storyId)
    {
        $db = \Config\Database::connect();

        // Count active chapters for this story
        $chapterCount = $this->where('story_id', $storyId)
                            ->where('status', 'active')
                            ->countAllResults();

        // Update the story record
        $db->table('stories')
           ->set('chapter_count', $chapterCount)
           ->set('updated_at', date('Y-m-d H:i:s'))
           ->where('id', $storyId)
           ->update();

        return $chapterCount;
    }
}
