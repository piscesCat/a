<?php
namespace App\Controllers;

use App\Models\StoryModel;
use App\Models\CategoryModel;
use App\Models\ChapterModel;
use App\Models\CommentModel;
use App\Models\SettingsModel;

class Story extends BaseController
{
    protected $storyModel;
    protected $categoryModel;
    protected $chapterModel;
    protected $commentModel;
    protected $settingsModel;

    public function __construct()
    {
        $this->storyModel = new StoryModel();
        $this->categoryModel = new CategoryModel();
        $this->chapterModel = new ChapterModel();
        $this->commentModel = new CommentModel();
        $this->settingsModel = new SettingsModel();
    }

    /**
     * Hiển thị danh sách truyện
     */
    public function index()
    {
        $page = $this->request->getGet('page') ?? 1;
        $limit = 24;
        $offset = ($page - 1) * $limit;
        $sort = $this->request->getGet('sort') ?? '';
        $status = $this->request->getGet('status') ?? '';

        // Lấy tất cả truyện dựa trên sắp xếp và bộ lọc
        $stories = $this->storyModel->getStoryList($limit, $offset, $sort, $status);

        // Lấy tổng số truyện cho phân trang
        $totalStories = $this->storyModel->getStoryListCount($status);
        $totalPages = ceil($totalStories / $limit);

        // Lấy tất cả danh mục
        $categories = $this->categoryModel->getCategoriesWithCount();

        return $this->renderView('story/index.html', [
            'stories' => $stories,
            'current_page' => (int)$page,
            'total_pages' => $totalPages,
            'total_results' => $totalStories,
            'sort' => $sort,
            'status' => $status,
            'categories' => $categories
        ]);
    }

    /**
     * Hiển thị một truyện cụ thể
     */
    public function view($slug)
    {
        // Lấy thông tin chi tiết truyện
        $story = $this->storyModel->getStory($slug);

        if (!$story) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        // Tăng lượt xem
        $this->storyModel->incrementViews($story['id']);

        // Lấy danh sách chương (phân trang)
        $page = $this->request->getGet('page') ?? 1;
        $chaptersPerPage = 50;
        $offset = ($page - 1) * $chaptersPerPage;

        $chapters = $this->chapterModel->getChaptersByStory($story['id'], $chaptersPerPage, $offset);

        // Lấy tổng số chương cho phân trang
        $totalChapters = $this->chapterModel->getChaptersCountByStory($story['id']);
        $totalPages = ceil($totalChapters / $chaptersPerPage);

        // Lấy danh mục của truyện
        $categories = $story['categories'] ?? [];

        // Định dạng tiêu đề và mô tả sử dụng mẫu
        $titleTemplate = $this->settingsModel->getSetting('story_title_template', '[title] - [year] | [country]');
        $descTemplate = $this->settingsModel->getSetting('story_description_template', 'Truyện [title] [year] - [country] thuộc thể loại [categories]. Truyện do [publisher] đánh giá.');

        // Lấy danh mục dưới dạng chuỗi
        $categoryNames = array_column($categories, 'name');
        $categoryString = implode(', ', $categoryNames);

        // Lấy tên quốc gia
        $countryName = $story['country'] ?? '';

        // Thay thế placeholder trong mẫu
        $replacements = [
            '[title]' => $story['title'],
            '[year]' => $story['release_year'] ?? '',
            '[country]' => $countryName,
            '[publisher]' => $story['publisher_name'] ?? '', // Sử dụng publisher_name thay vì author_name
            '[categories]' => $categoryString,
            '[type]' => $story['type'] ?? ''
        ];

        $formattedTitle = str_replace(array_keys($replacements), array_values($replacements), $titleTemplate);
        $formattedDescription = str_replace(array_keys($replacements), array_values($replacements), $descTemplate);

        // Lấy chương mới nhất
        $latestChapter = $story['latest_chapter'] ?? null;

        // Lấy bình luận (phân trang)
        $commentsPage = $this->request->getGet('comments_page') ?? 1;
        $commentsPerPage = 10;
        $commentsOffset = ($commentsPage - 1) * $commentsPerPage;

        $comments = $this->commentModel->getStoryComments($story['id'], null, $commentsPerPage, $commentsOffset);

        // Lấy tổng số bình luận cho phân trang
        $totalComments = $this->commentModel->getStoryCommentsCount($story['id'], null);
        $commentsTotalPages = ceil($totalComments / $commentsPerPage);

        // Lấy replies cho mỗi bình luận
        foreach ($comments as &$comment) {
            $comment['replies'] = $this->commentModel->getCommentReplies($comment['id']);
        }

        // Không cần kiểm tra đăng nhập nữa, tất cả dùng localStorage
        $isBookmarked = false;
        $userRating = 0;
        $readingProgress = null;

        // Lấy các truyện tương tự dựa trên thuật toán mới
        $similarStories = $this->storyModel->getSmartSimilarStories($story['id'], $categories, 6);

        // Lấy số lượng đánh giá - sử dụng database vì đánh giá vẫn được lưu ở server
        $ratingsCount = $this->storyModel->getRatingsCount($story['id']);

        // Lấy số yêu thích - không còn sử dụng database mà dùng trường total_favorites trên story
        $bookmarksCount = $story['total_favorites'] ?? 0;

        return $this->renderView('story/view.html', [
            'story' => $story,
            'chapters' => $chapters,
            'categories' => $categories,
            'comments' => $comments,
            'latest_chapter' => $latestChapter,
            'is_bookmarked' => $isBookmarked,
            'user_rating' => $userRating,
            'reading_progress' => $readingProgress,
            'similar_stories' => $similarStories,
            'ratings_count' => $ratingsCount,
            'bookmarks_count' => $bookmarksCount,
            'current_page' => (int)$page,
            'total_pages' => $totalPages,
            'comments_page' => (int)$commentsPage,
            'comments_total_pages' => $commentsTotalPages,
            'current_url' => current_url(),
            'formatted_title' => $formattedTitle,
            'formatted_description' => $formattedDescription
        ]);
    }

    /**
     * Hiển thị truyện theo danh mục
     */
    public function category($slug)
    {
        $category = $this->categoryModel->where('slug', $slug)->first();

        if (!$category) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        $page = $this->request->getGet('page') ?? 1;
        $limit = 24;
        $offset = ($page - 1) * $limit;
        $sort = $this->request->getGet('sort') ?? '';
        $status = $this->request->getGet('status') ?? '';

        // Lấy truyện theo danh mục
        $stories = $this->storyModel->getByCategory($category['id'], $limit, $offset, $sort, $status);

        // Lấy tổng số truyện cho phân trang
        $totalStories = $this->storyModel->getByCategoryCount($category['id'], $status);
        $totalPages = ceil($totalStories / $limit);

        // Lấy các danh mục liên quan (có truyện chung với danh mục này)
        $relatedCategories = $this->categoryModel->getRelatedCategories($category['id'], 8);

        return $this->renderView('category/view.html', [
            'category' => $category,
            'stories' => $stories,
            'current_page' => (int)$page,
            'total_pages' => $totalPages,
            'total_results' => $totalStories,
            'sort' => $sort,
            'status' => $status,
            'related_categories' => $relatedCategories
        ]);
    }

    /**
     * Hiển thị truyện theo quốc gia
     */
    public function country($slug)
    {
        // Tìm truyện theo quốc gia (sử dụng trường country)
        $countryName = ucfirst(str_replace('-', ' ', $slug));

        $page = $this->request->getGet('page') ?? 1;
        $limit = 24;
        $offset = ($page - 1) * $limit;
        $sort = $this->request->getGet('sort') ?? '';
        $status = $this->request->getGet('status') ?? '';

        // Lấy truyện theo quốc gia
        $stories = $this->storyModel->getStoriesByCountry($countryName, $limit, $offset);

        // Lấy tổng số truyện cho phân trang
        $totalStories = $this->storyModel->countStoriesByCountry($countryName);
        $totalPages = ceil($totalStories / $limit);

        // Lấy tất cả danh mục
        $categories = $this->categoryModel->getCategoriesWithCount();

        return $this->renderView('story/country.html', [
            'country_slug' => $slug,
            'country_name' => $countryName,
            'stories' => $stories,
            'current_page' => (int)$page,
            'total_pages' => $totalPages,
            'total_results' => $totalStories,
            'sort' => $sort,
            'status' => $status,
            'categories' => $categories
        ]);
    }

    /**
     * Hiển thị truyện đã hoàn thành
     */
    public function completed()
    {
        $page = $this->request->getGet('page') ?? 1;
        $limit = 24;
        $offset = ($page - 1) * $limit;
        $sort = $this->request->getGet('sort') ?? '';

        // Lấy truyện đã hoàn thành
        $stories = $this->storyModel->getCompleted($limit, $offset, $sort);

        // Lấy tổng số truyện cho phân trang
        $totalStories = $this->storyModel->getCompletedCount();
        $totalPages = ceil($totalStories / $limit);

        // Lấy tất cả danh mục
        $categories = $this->categoryModel->getCategoriesWithCount();

        return $this->renderView('story/completed.html', [
            'stories' => $stories,
            'current_page' => (int)$page,
            'total_pages' => $totalPages,
            'total_results' => $totalStories,
            'sort' => $sort,
            'categories' => $categories
        ]);
    }

    /**
     * Hiển thị truyện hot
     */
    public function hot()
    {
        $page = $this->request->getGet('page') ?? 1;
        $limit = 24;
        $offset = ($page - 1) * $limit;
        $sort = $this->request->getGet('sort') ?? 'views';
        $status = $this->request->getGet('status') ?? '';

        // Lấy truyện hot
        $stories = $this->storyModel->getHotStories($limit, $offset, $sort, $status);

        // Lấy tổng số truyện cho phân trang
        $totalStories = $this->storyModel->getHotStoriesCount($status);
        $totalPages = ceil($totalStories / $limit);

        // Lấy tất cả danh mục
        $categories = $this->categoryModel->getCategoriesWithCount();

        return $this->renderView('story/hot.html', [
            'stories' => $stories,
            'current_page' => (int)$page,
            'total_pages' => $totalPages,
            'total_results' => $totalStories,
            'sort' => $sort,
            'status' => $status,
            'categories' => $categories
        ]);
    }

    /**
     * Hiển thị truyện mới cập nhật gần đây
     */
    public function recentlyd()
    {
        $page = $this->request->getGet('page') ?? 1;
        $limit = 24;
        $offset = ($page - 1) * $limit;
        $status = $this->request->getGet('status') ?? '';

        // Lấy truyện mới cập nhật gần đây
        $stories = $this->storyModel->getRecentlyUpdated($limit, $offset, $status);

        // Lấy tổng số truyện cho phân trang
        $totalStories = $this->storyModel->getRecentlyUpdatedCount($status);
        $totalPages = ceil($totalStories / $limit);

        // Lấy tất cả danh mục
        $categories = $this->categoryModel->getCategoriesWithCount();

        return $this->renderView('story/recently_updated.html', [
            'stories' => $stories,
            'current_page' => (int)$page,
            'total_pages' => $totalPages,
            'total_results' => $totalStories,
            'status' => $status,
            'categories' => $categories
        ]);
    }

    /**
     * Hiển thị truyện mới nhất
     */
    public function latest()
    {
        $page = $this->request->getGet('page') ?? 1;
        $limit = 24;
        $offset = ($page - 1) * $limit;
        $sort = $this->request->getGet('sort') ?? '';
        $status = $this->request->getGet('status') ?? '';

        // Lấy truyện mới nhất
        $stories = $this->storyModel->getLatest($limit, $offset, $sort, $status);

        // Lấy tổng số truyện cho phân trang
        $totalStories = $this->storyModel->getLatestCount($status);
        $totalPages = ceil($totalStories / $limit);

        // Lấy tất cả danh mục
        $categories = $this->categoryModel->getCategoriesWithCount();

        return $this->renderView('story/latest.html', [
            'stories' => $stories,
            'current_page' => (int)$page,
            'total_pages' => $totalPages,
            'total_results' => $totalStories,
            'sort' => $sort,
            'status' => $status,
            'categories' => $categories
        ]);
    }

    /**
     * Hiển thị truyện được đề xuất
     */
    public function recommended()
    {
        $page = $this->request->getGet('page') ?? 1;
        $limit = 24;
        $offset = ($page - 1) * $limit;
        $sort = $this->request->getGet('sort') ?? '';
        $status = $this->request->getGet('status') ?? '';

        // Sử dụng thuật toán đề xuất thông minh nếu ở trang đầu tiên
        if ($page == 1 && empty($sort) && empty($status)) {
            $smartRecommendations = $this->storyModel->getSmartRecommendations($limit);
            $stories = $smartRecommendations;
        } else {
            // Nếu không, sử dụng phương thức đề xuất thông thường với phân trang và sắp xếp
            $stories = $this->storyModel->getRecommended($limit, $offset, $sort, $status);
        }

        // Lấy tổng số truyện cho phân trang
        $totalStories = $this->storyModel->getRecommendedCount($status);
        $totalPages = ceil($totalStories / $limit);

        // Lấy tất cả danh mục
        $categories = $this->categoryModel->getCategoriesWithCount();

        return $this->renderView('story/recommended.html', [
            'stories' => $stories,
            'current_page' => (int)$page,
            'total_pages' => $totalPages,
            'total_results' => $totalStories,
            'sort' => $sort,
            'status' => $status,
            'categories' => $categories,
            'is_smart_recommendation' => ($page == 1 && empty($sort) && empty($status))
        ]);
    }

    /**
     * Hiển thị truyện theo tác giả
     */
    public function author($authorName)
    {
        // Đổi tên tham số từ username thành authorName để rõ ràng hơn
        // Tìm truyện theo tên tác giả thay vì người đăng
        $page = $this->request->getGet('page') ?? 1;
        $limit = 24;
        $offset = ($page - 1) * $limit;
        $sort = $this->request->getGet('sort') ?? '';
        $status = $this->request->getGet('status') ?? '';

        // Tạo đối tượng author để hiển thị thông tin tác giả
        $author = [
            'name' => urldecode($authorName) // Giải mã URL để hiển thị tên tác giả đúng
        ];

        // Tìm truyện theo tên tác giả thay vì ID người dùng
        $stories = $this->storyModel->getByAuthorName($authorName, $limit, $offset, $sort, $status);

        // Lấy tổng số truyện cho phân trang
        $totalStories = $this->storyModel->getByAuthorNameCount($authorName, $status);
        $totalPages = ceil($totalStories / $limit);

        return $this->renderView('story/author.html', [
            'author' => $author,
            'stories' => $stories,
            'current_page' => (int)$page,
            'total_pages' => $totalPages,
            'total_results' => $totalStories,
            'sort' => $sort,
            'status' => $status,
            'type' => 'publisher' // Thêm trường type để phân biệt là publisher hay author thật
        ]);
    }

    /**
     * Hiển thị truyện theo tác giả thực
     */
    public function realAuthor($authorName)
    {
        $page = $this->request->getGet('page') ?? 1;
        $limit = 24;
        $offset = ($page - 1) * $limit;
        $sort = $this->request->getGet('sort') ?? '';
        $status = $this->request->getGet('status') ?? '';

        // Tạo đối tượng author để hiển thị thông tin tác giả
        $author = [
            'name' => urldecode($authorName) // Giải mã URL để hiển thị tên tác giả đúng
        ];

        // Tìm truyện theo tên tác giả thực
        $stories = $this->storyModel->getByRealAuthorName($authorName, $limit, $offset, $sort, $status);

        // Lấy tổng số truyện cho phân trang
        $totalStories = $this->storyModel->countByRealAuthorName($authorName, $status);
        $totalPages = ceil($totalStories / $limit);

        return $this->renderView('story/author.html', [
            'author' => $author,
            'stories' => $stories,
            'current_page' => (int)$page,
            'total_pages' => $totalPages,
            'total_results' => $totalStories,
            'sort' => $sort,
            'status' => $status,
            'type' => 'real_author' // Thêm trường type để phân biệt là publisher hay author thật
        ]);
    }

    /**
     * Hiển thị danh sách tác giả
     */
    public function authors()
    {
        // Lấy danh sách tác giả thực (author_name) có trong hệ thống
        $authors = $this->storyModel->getAllRealAuthors();

        return $this->renderView('story/authors.html', [
            'authors' => $authors,
            'type' => 'real_authors'
        ]);
    }

    /**
     * Hiển thị danh sách người đăng
     */
    public function publishers()
    {
        // Lấy danh sách người đăng (publisher) có trong hệ thống
        $publishers = $this->storyModel->getAllPublishers();

        return $this->renderView('story/authors.html', [
            'authors' => $publishers,
            'type' => 'publishers'
        ]);
    }

    /**
     * Hiển thị trang xếp hạng
     */
    public function rankings()
    {
        // Lấy top truyện theo lượt xem (mọi thời điểm)
        $topByViews = $this->storyModel->getTopByViews(10);

        // Lấy top truyện theo lượt xem ngày
        $topDaily = $this->storyModel->where('status', 'published')
                                   ->orderBy('views_day', 'DESC')
                                   ->limit(10)
                                   ->find();

        // Lấy top truyện theo lượt xem tuần
        $topWeekly = $this->storyModel->getTopThisWeek(10);

        // Lấy top truyện theo lượt xem tháng
        $topMonthly = $this->storyModel->getTopThisMonth(10);

        // Lấy top truyện theo đánh giá
        $topByRating = $this->storyModel->getTopByRating(10);

        // Lấy top truyện theo lượt yêu thích
        $topByFavorites = $this->storyModel->getTopByFavorites(10);

        // Lấy top truyện đã hoàn thành
        $topCompleted = $this->storyModel->where('status', 'published')
                                        ->where('is_completed', true)
                                        ->orderBy('views', 'DESC')
                                        ->limit(10)
                                        ->find();

        return $this->renderView('story/rankings.html', [
            'rankings' => [
                'most_viewed' => $topByViews,
                'daily' => $topDaily,
                'weekly' => $topWeekly,
                'monthly' => $topMonthly,
                'top_rated' => $topByRating,
                'most_favorited' => $topByFavorites,
                'completed' => $topCompleted
            ],
            'page_title' => 'Bảng xếp hạng truyện - Top truyện hot nhất',
            'page_description' => 'Bảng xếp hạng truyện theo lượt xem, đánh giá và yêu thích. Cập nhật hàng ngày, hàng tuần và hàng tháng.'
        ]);
    }

    /**
     * Đánh giá một truyện
     */
    public function rate()
    {
        if (!$this->request->isAJAX()) {
            return $this->response->setStatusCode(403);
        }

        $rules = [
            'story_id' => 'required|numeric',
            'rating' => 'required|numeric|min_value[1]|max_value[5]',
        ];

        if (!$this->validate($rules)) {
            return $this->response->setJSON(['success' => false, 'message' => 'Dữ liệu không hợp lệ.']);
        }

        $storyId = $this->request->getPost('story_id');
        $rating = $this->request->getPost('rating');

        // Không cần user_id để đánh giá nữa
        $userId = session()->get('user')['id'] ?? null;

        // Lưu đánh giá
        $result = $this->storyModel->rateStory($storyId, $userId, $rating);

        return $this->response->setJSON(['success' => $result]);
    }

    /**
     * Lưu/xóa bookmark (hoạt động với cả user đăng nhập và không đăng nhập)
     */
    public function toggleBookmark()
    {
        // Lấy story_id từ request
        $storyId = $this->request->getPost('story_id');
        if (!$storyId) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'ID truyện không hợp lệ'
            ]);
        }

        // Kiểm tra truyện có tồn tại không
        $story = $this->storyModel->find($storyId);
        if (!$story) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'Truyện không tồn tại'
            ]);
        }

        // Chỉ trả về thành công, việc lưu thực sự được xử lý ở phía client bằng localStorage
        return $this->response->setJSON([
            'status' => 'success',
            'action' => 'toggle',
            'message' => 'Đã cập nhật trạng thái đánh dấu truyện',
            'story' => [
                'id' => $story['id'],
                'title' => $story['title'],
                'slug' => $story['slug'],
                'cover_image' => $story['cover_image'],
                'publisher_name' => $story['publisher_name'] // Sử dụng publisher_name thay vì author_name
            ]
        ]);
    }

    /**
     * Cập nhật số lượng yêu thích của truyện
     * Chức năng này được gọi từ JavaScript để cập nhật số lượng yêu thích
     */
    public function updateFavoritesCount()
    {
        // Kiểm tra nếu là AJAX request
        if (!$this->request->isAJAX()) {
            return $this->response->setStatusCode(403)->setJSON(['error' => 'Forbidden']);
        }

        // Lấy dữ liệu từ request
        $storyId = $this->request->getPost('story_id');
        $delta = $this->request->getPost('delta');

        // Kiểm tra dữ liệu
        if (!$storyId || !in_array($delta, ['1', '-1'])) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Dữ liệu không hợp lệ'
            ]);
        }

        // Chuyển đổi sang số
        $storyId = (int)$storyId;
        $delta = (int)$delta;

        // Cập nhật số lượng yêu thích
        $model = new \App\Models\StoryModel();
        $story = $model->find($storyId);

        if (!$story) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Không tìm thấy truyện'
            ]);
        }

        // Cập nhật total_favorites, đảm bảo không bị âm
        if ($delta < 0 && $story['total_favorites'] <= 0) {
            // Không làm gì nếu total_favorites đã là 0 và delta là -1
        } else {
            $model->update($storyId, [
                'total_favorites' => $story['total_favorites'] + $delta
            ]);
        }

        return $this->response->setJSON([
            'success' => true,
            'message' => 'Đã cập nhật số lượng yêu thích'
        ]);
    }
}
