<?php
namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table = 'users';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'username', 'email', 'password', 'display_name', 'role', 'status', 'avatar',
        'created_at', 'updated_at', 'reset_token', 'reset_token_expires_at', 'last_login'
    ];

    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    protected $beforeInsert = ['hashPassword'];
    protected $beforeUpdate = ['hashPassword'];

    /**
     * Hash mật khẩu trước khi lưu vào database
     */
    protected function hashPassword(array $data)
    {
        if (!isset($data['data']['password'])) {
            return $data;
        }

        // Nếu mật khẩu đã được hash, không hash lại
        if (password_get_info($data['data']['password'])['algo'] !== 0) {
            return $data;
        }

        $data['data']['password'] = password_hash($data['data']['password'], PASSWORD_DEFAULT);
        return $data;
    }

    /**
     * Kiểm tra đăng nhập
     */
    public function attemptLogin($email, $password)
    {
        $user = $this->where('email', $email)
                     ->orWhere('username', $email)
                     ->first();

        if (!$user) {
            return false;
        }

        if ($user['status'] !== 'active') {
            return false;
        }

        if (!password_verify($password, $user['password'])) {
            return false;
        }

        // Update last login
        $this->update($user['id'], ['last_login' => date('Y-m-d H:i:s')]);

        unset($user['password']);
        return $user;
    }

    /**
     * Lấy thông tin người dùng kèm theo phân quyền dễ đọc
     */
    public function getWithRoleText($userId)
    {
        $user = $this->find($userId);
        if (!$user) {
            return null;
        }

        $user['role_text'] = $this->getRoleText($user['role']);
        return $user;
    }

    /**
     * Lấy text hiển thị cho phân quyền
     */
    public function getRoleText($roleId)
    {
        $roles = [
            '1' => 'Cộng tác viên',
            '2' => 'Admin',
            '3' => 'Người sáng lập'
        ];

        return $roles[$roleId] ?? 'Không xác định';
    }

    /**
     * Lấy màu hiển thị cho phân quyền
     */
    public function getRoleColor($roleId)
    {
        $colors = [
            '1' => 'success',   // Cộng tác viên: xanh lá
            '2' => 'primary',   // Admin: xanh dương
            '3' => 'danger'     // Người sáng lập: đỏ
        ];

        return $colors[$roleId] ?? 'secondary';
    }

    /**
     * Cập nhật mật khẩu cho người dùng
     */
    public function updateUserPassword($userId, $newPassword)
    {
        // Hash mật khẩu mới
        $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

        // Cập nhật mật khẩu trong database
        return $this->update($userId, ['password' => $hashedPassword]);
    }

    /**
     * Cập nhật token đặt lại mật khẩu
     *
     * @param int $userId ID của người dùng
     * @param string $token Token đặt lại mật khẩu
     * @param string $expiry Thời gian hết hạn (Y-m-d H:i:s)
     * @return bool Kết quả cập nhật
     */
    public function updateResetToken($userId, $token, $expiry)
    {
        return $this->update($userId, [
            'reset_token' => $token,
            'reset_token_expires_at' => $expiry
        ]);
    }

    /**
     * Lấy người dùng bằng token đặt lại mật khẩu
     *
     * @param string $token Token đặt lại mật khẩu
     * @return array|null Thông tin người dùng hoặc null nếu không tìm thấy
     */
    public function getUserByResetToken($token)
    {
        $user = $this->where('reset_token', $token)
                     ->first();

        if (!$user) {
            return null;
        }

        // Kiểm tra token có hết hạn chưa
        if (strtotime($user['reset_token_expires_at']) < time()) {
            return null;
        }

        return $user;
    }

    /**
     * Đặt lại mật khẩu và xóa token
     *
     * @param int $userId ID của người dùng
     * @param string $newPassword Mật khẩu mới
     * @return bool Kết quả cập nhật
     */
    public function resetPassword($userId, $newPassword)
    {
        // Hash mật khẩu mới
        $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

        // Cập nhật mật khẩu và xóa token
        return $this->update($userId, [
            'password' => $hashedPassword,
            'reset_token' => null,
            'reset_token_expires_at' => null
        ]);
    }
}
