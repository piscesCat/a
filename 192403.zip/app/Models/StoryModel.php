<?php

namespace App\Models;

use CodeIgniter\Model;

class StoryModel extends Model
{
    protected $allowedFields = [
        'title', 'slug', 'description', 'cover_image',
        'author_name', 'publisher_id', 'status', 'type', 'release_year',
        'country', 'views', 'views_day', 'views_week', 'views_month',
        'rating', 'total_ratings', 'total_favorites', 'created_at',
        'updated_at', 'is_featured', 'is_completed', 'is_recommended', 'is_hot'
    ];

    /**
     * Kiểm tra xem truyện có được đánh dấu theo dõi bởi người dùng không
     * Đã được cập nhật để hỗ trợ localStorage thay vì database
     */
    public function isBookmarked($storyId, $userId = null)
    {
        return false;
    }

    /**
     * Kiểm tra xem truyện có được yêu thích bởi người dùng không
     */
    public function isFavorited($storyId, $userId)
    {
        if (!$userId) {
            return false;
        }

        $db = \Config\Database::connect();
        $result = $db->table('favorites')
                    ->where('story_id', $storyId)
                    ->where('user_id', $userId)
                    ->countAllResults();

        return $result > 0;
    }

    /**
     * Thêm hoặc xóa truyện khỏi danh sách yêu thích
     */
    public function toggleFavorite($storyId, $userId)
    {
        if (!$userId) {
            return [
                'success' => false,
                'message' => 'Bạn phải đăng nhập để yêu thích truyện'
            ];
        }

        $db = \Config\Database::connect();
        $builder = $db->table('favorites');

        // Kiểm tra xem truyện đã được yêu thích chưa
        $exists = $this->isFavorited($storyId, $userId);

        if ($exists) {
            // Xóa khỏi danh sách yêu thích
            $builder->where('story_id', $storyId)
                   ->where('user_id', $userId)
                   ->delete();

            // Giảm số lượng yêu thích của truyện
            $this->where('id', $storyId)
                 ->set('total_favorites', 'total_favorites - 1', false)
                 ->update();

            return [
                'success' => true,
                'action' => 'removed',
                'message' => 'Đã xóa khỏi danh sách yêu thích'
            ];
        } else {
            // Thêm vào danh sách yêu thích
            $builder->insert([
                'story_id' => $storyId,
                'user_id' => $userId,
                'created_at' => date('Y-m-d H:i:s')
            ]);

            // Tăng số lượng yêu thích của truyện
            $this->where('id', $storyId)
                 ->set('total_favorites', 'total_favorites + 1', false)
                 ->update();

            return [
                'success' => true,
                'action' => 'added',
                'message' => 'Đã thêm vào danh sách yêu thích'
            ];
        }
    }

    /**
     * Lấy danh sách truyện yêu thích của người dùng
     */
    public function getUserFavorites($userId, $limit = 12, $offset = 0)
    {
        if (!$userId) {
            return [];
        }

        $db = \Config\Database::connect();
        $query = $db->table('stories s')
                   ->select('s.*, f.created_at as favorited_at')
                   ->join('favorites f', 's.id = f.story_id', 'inner')
                   ->where('f.user_id', $userId)
                   ->where('s.status', 'published')
                   ->orderBy('f.created_at', 'DESC')
                   ->limit($limit, $offset);

        return $query->get()->getResultArray();
    }

    /**
     * Đếm số lượng truyện yêu thích của người dùng
     */
    public function countUserFavorites($userId)
    {
        if (!$userId) {
            return 0;
        }

        $db = \Config\Database::connect();
        return $db->table('favorites')
                 ->where('user_id', $userId)
                 ->countAllResults();
    }

    /**
     * Thuật toán cập nhật trường is_hot (HOT)
     * Tự động đánh dấu một truyện là "hot" dựa vào mức độ phổ biến, lượt xem và sự tăng trưởng đột biến
     *
     * @param int $minDailyViews Số lượt xem tối thiểu trong ngày để đánh dấu là hot (mặc định: 100)
     * @param float $growthRate Tỷ lệ tăng trưởng tối thiểu so với ngày trước (mặc định: 30%)
     * @param int $minNewRatings Số lượng đánh giá mới tối thiểu trong 24h (mặc định: 10)
     * @param int $cooldownDays Số ngày tự động loại bỏ trạng thái hot nếu không còn đáp ứng tiêu chí (mặc định: 3)
     * @return bool Trả về true nếu cập nhật thành công
     */
    public function updateHotStories($minDailyViews = 100, $growthRate = 30, $minNewRatings = 10, $cooldownDays = 3)
    {
        $db = \Config\Database::connect();
        $logModel = new LogModel();
        $updated = 0;
        $reverted = 0;

        try {
            // 1. Đánh dấu truyện là hot nếu có lượt xem/ngày cao
            $highDailyViewsQuery = $this->where('views_day >', $minDailyViews)
                                       ->where('status', 'published')
                                       ->where('is_hot', false)
                                       ->set('is_hot', true)
                                       ->update();

            $updated += $this->db->affectedRows();

            // 2. Kiểm tra tỷ lệ tăng trưởng đột biến
            // Lấy dữ liệu lượt xem của các truyện từ hôm qua (lưu trong bảng story_stats)
            $statsTable = $db->table('story_stats');
            $yesterday = date('Y-m-d', strtotime('-1 day'));
            $storyStats = $statsTable->where('date', $yesterday)->get()->getResultArray();

            // Chuyển đổi thành mảng id => views để dễ truy xuất
            $yesterdayViews = [];
            foreach ($storyStats as $stat) {
                $yesterdayViews[$stat['story_id']] = $stat['views'];
            }

            // Kiểm tra từng truyện chưa được đánh dấu là hot
            $stories = $this->where('is_hot', false)
                          ->where('status', 'published')
                          ->find();

            foreach ($stories as $story) {
                // Nếu có dữ liệu lượt xem hôm qua
                if (isset($yesterdayViews[$story['id']])) {
                    $yesterdayView = $yesterdayViews[$story['id']];

                    // Nếu lượt xem hôm qua > 0 và có tỷ lệ tăng trưởng lớn
                    if ($yesterdayView > 0 && $story['views_day'] > 0) {
                        $growthPercentage = (($story['views_day'] - $yesterdayView) / $yesterdayView) * 100;

                        // Nếu tỷ lệ tăng trưởng vượt ngưỡng
                        if ($growthPercentage >= $growthRate) {
                            $this->update($story['id'], [
                                'is_hot' => true
                            ]);
                            $updated++;

                            // Ghi log
                            $logModel->info('Truyện được đánh dấu là hot do tăng trưởng đột biến', [
                                'story_id' => $story['id'],
                                'title' => $story['title'],
                                'growth_rate' => $growthPercentage,
                                'yesterday_views' => $yesterdayView,
                                'today_views' => $story['views_day']
                            ]);
                        }
                    }
                }
            }

            // 3. Kiểm tra số lượng đánh giá mới
            $ratingsTable = $db->table('ratings');
            $last24h = date('Y-m-d H:i:s', strtotime('-24 hours'));

            // Đếm số lượng đánh giá mới cho từng truyện trong 24h qua
            $newRatingsQuery = $ratingsTable->select('story_id, COUNT(*) as new_ratings')
                                          ->where('created_at >', $last24h)
                                          ->groupBy('story_id')
                                          ->having('new_ratings >=', $minNewRatings)
                                          ->get();

            $newRatings = $newRatingsQuery->getResultArray();

            // Đánh dấu hot cho các truyện có nhiều đánh giá mới
            foreach ($newRatings as $rating) {
                $story = $this->find($rating['story_id']);

                if ($story && $story['is_hot'] == false && $story['status'] == 'published') {
                    $this->update($rating['story_id'], [
                        'is_hot' => true
                    ]);
                    $updated++;

                    // Ghi log
                    $logModel->info('Truyện được đánh dấu là hot do có nhiều đánh giá mới', [
                        'story_id' => $rating['story_id'],
                        'title' => $story['title'],
                        'new_ratings' => $rating['new_ratings']
                    ]);
                }
            }

            // 4. Tự động loại bỏ trạng thái hot sau một thời gian nếu không còn đáp ứng tiêu chí
            $notHotAnymore = $this->where('is_hot', true)
                                ->where('views_day <', $minDailyViews)
                                ->find();

            foreach ($notHotAnymore as $story) {
                $this->update($story['id'], [
                    'is_hot' => false
                ]);
                $reverted++;

                // Ghi log
                $logModel->info('Truyện không còn được đánh dấu là hot', [
                    'story_id' => $story['id'],
                    'title' => $story['title'],
                    'current_daily_views' => $story['views_day']
                ]);
            }

            // Ghi log tổng kết
            $logModel->info('Đã cập nhật trạng thái hot cho truyện', [
                'updated' => $updated,
                'reverted' => $reverted,
                'min_daily_views' => $minDailyViews,
                'growth_rate' => $growthRate,
                'min_new_ratings' => $minNewRatings
            ]);

            return true;
        } catch (\Exception $e) {
            // Ghi log lỗi
            $logModel->error('Lỗi khi cập nhật trạng thái hot cho truyện', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);

            return false;
        }
    }

    /**
     * Tìm kiếm truyện
     */
    public function search($keyword, $limit = 12, $offset = 0)
    {
        // Làm sạch từ khóa tìm kiếm
        $keyword = trim($keyword);

        // Nếu từ khóa trống, trả về mảng trống
        if (empty($keyword)) {
            return [];
        }

        // Tìm kiếm sử dụng LIKE thay vì search_vector
        return $this->groupStart()
                ->like('title', $keyword)
                ->orLike('description', $keyword)
                ->orLike('author_name', $keyword)
                ->groupEnd()
                ->where('status', 'published')
                ->orderBy('title', 'ASC')
                ->limit($limit, $offset)
                ->find();
    }
}
