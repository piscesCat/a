# Hướng dẫn triển khai các chức năng còn lại

Tài liệu này cung cấp hướng dẫn chi tiết để triển khai các chức năng còn lại trong dự án. Tham khảo TODO.md để xem danh sách đầy đủ các việc cần làm.

## 1. Tổng quan về kiến trúc dự án

Dự án sử dụng framework CodeIgniter 4 với mô hình MVC:
- `app/Controllers`: Chứa controllers xử lý logic
- `app/Models`: Chứa các models tương tác với cơ sở dữ liệu
- `app/Views`: Chứa templates Twig để hiển thị giao diện
- `app/Config`: Chứa cấu hình ứng dụng
- `app/Libraries`: Chứa các thư viện tùy chỉnh (như ImgurClient)
- `app/Filters`: Chứa các filter middleware (như ApiAuthFilter)

## 2. Kiểm thử phân quyền đã triển khai

### Vai trò người dùng:
- **Người sáng lập (Role 3)**: Toàn quyền trên hệ thống, bao gồm quản lý admin
- **Admin (Role 2)**: Quản lý nội dung, cài đặt, người dùng thấp hơn
- **Cộng tác viên (Role 1)**: Thêm/sửa/xóa nội dung của mình, giới hạn một số chức năng

### Các điểm cần kiểm tra:
1. Kiểm tra vai trò Người sáng lập:
   ```
   - Có thể tạo người dùng mới với bất kỳ vai trò nào
   - Có thể chỉnh sửa/xóa bất kỳ người dùng nào
   - Có thể truy cập tất cả chức năng
   ```

2. Kiểm tra vai trò Admin:
   ```
   - Chỉ có thể tạo người dùng với vai trò Cộng tác viên
   - Chỉ có thể chỉnh sửa/xóa Cộng tác viên
   - Không thể chỉnh sửa/xóa Admin khác hoặc Người sáng lập
   - Có thể quản lý tất cả nội dung
   ```

3. Kiểm tra vai trò Cộng tác viên:
   ```
   - Không thể tạo người dùng mới
   - Chỉ có thể chỉnh sửa nội dung do mình tạo ra
   - Không thể truy cập các chức năng quản trị
   ```

## 3. Mở rộng phân quyền vào các controller còn lại

### Kiểm tra quyền trong controller mẫu:
```php
public function update($id)
{
    // Kiểm tra quyền truy cập cơ bản (yêu cầu Contributor trở lên)
    $check = $this->requireRole(1);
    if ($check !== true) {
        return $check;
    }

    // Lấy dữ liệu
    $item = $this->itemModel->find($id);
    if (!$item) {
        return redirect()->to('/error')->with('error', 'Không tìm thấy dữ liệu');
    }

    // Kiểm tra quyền chỉnh sửa (Admin trở lên hoặc là người tạo)
    if ($this->currentUser['role'] < 2 && $item['uploader_id'] != $this->currentUser['id']) {
        return redirect()->to('/error')->with('error', 'Bạn không có quyền chỉnh sửa');
    }

    // Tiếp tục xử lý cập nhật...
}
```

### Lưu ý khi thêm kiểm tra phân quyền:
1. Kiểm tra quyền sớm trong methods của controller
2. Sử dụng các helper như `requireRole()`, `requireAdmin()`, `isFounder()`
3. Kiểm tra quyền sở hữu đối với tài nguyên
4. Trả về thông báo lỗi phù hợp với từng trường hợp

## 4. Tinh chỉnh TinyMCE Editor và Imgur Integration

### Cấu hình TinyMCE nâng cao:
```javascript
tinymce.init({
    selector: '.tinymce-editor',
    height: 500,
    plugins: 'preview code table image link media template',
    toolbar: 'undo redo | formatselect | bold italic | alignleft aligncenter alignright | bullist numlist outdent indent | link image media template | removeformat',
    images_upload_handler: function (blobInfo, progress) {
        // Xử lý upload hình ảnh lên Imgur
    },
    content_style: 'body { font-family: -apple-system, BlinkMacSystemFont, San Francisco, Segoe UI, Roboto, Helvetica Neue, sans-serif; font-size: 14px; }'
});
```

### Cấu hình Imgur API và .env:
```
IMGUR_CLIENT_ID=your_client_id
IMGUR_CLIENT_SECRET=your_client_secret
```

### Kiểm tra cấu hình upload:
1. Kiểm tra giới hạn kích thước tệp
2. Kiểm tra định dạng tệp được cho phép
3. Xác minh xử lý lỗi khi upload thất bại
4. Xác minh fallback khi Imgur không khả dụng

## 5. Cải thiện giao diện theo phân quyền

### Hiển thị màu sắc theo vai trò:
```html
<span class="badge bg-{{ user.role == 3 ? 'danger' : (user.role == 2 ? 'primary' : 'success') }}">
    {{ user.role == 3 ? 'Người sáng lập' : (user.role == 2 ? 'Admin' : 'Cộng tác viên') }}
</span>
```

### Ẩn/hiện các nút chức năng theo quyền:
```html
{% if current_user.role >= 2 or (current_user.id == item.uploader_id) %}
    <a href="{{ base_url() }}/edit/{{ item.id }}" class="btn btn-primary">Chỉnh sửa</a>
{% endif %}

{% if current_user.role >= 2 %}
    <a href="{{ base_url() }}/delete/{{ item.id }}" class="btn btn-danger">Xóa</a>
{% endif %}
```

### Tạo CSS theo vai trò:
```css
.text-founder { color: #dc3545; }
.text-admin { color: #0d6efd; }
.text-contributor { color: #198754; }

.bg-founder { background-color: #dc3545; }
.bg-admin { background-color: #0d6efd; }
.bg-contributor { background-color: #198754; }
```

## 6. Kiểm thử và tối ưu hóa

### Kiểm thử cần thực hiện:
1. Kiểm tra các API endpoints với các vai trò khác nhau
2. Kiểm tra tính năng lưu trữ và đồng bộ bookmark
3. Kiểm tra tính năng upload và hiển thị ảnh
4. Kiểm tra hiệu suất khi tải nhiều dữ liệu
5. Kiểm tra tương thích trên các trình duyệt khác nhau

### Tối ưu SQL:
```sql
-- Tối ưu truy vấn lấy truyện theo thể loại với phân trang
SELECT s.*, u.username as uploader_name, COUNT(c.id) as chapter_count
FROM stories s
LEFT JOIN users u ON s.uploader_id = u.id
LEFT JOIN chapters c ON c.story_id = s.id
WHERE s.status = 'published'
AND EXISTS (
    SELECT 1 FROM story_categories sc
    WHERE sc.story_id = s.id AND sc.category_id = ?
)
GROUP BY s.id, u.username
ORDER BY s.updated_at DESC
LIMIT ? OFFSET ?;
```

### Tối ưu tải trang:
1. Sử dụng lazy loading cho hình ảnh
2. Sử dụng cache cho các dữ liệu tĩnh
3. Giảm thiểu số lượng HTTP requests

## 7. Triển khai document API và hướng dẫn

### Mẫu document API:
```markdown
## API Endpoint: POST /api/uploads/imgur

**Mô tả:** Upload hình ảnh lên Imgur thông qua API

**Yêu cầu quyền:** Đăng nhập (Cộng tác viên trở lên)

**Tham số:**
- `file`: File hình ảnh (JPG, PNG, GIF, WEBP)

**Phản hồi thành công:**
```json
{
    "success": true,
    "data": {
        "url": "https://i.imgur.com/abcdef.jpg",
        "delete_hash": "12345abcdef",
        "name": "image.jpg"
    }
}
```

**Phản hồi lỗi:**
```json
{
    "success": false,
    "message": "Lỗi khi upload ảnh"
}
```
```

### Tài liệu hướng dẫn sử dụng:
Tạo tài liệu hướng dẫn sử dụng cho:
1. Hướng dẫn quản lý người dùng theo phân quyền
2. Hướng dẫn sử dụng editor và tính năng upload ảnh
3. Hướng dẫn bảo mật và xác thực

## 8. Triển khai cho môi trường sản phẩm

### Chuẩn bị môi trường:
1. Cài đặt PHP 7.4+ với các extension cần thiết
2. Cài đặt và cấu hình PostgreSQL
3. Cấu hình Nginx/Apache với HTTPS

### Tối ưu cho sản phẩm:
1. Bật opcache và tối ưu PHP
2. Cấu hình caching tĩnh (static assets)
3. Sử dụng CDN cho assets
4. Cấu hình bảo mật CORS, CSP
5. Thiết lập monitoring và logging

### Triển khai cập nhật:
Khi triển khai cập nhật, cần:
1. Backup dữ liệu trước khi cập nhật
2. Chạy migration database
3. Cập nhật code
4. Xóa cache
5. Kiểm tra tính năng sau triển khai

## 9. Đánh giá hiệu suất

### Các chỉ số cần đo lường:
1. Thời gian tải trang
2. Thời gian phản hồi API
3. Sử dụng tài nguyên máy chủ (CPU, RAM)
4. Hiệu suất database

### Công cụ đề xuất:
1. Lighthouse (đánh giá hiệu suất frontend)
2. Blackfire (profiling PHP)
3. pgMustard (phân tích truy vấn PostgreSQL)
4. New Relic (monitoring toàn diện)

## 10. Tóm tắt kế hoạch triển khai

1. **Tuần 1:** Mở rộng phân quyền vào tất cả controllers và kiểm thử
2. **Tuần 2:** Cải thiện giao diện người dùng và tối ưu hóa
3. **Tuần 3:** Kiểm thử toàn diện và sửa lỗi
4. **Tuần 4:** Chuẩn bị tài liệu và triển khai cho môi trường sản phẩm

### Các chỉ số thành công:
1. Hoàn thành 100% các chức năng yêu cầu
2. Thời gian tải trang < 2 giây
3. Không có lỗ hổng bảo mật
4. Tài liệu đầy đủ và rõ ràng
