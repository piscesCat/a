<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddAuthorNameToStories extends Migration
{
    public function up()
    {
        // Add author_name column if it doesn't exist
        if (!$this->db->fieldExists('author_name', 'stories')) {
            $this->forge->addColumn('stories', [
                'author_name' => [
                    'type' => 'VARCHAR',
                    'constraint' => 100,
                    'after' => 'author_id',
                    'null' => true,
                ],
            ]);
        }

        // Add uploader_id column if it doesn't exist
        if (!$this->db->fieldExists('uploader_id', 'stories')) {
            $this->forge->addColumn('stories', [
                'uploader_id' => [
                    'type' => 'INT',
                    'constraint' => 11,
                    'null' => true,
                    'after' => 'author_name',
                ],
            ]);

            // Update the existing stories to set uploader_id = author_id
            $this->db->query('UPDATE stories SET uploader_id = author_id WHERE uploader_id IS NULL');
        }
    }

    public function down()
    {
        // Remove the columns if they exist
        if ($this->db->fieldExists('author_name', 'stories')) {
            $this->forge->dropColumn('stories', 'author_name');
        }

        if ($this->db->fieldExists('uploader_id', 'stories')) {
            $this->forge->dropColumn('stories', 'uploader_id');
        }
    }
}
