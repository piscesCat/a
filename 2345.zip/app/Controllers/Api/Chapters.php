<?php

namespace App\Controllers\Api;

use App\Controllers\BaseController;
use App\Models\StoryModel;
use App\Models\ChapterModel;

class Chapters extends BaseController
{
    protected $storyModel;
    protected $chapterModel;

    public function __construct()
    {
        $this->storyModel = new StoryModel();
        $this->chapterModel = new ChapterModel();
    }

    /**
     * API tạo chương mới
     */
    public function create()
    {
        // Kiểm tra xác thực API (token)
        $user = $this->verifyApiToken();
        if (!$user || $user['role'] < 1) { // Chỉ cộng tác viên trở lên mới được thêm chương
            return $this->response->setStatusCode(403)->setJSON([
                'success' => false,
                'message' => 'Không có quyền thực hiện hành động này'
            ]);
        }

        // Validate dữ liệu
        $rules = [
            'story_id' => 'required|numeric',
            'chapter_number' => 'required|numeric',
            'title' => 'required|min_length[2]|max_length[200]',
            'content' => 'required'
        ];

        $data = $this->request->getJSON(true);

        if (!$this->validate($rules)) {
            return $this->response->setStatusCode(400)->setJSON([
                'success' => false,
                'message' => 'Dữ liệu không hợp lệ',
                'errors' => $this->validator->getErrors()
            ]);
        }

        // Kiểm tra truyện tồn tại
        $story = $this->storyModel->find($data['story_id']);
        if (!$story) {
            return $this->response->setStatusCode(404)->setJSON([
                'success' => false,
                'message' => 'Không tìm thấy truyện'
            ]);
        }

        // Kiểm tra quyền quản lý truyện
        if ($user['role'] < 2 && $story['author_id'] != $user['id']) {
            return $this->response->setStatusCode(403)->setJSON([
                'success' => false,
                'message' => 'Bạn không có quyền thêm chương cho truyện này'
            ]);
        }

        // Kiểm tra trùng số chương
        $existingChapter = $this->chapterModel->where('story_id', $data['story_id'])
            ->where('chapter_number', $data['chapter_number'])
            ->first();

        if ($existingChapter) {
            return $this->response->setStatusCode(400)->setJSON([
                'success' => false,
                'message' => 'Số chương đã tồn tại cho truyện này'
            ]);
        }

        // Chuẩn bị dữ liệu
        $chapterData = [
            'story_id' => $data['story_id'],
            'chapter_number' => $data['chapter_number'],
            'title' => $data['title'],
            'content' => $data['content'],
            'status' => $data['status'] ?? 'published',
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s'),
            'created_by' => $user['id']
        ];

        // Lưu vào database
        try {
            $chapterId = $this->chapterModel->insert($chapterData);

            // Cập nhật số chương và thời gian cập nhật cho truyện
            $this->storyModel->updateChapterCount($data['story_id']);
            $this->storyModel->update($data['story_id'], ['updated_at' => date('Y-m-d H:i:s')]);

            // Lấy thông tin chương đã tạo
            $chapter = $this->chapterModel->find($chapterId);

            return $this->response->setJSON([
                'success' => true,
                'message' => 'Chương mới đã được tạo thành công',
                'data' => $chapter
            ]);
        } catch (\Exception $e) {
            return $this->response->setStatusCode(500)->setJSON([
                'success' => false,
                'message' => 'Đã xảy ra lỗi: ' . $e->getMessage()
            ]);
        }
    }

    /**
     * API cập nhật chương
     */
    public function update($id)
    {
        // Kiểm tra xác thực API (token)
        $user = $this->verifyApiToken();
        if (!$user || $user['role'] < 1) { // Chỉ cộng tác viên trở lên mới được cập nhật chương
            return $this->response->setStatusCode(403)->setJSON([
                'success' => false,
                'message' => 'Không có quyền thực hiện hành động này'
            ]);
        }

        // Kiểm tra chương tồn tại
        $chapter = $this->chapterModel->find($id);
        if (!$chapter) {
            return $this->response->setStatusCode(404)->setJSON([
                'success' => false,
                'message' => 'Không tìm thấy chương'
            ]);
        }

        // Kiểm tra truyện tồn tại
        $story = $this->storyModel->find($chapter['story_id']);
        if (!$story) {
            return $this->response->setStatusCode(404)->setJSON([
                'success' => false,
                'message' => 'Không tìm thấy truyện'
            ]);
        }

        // Kiểm tra quyền quản lý truyện
        if ($user['role'] < 2 && $story['author_id'] != $user['id']) {
            return $this->response->setStatusCode(403)->setJSON([
                'success' => false,
                'message' => 'Bạn không có quyền cập nhật chương cho truyện này'
            ]);
        }

        // Validate dữ liệu
        $rules = [
            'title' => 'required|min_length[2]|max_length[200]',
            'content' => 'required'
        ];

        $data = $this->request->getJSON(true);

        if (!$this->validate($rules)) {
            return $this->response->setStatusCode(400)->setJSON([
                'success' => false,
                'message' => 'Dữ liệu không hợp lệ',
                'errors' => $this->validator->getErrors()
            ]);
        }

        // Kiểm tra nếu thay đổi số chương
        if (isset($data['chapter_number']) && $data['chapter_number'] != $chapter['chapter_number']) {
            $existingChapter = $this->chapterModel->where('story_id', $chapter['story_id'])
                ->where('chapter_number', $data['chapter_number'])
                ->where('id !=', $id)
                ->first();

            if ($existingChapter) {
                return $this->response->setStatusCode(400)->setJSON([
                    'success' => false,
                    'message' => 'Số chương đã tồn tại cho truyện này'
                ]);
            }
        }

        // Chuẩn bị dữ liệu
        $chapterData = [
            'title' => $data['title'],
            'content' => $data['content'],
            'updated_at' => date('Y-m-d H:i:s')
        ];

        // Cập nhật số chương nếu có
        if (isset($data['chapter_number'])) {
            $chapterData['chapter_number'] = $data['chapter_number'];
        }

        // Cập nhật trạng thái nếu có
        if (isset($data['status'])) {
            $chapterData['status'] = $data['status'];
        }

        // Lưu vào database
        try {
            $this->chapterModel->update($id, $chapterData);

            // Cập nhật thời gian cập nhật cho truyện
            $this->storyModel->update($chapter['story_id'], ['updated_at' => date('Y-m-d H:i:s')]);

            // Lấy thông tin chương đã cập nhật
            $updatedChapter = $this->chapterModel->find($id);

            return $this->response->setJSON([
                'success' => true,
                'message' => 'Chương đã được cập nhật thành công',
                'data' => $updatedChapter
            ]);
        } catch (\Exception $e) {
            return $this->response->setStatusCode(500)->setJSON([
                'success' => false,
                'message' => 'Đã xảy ra lỗi: ' . $e->getMessage()
            ]);
        }
    }

    /**
     * Xác thực token API
     */
    protected function verifyApiToken()
    {
        $authHeader = $this->request->getHeaderLine('Authorization');
        if (empty($authHeader) || !preg_match('/Bearer\s+(.*)$/i', $authHeader, $matches)) {
            return null;
        }

        $token = $matches[1];
        $tokenModel = new \App\Models\TokenModel();

        return $tokenModel->getUserFromToken($token);
    }
}
