<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?? 'Cài đặt hệ thống' ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .card {
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .navbar-brand {
            font-weight: 700;
        }
        .steps {
            display: flex;
            margin-bottom: 30px;
        }
        .step {
            flex: 1;
            text-align: center;
            padding: 10px;
            position: relative;
            color: #6c757d;
        }
        .step.active {
            color: #0d6efd;
            font-weight: 700;
        }
        .step.completed {
            color: #198754;
        }
        .step:not(:last-child):after {
            content: '';
            position: absolute;
            top: 50%;
            right: 0;
            width: 100%;
            height: 2px;
            background-color: #e9ecef;
            z-index: -1;
        }
        .step-number {
            display: inline-block;
            width: 40px;
            height: 40px;
            line-height: 40px;
            border-radius: 50%;
            background-color: #fff;
            border: 1px solid #ced4da;
            margin-bottom: 10px;
        }
        .step.active .step-number {
            background-color: #0d6efd;
            color: #fff;
            border-color: #0d6efd;
        }
        .step.completed .step-number {
            background-color: #198754;
            color: #fff;
            border-color: #198754;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
        <div class="container">
            <a class="navbar-brand" href="#">Web Truyện - Cài đặt</a>
            <span class="navbar-text text-white">
                <i class="fas fa-code"></i> Phiên bản <?= INSTALLER_VERSION ?>
            </span>
        </div>
    </nav>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-10">
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="steps">
                            <div class="step <?= $step >= 1 ? 'active' : '' ?> <?= $step > 1 ? 'completed' : '' ?>">
                                <div class="step-number"><?= $step > 1 ? '<i class="fas fa-check"></i>' : '1' ?></div>
                                <div class="step-title">Kiểm tra yêu cầu</div>
                            </div>
                            <div class="step <?= $step >= 2 ? 'active' : '' ?> <?= $step > 2 ? 'completed' : '' ?>">
                                <div class="step-number"><?= $step > 2 ? '<i class="fas fa-check"></i>' : '2' ?></div>
                                <div class="step-title">Cấu hình cơ sở dữ liệu</div>
                            </div>
                            <div class="step <?= $step >= 3 ? 'active' : '' ?> <?= $step > 3 ? 'completed' : '' ?>">
                                <div class="step-number"><?= $step > 3 ? '<i class="fas fa-check"></i>' : '3' ?></div>
                                <div class="step-title">Tạo tài khoản quản trị</div>
                            </div>
                            <div class="step <?= $step >= 4 ? 'active' : '' ?>">
                                <div class="step-number"><?= $step > 4 ? '<i class="fas fa-check"></i>' : '4' ?></div>
                                <div class="step-title">Hoàn tất</div>
                            </div>
                        </div>

                        <?php if (isset($_SESSION['error'])): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <i class="fas fa-exclamation-triangle"></i> <?= $_SESSION['error'] ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                        <?php unset($_SESSION['error']); endif; ?>

                        <?php if (isset($_SESSION['success'])): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <i class="fas fa-check-circle"></i> <?= $_SESSION['success'] ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                        <?php unset($_SESSION['success']); endif; ?>

                        <h2 class="card-title mb-4"><?= $title ?></h2>
