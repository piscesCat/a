<?php

namespace App\Controllers;

use App\Models\StoryModel;
use App\Models\ChapterModel;

class Bookmark extends BaseController
{
    protected $storyModel;
    protected $chapterModel;

    public function __construct()
    {
        $this->storyModel = new StoryModel();
        $this->chapterModel = new ChapterModel();
    }

    /**
     * Hiển thị trang danh sách bookmark
     * Bookmark được xử lý hoàn toàn ở client-side bằng localStorage
     */
    public function index()
    {
        return view('bookmark/index.html');
    }

    /**
     * API endpoint cho việc kiểm tra trạng thái bookmark
     */
    public function checkStatus()
    {
        $storyId = $this->request->getGet('story_id');

        if (!$storyId) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Thiếu thông tin truyện'
            ]);
        }

        // Chỉ kiểm tra xem truyện có tồn tại không
        $story = $this->storyModel->find($storyId);
        if (!$story) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Không tìm thấy truyện'
            ]);
        }

        // Trả về thành công nhưng không có dữ liệu, vì dữ liệu bookmark được xử lý hoàn toàn ở client
        return $this->response->setJSON([
            'success' => true,
            'data' => [
                'story_slug' => $story['slug'],
                'story_title' => $story['title'],
                'author_name' => $story['author_name']
            ]
        ]);
    }

    /**
     * API endpoint cho việc kiểm tra thông tin chương
     */
    public function checkChapter()
    {
        $chapterId = $this->request->getGet('chapter_id');

        if (!$chapterId) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Thiếu thông tin chương'
            ]);
        }

        // Chỉ kiểm tra xem chương có tồn tại không
        $chapter = $this->chapterModel->find($chapterId);
        if (!$chapter) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Không tìm thấy chương'
            ]);
        }

        // Trả về thông tin chương để client có thể tự cập nhật bookmark
        return $this->response->setJSON([
            'success' => true,
            'data' => [
                'chapter_id' => $chapter['id'],
                'chapter_number' => $chapter['chapter_number'],
                'chapter_title' => $chapter['title'],
                'story_id' => $chapter['story_id']
            ]
        ]);
    }
}
