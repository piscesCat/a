# Báo cáo tiến độ dự án

## Tổng quan

Dự án này là một trang web quản lý truyện xây dựng trên framework CodeIgniter 4, sử dụng PostgreSQL làm CSDL và Twig làm template engine. Dự án đang trong quá trình cải tiến với các chức năng mới theo yêu cầu trong file `log.txt`.

## Các chức năng đã hoàn thành

### 1. Quản lý quốc gia
- ✅ Đã loại bỏ hoàn toàn chức năng thêm/sửa/xóa quốc gia trong admin panel
- ✅ Đã thay thế bằng hiển thị danh sách quốc gia bằng thư viện JavaScript
- ✅ Đã thêm chức năng lấy danh sách quốc gia từ truyện đã có trong hệ thống

### 2. Chức năng bookmark nâng cao
- ✅ Đã thêm chức năng bookmark ở cấp độ chương
- ✅ Đã thêm API endpoint để cập nhật và kiểm tra trạng thái bookmark cho cả truyện và chương
- ✅ Đã chuẩn bị cơ sở để bookmark cho người dùng không đăng nhập

### 3. Quản lý API token
- ✅ Đã thêm chức năng quản lý API token trong Admin Panel
- ✅ Đã triển khai JWT làm cơ chế xác thực thay vì user/pass
- ✅ Đã thêm TokenModel và các controller cần thiết

### 4. Thuật toán thông minh cho truyện đề xuất
- ✅ Đã thay đổi "truyện hot" thành "truyện đề xuất"
- ✅ Đã triển khai thuật toán thông minh dựa trên nhiều yếu tố:
  - Lượt xem gần đây
  - Số lượng bình luận
  - Số lượng bookmark
  - Đánh giá trung bình
  - Thời gian cập nhật
  - Chương mới

### 5. Sửa layout admin
- ✅ Đã tạo file layouts/base.html làm cơ sở cho toàn bộ giao diện
- ✅ Đã cập nhật admin/layouts/admin.html để kế thừa từ layout cơ sở
- ✅ Đã cập nhật layouts/main.html để kế thừa từ layout cơ sở

### 6. Sử dụng JWT làm token
- ✅ Đã thêm middleware ApiAuthFilter để xác thực JWT token
- ✅ Đã cập nhật Routes.php để áp dụng filter cho các API endpoints cần xác thực
- ✅ Đã thiết lập Filters.php để đăng ký filter mới

### 7. Phân quyền và bảo mật
- ✅ Đã thêm phương thức kiểm tra quyền sở hữu tài nguyên vào BaseController
- ✅ Đã tạo requireResourceOwnership để ngăn chặn truy cập trái phép vào tài nguyên

### 8. Phân biệt tác giả và người đăng
- ✅ Đã tạo migration thêm trường author_name và uploader_id vào bảng stories
- ✅ Đã update StoryModel để hỗ trợ fields mới
- ✅ Đã cập nhật search_vector để tìm kiếm theo author_name

### 9. Bookmark không cần đăng nhập
- ✅ Đã tạo guest_bookmark.js để lưu trữ bookmark vào localStorage
- ✅ Đã tạo migration và SQL script để tạo bảng guest_bookmarks
- ✅ Đã triển khai đồng bộ giữa client và server

## Các chức năng đang triển khai

### 1. Cập nhật UI theo phân quyền
- 🔄 Đã thiết kế hệ thống 3 cấp phân quyền: Người sáng lập, Admin, Cộng tác viên
- 🔄 Cần cập nhật UI để hiển thị phù hợp với từng vai trò

### 2. Tích hợp Imgur API
- 🔄 Cần bổ sung post ảnh lên imgur qua API
- 🔄 Cần tích hợp vào editor WYSIWYG

### 3. WYSIWYG Editor
- 🔄 Cần chọn và tích hợp editor cho nội dung truyện
- 🔄 Cần tích hợp upload ảnh từ Imgur

## Các vấn đề và giải pháp

### Vấn đề phân biệt tác giả và người đăng
- **Vấn đề**: Hiện tại code đang nhầm lẫn giữa tác giả thật của truyện và người đăng truyện
- **Giải pháp**: ✅ Đã thêm trường `author_name` và `uploader_id` vào bảng `stories` để phân biệt rõ ràng

### Vấn đề bảo mật vượt quyền hạn
- **Vấn đề**: Chưa có kiểm tra quyền đầy đủ tại các endpoints
- **Giải pháp**: ✅ Đã triển khai:
  1. Middleware JWT cho API
  2. Phương thức kiểm tra quyền sở hữu trong BaseController
  3. Kiểm tra quyền theo role và quyền sở hữu tài nguyên

### Vấn đề đồng bộ bookmark cho khách
- **Vấn đề**: Bookmark của khách có thể mất khi xóa cookie/localStorage
- **Giải pháp**: ✅ Đã triển khai:
  1. Sử dụng kết hợp localStorage và cookie để lưu ID khách
  2. Lưu trữ bookmark trên server với guest_id
  3. Đồng bộ giữa client và server

## Khuyến nghị tiếp theo

1. **Ưu tiên cao**:
   - Hoàn thiện UI theo phân quyền trong các views
   - Tích hợp Imgur API cho tải lên ảnh
   - Tích hợp WYSIWYG editor

2. **Ưu tiên trung bình**:
   - Cập nhật giao diện để hiển thị rõ ràng sự phân biệt giữa tác giả và người đăng
   - Thêm unit tests cho các chức năng quan trọng
   - Hoàn thiện documentation cho API

3. **Ưu tiên thấp**:
   - Cải thiện UI/UX
   - Tối ưu hiệu suất truy vấn
   - Thêm dashboard thống kê

## Tóm tắt trạng thái

- **Số yêu cầu tổng**: 16 yêu cầu từ file log.txt
- **Đã hoàn thành**: 9 yêu cầu (56%)
- **Đang thực hiện**: 3 yêu cầu (19%)
- **Chưa bắt đầu**: 4 yêu cầu (25%)

Dự án đã tiến triển tốt với hơn 50% yêu cầu đã được hoàn thành. Các chức năng chính về bảo mật, phân quyền, và cấu trúc đã được triển khai. Các chức năng còn lại chủ yếu liên quan đến UI/UX và tích hợp với dịch vụ bên thứ ba.

Tham khảo các file `TODO.md` và `IMPLEMENTATION_GUIDE.md` để biết thêm chi tiết.
