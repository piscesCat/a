# Danh sách công việc cần làm tiếp theo

Dựa trên yêu cầu từ file `log.txt`, danh sách các công việc cần thực hiện:

## Đã hoàn thành
- [x] Xoá bỏ hoàn toàn chức năng tạo quốc gia trong admin panel và hiển thị danh sách quốc gia bằng thư viện js, sau đó truy vấn để hiển thị danh sách quốc gia ở header của những truyện có sẵn
- [x] Thêm bookmark ở chương
- [x] API token sẽ lấy ở Admin Panel thay vì sử dụng api với user pass
- [x] Truyện hot thay đổi thành truyện đề xuất kèm thuật toán thông minh
- [x] Sửa layout admin thành admin/layouts/admin.html
- [x] Cập nhật template theo sự thay đổi trên
- [x] Bảo mật không cho phép thao tác vượt quyền hạn
- [x] Phân biệt rõ ràng tác giả với người đăng (tài khoản đã đăng truyện) trong code đang bị nhầm lẫn
- [x] Chức năng bookmark cho bất kỳ người truy cập nào không cần đăng nhập vì mã nguồn không cho phép users đăng ky, đăng nhập
- [x] Sử dụng JWT làm token

## Cần thực hiện tiếp theo
- [ ] Thêm chức năng tạo thành viên dưới phân quyền thấp hơn người sáng lập (tài khoản đầu tiên được tạo lúc install) với 3 phân quyền: Người sáng lập, Admin, Cộng tác viên
- [ ] Áp dụng hiển thị và sử dụng chức năng cho từng phân quyền theo màu sắc trên web (ví dụ comments)
- [ ] Hoàn thành các chức năng đang làm dở
- [ ] Bổ sung post ảnh lên imgur qua api và trong mã nguồn
- [ ] Bổ sung bảng editor cho phần viết truyện có tuỳ chọn post ảnh mô tả nội dung
- [ ] Sửa template bao gồm css, jss, views là sửa hẳn nội dung file không bao gồm template của admin panel

## Chi tiết công việc

### 1. Hoàn thiện UI theo phân quyền
- Áp dụng UI phân quyền đã thiết kế vào tất cả giao diện
- Điều chỉnh hiển thị phù hợp với quyền của người dùng
- Kiểm tra màu sắc và trải nghiệm người dùng với mỗi nhóm quyền

### 2. Chức năng User Manager
- Cập nhật form tạo và chỉnh sửa người dùng có thêm role
- Cập nhật kiểm tra phân quyền trong các thao tác
- Chỉ người sáng lập mới được gán quyền Admin và quản lý người sáng lập khác

### 3. Editor cho Story và Chapter
- Tích hợp WYSIWYG editor (có thể dùng TinyMCE, CKEditor hoặc Quill)
- Thêm chức năng upload ảnh qua API Imgur
- Lưu token Imgur vào cài đặt hệ thống

### 4. Tích hợp Imgur API
- Tạo ImgurClient library theo hướng dẫn
- Tích hợp vào Editor
- Tạo API endpoint cho việc upload ảnh lên Imgur

### 5. Cải thiện giao diện
- Cập nhật CSS/JS cho phù hợp với chức năng mới
- Đảm bảo trải nghiệm người dùng nhất quán
- Tối ưu hóa responsive design

## Đã hoàn thành nhưng cần kiểm tra lại
- API Authentication với JWT - Đã triển khai nhưng cần test
- Phân quyền và kiểm tra bảo mật - Đã triển khai logic nhưng cần áp dụng vào từng controller cụ thể
- Guest Bookmark - Đã triển khai nhưng cần kiểm tra trải nghiệm người dùng

## Lưu ý
- Cập nhật file TODO.md sau mỗi lần có tiến độ để theo dõi công việc
- Các công việc có thể cần phân chia nhỏ hơn để quản lý tốt
- Ưu tiên các chức năng quan trọng trước: tích hợp Imgur API, WYSIWYG editor
