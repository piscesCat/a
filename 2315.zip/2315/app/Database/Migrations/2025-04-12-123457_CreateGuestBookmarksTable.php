<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateGuestBookmarksTable extends Migration
{
    public function up()
    {
        // Create guest_bookmarks table if it doesn't exist
        if (!$this->db->tableExists('guest_bookmarks')) {
            $this->forge->addField([
                'id' => [
                    'type' => 'INT',
                    'constraint' => 11,
                    'unsigned' => true,
                    'auto_increment' => true,
                ],
                'guest_id' => [
                    'type' => 'VARCHAR',
                    'constraint' => 100,
                    'null' => false,
                ],
                'story_id' => [
                    'type' => 'INT',
                    'constraint' => 11,
                    'null' => false,
                ],
                'chapter_id' => [
                    'type' => 'INT',
                    'constraint' => 11,
                    'null' => true,
                ],
                'created_at' => [
                    'type' => 'DATETIME',
                    'null' => true,
                ],
                'updated_at' => [
                    'type' => 'DATETIME',
                    'null' => true,
                ],
            ]);

            $this->forge->addKey('id', true);
            $this->forge->addKey('guest_id');
            $this->forge->addKey('story_id');
            $this->forge->addKey('chapter_id');
            $this->forge->addUniqueKey(['guest_id', 'story_id']);
            $this->forge->addForeignKey('story_id', 'stories', 'id', 'CASCADE', 'CASCADE');
            $this->forge->addForeignKey('chapter_id', 'chapters', 'id', 'SET NULL', 'CASCADE');
            $this->forge->createTable('guest_bookmarks');
        }
    }

    public function down()
    {
        // Drop the table if it exists
        if ($this->db->tableExists('guest_bookmarks')) {
            $this->forge->dropTable('guest_bookmarks');
        }
    }
}
