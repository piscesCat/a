# Novel Application

A web application for managing and reading novels, stories, and other literature. This application provides a platform for users to browse, read, and bookmark stories, as well as for authors to publish their work.

## Project Structure

The project follows the CodeIgniter 4 MVC architecture:

- `app/Controllers/` - Contains all controllers that handle user requests
- `app/Models/` - Contains all models that interact with the database
- `app/Views/` - Contains all views (templates) for rendering HTML
- `app/Config/` - Contains configuration files
- `public/` - Public web root directory

## Completed Tasks

1. **Database Setup Improvement**
   - Consolidated multiple SQL files into a single unified schema file
   - Moved SQL files to the installation directory
   - Modified installation process to use the consolidated schema file
   - Added database procedure for automated cleanup

2. **Missing Features Implementation**
   - Added recommended stories feature
   - Added latest stories feature
   - Added completed stories feature
   - Created views for these features

3. **Database Maintenance Integration**
   - Created a database maintenance controller
   - Implemented cleanup procedure for automated database maintenance
   - Added command-line interface for cron job integration
   - Added statistics reset functionality

4. **Analysis**
   - Performed security analysis and documented findings
   - Identified missing functionality and documented it
   - Created comprehensive analysis document with recommendations

## Installation

1. Clone the repository
2. Configure the database connection in `app/Config/Database.php`
3. Run the installer at `public/install/`
4. Follow the installation steps to create the database and admin account

## Configuration

### Cron Jobs

To automate database maintenance, add the following cron jobs on your server:

```bash
# Reset daily views at midnight every day
0 0 * * * cd /path/to/project && php spark maintenance reset-daily

# Reset weekly views at midnight on Mondays
0 0 * * 1 cd /path/to/project && php spark maintenance reset-weekly

# Reset monthly views at midnight on the first day of each month
0 0 1 * * cd /path/to/project && php spark maintenance reset-monthly

# Run database cleanup at 3 AM every Sunday
0 3 * * 0 cd /path/to/project && php spark maintenance cleanup

# Update recommended stories at 4 AM every day
0 4 * * * cd /path/to/project && php spark maintenance update-recommended
```

## Future Improvements

See the following files for detailed information on future improvements:

- `security_analysis.md` - Security vulnerabilities and recommended fixes
- `missing_functionality.md` - Missing features and components
- `analysis.md` - Overall analysis and recommendations

## Main Features

- Browse stories by category, country, or author
- Search for stories with full-text search
- Read stories chapter by chapter
- Bookmark stories for later reading
- Rate and comment on stories
- User authentication and authorization
- Admin panel for content management

## Tech Stack

- PHP 7.4+
- PostgreSQL
- CodeIgniter 4
- HTML/CSS/JavaScript
- Bootstrap 5
- jQuery

## License

Copyright © 2025
