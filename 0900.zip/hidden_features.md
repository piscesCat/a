# Chức Năng Ẩn Trong Ứng Dụng

Tài liệu này liệt kê các chức năng ẩn trong hệ thống - những chức năng đã được phát triển một phần (có model) nhưng thiếu hoặc không đầy đủ controller và view.

## 1. Hệ Thống Nhật Ký (Logs)

**Model**: `LogModel.php`
**Trạng thái**: ✅ Có controller Admin nhưng thiếu view cho người dùng thông thường

**Chức năng có sẵn**:
- Ghi nhật ký hệ thống với các mức độ khác nhau (info, error, warning, debug)
- Quản lý nhật ký trong admin panel
- Xóa nhật ký cũ tự động

**Thiếu**:
- Giao diện hiển thị nhật ký cho người dùng thông thường
- Bộ lọc và tìm kiếm nâng cao cho nhật ký
- Xuất nhật ký dưới dạng CSV/PDF

## 2. Hệ Thống Quản Lý Tệp (Media)

**Model**: `MediaModel.php`
**Trạng thái**: ⚠️ Thiếu controller và view dành riêng cho người dùng

**Chức năng có sẵn**:
- API để tải lên tệp
- Lưu trữ và quản lý tệp đa phương tiện
- Quản lý tệp trong trang admin

**Thiếu**:
- Trang quản lý tệp dành cho người dùng thông thường
- Chức năng chia sẻ tệp giữa các người dùng
- Giao diện xem trước tệp đa phương tiện
- Bảo vệ tệp và phân quyền truy cập

## 3. Hệ Thống Xác Thực API (Token)

**Model**: `TokenModel.php`
**Trạng thái**: ✅ Có controllers nhưng thiếu views cho người dùng thông thường

**Chức năng có sẵn**:
- Tạo token JWT cho API
- Xác thực token
- Quản lý token trong admin panel
- Endpoint API để tạo và quản lý token

**Thiếu**:
- Giao diện cho người dùng thông thường để quản lý API token của họ
- Tài liệu API cho người dùng
- Khả năng thiết lập phạm vi (scope) cho token
- Thống kê sử dụng API

## 4. Đánh Dấu Truyện Cho Khách (Guest Bookmarks)

**Model**: `GuestBookmarkModel.php`
**Trạng thái**: ✅ Có đầy đủ controller nhưng cần cải thiện views

**Chức năng có sẵn**:
- Lưu bookmark cho người dùng không đăng nhập
- Cập nhật tiến trình đọc
- Chuyển bookmark từ khách sang người dùng sau khi đăng nhập

**Thiếu**:
- Giao diện đầy đủ để quản lý bookmark cho khách
- Đồng bộ hóa bookmark qua các thiết bị
- Thông báo khi có cập nhật cho truyện được đánh dấu

## 5. Đề Xuất Truyện Thông Minh

**Model**: Phương thức `getRecommendedStories()` và `updateRecommendedStories()` trong `StoryModel.php`
**Trạng thái**: ⚠️ Có thuật toán trong model nhưng thiếu controllers và views chuyên dụng

**Chức năng có sẵn**:
- Thuật toán đề xuất truyện dựa trên nhiều tiêu chí
- Phương thức tự động cập nhật truyện đề xuất
- Cron job để chạy cập nhật định kỳ

**Thiếu**:
- Giao diện tùy chỉnh đề xuất dựa trên sở thích người dùng
- Đề xuất cá nhân hóa dựa trên lịch sử đọc
- Giải thích lý do đề xuất

## 6. Hệ Thống Báo Cáo (Reports)

**Model**: Không có model chuyên dụng, nhưng có controller `Admin/Reports.php`
**Trạng thái**: ⚠️ Có controller nhưng thiếu model và views đầy đủ

**Chức năng có sẵn**:
- Controller để xem báo cáo trong admin panel
- Một số báo cáo cơ bản về hoạt động hệ thống

**Thiếu**:
- Model chuyên dụng cho hệ thống báo cáo
- Báo cáo chi tiết về hành vi người dùng
- Khả năng xuất báo cáo
- Biểu đồ và trực quan hóa dữ liệu

## 7. Hệ Thống Đánh Giá (Ratings)

**Model**: Phương thức `updateRating()` trong `StoryModel.php`
**Trạng thái**: ⚠️ Có cơ chế cơ bản nhưng thiếu controllers và views chuyên dụng

**Chức năng có sẵn**:
- Lưu trữ đánh giá cơ bản
- Cập nhật điểm đánh giá trung bình

**Thiếu**:
- Model chuyên dụng cho hệ thống đánh giá
- Giao diện đánh giá chi tiết (nhiều tiêu chí)
- Phân tích đánh giá người dùng
- Bình luận kèm đánh giá

## 8. Chỉ Mục Tìm Kiếm (Search Index)

**Model**: Phương thức `ensureSearchVectorColumn()` và `updateSearchVectors()` trong `StoryModel.php`
**Trạng thái**: ⚠️ Triển khai cơ bản nhưng thiếu giao diện tìm kiếm nâng cao

**Chức năng có sẵn**:
- Full-text search cơ bản
- Cập nhật vector tìm kiếm tự động
- Đánh chỉ mục cho tìm kiếm

**Thiếu**:
- Giao diện tìm kiếm nâng cao
- Hiển thị kết quả tìm kiếm cải tiến
- Đề xuất từ khóa tìm kiếm
- Lịch sử tìm kiếm của người dùng

## 9. Hệ Thống Backup

**Model**: `BackupModel.php`
**Trạng thái**: ✅ Có controller admin nhưng không có tùy chỉnh nâng cao

**Chức năng có sẵn**:
- Sao lưu và phục hồi database
- Quản lý các bản sao lưu trong admin panel

**Thiếu**:
- Lập lịch sao lưu tự động
- Sao lưu tăng dần
- Nén và mã hóa bản sao lưu
- Sao lưu đám mây

## 10. Dọn Dẹp Cơ Sở Dữ Liệu

**Model**: Phương thức `resetDailyViews()`, `resetWeeklyViews()`, `resetMonthlyViews()` trong `StoryModel.php`
**Trạng thái**: ✅ Đã được triển khai qua DatabaseMaintenance controller và cron jobs

**Chức năng có sẵn**:
- Quy trình dọn dẹp dữ liệu tự động
- Đặt lại thống kê định kỳ
- Cron job integration

**Thiếu**:
- Giao diện tùy chỉnh lịch trình dọn dẹp
- Báo cáo về không gian đã giải phóng
- Xem trước và chọn lọc dọn dẹp

## Đề Xuất Triển Khai

Dựa trên phân tích trên, dưới đây là các chức năng ưu tiên nên được phát triển hoàn chỉnh:

1. **Hệ Thống Quản Lý Tệp (Media)** - Ưu tiên cao vì ảnh hưởng trực tiếp đến trải nghiệm người dùng trong việc quản lý nội dung đa phương tiện.

2. **Hệ Thống Đánh Giá (Ratings)** - Cần model và giao diện đánh giá riêng để cải thiện tương tác người dùng.

3. **Đề Xuất Truyện Thông Minh** - Cá nhân hóa đề xuất sẽ giúp người dùng khám phá nội dung phù hợp hơn.

4. **Giao Diện Tìm Kiếm Nâng Cao** - Cải thiện tìm kiếm sẽ giúp người dùng dễ dàng tìm thấy nội dung họ quan tâm.

5. **Hệ Thống Báo Cáo (Reports)** - Cung cấp công cụ phân tích nâng cao cho quản trị viên.
