-- UNIFIED DATABASE SETUP SCRIPT
-- Combines: unified_schema.sql, remove_unused_db_elements.sql, cleanup.sql

-- =========================================
-- DATABASE SCHEMA (unified_schema.sql)
-- =========================================

-- CORE TABLES
-- =========================================

-- Users table
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role SMALLINT NOT NULL DEFAULT 1, -- 1: Cộng tác viên, 2: Admin, 3: Người sáng lập
    status VARCHAR(20) NOT NULL DEFAULT 'active',
    avatar VARCHAR(255),
    bio TEXT,
    last_login TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Countries table - Bảng quốc gia
CREATE TABLE countries (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    flag_image VARCHAR(255),
    region VARCHAR(50) DEFAULT 'Other', -- Khu vực
    code VARCHAR(10), -- Mã quốc gia
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Categories table
CREATE TABLE categories (
    id SERIAL PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    slug VARCHAR(50) NOT NULL UNIQUE,
    description TEXT,
    parent_id INTEGER REFERENCES categories(id) ON DELETE SET NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Stories table - Đổi tên từ novels để phù hợp với bối cảnh
CREATE TABLE stories (
    id SERIAL PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    slug VARCHAR(200) NOT NULL UNIQUE,
    description TEXT,
    cover_image VARCHAR(255),
    author_name VARCHAR(100), -- Tên tác giả thật
    uploader_id INTEGER REFERENCES users(id) ON DELETE SET NULL, -- Người đăng truyện
    status VARCHAR(20) NOT NULL DEFAULT 'draft',
    views INTEGER DEFAULT 0,
    views_day INTEGER DEFAULT 0, -- Lượt xem trong ngày
    views_week INTEGER DEFAULT 0, -- Lượt xem trong tuần
    views_month INTEGER DEFAULT 0, -- Lượt xem trong tháng
    rating DECIMAL(3,2) DEFAULT 0,
    total_ratings INTEGER DEFAULT 0, -- Tổng số đánh giá
    total_favorites INTEGER DEFAULT 0, -- Tổng số yêu thích
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    type VARCHAR(50), -- Loại truyện (phim lẻ, phim bộ, review)
    country_id INTEGER REFERENCES countries(id) ON DELETE SET NULL, -- Quốc gia
    release_year INTEGER, -- Năm phát hành
    is_featured BOOLEAN DEFAULT FALSE, -- Nổi bật
    is_recommended BOOLEAN DEFAULT FALSE, -- Đề xuất (thay thế cho is_hot)
    is_completed BOOLEAN DEFAULT FALSE, -- Hoàn thành
    search_vector TSVECTOR -- Vector tìm kiếm full-text
);

-- Story categories relationship
CREATE TABLE story_categories (
    story_id INTEGER REFERENCES stories(id) ON DELETE CASCADE,
    category_id INTEGER REFERENCES categories(id) ON DELETE CASCADE,
    PRIMARY KEY (story_id, category_id)
);

-- Chapters table
CREATE TABLE chapters (
    id SERIAL PRIMARY KEY,
    story_id INTEGER REFERENCES stories(id) ON DELETE CASCADE,
    chapter_number INTEGER NOT NULL,
    title VARCHAR(200) NOT NULL,
    content TEXT NOT NULL,
    views INTEGER DEFAULT 0,
    status VARCHAR(20) NOT NULL DEFAULT 'draft',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (story_id, chapter_number)
);

-- =========================================
-- USER INTERACTION TABLES
-- =========================================

-- Bookmarks table
CREATE TABLE bookmarks (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    story_id INTEGER REFERENCES stories(id) ON DELETE CASCADE,
    chapter_id INTEGER REFERENCES chapters(id) ON DELETE SET NULL, -- Chương đang đọc
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (user_id, story_id)
);

-- Guest bookmarks table - Thêm bảng guest_bookmarks để hỗ trợ đánh dấu truyện cho khách
CREATE TABLE guest_bookmarks (
    id SERIAL PRIMARY KEY,
    guest_id VARCHAR(100) NOT NULL,
    story_id INTEGER NOT NULL REFERENCES stories(id) ON DELETE CASCADE,
    chapter_id INTEGER REFERENCES chapters(id) ON DELETE SET NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT guest_bookmarks_guest_story_unique UNIQUE (guest_id, story_id)
);

-- Reading progress table
CREATE TABLE reading_progress (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    story_id INTEGER REFERENCES stories(id) ON DELETE CASCADE,
    chapter_id INTEGER REFERENCES chapters(id) ON DELETE CASCADE,
    last_read TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (user_id, story_id)
);

-- Ratings table
CREATE TABLE ratings (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    story_id INTEGER REFERENCES stories(id) ON DELETE CASCADE,
    rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (user_id, story_id)
);

-- Comments table
CREATE TABLE comments (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE SET NULL, -- Cho phép bình luận không cần đăng nhập (NULL)
    story_id INTEGER REFERENCES stories(id) ON DELETE CASCADE,
    chapter_id INTEGER REFERENCES chapters(id) ON DELETE CASCADE,
    content TEXT NOT NULL,
    guest_name VARCHAR(100), -- Tên người bình luận khách
    guest_email VARCHAR(100), -- Email người bình luận khách
    parent_id INTEGER REFERENCES comments(id) ON DELETE CASCADE, -- ID bình luận cha (nếu là reply)
    is_admin_reply BOOLEAN DEFAULT FALSE, -- Đánh dấu nếu là reply từ admin
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- User activities table
CREATE TABLE activities (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    action VARCHAR(100) NOT NULL,
    details JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =========================================
-- SYSTEM TABLES
-- =========================================

-- Site settings table - Thêm bảng cài đặt cho trang web
CREATE TABLE settings (
    id VARCHAR(50) PRIMARY KEY,
    value TEXT NOT NULL,
    description TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tokens table - Bảng lưu trữ tokens xác thực API
CREATE TABLE tokens (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token VARCHAR(255) NOT NULL UNIQUE,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Media table - Quản lý tệp đa phương tiện
CREATE TABLE media (
    id SERIAL PRIMARY KEY,
    file_name VARCHAR(255) NOT NULL,
    file_path VARCHAR(255) NOT NULL,
    file_type VARCHAR(50) NOT NULL,
    file_size INTEGER NOT NULL,
    user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Backups table - Quản lý các bản sao lưu
CREATE TABLE backups (
    id SERIAL PRIMARY KEY,
    file_name VARCHAR(255) NOT NULL,
    file_path VARCHAR(255) NOT NULL,
    file_size INTEGER NOT NULL,
    description TEXT,
    user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- System logs table - Nhật ký hệ thống
CREATE TABLE logs (
    id SERIAL PRIMARY KEY,
    level VARCHAR(20) NOT NULL,
    message TEXT NOT NULL,
    context JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- System changes table - Theo dõi các thay đổi hệ thống
CREATE TABLE system_changes (
    id SERIAL PRIMARY KEY,
    change_type VARCHAR(50) NOT NULL,
    description TEXT NOT NULL,
    sql_query TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =========================================
-- INDEXES
-- =========================================

-- Indexes for stories table
CREATE INDEX idx_stories_slug ON stories(slug);
CREATE INDEX idx_stories_uploader_id ON stories(uploader_id);
CREATE INDEX idx_stories_country ON stories(country_id);
CREATE INDEX idx_stories_is_recommended ON stories(is_recommended);

-- Indexes for chapters table
CREATE INDEX idx_chapters_story ON chapters(story_id);

-- Indexes for categories table
CREATE INDEX idx_categories_slug ON categories(slug);

-- Indexes for countries table
CREATE INDEX idx_countries_slug ON countries(slug);

-- Indexes for bookmarks table
CREATE INDEX idx_bookmarks_user ON bookmarks(user_id);
CREATE INDEX idx_bookmarks_story ON bookmarks(story_id);

-- Indexes for guest_bookmarks table
CREATE INDEX idx_guest_bookmarks_guest_id ON guest_bookmarks(guest_id);
CREATE INDEX idx_guest_bookmarks_story_id ON guest_bookmarks(story_id);
CREATE INDEX idx_guest_bookmarks_chapter_id ON guest_bookmarks(chapter_id);

-- Indexes for reading_progress table
CREATE INDEX idx_reading_progress_user ON reading_progress(user_id);

-- Indexes for comments table
CREATE INDEX idx_comments_story ON comments(story_id);
CREATE INDEX idx_comments_chapter ON comments(chapter_id);
CREATE INDEX idx_comments_parent ON comments(parent_id);

-- Indexes for activities table
CREATE INDEX idx_activities_user ON activities(user_id);

-- Indexes for tokens table
CREATE INDEX idx_tokens_user_id ON tokens(user_id);

-- =========================================
-- TRIGGERS
-- =========================================

-- Trigger function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger function for search vector
CREATE OR REPLACE FUNCTION stories_vector_update() RETURNS TRIGGER AS $$
BEGIN
    NEW.search_vector := to_tsvector('english',
        coalesce(NEW.title, '') || ' ' ||
        coalesce(NEW.description, '') || ' ' ||
        coalesce(NEW.author_name, '')
    );
    RETURN NEW;
END
$$ LANGUAGE plpgsql;

-- Apply trigger to stories table for updated_at
CREATE TRIGGER update_stories_updated_at
    BEFORE UPDATE ON stories
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- Apply trigger to stories table for search_vector
CREATE TRIGGER stories_vector_update
    BEFORE INSERT OR UPDATE ON stories
    FOR EACH ROW
    EXECUTE FUNCTION stories_vector_update();

-- Apply triggers to other tables for updated_at
CREATE TRIGGER update_chapters_updated_at
    BEFORE UPDATE ON chapters
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_users_updated_at
    BEFORE UPDATE ON users
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_countries_updated_at
    BEFORE UPDATE ON countries
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_bookmarks_updated_at
    BEFORE UPDATE ON bookmarks
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_guest_bookmarks_updated_at
    BEFORE UPDATE ON guest_bookmarks
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_comments_updated_at
    BEFORE UPDATE ON comments
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- =========================================
-- DEFAULT DATA
-- =========================================

-- Insert default admin user (password: admin123) with role=3 (Founder)
INSERT INTO users (username, email, password, role, status)
VALUES ('admin', 'admin@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 3, 'active');

-- Insert some default countries
INSERT INTO countries (name, slug, description, region, code)
VALUES
    ('Việt Nam', 'viet-nam', 'Truyện Việt Nam', 'Asia', 'VN'),
    ('Hàn Quốc', 'han-quoc', 'Truyện Hàn Quốc', 'Asia', 'KR'),
    ('Trung Quốc', 'trung-quoc', 'Truyện Trung Quốc', 'Asia', 'CN'),
    ('Mỹ', 'my', 'Truyện Mỹ', 'North America', 'US'),
    ('Nhật Bản', 'nhat-ban', 'Truyện Nhật Bản', 'Asia', 'JP'),
    ('Thái Lan', 'thai-lan', 'Truyện Thái Lan', 'Asia', 'TH'),
    ('Ấn Độ', 'an-do', 'Truyện Ấn Độ', 'Asia', 'IN'),
    ('Anh', 'anh', 'Truyện Anh', 'Europe', 'GB'),
    ('Pháp', 'phap', 'Truyện Pháp', 'Europe', 'FR'),
    ('Đài Loan', 'dai-loan', 'Truyện Đài Loan', 'Asia', 'TW');

-- Insert some default categories
INSERT INTO categories (name, slug, description)
VALUES
    ('Hành Động', 'hanh-dong', 'Truyện hành động'),
    ('Võ Thuật', 'vo-thuat', 'Truyện võ thuật'),
    ('Tình Cảm', 'tinh-cam', 'Truyện tình cảm'),
    ('Hoạt Hình', 'hoat-hinh', 'Truyện hoạt hình'),
    ('Viễn Tưởng', 'vien-tuong', 'Truyện viễn tưởng'),
    ('Khoa Học', 'khoa-hoc', 'Truyện khoa học'),
    ('Phiêu Lưu', 'phieu-luu', 'Truyện phiêu lưu'),
    ('Hài Hước', 'hai-huoc', 'Truyện hài hước'),
    ('Kinh Dị', 'kinh-di', 'Truyện kinh dị'),
    ('Tâm Lý', 'tam-ly', 'Truyện tâm lý'),
    ('Chiến Tranh', 'chien-tranh', 'Truyện chiến tranh'),
    ('Cổ Trang', 'co-trang', 'Truyện cổ trang'),
    ('Hình Sự', 'hinh-su', 'Truyện hình sự');

-- Insert default settings
INSERT INTO settings (id, value, description)
VALUES
    ('site_name', 'Web Truyện', 'Tên trang web'),
    ('site_description', 'Trang web truyện hay, cập nhật thông tin truyện mới nhất', 'Mô tả trang web'),
    ('site_keywords', 'truyện, truyện hay, truyện mới', 'Từ khóa trang web'),
    ('site_logo', '/assets/images/logo.png', 'Logo trang web'),
    ('site_favicon', '/assets/images/favicon.ico', 'Favicon trang web'),
    ('site_header', '<h1>Web Truyện</h1>', 'Tiêu đề header mặc định'),
    ('site_footer', '© 2025 Web Truyện - Tất cả quyền được bảo lưu', 'Nội dung footer mặc định'),
    ('story_title_template', '[title] - [year] | [country]', 'Mẫu tiêu đề mặc định cho truyện'),
    ('story_description_template', 'Truyện [title] [year] - [country] thuộc thể loại [categories]. Truyện do [author] đánh giá.', 'Mẫu mô tả mặc định cho truyện'),
    ('chapter_title_template', 'Chương [number]: [title] - [story_title]', 'Mẫu tiêu đề mặc định cho chương'),
    ('chapter_description_template', 'Đọc chương [number]: [title] của truyện [story_title]', 'Mẫu mô tả mặc định cho chương'),
    ('max_featured_stories', '6', 'Số lượng truyện nổi bật hiển thị trên trang chủ'),
    ('max_latest_stories', '12', 'Số lượng truyện mới nhất hiển thị trên trang chủ'),
    ('max_popular_stories', '5', 'Số lượng truyện phổ biến hiển thị trên trang chủ'),
    ('max_completed_stories', '6', 'Số lượng truyện đã hoàn thành hiển thị trên trang chủ'),
    ('max_guest_bookmarks', '50', 'Số lượng bookmark tối đa cho khách'),
    ('smtp_host', '', 'SMTP host'),
    ('smtp_port', '587', 'SMTP port'),
    ('smtp_user', '', 'SMTP username'),
    ('smtp_pass', '', 'SMTP password'),
    ('smtp_from', '', 'SMTP from email'),
    ('maintenance_mode', 'off', 'Chế độ bảo trì'),
    ('register_enabled', 'off', 'Cho phép đăng ký tài khoản mới'),
    ('comments_enabled', 'on', 'Cho phép bình luận'),
    ('guest_comments_enabled', 'on', 'Cho phép bình luận không cần đăng nhập'),
    ('analytics_code', '', 'Mã Google Analytics'),
    ('recaptcha_site_key', '', 'Google reCAPTCHA site key'),
    ('recaptcha_secret_key', '', 'Google reCAPTCHA secret key'),
    ('social_facebook', '', 'Đường dẫn Facebook'),
    ('social_twitter', '', 'Đường dẫn Twitter'),
    ('social_youtube', '', 'Đường dẫn YouTube'),
    ('social_instagram', '', 'Đường dẫn Instagram'),
    ('imgur_client_id', '', 'Imgur Client ID');

-- Ghi nhận việc tạo schema thống nhất
INSERT INTO system_changes (change_type, description, sql_query, created_at)
VALUES ('structure', 'Unified database schema created', 'Created unified schema with install script', CURRENT_TIMESTAMP);

-- =========================================
-- CLEANUP PROCEDURES (From cleanup.sql)
-- =========================================

-- Create a procedure for database cleanup to be used with cron jobs
CREATE OR REPLACE PROCEDURE cleanup_database()
LANGUAGE plpgsql
AS $$
BEGIN
    -- 1. Remove guest bookmarks older than 3 months (90 days)
    DELETE FROM guest_bookmarks
    WHERE updated_at < CURRENT_TIMESTAMP - INTERVAL '90 days';

    -- 2. Remove expired tokens
    DELETE FROM tokens
    WHERE expires_at < CURRENT_TIMESTAMP;

    -- 3. Remove old system logs (older than 30 days, except 'error' level logs which we keep for 90 days)
    DELETE FROM logs
    WHERE (level != 'error' AND created_at < CURRENT_TIMESTAMP - INTERVAL '30 days')
       OR (level = 'error' AND created_at < CURRENT_TIMESTAMP - INTERVAL '90 days');

    -- 4. Remove old system changes records (older than 1 year)
    DELETE FROM system_changes
    WHERE created_at < CURRENT_TIMESTAMP - INTERVAL '1 year';

    -- 5. Remove old backups (keep only the 10 most recent ones)
    DELETE FROM backups
    WHERE id NOT IN (
        SELECT id FROM backups
        ORDER BY created_at DESC
        LIMIT 10
    );

    -- 6. Remove old user activities (older than 60 days)
    DELETE FROM activities
    WHERE created_at < CURRENT_TIMESTAMP - INTERVAL '60 days';

    -- 7. Clean up orphaned comments (comments on deleted stories/chapters)
    DELETE FROM comments
    WHERE (story_id IS NOT NULL AND story_id NOT IN (SELECT id FROM stories))
       OR (chapter_id IS NOT NULL AND chapter_id NOT IN (SELECT id FROM chapters));

    -- 8. Remove unused/orphaned media files
    DELETE FROM media
    WHERE (user_id IS NULL OR user_id NOT IN (SELECT id FROM users))
      AND created_at < CURRENT_TIMESTAMP - INTERVAL '30 days';

    -- 9. Limit guest bookmarks per guest_id to respect max_guest_bookmarks setting
    DECLARE
        max_bookmarks INTEGER;
    BEGIN
        SELECT CAST(value AS INTEGER) INTO max_bookmarks FROM settings WHERE id = 'max_guest_bookmarks';
        IF max_bookmarks IS NULL THEN
            max_bookmarks := 50; -- Default if setting not found
        END IF;

        -- For each guest with more than max_bookmarks bookmarks, delete the oldest ones
        FOR guest IN SELECT DISTINCT guest_id FROM guest_bookmarks LOOP
            DELETE FROM guest_bookmarks
            WHERE id IN (
                SELECT id FROM guest_bookmarks
                WHERE guest_id = guest.guest_id
                ORDER BY updated_at ASC
                OFFSET max_bookmarks
            );
        END LOOP;
    END;

    -- 10. Remove stories that are in draft status for more than 6 months and have no chapters
    DELETE FROM stories
    WHERE status = 'draft'
      AND created_at < CURRENT_TIMESTAMP - INTERVAL '180 days'
      AND NOT EXISTS (SELECT 1 FROM chapters WHERE chapters.story_id = stories.id);

    -- Log the cleanup action
    INSERT INTO logs (level, message, context, created_at)
    VALUES ('info', 'Database cleanup procedure executed', '{"automatic": true}', CURRENT_TIMESTAMP);

END;
$$;
