<div class="alert alert-info">
    <i class="fas fa-info-circle"></i> Vui lòng nhập thông tin kết nối đến cơ sở dữ liệu PostgreSQL. Bạn cần tạo cơ sở dữ liệu trước khi thực hiện bước này.
</div>

<form method="post" action="">
    <input type="hidden" name="step" value="2">

    <h5 class="mb-3">Cấu hình Cơ sở dữ liệu</h5>

    <div class="mb-3">
        <label for="db_hostname" class="form-label">Hostname:</label>
        <input type="text" class="form-control" id="db_hostname" name="db_hostname" value="<?= $_SESSION['input']['db_hostname'] ?? 'localhost' ?>" required>
        <div class="form-text">Thường là "localhost" hoặc địa chỉ IP của máy chủ PostgreSQL.</div>
    </div>

    <div class="mb-3">
        <label for="db_port" class="form-label">Port:</label>
        <input type="number" class="form-control" id="db_port" name="db_port" value="<?= $_SESSION['input']['db_port'] ?? '5432' ?>" required>
        <div class="form-text">Port mặc định của PostgreSQL là 5432.</div>
    </div>

    <div class="mb-3">
        <label for="db_name" class="form-label">Tên database:</label>
        <input type="text" class="form-control" id="db_name" name="db_name" value="<?= $_SESSION['input']['db_name'] ?? '' ?>" required>
        <div class="form-text">Database phải được tạo trước khi cài đặt.</div>
    </div>

    <div class="mb-3">
        <label for="db_username" class="form-label">Tên đăng nhập:</label>
        <input type="text" class="form-control" id="db_username" name="db_username" value="<?= $_SESSION['input']['db_username'] ?? 'postgres' ?>" required>
    </div>

    <div class="mb-3">
        <label for="db_password" class="form-label">Mật khẩu:</label>
        <input type="password" class="form-control" id="db_password" name="db_password" value="<?= $_SESSION['input']['db_password'] ?? '' ?>">
    </div>

    <hr class="my-4">

    <h5 class="mb-3">Cấu hình Upload và API (File .env)</h5>

    <div class="mb-3">
        <label for="app_name" class="form-label">Tên ứng dụng:</label>
        <input type="text" class="form-control" id="app_name" name="app_name" value="<?= $_SESSION['input']['app_name'] ?? 'WebTruyen' ?>">
        <div class="form-text">Tên ứng dụng sẽ được sử dụng trong các email và thông báo.</div>
    </div>

    <div class="mb-3">
        <label for="app_url" class="form-label">URL ứng dụng:</label>
        <input type="text" class="form-control" id="app_url" name="app_url" value="<?= $_SESSION['input']['app_url'] ?? rtrim(BASE_URL, '/') ?>">
        <div class="form-text">URL đầy đủ đến trang web của bạn, không có dấu / ở cuối.</div>
    </div>

    <div class="mb-3">
        <label for="imgur_client_id" class="form-label">Imgur Client ID:</label>
        <input type="text" class="form-control" id="imgur_client_id" name="imgur_client_id" value="<?= $_SESSION['input']['imgur_client_id'] ?? '' ?>">
        <div class="form-text">Client ID từ Imgur API để upload ảnh lên Imgur (không bắt buộc).</div>
    </div>

    <div class="mb-3">
        <label for="imgur_client_secret" class="form-label">Imgur Client Secret:</label>
        <input type="text" class="form-control" id="imgur_client_secret" name="imgur_client_secret" value="<?= $_SESSION['input']['imgur_client_secret'] ?? '' ?>">
        <div class="form-text">Client Secret từ Imgur API (không bắt buộc).</div>
    </div>

    <div class="mb-3">
        <label for="app_key" class="form-label">App Key (bảo mật):</label>
        <input type="text" class="form-control" id="app_key" name="app_key" value="<?= $_SESSION['input']['app_key'] ?? bin2hex(random_bytes(16)) ?>">
        <div class="form-text">Khóa bảo mật cho ứng dụng, được tạo ngẫu nhiên.</div>
    </div>

    <div class="alert alert-warning">
        <i class="fas fa-exclamation-triangle"></i> Lưu ý: Khi bạn tiếp tục, hệ thống sẽ tạo các bảng cần thiết trong database và file cấu hình .env. Hãy đảm bảo rằng bạn đã sao lưu dữ liệu quan trọng (nếu có).
    </div>

    <div class="d-flex justify-content-between">
        <a href="<?= BASE_URL ?>install" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Quay lại
        </a>

        <button type="submit" class="btn btn-primary">
            Tiếp tục <i class="fas fa-arrow-right"></i>
        </button>
    </div>
</form>
