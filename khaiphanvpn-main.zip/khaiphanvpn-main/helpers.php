<?php

/**
 * Load environment variables from .env file
 */
function loadEnv() {
    $envFile = __DIR__ . '/.env';

    if (file_exists($envFile)) {
        $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

        foreach ($lines as $line) {
            // Skip comments
            if (strpos(trim($line), '#') === 0) {
                continue;
            }

            // Parse variable
            list($name, $value) = explode('=', $line, 2);
            $name = trim($name);
            $value = trim($value);

            // Handle array values
            if (strpos($value, '[') === 0 && strrpos($value, ']') === strlen($value) - 1) {
                $arrayValue = substr($value, 1, -1);
                $items = parseArrayItems($arrayValue);
                $_ENV[$name] = $items;
                putenv("$name=" . json_encode($items));
            } else {
                // Handle regular values
                $_ENV[$name] = $value;
                putenv("$name=$value");
            }
        }
    }
}

/**
 * Parse array items from .env file
 */
function parseArrayItems($arrayString) {
    $items = [];
    $inQuote = false;
    $currentItem = '';
    $quoteChar = '';

    for ($i = 0; $i < strlen($arrayString); $i++) {
        $char = $arrayString[$i];

        if (($char === '"' || $char === "'") && ($i === 0 || $arrayString[$i-1] !== '\\')) {
            if (!$inQuote) {
                $inQuote = true;
                $quoteChar = $char;
            } elseif ($char === $quoteChar) {
                $inQuote = false;
                $items[] = $currentItem;
                $currentItem = '';
                // Skip the comma after the quote
                $i++;
            } else {
                $currentItem .= $char;
            }
        } elseif ($char === ',' && !$inQuote) {
            if (trim($currentItem) !== '') {
                $items[] = trim($currentItem);
                $currentItem = '';
            }
        } else {
            $currentItem .= $char;
        }
    }

    // Add the last item if it exists
    if (trim($currentItem) !== '') {
        $items[] = trim($currentItem);
    }

    return array_map('trim', $items);
}

/**
 * Get environment variable
 */
function env($key) {
    $value = getenv($key);

    if ($value === false) {
        return null;
    }

    // Check if value is JSON (for arrays)
    if (strpos($value, '[') === 0 || strpos($value, '{') === 0) {
        return json_decode($value, true);
    }

    return $value;
}

// Load environment variables
loadEnv();
