<?php
require 'geoip2.phar';

use GeoIp2\Database\Reader;

function getGroupFromUrl(array $urls) {
    $groups = [];
    
    foreach ($urls as $url) {
        $serverIP = null;

        if (strpos($url, 'vmess://') === 0) {
            $decoded = json_decode(base64_decode(str_replace('vmess://', '', $url)), true);
            if (isset($decoded['add'])) {
                $serverIP = resolveHostname($decoded['add']);
            }
        } elseif (strpos($url, 'vless://') === 0 || strpos($url, 'trojan://') === 0) {
            $parsedUrl = parse_url($url);
            if (isset($parsedUrl['host'])) {
                $serverIP = resolveHostname($parsedUrl['host']);
            }
        }

        if ($serverIP) {
            $groups[] = getCountry($serverIP);
        } else {
            $groups[] = 'GROUP_OTHERS';
        }
    }

    $groups = array_unique($groups);

    if (($key = array_search('GROUP_OTHERS', $groups)) !== false) {
        unset($groups[$key]);
        $groups[] = 'GROUP_OTHERS';
    }

    return $groups;
}

function getIspGroupFromUrl(array $urls) {
    $groups = [];
    
    foreach ($urls as $url) {
        $serverIP = null;

        if (strpos($url, 'vmess://') === 0) {
            $decoded = json_decode(base64_decode(str_replace('vmess://', '', $url)), true);
            if (isset($decoded['add'])) {
                $serverIP = resolveHostname($decoded['add']);
            }
        } elseif (strpos($url, 'vless://') === 0 || strpos($url, 'trojan://') === 0) {
            $parsedUrl = parse_url($url);
            if (isset($parsedUrl['host'])) {
                $serverIP = resolveHostname($parsedUrl['host']);
            }
        }

        if ($serverIP) {
            $groups[] = getISP($serverIP);
        } else {
            $groups[] = 'ISP_OTHERS';
        }
    }

    $groups = array_unique($groups);

    if (($key = array_search('ISP_OTHERS', $groups)) !== false) {
        unset($groups[$key]);
        $groups[] = 'ISP_OTHERS';
    }

    return $groups;
}

function getProxiesByCountry($urls, $country) {
    $proxies = [];
    
    foreach ($urls as $url) {
        $serverIP = null;
		$proxyName = null;

        if (strpos($url, 'vmess://') === 0) {
            $decoded = json_decode(base64_decode(str_replace('vmess://', '', $url)), true);
            if (isset($decoded['add']) && isset($decoded['ps'])) {
                $serverIP = resolveHostname($decoded['add']);
				$proxyName = $decoded['ps'];
            }
        } elseif (strpos($url, 'vless://') === 0 || strpos($url, 'trojan://') === 0) {
            $parsedUrl = parse_url($url);
            if (isset($parsedUrl['host']) && isset($parsedUrl['fragment'])) {
                $serverIP = resolveHostname($parsedUrl['host']);
				$proxyName = urldecode($parsedUrl['fragment']);
            }
        }

        if ($serverIP && $proxyName) {
            $countryCode = getCountry($serverIP);
			if ($countryCode  === $country) {
				$proxies[] = $proxyName;
			}
        }
		
		if ($country === 'ALL' && $proxyName) {
			$proxies[] = $proxyName;
		}
    }

    return $proxies;
}

function getProxiesByISP($urls, $isp) {
    $proxies = [];
    
    foreach ($urls as $url) {
        $serverIP = null;
		$proxyName = null;

        if (strpos($url, 'vmess://') === 0) {
            $decoded = json_decode(base64_decode(str_replace('vmess://', '', $url)), true);
            if (isset($decoded['add']) && isset($decoded['ps'])) {
                $serverIP = resolveHostname($decoded['add']);
				$proxyName = $decoded['ps'];
            }
        } elseif (strpos($url, 'vless://') === 0 || strpos($url, 'trojan://') === 0) {
            $parsedUrl = parse_url($url);
            if (isset($parsedUrl['host']) && isset($parsedUrl['fragment'])) {
                $serverIP = resolveHostname($parsedUrl['host']);
				$proxyName = urldecode($parsedUrl['fragment']);
            }
        }

        if ($serverIP && $proxyName) {
            $_isp = getISP($serverIP);
			if ($_isp  === $isp) {
				$proxies[] = $proxyName;
			}
        }
		
		if ($isp === 'ALL' && $proxyName) {
			$proxies[] = $proxyName;
		}
    }

    return $proxies;
}

function removeEmptyValues(array $array): array {
    return array_filter($array, function($value) {
        return !empty($value) || $value === '0';
    });
}

function getDataFromUrl($url) {
	$parsedUrl = parse_url($url);
	
	if (!isset($parsedUrl['scheme']) || ($parsedUrl['scheme'] !== 'http' && $parsedUrl['scheme'] !== 'https')) {
        return [$url];
    }
	
	$cachedData = cacheGet($url);
	
	if ($cachedData !== null) {
		$data = isBase64($cachedData) ? base64_decode($cachedData) : $cachedData;
		return explode("\n", $data);
	}
	
    $curl = curl_init();
    
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "GET");
    
    $headers = [
        'User-Agent: v2rayn',
    ];
    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
    
    $response = curl_exec($curl);
    
    if (curl_errno($curl)) {
        curl_close($curl);
        return '';
    }
    
    curl_close($curl);
	
	cacheSave($url, $response, 7200);
	
	$data = isBase64($response) ? base64_decode($response) : $response;
	
    return explode("\n", $data);
}

function isBase64($string) {
    $decoded = base64_decode($string, true);
    return $decoded !== false && base64_encode($decoded) === $string;
}

function isIpFromVietnam($ip) {
	if (preg_match('/^34\./', $ip)) {
		return true;
	}
	
    $vietnamIpRanges = [
        '160.30.0.0/16',
    ];

    foreach ($vietnamIpRanges as $range) {
        if (isIpInRange($ip, $range)) {
            return true;
        }
    }

    return false;
}

function isIpInRange($ip, $range) {
    list($subnet, $bits) = explode('/', $range);
    $ip = ip2long($ip);
    $subnet = ip2long($subnet);
    $mask = -1 << (32 - $bits);
    $subnet &= $mask;

    return ($ip & $mask) === $subnet;
}

function getCountry($ip) {
	
	if (isIpFromVietnam($ip)) {
		return 'Vietnam';
	}
	
    $url = 'https://github.com/P3TERX/GeoLite.mmdb/raw/download/GeoLite2-Country.mmdb';
	$mmdbFilePath = downloadMmdb($url);
	
    $reader = new Reader($mmdbFilePath);

    try {
        $record = $reader->country($ip);
        return $record->country->name;
    } catch (Exception $e) {
		//error_log('Error: ' . $e->getMessage());
        return 'GROUP_OTHERS';
    }
}

function getISP($ip) {
	
    $url = 'https://github.com/P3TERX/GeoLite.mmdb/raw/download/GeoLite2-ASN.mmdb';
	$mmdbFilePath = downloadMmdb($url);
	
    $reader = new Reader($mmdbFilePath);

    try {
        $record = $reader->asn($ip);
        return $record->autonomousSystemOrganization;
    } catch (Exception $e) {
		//error_log('Error: ' . $e->getMessage());
        return 'ISP_OTHERS';
    }
}

function remakeSniUrlConfig($url, $newHost) {
	$randomStr = generateRandomString(3);
	
    if (strpos($url, 'vmess://') === 0) {
        $url = str_replace('vmess://', '', $url);
        $decoded = base64_decode($url);
        $config = json_decode($decoded, true);
		
		if (!isset($config['add']) || !isset($config['port']) || !isset($config['id'])) {
			return '';
		}
		
		if (!isset($config['ps'])) {
			$config['ps'] = 'Unknown';
		}
		
		$serverIP = resolveHostname($config['add']);
		
		if (!$serverIP) {
			return '';
		}
		
		if ($config['add'] === resolveHostname('api2-t3.musical.ly.live.tai4g.vn')) {
			$config['add'] = 'api2-t3.musical.ly.live.tai4g.vn';
		}
		
		$country = getCountry($serverIP);
		$isp = getISP($serverIP);
		$config['ps'] = preg_match("/$country/i", $config['ps']) ? $config['ps'] : $config['ps'].'_'.$country;
		$config['ps'] = ($config['ps'] === $country) ? 'Proxy_'.$config['ps'] : $config['ps'];
		$config['ps'] = $config['ps'].'_'.$isp;
		$config['ps'] = $config['ps'].'_'.$randomStr;
		
        if (isset($config['host'])) {
            $config['host'] = $newHost;
        }
		
        $newConfig = json_encode($config);
        $newUrl = 'vmess://' . base64_encode($newConfig);
		
        return $newUrl;
    } elseif (strpos($url, 'trojan://') === 0) {
        $parsedUrl = parse_url($url);
		
		if(!isset($parsedUrl['host']) || !isset($parsedUrl['port']) || !isset($parsedUrl['user'])) {
			return '';
		}
		
		$queryParams = [];
		if (isset($parsedUrl['query'])) {
			parse_str($parsedUrl['query'], $queryParams);
		}
		
        if (isset($queryParams['peer'])) {
            $queryParams['peer'] = $newHost;
        }
		
		if (isset($queryParams['sni'])) {
            $queryParams['sni'] = $newHost;
        }
		
		if ($parsedUrl['host'] === resolveHostname('api2-t3.musical.ly.live.tai4g.vn')) {
			$parsedUrl['host'] = 'api2-t3.musical.ly.live.tai4g.vn';
		}
		
		$newUrl = $parsedUrl['scheme'] . '://' . $parsedUrl['user'] . '@' . $parsedUrl['host'];
		
        if (isset($parsedUrl['port'])) {
            $newUrl .= ':' . $parsedUrl['port'];
        }
		
        $newUrl .= '?' . http_build_query($queryParams);
		
		$name = 'Unknown';
		
        if (isset($parsedUrl['fragment'])) {
			$name = rtrim(urldecode($parsedUrl['fragment']), '_');
        }
		
		$serverIP = resolveHostname($parsedUrl['host']);
		
		if (!$serverIP) {
			return '';
		}
		
		$country = getCountry($serverIP);
		$isp = getISP($serverIP);
		$name = preg_match("/$country/i", $name) ? $name : $name.'_'.$country;
		$name = ($name === $country) ? 'Proxy_'.$name : $name;
		$name = $name.'_'.$isp;
		$name = $name.'_'.$randomStr;
		$newUrl .= '#' . urlencode($name);
		
        return $newUrl;
    } elseif (strpos($url, 'vless://') === 0) {
		$parsedUrl = parse_url($url);
		
		if(!isset($parsedUrl['host']) || !isset($parsedUrl['port']) || !isset($parsedUrl['user'])) {
			return '';
		}
		
		$queryParams = [];
		if (isset($parsedUrl['query'])) {
			parse_str($parsedUrl['query'], $queryParams);
		}
		
		if (isset($queryParams['host'])) {
            $queryParams['host'] = $newHost;
        }
		
		$newUrl = $parsedUrl['scheme'] . '://' . $parsedUrl['user'] . '@' . $parsedUrl['host'];
		
        if (isset($parsedUrl['port'])) {
            $newUrl .= ':' . $parsedUrl['port'];
        }
		
        $newUrl .= '?' . http_build_query($queryParams);
		
		$name = 'Unknown';
		
        if (isset($parsedUrl['fragment'])) {
			$name = rtrim(urldecode($parsedUrl['fragment']), '_');
        }
		
		$serverIP = resolveHostname($parsedUrl['host']);
		
		if (!$serverIP) {
			return '';
		}
		
		$country = getCountry($serverIP);
		$isp = getISP($serverIP);
		$name = preg_match("/$country/i", $name) ? $name : $name.'_'.$country;
		$name = ($name === $country) ? 'Proxy_'.$name : $name;
		$name = $name.'_'.$isp;
		$name = $name.'_'.$randomStr;
		$newUrl .= '#' . urlencode($name);
		
        return $newUrl;
    }
    
	return '';
}

function downloadMmdb($url) {
    $tmpDir = getCacheDirectory();
    $fileName = basename(parse_url($url, PHP_URL_PATH));
    $filePath = $tmpDir . '/' . $fileName;

    if (file_exists($filePath) && pathinfo($fileName, PATHINFO_EXTENSION) === 'mmdb') {
        return $filePath;
    }

	$ch = curl_init($url);
    $fp = fopen($filePath, 'wb');
    curl_setopt($ch, CURLOPT_FILE, $fp);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_exec($ch);
    curl_close($ch);
    fclose($fp);

    if (file_exists($filePath) && pathinfo($fileName, PATHINFO_EXTENSION) === 'mmdb') {
        return $filePath;
    }

    return null;
}

function resolveHostname($input) {
	
	$cachedData = cacheGet('IP'.$input);
	
	if ($cachedData !== null) {
		return $cachedData;
	}
	
    if (filter_var($input, FILTER_VALIDATE_IP)) {
        return $input;
    } else {
        $ip = gethostbyname($input);
		
		if ($ip === $input) {
			return false;
		}
		
		cacheSave('IP'.$input, $ip, 604800);
		
        return $ip;
    }
}

function arrayToYaml($array, $indentLevel = 0, $isInList = false) {
    $yaml = '';
    $indent = str_repeat('  ', $indentLevel);

    foreach ($array as $key => $value) {
        if (is_array($value)) {
            if (is_numeric($key)) {
                $yaml .= $indent . "-";
                $yaml .= arrayToYaml($value, $indentLevel + 1, true);
            } else {
                $yaml .= $indent . $key . ":\n" . arrayToYaml($value, $indentLevel + 1);
            }
        } else {
            if (is_numeric($key)) {
				$valueFormatted = preg_match('/[^a-zA-Z0-9_]/', $value) ? '"'.$value.'"' : $value;
                $yaml .= $indent . "- " . (is_bool($valueFormatted) ? ($valueFormatted ? 'true' : 'false') : ($valueFormatted === '' ? '""' : $valueFormatted)) . "\n";
            } else {
				$valueFormatted = preg_match('/[^a-zA-Z0-9_]/', $value) ? '"'.$value.'"' : $value;
                $valueFormatted = is_bool($valueFormatted) ? ($valueFormatted ? 'true' : 'false') : ($valueFormatted === '' ? '""' : $valueFormatted);
				$yaml .= $indent . $key . ": $valueFormatted\n";
            }
        }
    }
    $yaml = str_replace('-   ', '-', $yaml);
	$yaml = str_replace('- -', '- ', $yaml);
	
	return $yaml;
}

function decodeVmessClash($vmessUrl) {
    $json = base64_decode(str_replace('vmess://', '', $vmessUrl));
    $vmessConfig = json_decode($json, true);
    
    if (!$vmessConfig || !isset($vmessConfig['ps'], $vmessConfig['add'], $vmessConfig['port'], $vmessConfig['id'])) {
        return '';
    }

    $config = [
        'name' => $vmessConfig['ps'],
        'server' => $vmessConfig['add'],
        'port' => (int)$vmessConfig['port'],
        'type' => 'vmess',
        'uuid' => $vmessConfig['id'],
        'cipher' => 'auto',
        'tls' => isset($vmessConfig['tls']) && $vmessConfig['tls'] === 'tls',
        'skip-cert-verify' => true,
        'servername' => $vmessConfig['host'] ?? ''
    ];
	if (isset($vmessConfig['aid'])) {
		$config['alterId'] = (int)$vmessConfig['aid'];
	} else {
		$config['alterId'] = 0;
	}

    if (isset($vmessConfig['net'])) {
        $config['network'] = $vmessConfig['net'];
        if ($vmessConfig['net'] === 'ws') {
            $config['ws-opts'] = [
                'path' => $vmessConfig['path'] ?? '',
                'headers' => [
                    'Host' => $vmessConfig['host'] ?? ''
                ]
            ];
        }
    }

    $config['udp'] = !isset($vmessConfig['udp']) || (bool)$vmessConfig['udp'];

    return $config;
}

function decodeVlessClash($vlessUrl) {
    $urlComponents = parse_url($vlessUrl);
    parse_str($urlComponents['query'], $queryParams);

    if (!$urlComponents || !isset($urlComponents['host'], $urlComponents['port'], $urlComponents['user'])) {
        return '';
    }

    $config = [
        'name' => isset($urlComponents['fragment']) ? urldecode($urlComponents['fragment']) : 'Unnamed-Vless',
        'server' => $urlComponents['host'],
        'port' => (int)$urlComponents['port'],
        'type' => 'vless',
        'uuid' => $urlComponents['user'],
        'cipher' => 'auto',
        'tls' => isset($queryParams['security']) && $queryParams['security'] === 'tls',
        'skip-cert-verify' => true,
        'servername' => $queryParams['host'] ?? ''
    ];

    if (isset($queryParams['type'])) {
        $config['network'] = $queryParams['type'];
        if ($queryParams['type'] === 'ws') {
            $config['ws-opts'] = [
                'path' => $queryParams['path'] ?? '',
                'headers' => [
                    'Host' => $queryParams['host'] ?? ''
                ]
            ];
        }
    }

    $config['udp'] = !isset($queryParams['udp']) || (bool)$queryParams['udp'];

    return $config;
}

function decodeTrojanClash($trojanUrl) {
    $urlComponents = parse_url($trojanUrl);
    parse_str($urlComponents['query'], $queryParams);

    if (!$urlComponents || !isset($urlComponents['host'], $urlComponents['port'], $urlComponents['user'])) {
        return '';
    }

    $peer = $queryParams['peer'] ?? '';
    $sni = $queryParams['sni'] ?? $peer;

    $config = [
        'name' => isset($urlComponents['fragment']) ? urldecode($urlComponents['fragment']) : 'Unnamed-Trojan',
        'server' => $urlComponents['host'],
        'port' => (int)$urlComponents['port'],
        'type' => 'trojan',
        'password' => $urlComponents['user'],
        'skip-cert-verify' => isset($queryParams['allowInsecure']) && $queryParams['allowInsecure'] == '1',
        'sni' => $sni
    ];

    if (isset($queryParams['type'])) {
        $config['network'] = $queryParams['type'];
        if ($queryParams['type'] === 'grpc') {
            $config['grpc-opts'] = [
                'grpc-mode' => 'gun',
                'grpc-service-name' => $queryParams['serviceName'] ?? ''
            ];
        }
    }

    $config['udp'] = !isset($queryParams['udp']) || (bool)$queryParams['udp'];

    return $config;
}

function generateClashProxyProviderConfig($urls) {
    $proxies = [];
    foreach ($urls as $url) {
		if (strpos($url, 'vmess://') === 0) {
			$proxies[] = decodeVmessClash($url);
		} elseif (strpos($url, 'vless://') === 0) {
			$proxies[] = decodeVlessClash($url);
		} elseif (strpos($url, 'trojan://') === 0) {
			$proxies[] = decodeTrojanClash($url);
		} else {
			continue;
		}
    }
	
	echo arrayToYaml(['proxies' => $proxies]);
}

function generateClashConfig($urls = [], $requestData = []) {
    $proxies = [];
    foreach ($urls as $url) {
        if (strpos($url, 'vmess://') === 0) {
            $proxies[] = decodeVmessClash($url);
        } elseif (strpos($url, 'vless://') === 0) {
            $proxies[] = decodeVlessClash($url);
        } elseif (strpos($url, 'trojan://') === 0) {
            $proxies[] = decodeTrojanClash($url);
        } else {
            continue;
        }
    }
	
	$url = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://") . $_SERVER['HTTP_HOST'] . strtok($_SERVER['REQUEST_URI'], '?');
	$isRemote = isset($requestData['isRemote']) && is_bool($requestData['isRemote']) ? $requestData['isRemote'] : false;
	
	$rules = isset($requestData['rules']) && is_string($requestData['rules']) ? explode("\n", $requestData['rules']) : [];
	
	$groups = getGroupFromUrl($urls);
	$ispGroups = getIspGroupFromUrl($urls);

	$nameProxies = getProxiesByCountry($urls, 'ALL');
	$noVietnamProxies = array_values(array_diff($nameProxies, getProxiesByCountry($urls, 'Vietnam')));
	
	$selectProxies = [];
	if (!empty($noVietnamProxies)) {
		$selectProxies = array_merge(['NO-VIETNAM'], $nameProxies);
	}
	
	$baseProxies = array_merge(['BEST-PING', 'LOAD-BALANCE', 'FALLBACK', 'DIRECT'], array_map('strtoupper', $groups), array_map('strtoupper', $ispGroups), $selectProxies);
	
    $proxyGroups = [
        [
            'name' => 'KHAIPHAN',
            'type' => 'select',
            'proxies' => $baseProxies,
        ],
        [
            'name' => 'BEST-PING',
            'type' => 'url-test',
            'url' => 'http://www.gstatic.com/generate_204',
            'interval' => 300,
            'tolerance' => 5,
			'proxies' => $nameProxies
        ],
		[
            'name' => 'LOAD-BALANCE',
            'type' => 'load-balance',
			'strategy' => 'consistent-hashing',
            'url' => 'http://www.gstatic.com/generate_204',
            'interval' => 300,
			'proxies' => $nameProxies
        ],
		[
            'name' => 'FALLBACK',
            'type' => 'fallback',
            'url' => 'http://www.gstatic.com/generate_204',
            'interval' => 300,
			'proxies' => $nameProxies
        ]
    ];
	
	if (!empty($noVietnamProxies)) {
		$proxyGroups[] = [
            'name' => 'NO-VIETNAM',
            'type' => 'url-test',
            'url' => 'http://www.gstatic.com/generate_204',
            'interval' => 300,
            'tolerance' => 5,
			'proxies' => $noVietnamProxies
        ];
	}
	
	foreach($groups as $groupName) {
		$proxyGroups[] = [
            'name' => strtoupper($groupName),
            'type' => 'url-test',
            'url' => 'http://www.gstatic.com/generate_204',
            'interval' => 300,
            'tolerance' => 5,
			'proxies' => getProxiesByCountry($urls, $groupName)
        ];
	}
	
	foreach($ispGroups as $groupName) {
		$proxyGroups[] = [
            'name' => strtoupper($groupName),
            'type' => 'url-test',
            'url' => 'http://www.gstatic.com/generate_204',
            'interval' => 300,
            'tolerance' => 5,
			'proxies' => getProxiesByISP($urls, $groupName)
        ];
	}

    $clashConfig = [
        'port' => 7890,
        'socks-port' => 7891,
        'mixed-port' => 7893,
        'tproxy-port' => 9898,
        'redir-port' => 9797,
        'mode' => 'rule',
        'allow-lan' => true,
        'bind-address' => '*',
        'log-level' => 'silent',
        'unified-delay' => true,
        'geodata-mode' => true,
        'geodata-loader' => 'memconservative',
        'ipv6' => false,
        'external-controller' => '0.0.0.0:9090',
        'secret' => '',
        'external-ui' => '/data/adb/box/clash/dashboard',
        'profile' => [
            'store-selected' => true,
            'store-fake-ip' => false,
        ],
        'find-process-mode' => 'strict',
        'geox-url' => [
            'geoip' => "https://ghp.ci/https://github.com/MetaCubeX/meta-rules-dat/releases/download/latest/geoip.dat",
            'mmdb' => "https://ghp.ci/https://github.com/MetaCubeX/meta-rules-dat/releases/download/latest/country.mmdb",
            'geosite' => "https://ghp.ci/https://github.com/MetaCubeX/meta-rules-dat/releases/download/latest/geosite.dat",
        ],
        'sniffer' => [
            'enable' => true,
        ],
        'dns' => [
            'cache-algorithm' => 'arc',
            'enable' => true,
            'prefer-h3' => false,
            'ipv6' => false,
            'ipv6-timeout' => 300,
            'default-nameserver' => [
                '1.1.1.1',
                '8.8.8.8',
				'203.113.131.6',
				'203.113.131.1'
            ],
            'listen' => '0.0.0.0:1053',
            'use-hosts' => true,
            'enhanced-mode' => 'redir-host',
            'fake-ip-range' => '198.18.0.1/16',
            'fake-ip-filter' => [
                '*.lan',
                '*.ntp.*',
            ],
            'nameserver' => [
                '8.8.8.8#GLOBAL',
                '1.1.1.1',
                'https://cloudflare-dns.com/dns-query#GLOBAL',
                'https://dns.google/dns-query',
				'203.113.131.6',
				'203.113.131.1'
            ],
            // 'proxy-server-nameserver' => [
            //     '192.168.130.30'
            // ],
            // 'nameserver-policy' => [
            //     '+.googlesyndication.com' => '1.1.1.1',
            //     'geosite:category-ads-all' => 'rcode://success'
            // ],
            // 'respect-rules' => false
        ],
        'tun' => [
            'enable' => false,
            'mtu' => 9000,
            'device' => 'tun9',
            'stack' => 'mixed',
            'dns-hijack' => [
                'any:53',
            ],
            'auto-route' => true,
            'strict-route' => false,
            'auto-redirect' => true,
            'auto-detect-interface' => true,
            'include-android-user' => [0, 10],
            'exclude-package' => [],
            'include-package' => [],
        ],
        'keep-alive-interval' => 60,
        'geo-auto-update' => false,
        'geo-update-interval' => 24,
        'global-client-fingerprint' => 'random',
        'tcp-concurrent' => false,
		'rule-providers' => [
			'gfw' => [
				'type' => 'http',
				'behavior' => 'domain',
				'url' => 'https://cdn.jsdelivr.net/gh/Loyalsoldier/clash-rules@release/gfw.txt',
				'path' => './provide/gfw.yaml',
				'interval' => 86400
			],
			'openai' => [
				'type' => 'http',
				'behavior' => 'ipcidr',
				'url' => 'https://github.com/Chocolate4U/Iran-clash-rules/raw/refs/heads/release/openai.yaml',
				'path' => './provide/openai.yaml',
				'interval' => 86400
			],
			'google' => [
				'type' => 'http',
				'behavior' => 'domain',
				'url' => 'https://cdn.jsdelivr.net/gh/Loyalsoldier/clash-rules@release/google.txt',
				'path' => './provide/google.yaml',
				'interval' => 86400
			],
			'facebook' => [
				'type' => 'http',
				'behavior' => 'ipcidr',
				'url' => 'https://github.com/Chocolate4U/Iran-clash-rules/raw/refs/heads/release/facebook.yaml',
				'path' => './provide/facebook.yaml',
				'interval' => 86400
			],
			'porn' => [
				'type' => 'http',
				'behavior' => 'domain',
				'url' => 'https://raw.githubusercontent.com/Chocolate4U/Iran-clash-rules/refs/heads/release/nsfw.yaml',
				'path' => './provide/porn.yaml',
				'interval' => 86400
			],
			'ads' => [
				'type' => 'http',
				'behavior' => 'domain',
				'url' => 'https://raw.githubusercontent.com/Chocolate4U/Iran-clash-rules/release/category-ads-all.yaml',
				'path' => './provide/ads.yaml',
				'interval' => 86400
			]
		],
		'proxies' => $proxies,
		'proxy-providers' => [],
        'proxy-groups' => $proxyGroups,
        'rules' => [],
    ];
	
	$isVina = false;
	$isFirsty = false;
	
	foreach($rules as $rule) {
		if (preg_match("/FIRSTY,(\d+)\|([^,]+),AUTO-RENEW/i", $rule, $matches)) {
			list($iccid, $jwtToken) = [$matches[1], $matches[2]];
			$clashConfig['rule-providers']['firsty'] = [
			'type' => 'http',
			'behavior' => 'domain',
			'url' => $url.'?'.str_replace('=1&', '&', http_build_query(['clash-firsty-rule-provider' => true, 'iccid' => $iccid, 'token' => $jwtToken])),
			'path' => './provide/firsty.yaml',
			'interval' => 1680
			];
			
			if ($isRemote) {
			$firstyRequestData = $requestData;
			unset($firstyRequestData['rules']);
			unset($firstyRequestData['isRemote']);
			
			$arrQueryParams = [];
			if (isset($firstyRequestData['customData'])) {
			unset($firstyRequestData['customData']);
			$arrQueryParams['customData'] = true;
			}
			$firstyRequestData['sni'] = 'backoffice.firsty.app';
			$arrQueryParams['data'] = base64UrlEncode(http_build_query($firstyRequestData));
			$proxyParams = str_replace('=1&', '&', http_build_query($arrQueryParams));
			if (!isset($clashConfig['proxy-providers'])) {
			$clashConfig['proxy-providers'] = array();
			}
			
			$clashConfig['proxy-providers'][] = [
			'firsty-proxy-cloud' => [
			'type' => 'http',
			'path' => './provide/firsty-proxy-cloud.yaml',
			'url' => $url.'?clash-proxy-cloud&'.$proxyParams,
			'interval' => 3600,
			'health-check' => [
			'enable' => true,
			'url' => 'http://www.gstatic.com/generate_204',
			'interval' => 1800
			]
			]
			];
			
			$isFirsty = true;
			}
		} elseif ($isRemote && preg_match('/VINAPHONE-GOOGLE-SERVERS/i', $rule)) {
			$isVina = true;
		} elseif (isClashRule($rule)) {
			$clashConfig['rules'][] = $rule;
		}
	}
	
	if ($isRemote) {
		unset($requestData['rules']);
		unset($requestData['isRemote']);
		unset($clashConfig['proxies']);
		
		$arrQueryParams = [];
		if (isset($requestData['customData'])) {
		unset($requestData['customData']);
		$arrQueryParams['customData'] = true;
		}
		$arrQueryParams['data'] = base64UrlEncode(http_build_query($requestData));
		$proxyParams = str_replace('=1&', '&', http_build_query($arrQueryParams));
		if (!isset($clashConfig['proxy-providers'])) {
		$clashConfig['proxy-providers'] = array();
		}
		$clashConfig['proxy-providers'][] = [
		'proxy-cloud' => [
		'type' => 'http',
		'path' => './provide/proxy-cloud.yaml',
		'url' => $url.'?clash-proxy-cloud&'.$proxyParams,
		'interval' => 3600,
		'health-check' => [
		'enable' => true,
		'url' => 'http://www.gstatic.com/generate_204',
		'interval' => 1800
		]
		]
		];
		
		$baseProxies = ['BEST-PING', 'LOAD-BALANCE', 'FALLBACK', 'DIRECT', 'VIETNAM', 'NO-VIETNAM'];
		if ($isVina) {
			$baseProxies[] = 'GOOGLE-SERVERS';
		}
		if ($isFirsty) {
			$baseProxies[] = 'FIRSTY-ESIM';
		}
		$clashConfig['proxy-groups'] = [];
		$clashConfig['proxy-groups'][] = [
            'name' => 'KHAIPHAN',
            'type' => 'select',
			'use' => ['proxy-cloud'],
            'proxies' => $baseProxies,
		];
		$clashConfig['proxy-groups'][] = [
            'name' => 'BEST-PING',
            'type' => 'url-test',
            'url' => 'http://www.gstatic.com/generate_204',
            'interval' => 300,
            'tolerance' => 5,
			'use' => ['proxy-cloud']
        ];
		
		$clashConfig['proxy-groups'][] = [
            'name' => 'LOAD-BALANCE',
            'type' => 'load-balance',
            'strategy' => 'consistent-hashing',
			'url' => 'http://www.gstatic.com/generate_204',
            'interval' => 300,
			'use' => ['proxy-cloud']
        ];
		
		$clashConfig['proxy-groups'][] = [
            'name' => 'FALLBACK',
            'type' => 'url-test',
            'url' => 'http://www.gstatic.com/generate_204',
            'interval' => 300,
			'use' => ['proxy-cloud']
        ];
		
		$clashConfig['proxy-groups'][] = [
            'name' => 'VIETNAM',
            'type' => 'url-test',
            'url' => 'http://www.gstatic.com/generate_204',
            'interval' => 300,
			'filter' => '.*[Vv][Ii][Ee][Tt][Nn][Aa][Mm].*',
			'use' => ['proxy-cloud']
        ];
		
		$clashConfig['proxy-groups'][] = [
            'name' => 'NO-VIETNAM',
            'type' => 'url-test',
            'url' => 'http://www.gstatic.com/generate_204',
            'interval' => 300,
			'filter' => '^(?!.*[Vv][Ii][Ee][Tt][Nn][Aa][Mm]).*',
			'use' => ['proxy-cloud']
        ];
		
		if ($isFirsty) {
			$clashConfig['proxy-groups'][] = [
			'name' => 'FIRSTY-ESIM',
			'type' => 'url-test',
			'url' => 'http://www.gstatic.com/generate_204',
			'interval' => 300,
			'use' => ['firsty-proxy-cloud']
			];
		}
		
		if ($isVina) {
			$clashConfig['proxy-groups'][] = [
            'name' => 'GOOGLE-SERVERS',
            'type' => 'url-test',
            'url' => 'http://www.gstatic.com/generate_204',
            'interval' => 300,
			'filter' => '.*GOOGLE[-_\s]CLOUD[-_\s]PLATFORM.*',
			'use' => ['proxy-cloud']
        	];
		}
	} else {
		unset($clashConfig['proxy-providers']);
	}
	
	if (clashGroupExists($clashConfig['proxy-groups'], 'NO-VIETNAM')) {
		//$clashConfig['rules'][] = 'DOMAIN-KEYWORD,phimmoi,NO-VIETNAM';
		$clashConfig['rules'][] = 'DOMAIN-KEYWORD,bilutv,NO-VIETNAM';
		$clashConfig['rules'][] = 'DOMAIN-KEYWORD,phim14,NO-VIETNAM';
		$clashConfig['rules'][] = 'DOMAIN-KEYWORD,tvhay,NO-VIETNAM';
		$clashConfig['rules'][] = 'DOMAIN-KEYWORD,motchill,NO-VIETNAM';
		$clashConfig['rules'][] = 'DOMAIN-KEYWORD,motphim,NO-VIETNAM';
		$clashConfig['rules'][] = 'RULE-SET,porn,NO-VIETNAM';
		$clashConfig['rules'][] = 'RULE-SET,google,KHAIPHAN';
		$clashConfig['rules'][] = 'RULE-SET,facebook,KHAIPHAN';
		$clashConfig['rules'][] = 'RULE-SET,openai,KHAIPHAN';
		$clashConfig['rules'][] = 'RULE-SET,gfw,NO-VIETNAM';
	}
	
	$clashConfig['rules'][] = 'MATCH,KHAIPHAN';

    return arrayToYaml($clashConfig);
}

function clashGroupExists($clashGroups, $groupName) {
    foreach ($clashGroups as $group) {
        if (isset($group['name']) && $group['name'] === $groupName) {
            return true;
        }
    }
    return false;
}

function decodeVmessSB($vmessUrl) {
    $json = base64_decode(str_replace('vmess://', '', $vmessUrl));
    $vmessConfig = json_decode($json, true);
    
    if (!$vmessConfig || !isset($vmessConfig['ps'], $vmessConfig['add'], $vmessConfig['port'], $vmessConfig['id'])) {
        return '';
    }

    $config = [
        'tag' => $vmessConfig['ps'],
        'server' => $vmessConfig['add'],
        'server_port' => (int)$vmessConfig['port'],
        'type' => 'vmess',
        'uuid' => $vmessConfig['id'],
        'security' => 'auto',
    ];
	if (isset($vmessConfig['aid'])) {
		$config['alter_id'] = (int)$vmessConfig['aid'];
	} else {
		$config['alter_id'] = 0;
	}

    if (isset($vmessConfig['net'])) {
        if ($vmessConfig['net'] === 'ws') {
            $config['transport'] = [
				'type' => $vmessConfig['net'],
                'path' => $vmessConfig['path'] ?? '',
                'headers' => [
                    'Host' => $vmessConfig['host'] ?? ''
                ],
				"max_early_data" => 2048,
				"early_data_header_name" => "Sec-WebSocket-Protocol"
            ];
        }
    }

    $config['packet_encoding'] = 'xudp';

    return $config;
}

function decodeVlessSB($vlessUrl) {
    $urlComponents = parse_url($vlessUrl);
    parse_str($urlComponents['query'], $queryParams);

    if (!$urlComponents || !isset($urlComponents['host'], $urlComponents['port'], $urlComponents['user'])) {
        return '';
    }

    $config = [
        'tag' => isset($urlComponents['fragment']) ? urldecode($urlComponents['fragment']) : 'Unnamed-Vless',
        'server' => $urlComponents['host'],
        'server_port' => (int)$urlComponents['port'],
        'type' => 'vless',
        'uuid' => $urlComponents['user']
    ];
	
	if (isset($queryParams['type'])) {
        if ($queryParams['type'] === 'ws') {
            $config['transport'] = [
				'type' => $queryParams['type'],
                'path' => $queryParams['path'] ?? '',
                'headers' => [
                    'Host' => $queryParams['host'] ?? ''
                ],
				"max_early_data" => 2048,
				"early_data_header_name" => "Sec-WebSocket-Protocol"
            ];
        }
    }

    $config['packet_encoding'] = 'xudp';

    return $config;
}

function decodeTrojanSB($trojanUrl) {
    $urlComponents = parse_url($trojanUrl);
    parse_str($urlComponents['query'], $queryParams);

    if (!$urlComponents || !isset($urlComponents['host'], $urlComponents['port'], $urlComponents['user'])) {
        return '';
    }

    $peer = $queryParams['peer'] ?? '';
    $sni = $queryParams['sni'] ?? $peer;

    $config = [
        'tag' => isset($urlComponents['fragment']) ? urldecode($urlComponents['fragment']) : 'Unnamed-Trojan',
        'server' => $urlComponents['host'],
        'server_port' => (int)$urlComponents['port'],
        'type' => 'trojan',
        'password' => $urlComponents['user'],
		'tls' => [
			'enabled' => true,
			'insecure' => isset($queryParams['allowInsecure']) && $queryParams['allowInsecure'] == '1',
			'server_name' => $sni
		]
    ];

    if (isset($queryParams['type'])) {
        if ($queryParams['type'] === 'grpc') {
            $config['transport'] = [
				'type' => $queryParams['type'],
				'service_name' => $queryParams['serviceName'] ?? ''
			];
        }
    }

    return $config;
}

function generateSingboxConfig($urls, $requestData = []) {
	$enabledRule = false;
	
    $proxies = [];
    foreach ($urls as $url) {
        if (strpos($url, 'vmess://') === 0) {
            $proxies[] = decodeVmessSB($url);
        } elseif (strpos($url, 'vless://') === 0) {
            $proxies[] = decodeVlessSB($url);
        } elseif (strpos($url, 'trojan://') === 0) {
            $proxies[] = decodeTrojanSB($url);
        } else {
            continue;
        }
    }
	
	$rules = isset($requestData['rules']) && is_string($requestData['rules']) ? explode("\n", $requestData['rules']) : [];
	
	$groups = getGroupFromUrl($urls);
	$ispGroups = getIspGroupFromUrl($urls);

	$nameProxies = getProxiesByCountry($urls, 'ALL');
	$noVietnamProxies = array_values(array_diff($nameProxies, getProxiesByCountry($urls, 'Vietnam')));
	
	$selectProxies = [];
	if (!empty($noVietnamProxies)) {
		$selectProxies = array_merge(['NO-VIETNAM'], $nameProxies);
	}
	
	$baseProxies = array_merge(['BEST-PING', 'DIRECT'], array_map('strtoupper', $groups), array_map('strtoupper', $ispGroups), $selectProxies);

    $proxyGroups = [
        [
            "tag" => "KHAIPHAN",
            "type" => "selector",
			"default" => "BEST-PING",
            "outbounds" => $baseProxies
        ],
        [
            "tag" => "BEST-PING",
            "type" => "urltest",
            "outbounds" => $nameProxies,
            "url" => "http://www.gstatic.com/generate_204",
            "interval" => "10m",
            "tolerance" => 50
        ]
    ];
	
	if (!empty($noVietnamProxies)) {
		$proxyGroups[] = [
            "tag" => "NO-VIETNAM",
            "type" => "urltest",
            "outbounds" => $noVietnamProxies,
            "url" => "http://www.gstatic.com/generate_204",
            "interval" => "10m",
            "tolerance" => 50
        ];
	}
	
	foreach($groups as $groupName) {
		$proxyGroups[] = [
            "tag" => strtoupper($groupName),
            "type" => "urltest",
            "outbounds" => getProxiesByCountry($urls, $groupName),
            "url" => "http://www.gstatic.com/generate_204",
            "interval" => "10m",
            "tolerance" => 50
        ];
	}
	
	foreach($ispGroups as $groupName) {
		$proxyGroups[] = [
            "tag" => strtoupper($groupName),
            "type" => "urltest",
            "outbounds" => getProxiesByISP($urls, $groupName),
            "url" => "http://www.gstatic.com/generate_204",
            "interval" => "10m",
            "tolerance" => 50
        ];
	}
	
	$dnsServers = [
		[
			"tag" => "PROXY-DNS",
			"address" => "1.1.1.1",
			"detour" => "KHAIPHAN"
		],
		[
			"tag" => "LOCAL-DNS",
			"address" => "local"/*['203.113.131.1', '203.113.131.6'][array_rand(['203.113.131.1', '203.113.131.6'])]*/,
			"strategy" => "ipv4_only",
			"detour" => "DIRECT"
		],
		[
			"tag" => "DNS-BLOCK",
			"address" => "rcode://success"
		],
		[
			"tag" => "DNS-REJECT",
			"address" => "rcode://refused"
		],
		/*[
		"tag" => "DNS-DHCP",
		"address" => "dhcp://auto"
		],
		[
		"tag" => "DNS-FAKEIP",
		"address" => "fakeip"
		]*/
    ];
	
	$dnsRules = [
		[
			"domain_suffix" => [".arpa.", ".arpa"],
			"server" => "DNS-BLOCK"
		],
		[
			"outbound" => "any",
			"server" => "LOCAL-DNS",
			"disable_cache" => true
		],
		[
			"query_type" => [
				"A",
				"AAAA"
			],
		"server" => "PROXY-DNS"
		],
		[
			"clash_mode" => "direct",
			"server" => "LOCAL-DNS"
		],
		[
			"clash_mode" => "global",
			"server" => "PROXY-DNS"
		]
	];
	
	$config = [
		"log" => [
        	"level" => "info",
        	"timestamp" => true
		],
		"experimental" => [
        	"cache_file" => [
				"enabled" => true,
				"path" => "",
				"cache_id" => "",
				"store_fakeip" => false
        	],
        	"clash_api" => [
				"external_controller" => "0.0.0.0:9090",
                "external_ui" => "ui",
                "secret" => "",
                "external_ui_download_url" => "https://ghp.ci/https://github.com/MetaCubeX/Yacd-meta/archive/gh-pages.zip",
                "external_ui_download_detour" => "KHAIPHAN",
                "default_mode" => "rule"
        	]
		],
		"dns" => [
        	"servers" => $dnsServers,
        	"rules" => $dnsRules,
        	"independent_cache" => true,
        	"strategy" => "ipv4_only"
		],
		"route" => [
        	"auto_detect_interface" => true,
        	"override_android_vpn" => true,
        	"final" => "KHAIPHAN",
			"rule_set" => [
				[
					"tag" => "gfw",
					"type" => "remote",
					"download_detour" => "KHAIPHAN",
					"update_interval" => "1d",
					"format" => "binary",
					"url" => "https://raw.githubusercontent.com/chg1f/sing-geosite-mixed/rule-set/gfw.srs"
				],
				[
					"tag" => "openai",
					"type" => "remote",
					"download_detour" => "KHAIPHAN",
					"update_interval" => "1d",
					"format" => "binary",
					"url" => "https://github.com/KaringX/karing-ruleset/raw/refs/heads/sing/geo/geoip/openai.srs"
				],
				[
					"tag" => "google",
					"type" => "remote",
					"download_detour" => "KHAIPHAN",
					"update_interval" => "1d",
					"format" => "binary",
					"url" => "https://raw.githubusercontent.com/KaringX/karing-ruleset/refs/heads/sing/geo/geoip/google.srs"
				],
				[
					"tag" => "facebook",
					"type" => "remote",
					"download_detour" => "KHAIPHAN",
					"update_interval" => "1d",
					"format" => "binary",
					"url" => "https://github.com/KaringX/karing-ruleset/raw/refs/heads/sing/geo/geoip/facebook.srs"
				],
				[
					"tag" => "porn",
					"type" => "remote",
					"download_detour" => "KHAIPHAN",
					"update_interval" => "1d",
					"format" => "binary",
					"url" => "https://github.com/KaringX/karing-ruleset/raw/refs/heads/sing/geo/geosite/category-porn.srs"
				],
				[
					"tag" => "ads",
					"type" => "remote",
					"download_detour" => "KHAIPHAN",
					"update_interval" => "1d",
					"format" => "binary",
					"url" => "https://github.com/KaringX/karing-ruleset/raw/refs/heads/sing/geo/geosite/category-ads-all.srs"
				]
			],
			"geoip" => [
				'path' => 'geoip.db',
				'download_url' => 'https://ghp.ci/https://github.com/MetaCubeX/meta-rules-dat/releases/download/latest/geoip.db',
				'download_detour' => 'KHAIPHAN',
			],
			"geosite" => [
				'path' => 'geosite.db',
				'download_url' => 'https://ghp.ci/https://github.com/MetaCubeX/meta-rules-dat/releases/download/latest/geosite.db',
				'download_detour' => 'KHAIPHAN',
			],
        	"rules" => []
		],
		"inbounds" => [
        	[
				"type" => "tun",
				"tag" => "tun-in",
				"interface_name" => "tun0",
				"inet4_address" => "172.19.0.1/30",
				"inet6_address" => "2001:0470:f9da:fdfa::1/64",
				"mtu" => 9000,
				"auto_route" => true,
				"strict_route" => true,
				"stack" => "system",
				"endpoint_independent_nat" => true,
				"sniff" => true,
				"sniff_override_destination" => true,
				"domain_strategy" => "prefer_ipv4"
        	],
        	[
				"domain_strategy" => "prefer_ipv4",
				"listen" => "0.0.0.0",
				"listen_port" => 2333,
				"sniff" => true,
				"sniff_override_destination" => true,
				"tag" => "socks-in",
				"type" => "socks",
				"users" => []
        	],
			[
				"domain_strategy" => "prefer_ipv4",
				"listen" => "0.0.0.0",
				"listen_port" => 2080,
				"sniff" => true,
				"sniff_override_destination" => true,
				"tag" => "mixed-in",
				"type" => "mixed",
				"users" => []
        	]
		],
		"outbounds" => array_merge(
			[
				["type" => "direct", "tag" => "DIRECT"],
				["type" => "dns", "tag" => "DNS-OUT"],
				["type" => "block", "tag" => "BLOCK"]
			],
			$proxyGroups,
			$proxies
		)
	];
	
	if (isset($requestData['sni'])) {
		$sni = $requestData['sni'];
		$config['dns']['rules'] = array_merge([['domain' => $sni, 'server' => 'LOCAL-DNS']], $config['dns']['rules']);
		$rules = array_merge(["DOMAIN,$sni,DIRECT"], $rules);
	}
	
	if (!empty($noVietnamProxies)) {
		//$rules[] = 'domain_keyword,phimmoi,NO-VIETNAM';
		$rules[] = 'domain_keyword,bilutv,NO-VIETNAM';
		$rules[] = 'domain_keyword,phim14,NO-VIETNAM';
		$rules[] = 'domain_keyword,tvhay,NO-VIETNAM';
		$rules[] = 'domain_keyword,motchill,NO-VIETNAM';
		$rules[] = 'domain_keyword,motphim,NO-VIETNAM';
		$rules[] = 'rule_set,porn,NO-VIETNAM';
		$rules[] = 'rule_set,google,KHAIPHAN';
		$rules[] = 'rule_set,facebook,KHAIPHAN';
		$rules[] = 'rule_set,openai,KHAIPHAN';
		$rules[] = 'rule_set,gfw,NO-VIETNAM';
	}
	
	$rules = groupRulesByOutbound($rules);
	$orderRules = ['DIRECT', 'KHAIPHAN', 'NO-VIETNAM'];
	$rules = singboxSortRules($rules, $orderRules);

	foreach (array_reverse($rules) as $outbound => $itemRules) {
		$newRules = [];
		foreach ($itemRules as $rule) {
        $type = $rule['type'];
        $value = $rule['value'];
        
        if (!isset($newRules[$type])) {
			$newRules[$type] = [];
        }
        	$newRules[$type][] = $value;
		}
		
		$rulesArray = [];
		foreach ($newRules as $type => $values) {
        	$rulesArray[] = [$type => $values];
		}
		
		$rulesConfig = [
        	'type' => 'logical',
        	'mode' => 'or',
        	'rules' => $rulesArray,
        	'outbound' => $outbound
		];
		$config['route']['rules'] = array_merge([$rulesConfig], $config['route']['rules']);
	}
	
	$preRules[] = ['protocol' => 'dns', 'outbound' => 'DNS-OUT'];	
	$preRules[] = ['port' => 53, 'outbound' => 'DNS-OUT'];
	$preRules[] = ['inbound' => ['dns-in'], 'outbound' => 'DNS-OUT'];
	$preRules[] = ["ip_cidr" => ["224.0.0.0/3", "ff00::/8"], "outbound" => "BLOCK"];
	$preRules[] = ["source_ip_cidr" => ["224.0.0.0/3", "ff00::/8"], "outbound" => "BLOCK"];
	
	// Không được đổi vị trí dòng này
	$preRules[] = ["ip_is_private" => true, "outbound" => "DIRECT"];
	
	$config['route']['rules'] = array_merge($preRules, $config['route']['rules']);

    $jsonConfig = json_encode($config, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);

    return $jsonConfig;
}

function singboxSortRules($rules, $order) {
    uksort($rules, function($a, $b) use ($order) {
        $posA = array_search($a, $order);
        $posB = array_search($b, $order);

        $posA = ($posA === false) ? PHP_INT_MAX : $posA;
        $posB = ($posB === false) ? PHP_INT_MAX : $posB;

        return $posA - $posB;
    });

    return $rules;
}

function isClashRule($rule) {
	$pattern = '/^(FIRSTY|IP-CIDR6|SCRIPT|RULE-SET|IPSET|PROCESS-PATH|SRC-IP-CIDR|SRC-PORT|DST-PORT|RULE-SET|IP-CIDR|PROCESS-NAME|GEOSITE|GEOIP|DOMAIN|DOMAIN-SUFFIX|DOMAIN-KEYWORD),\s*[^,]+,\s*[^,]+(?:,\s*[^,]+)?$/';
	return preg_match($pattern, $rule);
}

function isSingboxRule($rule) {
	$pattern = '/^(firsty|inbound|ip_version|network|auth_user|protocol|client|domain|domain_suffix|domain_keyword|domain_regex|geosite|source_geoip|geoip|source_ip_cidr|source_ip_is_private|ip_cidr|ip_is_private|source_port|source_port_range|port|port_range|process_name|process_path|package_name|user|user_id|clash_mode|wifi_ssid|wifi_bssid|rule_set),\s*[^,]+,\s*[^,]+(?:,\s*[^,]+)?$/';
	return preg_match($pattern, $rule);
}

function groupRulesByOutbound($rules) {
    $groupedRules = [];

    foreach ($rules as $rule) {
        if (!isClashRule($rule) && !isSingboxRule($rule)) {
            continue;
        }

        list($type, $value, $outbound) = explode(',', $rule);
        
        if (!isset($groupedRules[$outbound])) {
            $groupedRules[$outbound] = [];
        }

        $conversionMap = [
            "DOMAIN" => "domain",
            "DOMAIN-SUFFIX" => "domain_suffix",
            "DOMAIN-KEYWORD" => "domain_keyword",
            "GEOIP" => "geoip",
			"GEOSITE" => "geosite",
            "IP-CIDR" => "ip_cidr",
            "IP-CIDR6" => "ip_cidr",
            "SRC-IP-CIDR" => "source_ip_cidr",
            "SRC-PORT" => "source_port",
            "DST-PORT" => "port",
            "PROCESS-NAME" => "process_name",
            "PROCESS-PATH" => "process_path",
            "RULE-SET" => "rule_set",
			"FIRSTY" => "firsty"
        ];

        $type = $conversionMap[$type] ?? $type;

        $groupedRules[$outbound][] = [
            'type' => $type,
            'value' => $value,
        ];
    }

    return $groupedRules;
}

function getCacheDirectory() {
	$cacheDir = './cache';
    if (is_dir($cacheDir) && is_readable($cacheDir) && is_writable($cacheDir)) {
        return rtrim(realpath($cacheDir), DIRECTORY_SEPARATOR);
    }
    return rtrim(realpath(sys_get_temp_dir()), DIRECTORY_SEPARATOR);
}

function cacheSave($key, $data, $ttl = 3600) {
    $cacheFile = getCacheDirectory() . "/cache_" . md5($key);
    $cacheData = [
        'data' => $data,
        'expiry' => time() + $ttl
    ];
    file_put_contents($cacheFile, serialize($cacheData));
}

function cacheGet($key) {
    $cacheFile = getCacheDirectory() . "/cache_" . md5($key);

    if (file_exists($cacheFile)) {
        $cacheData = unserialize(file_get_contents($cacheFile));

        if (time() < $cacheData['expiry']) {
            return $cacheData['data'];
        } else {
            unlink($cacheFile);
        }
    }

    return null;
}

function base64UrlDecode($base64Url) {
    $base64 = str_replace(['-', '_'], ['+', '/'], $base64Url);
    $padding = strlen($base64) % 4;
    if ($padding) {
        $base64 .= str_repeat('=', 4 - $padding);
    }
    return base64_decode($base64);
}

function base64UrlEncode($data) {
    $base64 = base64_encode($data);
    $base64Url = str_replace(['+', '/'], ['-', '_'], rtrim($base64, '='));
    return $base64Url;
}

function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

function renewFirsty($token, $iccid) {
	
	$authToken = getAccessTokenFirsty($token);
	
	if (!$authToken) {
		return null;
	}
	
    $parts = explode('.', $authToken);
	if (!isset($parts[1])) {
		return false;
	}
    $payload = base64_decode($parts[1]);
    $data = json_decode($payload, true);
	if (!isset($data['user_id'])) {
		return false;
	}
    $userId = $data['user_id'];
	

    $baseUrl = 'https://backoffice.firsty.app/api/mobile/users/v2/' . $userId . '/';
    $headers = [
        'user-agent: Dart/3.5 (dart:io)',
        'accept-encoding: gzip',
        'authorization: Bearer ' . $authToken,
        'device-info: iPhone11,8 17.0',
        'app-build: 9999',
        'content-type: application/json',
        'app-version: 9.9.999',
    ];

    function executeCurl($url, $headers, $postData = null) {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_ENCODING, 'gzip');

        if ($postData !== null) {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
        }

        $response = curl_exec($ch);
        curl_close($ch);
        return $response;
    }

    $waitlistUrl = $baseUrl . 'waitlist';
    $waitlistResponse = executeCurl($waitlistUrl, $headers);
    //echo "Response from waitlist: \n" . $waitlistResponse . "\n\n";

    $subscriptionUrl = 'https://backoffice.firsty.app/api/mobile/subscriptions/v2/' . $userId . '/iccid/' . $iccid . '/free';
    $postData = json_encode([
        "planType" => "ADVERTISEMENT",
        "deviceId" => "5993C521-924B-4808-9D36-24AFAB569C3F",
        "country" => "TW"
    ]);
    $subscriptionResponse = executeCurl($subscriptionUrl, $headers, $postData);
	$subcriptionResponseDecoded = json_decode($subscriptionResponse, true);
	if (isset($subcriptionResponseDecoded['code']) && isset($subcriptionResponseDecoded['data']['freeSubscriptionTransactionId'])) {
		return $subcriptionResponseDecoded['data']['freeSubscriptionTransactionId'];
	}
	
	return null;
}

function getAccessTokenFirsty($refreshToken) {
    $url = "https://securetoken.googleapis.com/v1/token?key=AIzaSyAw4dSOEuZNgBWLAiwSAqPJ9qArvSOaZDM";

    $headers = [
        'Accept-Encoding: gzip, deflate, br',
        'Accept: */*',
        'Connection: keep-alive',
        'Content-Type: application/json',
        'Host: securetoken.googleapis.com',
        'X-Ios-Bundle-Identifier: com.firsty.app',
        'User-Agent: FirebaseAuth.iOS/10.25.0 com.firsty.app/1.0.352 iPad/17.5.1 hw/iPad11_3',
        'Accept-Language: en',
        'X-Client-Version: iOS/FirebaseSDK/10.25.0/FirebaseCore-iOS',
        'X-Firebase-GMPID: 1:962364472393:ios:fede98035afd07718c1398'
    ];

    $body = [
        "grantType" => "refresh_token",
        "refreshToken" => $refreshToken
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
    curl_setopt($ch, CURLOPT_ENCODING, 'gzip');

    $response = curl_exec($ch);
    $info = curl_getinfo($ch);
    curl_close($ch);

    if (isset($info['content_encoding']) && $info['content_encoding'] === 'gzip') {
        $response = gzdecode($response);
    }

    $respDecoded = json_decode($response, true);
	
	if (isset($respDecoded['access_token'])) {
		return $respDecoded['access_token'];
	}
	
	return null;
}