<?php

require 'helpers.php';

// Nhận dữ liệu từ yêu cầu
$input = file_get_contents('php://input');
$requestData = json_decode($input, true);

// Tải custom data từ biến môi trường
$customData = env('SUBSCRIPTION_URLS', [
    'https://data4ggiare.com/api/v1/client/subscribe?token=e8663392cc278ddd6f3a60058adf2b9b',
    'https://vpn.xn--ss-8ja.vn/api/v1/client/fa636b9e55a98a9b4d7a9d685aa06740',
    'https://tai4g.vn/api/v1/client/subscribe?token=f6b0abfa71cb4391d0bbb3fea862bc70',
    'https://sub.fuzzypn.me/api/v1/client/8eb6d8b9090260e21072a04ef1729335?sni=m.tiktok.com',
    'vless://2211755b-8af2-4f37-a8aa-5aa595282e22@hoaivnpt.duckdns.org:80?path=%2F&security=none&encryption=none&host=backoffice.firsty.app&type=ws#VNPT-KhaiPhan',
    'vmess://ewogICJ2IjogIjIiLAogICJwcyI6ICJ2aW5hK3lvdXR1YmUtbHpzc25sbmgiLAogICJhZGQiOiAiNGcuYW5ocXVhbi50ZWNoIiwKICAicG9ydCI6IDgwLAogICJpZCI6ICIwOTYyODU3MC01NTYyLTRhNjUtOTVjMy1jNjg1ZmFjMThjMGEiLAogICJzY3kiOiAiYXV0byIsCiAgIm5ldCI6ICJ3cyIsCiAgInR5cGUiOiAibm9uZSIsCiAgInRscyI6ICJub25lIiwKICAicGF0aCI6ICIvIiwKICAiaG9zdCI6ICIiCn0='
]);

/**
 * Xử lý yêu cầu POST
 */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');

    if (isset($requestData['urlList']) && is_string($requestData['urlList']) && !empty($requestData['urlList'])) {
        $configList = trim($requestData['urlList']);
        if (!empty($configList)) {
            $sni = isset($requestData['sni']) && !empty($requestData['sni']) && is_string($requestData['sni']) ? $requestData['sni'] : $_SERVER['HTTP_HOST'];
            $sni = getSniQuickly($sni);

            $urls = explode("\n", $configList);
            $dataArrays = array_map('getDataFromUrl', $urls);
            $parsedData = array_merge(...$dataArrays);

            $dataRemakeArrays = array_map(function($url) use ($sni) {
                return [remakeSniUrlConfig($url, $sni)];
            }, $parsedData);

            $finalData = array_merge(...$dataRemakeArrays);
            $finalData = removeEmptyValues($finalData);

            $clashConfig = generateClashConfig($finalData, $requestData);
            $singboxConfig = generateSingboxConfig($finalData, $requestData);
            $clashProxyProviderConfig = generateClashConfig([], array_merge(['isRemote' => true], $requestData));

            echo json_encode([
                'clashConfig' => $clashConfig,
                'clashProxyProviderConfig' => $clashProxyProviderConfig,
                'singboxConfig' => $singboxConfig,
            ]);
        } else {
            echo json_encode([
                'error' => 'Dữ liệu không hợp lệ!',
            ]);
        }
    } else {
        echo json_encode([
            'error' => 'Dữ liệu không hợp lệ!',
        ]);
    }
/**
 * Xử lý yêu cầu GET
 */
} elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
    header('Content-Type: text/plain');

    // Xử lý yêu cầu clash
    if (isset($_GET['clash'])) {
        processClashRequest();
    }
    // Xử lý yêu cầu sing-box
    elseif (isset($_GET['sing-box'])) {
        processSingboxRequest();
    }
    // Xử lý yêu cầu sing-box-basic
    elseif (isset($_GET['sing-box-basic'])) {
        processSingboxBasicRequest();
    }
    // Xử lý yêu cầu clash-proxy-provider
    elseif (isset($_GET['clash-proxy-provider'])) {
        processClashProxyProviderRequest();
    }
    // Xử lý yêu cầu clash-proxy-cloud
    elseif (isset($_GET['clash-proxy-cloud'])) {
        processClashProxyCloudRequest();
    }
    // Xử lý yêu cầu clash-firsty-rule-provider
    elseif (isset($_GET['clash-firsty-rule-provider'])) {
        processClashFirstyRuleProviderRequest();
    } else {
        echo 'Tham số không chính xác!';
    }
} else {
    header('Content-Type: text/plain');
    echo 'Yêu cầu bị từ chối!';
}

/**
 * Xử lý yêu cầu Clash
 */
function processClashRequest() {
    global $customData;

    $requestData = [];
    parse_str(isset($_GET['data']) && is_string($_GET['data']) ? base64UrlDecode($_GET['data']) : '', $requestData);

    if ((isset($requestData['urlList']) && is_string($requestData['urlList'])) || isset($_GET['customData'])) {
        $sni = isset($requestData['sni']) && !empty($requestData['sni']) && is_string($requestData['sni']) ? $requestData['sni'] : $_SERVER['HTTP_HOST'];
        $sni = getSniQuickly($sni);

        $urls = isset($_GET['customData']) ? $customData : explode("\n", trim($requestData['urlList']));
        $dataArrays = array_map('getDataFromUrl', $urls);
        $parsedData = array_merge(...$dataArrays);

        $dataRemakeArrays = array_map(function($url) use ($sni) {
            return [remakeSniUrlConfig($url, $sni)];
        }, $parsedData);

        $finalData = array_merge(...$dataRemakeArrays);
        $finalData = removeEmptyValues($finalData);

        $clashConfig = generateClashConfig($finalData, $requestData);

        echo $clashConfig;
    } else {
        echo 'Dữ liệu không hợp lệ!';
    }
}

/**
 * Xử lý yêu cầu Sing-box
 */
function processSingboxRequest() {
    global $customData;

    $requestData = [];
    parse_str(isset($_GET['data']) && is_string($_GET['data']) ? base64UrlDecode($_GET['data']) : '', $requestData);

    if ((isset($requestData['urlList']) && is_string($requestData['urlList'])) || isset($_GET['customData'])) {
        $sni = isset($requestData['sni']) && !empty($requestData['sni']) && is_string($requestData['sni']) ? $requestData['sni'] : $_SERVER['HTTP_HOST'];
        $sni = getSniQuickly($sni);

        $urls = isset($_GET['customData']) ? $customData : explode("\n", trim($requestData['urlList']));
        $dataArrays = array_map('getDataFromUrl', $urls);
        $parsedData = array_merge(...$dataArrays);

        $dataRemakeArrays = array_map(function($url) use ($sni) {
            return [remakeSniUrlConfig($url, $sni)];
        }, $parsedData);

        $finalData = array_merge(...$dataRemakeArrays);
        $finalData = removeEmptyValues($finalData);

        $singboxConfig = generateSingboxConfig($finalData, $requestData);

        echo $singboxConfig;
    } else {
        echo 'Dữ liệu không hợp lệ!';
    }
}

/**
 * Xử lý yêu cầu Sing-box Basic
 */
function processSingboxBasicRequest() {
    global $customData;

    $requestData = [];
    parse_str(isset($_GET['data']) && is_string($_GET['data']) ? base64UrlDecode($_GET['data']) : '', $requestData);

    if ((isset($requestData['urlList']) && is_string($requestData['urlList'])) || isset($_GET['customData'])) {
        $sni = isset($requestData['sni']) && !empty($requestData['sni']) && is_string($requestData['sni']) ? $requestData['sni'] : $_SERVER['HTTP_HOST'];
        $sni = getSniQuickly($sni);

        $urls = isset($_GET['customData']) ? $customData : explode("\n", trim($requestData['urlList']));
        $dataArrays = array_map('getDataFromUrl', $urls);
        $parsedData = array_merge(...$dataArrays);

        $dataRemakeArrays = array_map(function($url) use ($sni) {
            return [remakeSniUrlConfig($url, $sni)];
        }, $parsedData);

        $finalData = array_merge(...$dataRemakeArrays);
        $finalData = removeEmptyValues($finalData);

        $singboxBasicConfig = generateSingboxBasicConfig($finalData, $requestData);

        echo $singboxBasicConfig;
    } else {
        echo 'Dữ liệu không hợp lệ!';
    }
}

/**
 * Xử lý yêu cầu Clash Proxy Provider
 */
function processClashProxyProviderRequest() {
    $requestData = [];
    parse_str(isset($_GET['data']) && is_string($_GET['data']) ? base64UrlDecode($_GET['data']) : '', $requestData);

    if ((isset($requestData['urlList']) && is_string($requestData['urlList'])) || isset($_GET['customData'])) {
        if (isset($_GET['customData'])) {
            $requestData['customData'] = true;
        }
        echo generateClashConfig([], array_merge(['isRemote' => true], $requestData));
    } else {
        echo 'Dữ liệu không hợp lệ!';
    }
}

/**
 * Xử lý yêu cầu Clash Proxy Cloud
 */
function processClashProxyCloudRequest() {
    global $customData;

    $requestData = [];
    parse_str(isset($_GET['data']) && is_string($_GET['data']) ? base64UrlDecode($_GET['data']) : '', $requestData);

    if ((isset($requestData['urlList']) && is_string($requestData['urlList'])) || isset($_GET['customData'])) {
        $sni = isset($requestData['sni']) && !empty($requestData['sni']) && is_string($requestData['sni']) ? $requestData['sni'] : $_SERVER['HTTP_HOST'];
        $sni = getSniQuickly($sni);
        $urls = isset($_GET['customData']) ? $customData : explode("\n", trim($requestData['urlList']));
        $dataArrays = array_map('getDataFromUrl', $urls);
        $parsedData = array_merge(...$dataArrays);

        $dataRemakeArrays = array_map(function($url) use ($sni) {
            return [remakeSniUrlConfig($url, $sni)];
        }, $parsedData);

        $finalData = array_merge(...$dataRemakeArrays);
        $finalData = removeEmptyValues($finalData);

        echo generateClashProxyProviderConfig($finalData);
    }
}

/**
 * Xử lý yêu cầu Clash Firsty Rule Provider
 */
function processClashFirstyRuleProviderRequest() {
    if (isset($_GET['iccid']) && isset($_GET['token']) && is_string($_GET['token']) && is_string($_GET['iccid'])) {
        if($renewId = renewFirsty($_GET['token'], $_GET['iccid'])) {
            echo "# Renew thanh cong. ID: $renewId\n";
        }
    }

    $domains = [
        'firsty.app',
        'backoffice.firsty.app',
        'refer.test.firsty.app',
        'refer.firsty.app',
        'backoffice.test.firsty.app',
        'googleads.g.doubleclick.net'
    ];

    $formattedDomains = [];

    foreach ($domains as $domain) {
        $formattedDomains[] = '+.' . $domain;
    }

    echo arrayToYaml(['payload' => $formattedDomains]);
}

/**
 * Kiểm tra hỗ trợ rewrite URL
 */
function isSupportRewrite() {
    return isset($_SERVER['HTTP_X_VERCEL_ID']) || isset($_SERVER['KOYEB_APP_ID']) || isset($_ENV['RENDER_SERVICE_ID']);
}
