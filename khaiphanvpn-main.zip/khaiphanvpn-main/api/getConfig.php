<?php

require 'helpers.php';

$input = file_get_contents('php://input');
$requestData = json_decode($input, true);

$customData = array (
	'https://data4ggiare.com/api/v1/client/subscribe?token=e8663392cc278ddd6f3a60058adf2b9b',
    'https://vpn.xn--ss-8ja.vn/api/v1/client/fa636b9e55a98a9b4d7a9d685aa06740',
    'https://tai4g.vn/api/v1/client/subscribe?token=f6b0abfa71cb4391d0bbb3fea862bc70',
    'https://sub.fuzzypn.me/api/v1/client/8eb6d8b9090260e21072a04ef1729335?sni=m.tiktok.com',
	// Lẻ
	'vless://2211755b-8af2-4f37-a8aa-5aa595282e22@hoaivnpt.duckdns.org:80?path=%2F&security=none&encryption=none&host=backoffice.firsty.app&type=ws#VNPT-KhaiPhan',
	// GG
	'vmess://ewogICJ2IjogIjIiLAogICJwcyI6ICJ2aW5hK3lvdXR1YmUtbHpzc25sbmgiLAogICJhZGQiOiAiNGcuYW5ocXVhbi50ZWNoIiwKICAicG9ydCI6IDgwLAogICJpZCI6ICIwOTYyODU3MC01NTYyLTRhNjUtOTVjMy1jNjg1ZmFjMThjMGEiLAogICJzY3kiOiAiYXV0byIsCiAgIm5ldCI6ICJ3cyIsCiAgInR5cGUiOiAibm9uZSIsCiAgInRscyI6ICJub25lIiwKICAicGF0aCI6ICIvIiwKICAiaG9zdCI6ICIiCn0='
);

//$_SERVER['REQUEST_METHOD'] = 'POST';
//$requestData['urlList'] = implode("\n", $customData);
//$_GET['clash'] = true;
//$_GET['customData'] = true;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    
    if (isset($requestData['urlList']) && is_string($requestData['urlList']) && !empty($requestData['urlList'])) {
        $configList = trim($requestData['urlList']);
        if (!empty($configList)) {
            $sni = isset($requestData['sni']) && !empty($requestData['sni']) && is_string($requestData['sni']) ? $requestData['sni'] : $_SERVER['HTTP_HOST'];
			$sni = getSniQuickly($sni);
            
            $urls = explode("\n", $configList);
            $dataArrays = array_map('getDataFromUrl', $urls);
            $parsedData = array_merge(...$dataArrays);

            $dataRemakeArrays = array_map(function($url) use ($sni) {
                return [remakeSniUrlConfig($url, $sni)];
            }, $parsedData);

            $finalData = array_merge(...$dataRemakeArrays);
            $finalData = removeEmptyValues($finalData);
            
            $clashConfig = generateClashConfig($finalData, $requestData);
            $singboxConfig = generateSingboxConfig($finalData, $requestData);
			$clashProxyProviderConfig = generateClashConfig([], array_merge(['isRemote' => true], $requestData));
            
            echo json_encode([
                'clashConfig' => $clashConfig,
				'clashProxyProviderConfig' => $clashProxyProviderConfig,
                'singboxConfig' => $singboxConfig,
            ]);
        } else {
            echo json_encode([
                'error' => 'Dữ liệu không hợp lệ!',
            ]);
        }
    } else {
        echo json_encode([
            'error' => 'Dữ liệu không hợp lệ!',
        ]);
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
    header('Content-Type: text/plain');
    
    if (isset($_GET['clash'])) {
        $requestData = [];
        parse_str(isset($_GET['data']) && is_string($_GET['data']) ? base64UrlDecode($_GET['data']) : '', $requestData);
        
        if ((isset($requestData['urlList']) && is_string($requestData['urlList'])) || isset($_GET['customData'])) {
            $sni = isset($requestData['sni']) && !empty($requestData['sni']) && is_string($requestData['sni']) ? $requestData['sni'] : $_SERVER['HTTP_HOST'];
			$sni = getSniQuickly($sni);

            $urls = isset($_GET['customData']) ? $customData : explode("\n", trim($requestData['urlList']));
            $dataArrays = array_map('getDataFromUrl', $urls);
            $parsedData = array_merge(...$dataArrays);

            $dataRemakeArrays = array_map(function($url) use ($sni) {
                return [remakeSniUrlConfig($url, $sni)];
            }, $parsedData);

            $finalData = array_merge(...$dataRemakeArrays);
            $finalData = removeEmptyValues($finalData);

            $clashConfig = generateClashConfig($finalData, $requestData);
            
            echo $clashConfig;
        } else {
            echo 'Dữ liệu không hợp lệ!';
        }
    } elseif (isset($_GET['sing-box'])) {
        $requestData = [];
        parse_str(isset($_GET['data']) && is_string($_GET['data']) ? base64UrlDecode($_GET['data']) : '', $requestData);
        
        if ((isset($requestData['urlList']) && is_string($requestData['urlList'])) || isset($_GET['customData'])) {
            $sni = isset($requestData['sni']) && !empty($requestData['sni']) && is_string($requestData['sni']) ? $requestData['sni'] : $_SERVER['HTTP_HOST'];
			$sni = getSniQuickly($sni);
			
            $urls = isset($_GET['customData']) ? $customData : explode("\n", trim($requestData['urlList']));
            $dataArrays = array_map('getDataFromUrl', $urls);
            $parsedData = array_merge(...$dataArrays);

            $dataRemakeArrays = array_map(function($url) use ($sni) {
                return [remakeSniUrlConfig($url, $sni)];
            }, $parsedData);

            $finalData = array_merge(...$dataRemakeArrays);
            $finalData = removeEmptyValues($finalData);

            $clashConfig = generateSingboxConfig($finalData, $requestData);
            
            echo $clashConfig;
        } else {
            echo 'Dữ liệu không hợp lệ!';
        }
	} elseif (isset($_GET['sing-box-basic'])) {
        $requestData = [];
        parse_str(isset($_GET['data']) && is_string($_GET['data']) ? base64UrlDecode($_GET['data']) : '', $requestData);
        
        if ((isset($requestData['urlList']) && is_string($requestData['urlList'])) || isset($_GET['customData'])) {
            $sni = isset($requestData['sni']) && !empty($requestData['sni']) && is_string($requestData['sni']) ? $requestData['sni'] : $_SERVER['HTTP_HOST'];
			$sni = getSniQuickly($sni);
			
            $urls = isset($_GET['customData']) ? $customData : explode("\n", trim($requestData['urlList']));
            $dataArrays = array_map('getDataFromUrl', $urls);
            $parsedData = array_merge(...$dataArrays);

            $dataRemakeArrays = array_map(function($url) use ($sni) {
                return [remakeSniUrlConfig($url, $sni)];
            }, $parsedData);

            $finalData = array_merge(...$dataRemakeArrays);
            $finalData = removeEmptyValues($finalData);

            $clashConfig = generateSingboxBasicConfig($finalData, $requestData);
            
            echo $clashConfig;
        } else {
            echo 'Dữ liệu không hợp lệ!';
        }
    } elseif (isset($_GET['clash-proxy-provider'])) {
		$requestData = [];
        parse_str(isset($_GET['data']) && is_string($_GET['data']) ? base64UrlDecode($_GET['data']) : '', $requestData);
        
        if ((isset($requestData['urlList']) && is_string($requestData['urlList'])) || isset($_GET['customData'])) {
			if (isset($_GET['customData'])) {
				$requestData['customData'] = true;
			}
			echo generateClashConfig([], array_merge(['isRemote' => true], $requestData));
		} else {
            echo 'Dữ liệu không hợp lệ!';
        }
	} elseif (isset($_GET['clash-proxy-cloud'])) {
		$requestData = [];
        parse_str(isset($_GET['data']) && is_string($_GET['data']) ? base64UrlDecode($_GET['data']) : '', $requestData);
		
		if ((isset($requestData['urlList']) && is_string($requestData['urlList'])) || isset($_GET['customData'])) {
			$sni = isset($requestData['sni']) && !empty($requestData['sni']) && is_string($requestData['sni']) ? $requestData['sni'] : $_SERVER['HTTP_HOST'];
			$sni = getSniQuickly($sni);
			$urls = isset($_GET['customData']) ? $customData : explode("\n", trim($requestData['urlList']));
            $dataArrays = array_map('getDataFromUrl', $urls);
            $parsedData = array_merge(...$dataArrays);

            $dataRemakeArrays = array_map(function($url) use ($sni) {
                return [remakeSniUrlConfig($url, $sni)];
            }, $parsedData);

            $finalData = array_merge(...$dataRemakeArrays);
            $finalData = removeEmptyValues($finalData);
			
			echo generateClashProxyProviderConfig($finalData);
		}
		
	} elseif (isset($_GET['clash-firsty-rule-provider'])) {
		if (isset($_GET['iccid']) && isset($_GET['token']) && is_string($_GET['token']) && is_string($_GET['iccid'])) {
			if($renewId = renewFirsty($_GET['token'], $_GET['iccid'])) {
				echo "# Renew thanh cong. ID: $renewId\n";
			}
		}
		
		$domains = [
			'firsty.app',
			'backoffice.firsty.app',
			'refer.test.firsty.app',
			'refer.firsty.app',
			'backoffice.test.firsty.app',
			'googleads.g.doubleclick.net'
		];
		
		$formattedDomains = [];
		
		foreach ($domains as $domain) {
			$formattedDomains[] = '+.' . $domain;
		}
		
		echo arrayToYaml(['payload' => $formattedDomains]);
	} else {
        echo 'Tham số không chính xác!';
    }
} else {
    header('Content-Type: text/plain');
    echo 'Yêu cầu bị từ chối!';
}
