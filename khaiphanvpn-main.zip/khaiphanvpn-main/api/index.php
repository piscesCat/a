<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tạo Cấu Hình Clash, Sing-box cho BoxForMagisk</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .loading {
            display: none;
        }
        .config-result {
            display: none;
            margin-top: 20px;
        }
        .copy-btn {
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <h2 class="mb-4">Tạo Cấu Hình Clash, Sing-box cho BoxForMagisk</h2>
        <form id="configForm">
            <?php if (!isset($_GET['customData'])) { ?>
            <div class="mb-3">
                <label for="urlList" class="form-label">Nhập V2ray/Xray/Subcribes URL (Cách nhau bởi dấu xuống dòng)</label>
                <textarea class="form-control" id="urlList" rows="5" placeholder="vless://example
vless://example
trojan://example
https://example.com/subcribe?token=
			"></textarea>
            </div>
            <?php } ?>

            <div class="mb-3">
                <label for="sni" class="form-label">Nhập SNI</label>
                <input type="text" class="form-control" id="sni" placeholder="<?= $_SERVER['HTTP_HOST'] ?? 'Nhập SNI' ?>">
            </div>

            <div class="mb-3">
                <label for="rules" class="form-label">Rules (hỗ trợ GEOSITE, GEOIP, DOMAIN, DOMAIN-SUFFIX, DOMAIN-KEYWORD, Sing-box chưa hỗ trợ -no-relsove)</label>
                <textarea class="form-control" id="rules" rows="5" placeholder="GEOSITE,category-porn,US
GEOIP,tiktok,DIRECT
DOMAIN-SUFFIX,viettel.vn,DIRECT"></textarea>
            </div>

            <div class="text-center loading">
                <div class="spinner-border" role="status">
                    <span class="visually-hidden">Đang tạo config...</span>
                </div>
                <p>Đang tạo config...</p>
            </div>

            <button type="submit" class="btn btn-primary">Tạo Config</button>
        </form>

        <div id="configResults" class="config-result">
			<?php if (!isset($_GET['customData'])) { ?>
            <div class="alert alert-info" role="alert">
			<strong>Để config này có hiệu lực cần:</strong>
			<p>- Tại /data/adb/box/settings.ini sửa bin_name="clash" hoặc bin_name="sing-box" tương ứng.</p>
			<p>- Tiếp tục copy config và thay thế vào /data/adb/box/clash/config.yaml hoặc /data/adb/box/sing-box/config.json tương ứng.</p>
			<p>- Tại /data/adb/box/settings.ini sửa network_mode="tun" thay cho tproxy nếu config không hoạt động.</p>
			<p>- Quản lý tại http://ip-lan:9090 hoặc http://127.0.0.1:9090</p>
			<p>Lưu ý: Lần đầu tiên khởi động BFM cần phải có internet (VD: WIFI), bật và để ít phút sau đó khởi động lại điện thoại để có hiệu lực.</p>
            </div>
			<?php } ?>

            <div class="row mt-4">
                <div class="col-md-6">
                    <label for="clashUrl" class="form-label">Link tạo Clash Config cho app:</label>
                    <input type="text" class="form-control" id="clashUrl" readonly>
                    <button type="button" class="btn btn-secondary copy-btn" onclick="copyToClipboard('clashUrl')">Sao chép URL</button>
                </div>
				
				<div class="col-md-6">
                    <label for="clashUrl" class="form-label">Link tạo Clash Proxy Provider Config cho app:</label>
                    <input type="text" class="form-control" id="clashProxyProviderUrl" readonly>
                    <button type="button" class="btn btn-secondary copy-btn" onclick="copyToClipboard('clashProxyProviderUrl')">Sao chép URL</button>
                </div>

                <?php if (!isset($_GET['customData'])) { ?>
                <div class="col-md-6">
                    <label for="clashConfig" class="form-label">Clash Config:</label>
                    <textarea class="form-control" id="clashConfig" rows="5" placeholder="Kết quả Clash Config..."></textarea>
                    <button type="button" class="btn btn-secondary copy-btn" onclick="copyToClipboard('clashConfig')">Sao chép Clash Config</button>
                </div>
				
				<div class="col-md-6">
                    <label for="clashConfig" class="form-label">Clash Provider Config:</label>
                    <textarea class="form-control" id="clashProxyProviderConfig" rows="5" placeholder="Kết quả Clash Provider Config..."></textarea>
                    <button type="button" class="btn btn-secondary copy-btn" onclick="copyToClipboard('clashConfig')">Sao chép Clash Provider Config</button>
                </div>
                <?php } ?>

                <div class="col-md-6">
                    <label for="singboxUrl" class="form-label">Link tạo Sing-box Config cho app:</label>
                    <input type="text" class="form-control" id="singboxUrl" readonly>
                    <button type="button" class="btn btn-secondary copy-btn" onclick="copyToClipboard('singboxUrl')">Sao chép URL</button>
                </div>
				
				<?php if (isset($_GET['customData'])) { ?>
                <div class="col-md-6">
                    <label for="singboxBasicUrl" class="form-label">Link tạo Sing-box Basic Config cho app:</label>
                    <input type="text" class="form-control" id="singboxBasicUrl" readonly>
                    <button type="button" class="btn btn-secondary copy-btn" onclick="copyToClipboard('singboxBasicUrl')">Sao chép URL</button>
                </div>
                <?php } ?>

                <?php if (!isset($_GET['customData'])) { ?>
                <div class="col-md-6">
                    <label for="singboxConfig" class="form-label">Sing-box Config:</label>
                    <textarea class="form-control" id="singboxConfig" rows="5" placeholder="Kết quả Sing-box Config..."></textarea>
                    <button type="button" class="btn btn-secondary copy-btn" onclick="copyToClipboard('singboxConfig')">Sao chép Sing-box Config</button>
                </div>
                <?php } ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        function copyToClipboard(elementId) {
            var copyText = document.getElementById(elementId);
            copyText.select();
            document.execCommand("copy");
            alert("Đã sao chép!");
        }

        function saveToLocalStorage() {
            <?php if (!isset($_GET['customData'])) { ?>
            const urlList = document.getElementById('urlList').value;
            <?php } ?>
            const sni = document.getElementById('sni').value;
            const rules = document.getElementById('rules').value;

            <?php if (!isset($_GET['customData'])) { ?>
            localStorage.setItem('urlList', urlList);
            <?php } ?>
            localStorage.setItem('sni', sni);
            localStorage.setItem('rules', rules);
        }

        function loadFromLocalStorage() {
			<?php if (!isset($_GET['customData'])) { ?>
			const urlList = localStorage.getItem('urlList');
			<?php } ?>
            const sni = localStorage.getItem('sni');
            const rules = localStorage.getItem('rules');

			<?php if (!isset($_GET['customData'])) { ?>
			if (urlList) document.getElementById('urlList').value = urlList;
			<?php } ?>
            if (sni) document.getElementById('sni').value = sni;
            if (rules) document.getElementById('rules').value = rules;
        }

        function base64UrlEncode(input) {
            let base64 = btoa(input);
            base64 = base64.replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
            return base64;
        }

        function createGetUrl(baseUrl, params) {
            const queryString = new URLSearchParams(params).toString();
            const data = base64UrlEncode(queryString);
            return `${baseUrl}${data}`;
        }

		loadFromLocalStorage();
		
        document.getElementById('configForm').addEventListener('submit', function(event) {
            event.preventDefault();

            document.querySelector('.loading').style.display = 'block';
            document.getElementById('configResults').style.display = 'none';

            saveToLocalStorage();

            const sni = document.getElementById('sni').value;
            const rules = document.getElementById('rules').value;

            <?php if (!isset($_GET['customData'])) { ?>
            const urlList = document.getElementById('urlList').value;
            <?php } else { ?>
            const urlList = '';
            <?php } ?>

            <?php if (!isset($_GET['customData'])) { ?>
				fetch('<?= isSupportRewrite() ? '/getConfig' : 'getConfig.php' ?>', {
                method: 'POST',
                headers: {
				'Content-Type': 'application/json',
                },
                body: JSON.stringify({
				urlList: urlList,
				sni: sni,
				rules: rules,
                }),
				})
				.then(response => response.json())
				.then(data => {
                if (data.error) {
					document.querySelector('.loading').style.display = 'none';
					alert('Lỗi: ' + data.error);
                } else {
					
					document.getElementById('clashConfig').value = data.clashConfig;
					document.getElementById('clashProxyProviderConfig').value = data.clashProxyProviderConfig;
					document.getElementById('singboxConfig').value = data.singboxConfig;
					
					const baseUrl = `${window.location.protocol}//${window.location.host}`;
					const clashUrl = createGetUrl(baseUrl + '/<?= isSupportRewrite() ? 'getConfig' : 'getConfig.php' ?>?clash&data=', { urlList, sni, rules });
					const singboxUrl  = createGetUrl(baseUrl + '/<?= isSupportRewrite() ? 'getConfig' : 'getConfig.php' ?>?sing-box&data=', { urlList, sni, rules });
					const clashProxyProviderUrl = createGetUrl(baseUrl + '/<?= isSupportRewrite() ? 'getConfig' : 'getConfig.php' ?>?clash-proxy-provider&data=', { urlList, sni, rules });
					
					document.getElementById('clashUrl').value = clashUrl;
					document.getElementById('singboxUrl').value = singboxUrl;
					document.getElementById('clashProxyProviderUrl').value = clashProxyProviderUrl;
					
					document.querySelector('.loading').style.display = 'none';
					document.getElementById('configResults').style.display = 'block';
					document.getElementById('configForm').style.display = 'none';
				}
				});
				<?php } else { ?>
				const baseUrl = `${window.location.protocol}//${window.location.host}`;
				const clashUrl = createGetUrl(baseUrl + '/<?= isSupportRewrite() ? 'getConfig' : 'getConfig.php' ?>?clash&customData&data=', { sni, rules });
				const singboxUrl = createGetUrl(baseUrl + '/<?= isSupportRewrite() ? 'getConfig' : 'getConfig.php' ?>?sing-box&customData&data=', { sni, rules });
				const singboxBasicUrl  = createGetUrl(baseUrl + '/<?= isSupportRewrite() ? 'getConfig' : 'getConfig.php' ?>?sing-box-basic&customData&data=', { sni, rules });
				const clashProxyProviderUrl = createGetUrl(baseUrl + '/<?= isSupportRewrite() ? 'getConfig' : 'getConfig.php' ?>?clash-proxy-provider&customData&data=', { sni, rules });
				
				document.getElementById('clashUrl').value = clashUrl;
				document.getElementById('singboxUrl').value = singboxUrl;
				document.getElementById('singboxBasicUrl').value = singboxBasicUrl;
				document.getElementById('clashProxyProviderUrl').value = clashProxyProviderUrl;
				
				document.getElementById('configForm').style.display = 'none';
				document.querySelector('.loading').style.display = 'none';
				document.getElementById('configResults').style.display = 'block';
				<?php } ?>
			
        });
    </script>
</body>
</html>
<?php
	function isSupportRewrite() {
		return isset($_SERVER['HTTP_X_VERCEL_ID']) || isset($_SERVER['KOYEB_APP_ID']) || isset($_ENV['RENDER_SERVICE_ID']);
	}
?>