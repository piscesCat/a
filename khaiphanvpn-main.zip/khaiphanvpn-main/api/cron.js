const axios = require('axios');

async function fetchData() {
  try {
    const response = await axios.get('https://khaiphanvpn.onrender.com/getConfig?clash-firsty-rule-provider&iccid=893107062434917784&token=AMf-vBzvSJf1H89gDV0RD5XB3E0XT-H9PGOkxORqNe8a73CPwWDb_a7BbV4YPEDZcEE8TrK7EBdaV5pxu-q8LAP09L2Y0XdBiK7N8Cc7yWiEuLvtKBgYrGB4dmNbvLL4EjKlXpHhFUEHiSzERqZr7ZNYknkiwYBHoWgEhnY8wwHMkTxmAe3X-aGEjZCtCBxCA4-mu0yWmnml_3jh1It9ko5CtcGaMI36LFBFyLGUkkSAAv2Go1zxhGYxgdu5nJKXJ2JdFmxqc0bSpYQH-xpkAE40Kw6irCQQb8PSDMEh4NbURUWPsCDlvqFCkPH8YiepCpSw1nJiOE_KrbpO7gdZcY6zvL4HvUNW6lINai-m8dkaNUQCJjgm0nfjoQ6esF6lawHw76m2eN7Bo4HlmvS2pezNdhbxLyV7A');
    const data = response.data;
    console.log(data);
  } catch (error) {
    console.error(error);
  }
}

fetchData();
