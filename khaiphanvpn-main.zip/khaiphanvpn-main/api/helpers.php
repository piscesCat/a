<?php
require 'geoip2.phar';
require '../helpers.php';  // Thêm dòng này để sử dụng các hàm xử lý biến môi trường

use GeoIp2\Database\Reader;

/**
 * Lấy nhóm quốc gia từ danh sách URL
 */
function getGroupFromUrl(array $urls) {
    $groups = [];

    foreach ($urls as $url) {
        $serverIP = null;

        if (strpos($url, 'vmess://') === 0) {
            $decoded = json_decode(base64_decode(str_replace('vmess://', '', $url)), true);
            if (isset($decoded['add'])) {
                $serverIP = resolveHostname($decoded['add']);
            }
        } elseif (strpos($url, 'vless://') === 0 || strpos($url, 'trojan://') === 0) {
            $parsedUrl = parse_url($url);
            if (isset($parsedUrl['host'])) {
                $serverIP = resolveHostname($parsedUrl['host']);
            }
        }

        if ($serverIP) {
            $groups[] = getCountry($serverIP);
        } else {
            $groups[] = 'GROUP_OTHERS';
        }
    }

    $groups = array_unique($groups);

    if (($key = array_search('GROUP_OTHERS', $groups)) !== false) {
        unset($groups[$key]);
        $groups[] = 'GROUP_OTHERS';
    }

    return $groups;
}

/**
 * Lấy nhóm ISP từ danh sách URL
 */
function getIspGroupFromUrl(array $urls) {
    $groups = [];

    foreach ($urls as $url) {
        $serverIP = null;

        if (strpos($url, 'vmess://') === 0) {
            $decoded = json_decode(base64_decode(str_replace('vmess://', '', $url)), true);
            if (isset($decoded['add'])) {
                $serverIP = resolveHostname($decoded['add']);
            }
        } elseif (strpos($url, 'vless://') === 0 || strpos($url, 'trojan://') === 0) {
            $parsedUrl = parse_url($url);
            if (isset($parsedUrl['host'])) {
                $serverIP = resolveHostname($parsedUrl['host']);
            }
        }

        if ($serverIP) {
            $groups[] = getISP($serverIP);
        } else {
            $groups[] = 'ISP_OTHERS';
        }
    }

    $groups = array_unique($groups);

    if (($key = array_search('ISP_OTHERS', $groups)) !== false) {
        unset($groups[$key]);
        $groups[] = 'ISP_OTHERS';
    }

    return $groups;
}

/**
 * Lấy proxy theo quốc gia từ danh sách URL
 */
function getProxiesByCountry($urls, $country) {
    $proxies = [];

    foreach ($urls as $url) {
        $serverIP = null;
        $proxyName = null;

        if (strpos($url, 'vmess://') === 0) {
            $decoded = json_decode(base64_decode(str_replace('vmess://', '', $url)), true);
            if (isset($decoded['add']) && isset($decoded['ps'])) {
                $serverIP = resolveHostname($decoded['add']);
                $proxyName = $decoded['ps'];
            }
        } elseif (strpos($url, 'vless://') === 0 || strpos($url, 'trojan://') === 0) {
            $parsedUrl = parse_url($url);
            if (isset($parsedUrl['host']) && isset($parsedUrl['fragment'])) {
                $serverIP = resolveHostname($parsedUrl['host']);
                $proxyName = urldecode($parsedUrl['fragment']);
            }
        }

        if ($serverIP && $proxyName) {
            $countryCode = getCountry($serverIP);
            if ($countryCode  === $country) {
                $proxies[] = $proxyName;
            }
        }

        if ($country === 'ALL' && $proxyName) {
            $proxies[] = $proxyName;
        }
    }

    return $proxies;
}

/**
 * Lấy proxy theo ISP từ danh sách URL
 */
function getProxiesByISP($urls, $isp) {
    $proxies = [];

    foreach ($urls as $url) {
        $serverIP = null;
        $proxyName = null;

        if (strpos($url, 'vmess://') === 0) {
            $decoded = json_decode(base64_decode(str_replace('vmess://', '', $url)), true);
            if (isset($decoded['add']) && isset($decoded['ps'])) {
                $serverIP = resolveHostname($decoded['add']);
                $proxyName = $decoded['ps'];
            }
        } elseif (strpos($url, 'vless://') === 0 || strpos($url, 'trojan://') === 0) {
            $parsedUrl = parse_url($url);
            if (isset($parsedUrl['host']) && isset($parsedUrl['fragment'])) {
                $serverIP = resolveHostname($parsedUrl['host']);
                $proxyName = urldecode($parsedUrl['fragment']);
            }
        }

        if ($serverIP && $proxyName) {
            $_isp = getISP($serverIP);
            if ($_isp  === $isp) {
                $proxies[] = $proxyName;
            }
        }

        if ($isp === 'ALL' && $proxyName) {
            $proxies[] = $proxyName;
        }
    }

    return $proxies;
}

/**
 * Loại bỏ giá trị rỗng khỏi mảng
 */
function removeEmptyValues(array $array): array {
    return array_filter($array, function($value) {
        return !empty($value) || $value === '0';
    });
}

/**
 * Lấy dữ liệu từ URL với bộ nhớ cache
 */
function getDataFromUrl($url) {
    $parsedUrl = parse_url($url);

    if (!isset($parsedUrl['scheme']) || ($parsedUrl['scheme'] !== 'http' && $parsedUrl['scheme'] !== 'https')) {
        return [$url];
    }

    $cachedData = cacheGet($url);

    if ($cachedData !== null) {
        $data = isBase64($cachedData) ? base64_decode($cachedData) : $cachedData;
        return explode("\n", $data);
    }

    $curl = curl_init();

    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "GET");

    $headers = [
        'User-Agent: v2rayn',
    ];
    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

    $response = curl_exec($curl);

    if (curl_errno($curl)) {
        curl_close($curl);
        return [];
    }

    curl_close($curl);

    cacheSave($url, $response, env('CACHE_TTL', 7200));

    $data = isBase64($response) ? base64_decode($response) : $response;

    return explode("\n", $data);
}

/**
 * Kiểm tra chuỗi có phải base64 không
 */
function isBase64($string) {
    $decoded = base64_decode($string, true);
    return $decoded !== false && base64_encode($decoded) === $string;
}

/**
 * Kiểm tra IP có thuộc Vietnam không
 */
function isIpFromVietnam($ip) {
    if (preg_match('/^34\./', $ip)) {
        return true;
    }

    $vietnamIpRanges = [
        '160.30.0.0/16',
    ];

    foreach ($vietnamIpRanges as $range) {
        if (isIpInRange($ip, $range)) {
            return true;
        }
    }

    return false;
}

/**
 * Kiểm tra IP có nằm trong dải IP không
 */
function isIpInRange($ip, $range) {
    list($subnet, $bits) = explode('/', $range);
    $ip = ip2long($ip);
    $subnet = ip2long($subnet);
    $mask = -1 << (32 - $bits);
    $subnet &= $mask;

    return ($ip & $mask) === $subnet;
}

/**
 * Lấy tên quốc gia từ IP
 */
function getCountry($ip) {
    if (isIpFromVietnam($ip)) {
        return 'Vietnam';
    }

    $url = env('GEOIP_MMDB_URL', 'https://github.com/P3TERX/GeoLite.mmdb/raw/download/GeoLite2-Country.mmdb');
    $mmdbFilePath = downloadMmdb($url);

    if (!$mmdbFilePath) {
        return 'GROUP_OTHERS';
    }

    $reader = new Reader($mmdbFilePath);

    try {
        $record = $reader->country($ip);
        return $record->country->name;
    } catch (Exception $e) {
        return 'GROUP_OTHERS';
    }
}

/**
 * Lấy ISP từ IP
 */
function getISP($ip) {
    $url = env('GEOIP_ASN_MMDB_URL', 'https://github.com/P3TERX/GeoLite.mmdb/raw/download/GeoLite2-ASN.mmdb');
    $mmdbFilePath = downloadMmdb($url);

    if (!$mmdbFilePath) {
        return 'ISP_OTHERS';
    }

    $reader = new Reader($mmdbFilePath);

    try {
        $record = $reader->asn($ip);
        return $record->autonomousSystemOrganization;
    } catch (Exception $e) {
        return 'ISP_OTHERS';
    }
}

/**
 * Cập nhật SNI trong cấu hình URL
 */
function remakeSniUrlConfig($url, $newHost) {
    $randomStr = generateRandomString(3);

    if (strpos($url, 'vmess://') === 0) {
        $url = str_replace('vmess://', '', $url);
        $decoded = base64_decode($url);
        $config = json_decode($decoded, true);

        if (!isset($config['add']) || !isset($config['port']) || !isset($config['id'])) {
            return '';
        }

        if (!isset($config['ps'])) {
            $config['ps'] = 'Unknown';
        }

        $serverIP = resolveHostname($config['add']);

        if (!$serverIP) {
            return '';
        }

        $country = getCountry($serverIP);
        $isp = getISP($serverIP);
        $config['ps'] = preg_match("/$country/i", $config['ps']) ? $config['ps'] : $config['ps'].'_'.$country;
        $config['ps'] = ($config['ps'] === $country) ? 'Proxy_'.$config['ps'] : $config['ps'];
        $config['ps'] = $config['ps'].'_'.$isp;
        $config['ps'] = $config['ps'].'_'.$randomStr;

        if (isset($config['host'])) {
            $config['host'] = $newHost;
        }

        $newConfig = json_encode($config);
        $newUrl = 'vmess://' . base64_encode($newConfig);

        return $newUrl;
    } elseif (strpos($url, 'trojan://') === 0) {
        $parsedUrl = parse_url($url);

        if(!isset($parsedUrl['host']) || !isset($parsedUrl['port']) || !isset($parsedUrl['user'])) {
            return '';
        }

        $queryParams = [];
        if (isset($parsedUrl['query'])) {
            parse_str($parsedUrl['query'], $queryParams);
        }

        if (isset($queryParams['peer'])) {
            $queryParams['peer'] = $newHost;
        }

        if (isset($queryParams['sni'])) {
            $queryParams['sni'] = $newHost;
        }

        $newUrl = $parsedUrl['scheme'] . '://' . $parsedUrl['user'] . '@' . $parsedUrl['host'];

        if (isset($parsedUrl['port'])) {
            $newUrl .= ':' . $parsedUrl['port'];
        }

        $newUrl .= '?' . http_build_query($queryParams);

        $name = 'Unknown';

        if (isset($parsedUrl['fragment'])) {
            $name = rtrim(urldecode($parsedUrl['fragment']), '_');
        }

        $serverIP = resolveHostname($parsedUrl['host']);

        if (!$serverIP) {
            return '';
        }

        $country = getCountry($serverIP);
        $isp = getISP($serverIP);
        $name = preg_match("/$country/i", $name) ? $name : $name.'_'.$country;
        $name = ($name === $country) ? 'Proxy_'.$name : $name;
        $name = $name.'_'.$isp;
        $name = $name.'_'.$randomStr;
        $newUrl .= '#' . urlencode($name);

        return $newUrl;
    } elseif (strpos($url, 'vless://') === 0) {
        $parsedUrl = parse_url($url);

        if(!isset($parsedUrl['host']) || !isset($parsedUrl['port']) || !isset($parsedUrl['user'])) {
            return '';
        }

        $queryParams = [];
        if (isset($parsedUrl['query'])) {
            parse_str($parsedUrl['query'], $queryParams);
        }

        if (isset($queryParams['host'])) {
            $queryParams['host'] = $newHost;
        }

        $newUrl = $parsedUrl['scheme'] . '://' . $parsedUrl['user'] . '@' . $parsedUrl['host'];

        if (isset($parsedUrl['port'])) {
            $newUrl .= ':' . $parsedUrl['port'];
        }

        $newUrl .= '?' . http_build_query($queryParams);

        $name = 'Unknown';

        if (isset($parsedUrl['fragment'])) {
            $name = rtrim(urldecode($parsedUrl['fragment']), '_');
        }

        $serverIP = resolveHostname($parsedUrl['host']);

        if (!$serverIP) {
            return '';
        }

        $country = getCountry($serverIP);
        $isp = getISP($serverIP);
        $name = preg_match("/$country/i", $name) ? $name : $name.'_'.$country;
        $name = ($name === $country) ? 'Proxy_'.$name : $name;
        $name = $name.'_'.$isp;
        $name = $name.'_'.$randomStr;
        $newUrl .= '#' . urlencode($name);

        return $newUrl;
    }

    return '';
}

/**
 * Tải file MMDB
 */
function downloadMmdb($url) {
    $tmpDir = getCacheDirectory();
    $fileName = basename(parse_url($url, PHP_URL_PATH));
    $filePath = $tmpDir . '/' . $fileName;

    if (file_exists($filePath) && pathinfo($fileName, PATHINFO_EXTENSION) === 'mmdb') {
        return $filePath;
    }

    $ch = curl_init($url);
    $fp = fopen($filePath, 'wb');
    curl_setopt($ch, CURLOPT_FILE, $fp);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_exec($ch);
    curl_close($ch);
    fclose($fp);

    if (file_exists($filePath) && pathinfo($fileName, PATHINFO_EXTENSION) === 'mmdb') {
        return $filePath;
    }

    return null;
}

/**
 * Giải quyết hostname thành IP
 */
function resolveHostname($input) {
    $cachedData = cacheGet('IP'.$input);

    if ($cachedData !== null) {
        return $cachedData;
    }

    if (filter_var($input, FILTER_VALIDATE_IP)) {
        return $input;
    } else {
        $ip = gethostbyname($input);

        if ($ip === $input) {
            return false;
        }

        cacheSave('IP'.$input, $ip, env('IP_CACHE_TTL', 604800));

        return $ip;
    }
}

/**
 * Lấy SNI từ các preset
 */
function getSniQuickly($sni) {
    $quicklySni = [
        'tiktok' => env('SNI_TIKTOK', 'v45.tiktokcdn.com'),
        'youtube' => env('SNI_YOUTUBE', 'rr1---sn-8qj-i5o6d.googlevideo.com'),
        'firsty' => env('SNI_FIRSTY', 'googleads.g.doubleclick.net')
    ];

    if (array_key_exists($sni, $quicklySni)) {
        return $quicklySni[$sni];
    }

    return $sni;
}

/**
 * Chuyển đổi mảng sang YAML
 */
function arrayToYaml($array, $indentLevel = 0, $isInList = false) {
    $yaml = '';
    $indent = str_repeat('  ', $indentLevel);

    foreach ($array as $key => $value) {
        if (is_array($value)) {
            if (is_numeric($key)) {
                $yaml .= $indent . "-";
                $yaml .= arrayToYaml($value, $indentLevel + 1, true);
            } else {
                $yaml .= $indent . $key . ":\n" . arrayToYaml($value, $indentLevel + 1);
            }
        } else {
            if (is_numeric($key)) {
                $valueFormatted = preg_match('/[^a-zA-Z0-9_]/', $value) ? '"'.$value.'"' : $value;
                $yaml .= $indent . "- " . (is_bool($valueFormatted) ? ($valueFormatted ? 'true' : 'false') : ($valueFormatted === '' ? '""' : $valueFormatted)) . "\n";
            } else {
                $valueFormatted = preg_match('/[^a-zA-Z0-9_]/', $value) ? '"'.$value.'"' : $value;
                $valueFormatted = is_bool($valueFormatted) ? ($valueFormatted ? 'true' : 'false') : ($valueFormatted === '' ? '""' : $valueFormatted);
                $yaml .= $indent . $key . ": $valueFormatted\n";
            }
        }
    }
    $yaml = str_replace('-   ', '-', $yaml);
    $yaml = str_replace('- -', '- ', $yaml);

    return $yaml;
}

/**
 * Lấy thư mục cache
 */
function getCacheDirectory() {
    $cacheDir = env('CACHE_DIRECTORY', './cache');
    if (is_dir($cacheDir) && is_readable($cacheDir) && is_writable($cacheDir)) {
        return rtrim(realpath($cacheDir), DIRECTORY_SEPARATOR);
    }
    return rtrim(realpath(sys_get_temp_dir()), DIRECTORY_SEPARATOR);
}

/**
 * Lưu dữ liệu vào cache
 */
function cacheSave($key, $data, $ttl = 3600) {
    $cacheFile = getCacheDirectory() . "/cache_" . md5($key);
    $cacheData = [
        'data' => $data,
        'expiry' => time() + $ttl
    ];
    file_put_contents($cacheFile, serialize($cacheData));
}

/**
 * Lấy dữ liệu từ cache
 */
function cacheGet($key) {
    $cacheFile = getCacheDirectory() . "/cache_" . md5($key);

    if (file_exists($cacheFile)) {
        $cacheData = unserialize(file_get_contents($cacheFile));

        if (time() < $cacheData['expiry']) {
            return $cacheData['data'];
        } else {
            unlink($cacheFile);
        }
    }

    return null;
}

/**
 * Giải mã chuỗi base64 URL
 */
function base64UrlDecode($base64Url) {
    $base64 = str_replace(['-', '_'], ['+', '/'], $base64Url);
    $padding = strlen($base64) % 4;
    if ($padding) {
        $base64 .= str_repeat('=', 4 - $padding);
    }
    return base64_decode($base64);
}

/**
 * Mã hóa chuỗi thành base64 URL
 */
function base64UrlEncode($data) {
    $base64 = base64_encode($data);
    $base64Url = str_replace(['+', '/'], ['-', '_'], rtrim($base64, '='));
    return $base64Url;
}

/**
 * Tạo chuỗi ngẫu nhiên
 */
function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

/**
 * Làm mới Firsty
 */
function renewFirsty($token, $iccid) {
    $authToken = getAccessTokenFirsty($token);

    if (!$authToken) {
        return null;
    }

    $parts = explode('.', $authToken);
    if (!isset($parts[1])) {
        return false;
    }
    $payload = base64_decode($parts[1]);
    $data = json_decode($payload, true);
    if (!isset($data['user_id'])) {
        return false;
    }
    $userId = $data['user_id'];

    $baseUrl = env('FIRSTY_API_BASE_URL', 'https://backoffice.firsty.app/api/mobile') . '/users/v2/' . $userId . '/';
    $headers = [
        'user-agent: Dart/3.5 (dart:io)',
        'accept-encoding: gzip',
        'authorization: Bearer ' . $authToken,
        'device-info: iPhone11,8 17.0',
        'app-build: 9999',
        'content-type: application/json',
        'app-version: 9.9.999',
    ];

    $waitlistUrl = $baseUrl . 'waitlist';
    $waitlistResponse = executeCurl($waitlistUrl, $headers);

    $subscriptionUrl = env('FIRSTY_API_BASE_URL', 'https://backoffice.firsty.app/api/mobile') . '/subscriptions/v2/' . $userId . '/iccid/' . $iccid . '/free';
    $postData = json_encode([
        "planType" => "ADVERTISEMENT",
        "deviceId" => "5993C521-924B-4808-9D36-24AFAB569C3F",
        "country" => "TW"
    ]);
    $subscriptionResponse = executeCurl($subscriptionUrl, $headers, $postData);
    $subcriptionResponseDecoded = json_decode($subscriptionResponse, true);
    if (isset($subcriptionResponseDecoded['code']) && isset($subcriptionResponseDecoded['data']['freeSubscriptionTransactionId'])) {
        return $subcriptionResponseDecoded['data']['freeSubscriptionTransactionId'];
    }

    return null;
}

/**
 * Thực hiện yêu cầu cURL
 */
function executeCurl($url, $headers, $postData = null) {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_ENCODING, 'gzip');

    if ($postData !== null) {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
    }

    $response = curl_exec($ch);
    curl_close($ch);
    return $response;
}

/**
 * Lấy access token Firsty
 */
function getAccessTokenFirsty($refreshToken) {
    $url = "https://securetoken.googleapis.com/v1/token?key=" . env('FIRSTY_API_KEY', 'AIzaSyAw4dSOEuZNgBWLAiwSAqPJ9qArvSOaZDM');

    $headers = [
        'Accept-Encoding: gzip, deflate, br',
        'Accept: */*',
        'Connection: keep-alive',
        'Content-Type: application/json',
        'Host: securetoken.googleapis.com',
        'X-Ios-Bundle-Identifier: com.firsty.app',
        'User-Agent: FirebaseAuth.iOS/10.25.0 com.firsty.app/1.0.352 iPad/17.5.1 hw/iPad11_3',
        'Accept-Language: en',
        'X-Client-Version: iOS/FirebaseSDK/10.25.0/FirebaseCore-iOS',
        'X-Firebase-GMPID: 1:962364472393:ios:fede98035afd07718c1398'
    ];

    $body = [
        "grantType" => "refresh_token",
        "refreshToken" => $refreshToken
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
    curl_setopt($ch, CURLOPT_ENCODING, 'gzip');

    $response = curl_exec($ch);
    $info = curl_getinfo($ch);
    curl_close($ch);

    if (isset($info['content_encoding']) && $info['content_encoding'] === 'gzip') {
        $response = gzdecode($response);
    }

    $respDecoded = json_decode($response, true);

    if (isset($respDecoded['access_token'])) {
        return $respDecoded['access_token'];
    }

    return null;
}
