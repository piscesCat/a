# Tài liệu hợp nhất cơ sở dữ liệu

## Tổng quan

Dự án đã được cải tiến với việc hợp nhất các file cơ sở dữ liệu riêng lẻ thành một file thống nhất. Việc này giúp quản lý và triển khai cơ sở dữ liệu dễ dàng hơn, đồng thời đảm bảo tính nhất quán giữa các môi trường.

## Thay đổi chính

### 1. Hợp nhất các file SQL

Các file SQL riêng lẻ đã được hợp nhất thành một file duy nhất:

- **schema.sql**: Cấu trúc cơ bản của cơ sở dữ liệu
- **update_stories_table.sql**: Cập nhật bảng stories
- **create_guest_bookmarks_table.sql**: Tạo bảng guest_bookmarks

Tất cả đã được hợp nhất thành file: **unified_schema.sql**

### 2. Cải tiến cấu trúc SQL

- Chuẩn hóa cú pháp cho PostgreSQL
- Tổ chức lại cấu trúc các bảng theo chức năng
- Bổ sung các chỉ mục (indexes) để tăng hiệu suất truy vấn
- Bổ sung các trigger để tự động cập nhật dữ liệu

### 3. Tạo script cài đặt

Đã tạo script **install.sh** để tự động hóa việc cài đặt cơ sở dữ liệu. Script này:

- Tạo backup cho các file SQL gốc
- Tạo mới hoặc cập nhật database
- Thực thi file unified_schema.sql
- Hiển thị thông tin đăng nhập mặc định

### 4. Tạo tài liệu hướng dẫn

Đã tạo các tài liệu hướng dẫn:

- **DATABASE_README.md**: Giải thích chi tiết về cấu trúc cơ sở dữ liệu
- **README.md** (file này): Tổng quan về các thay đổi

## Cách sử dụng

### 1. Cài đặt cơ sở dữ liệu mới

```bash
cd database
./install.sh [tên_database] [tên_người_dùng] [mật_khẩu]
```

Ví dụ:
```bash
./install.sh web_truyen postgres mypassword
```

### 2. Sử dụng file SQL thủ công

```bash
psql -U username -d database_name -f database/unified_schema.sql
```

## Cấu trúc thư mục

```
database/
├── backup/             # Thư mục chứa các file backup
├── unified_schema.sql  # File SQL thống nhất
├── install.sh          # Script cài đặt
├── schema.sql          # File schema gốc (đã backup)
├── update_stories_table.sql  # File cập nhật bảng stories (đã backup)
└── create_guest_bookmarks_table.sql  # File tạo bảng guest_bookmarks (đã backup)
```

## Lưu ý

1. Các file SQL gốc đã được sao lưu trong thư mục `database/backup/`
2. Nếu bạn muốn khôi phục cấu trúc ban đầu, có thể sao chép các file từ thư mục backup
3. Mật khẩu mặc định cho tài khoản admin là `admin123`. Nên thay đổi sau khi cài đặt

## Liên hệ

Nếu có bất kỳ câu hỏi hoặc vấn đề nào, vui lòng liên hệ qua email hoặc tạo issue trong repository.

---

*Lưu ý: Tài liệu chi tiết về cấu trúc cơ sở dữ liệu có thể được tìm thấy trong file DATABASE_README.md*
