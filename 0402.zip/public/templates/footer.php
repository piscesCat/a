<div class="text-center mt-4 text-muted small">
            <p>Web Truyện - Phiên bản trình cài đặt <?= INSTALLER_VERSION ?></p>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
