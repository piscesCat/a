<div class="card">
    <div class="card-header">
        <i class="bi bi-gear-fill me-2"></i>Kiểm tra hệ thống
    </div>
    <div class="card-body">
        <div class="alert alert-info">
            <i class="bi bi-info-circle-fill me-2"></i>Hệ thống sẽ kiểm tra xem máy chủ của bạn đáp ứng các yêu cầu tối thiểu để chạy ứng dụng.
        </div>

        <table class="table">
            <thead>
                <tr>
                    <th>Yêu cầu</th>
                    <th>Giá trị yêu cầu</th>
                    <th>Giá trị hiện tại</th>
                    <th>Trạng thái</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($requirements as $requirement): ?>
                <tr>
                    <td><?= $requirement['name'] ?></td>
                    <td><?= $requirement['required'] ?></td>
                    <td><?= $requirement['current'] ?></td>
                    <td>
                        <?php if ($requirement['status']): ?>
                            <span class="text-success"><i class="bi bi-check-circle-fill"></i> Đạt</span>
                        <?php else: ?>
                            <span class="text-danger"><i class="bi bi-x-circle-fill"></i> Không đạt</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <i class="bi bi-folder-check me-2"></i>Kiểm tra quyền thư mục
    </div>
    <div class="card-body">
        <div class="alert alert-info">
            <i class="bi bi-info-circle-fill me-2"></i>Hệ thống cần quyền ghi vào một số thư mục để hoạt động chính xác.
        </div>

        <table class="table">
            <thead>
                <tr>
                    <th>Thư mục</th>
                    <th>Quyền yêu cầu</th>
                    <th>Trạng thái hiện tại</th>
                    <th>Kết quả</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($permissions as $permission): ?>
                <tr>
                    <td><?= $permission['name'] ?></td>
                    <td><?= $permission['required'] ?></td>
                    <td><?= $permission['current'] ?></td>
                    <td>
                        <?php if ($permission['status']): ?>
                            <span class="text-success"><i class="bi bi-check-circle-fill"></i> Đạt</span>
                        <?php else: ?>
                            <span class="text-danger"><i class="bi bi-x-circle-fill"></i> Không đạt</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="text-end mt-4">
    <?php
    $canProceed = true;

    foreach ($requirements as $requirement) {
        if (!$requirement['status']) {
            $canProceed = false;
            break;
        }
    }

    if ($canProceed) {
        foreach ($permissions as $permission) {
            if (!$permission['status']) {
                $canProceed = false;
                break;
            }
        }
    }
    ?>

    <?php if ($canProceed): ?>
    <a href="<?= BASE_URL ?>install.php/database" class="btn btn-primary">
        <i class="bi bi-arrow-right-circle me-1"></i> Tiếp tục
    </a>
    <?php else: ?>
    <div class="alert alert-danger">
        <i class="bi bi-exclamation-triangle-fill me-2"></i>Vui lòng đảm bảo tất cả các yêu cầu đều được đáp ứng trước khi tiếp tục.
    </div>
    <button class="btn btn-primary" disabled>
        <i class="bi bi-arrow-right-circle me-1"></i> Tiếp tục
    </button>
    <?php endif; ?>
</div>
