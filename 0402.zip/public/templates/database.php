<div class="card">
    <div class="card-header">
        <i class="bi bi-database-fill me-2"></i>Cấu hình cơ sở dữ liệu
    </div>
    <div class="card-body">
        <div class="alert alert-info">
            <i class="bi bi-info-circle-fill me-2"></i>Nhập thông tin kết nối đến cơ sở dữ liệu PostgreSQL của bạn.
        </div>

        <form action="<?= BASE_URL ?>install.php/process-database" method="post">
            <div class="mb-3">
                <label for="db_hostname" class="form-label">Máy chủ cơ sở dữ liệu</label>
                <input type="text" class="form-control" id="db_hostname" name="db_hostname" value="<?= isset($_SESSION['input']['db_hostname']) ? $_SESSION['input']['db_hostname'] : 'localhost' ?>" required>
                <div class="form-text">Thường là "localhost" nếu cơ sở dữ liệu chạy trên cùng một máy chủ.</div>
                <?php if (isset($_SESSION['errors']['db_hostname'])): ?>
                <div class="text-danger"><?= $_SESSION['errors']['db_hostname'] ?></div>
                <?php endif; ?>
            </div>

            <div class="mb-3">
                <label for="db_port" class="form-label">Cổng</label>
                <input type="text" class="form-control" id="db_port" name="db_port" value="<?= isset($_SESSION['input']['db_port']) ? $_SESSION['input']['db_port'] : '5432' ?>" required>
                <div class="form-text">Cổng mặc định của PostgreSQL là 5432.</div>
                <?php if (isset($_SESSION['errors']['db_port'])): ?>
                <div class="text-danger"><?= $_SESSION['errors']['db_port'] ?></div>
                <?php endif; ?>
            </div>

            <div class="mb-3">
                <label for="db_name" class="form-label">Tên cơ sở dữ liệu</label>
                <input type="text" class="form-control" id="db_name" name="db_name" value="<?= isset($_SESSION['input']['db_name']) ? $_SESSION['input']['db_name'] : 'web_truyen' ?>" required>
                <div class="form-text">Tên của cơ sở dữ liệu. Nếu chưa tồn tại, hệ thống sẽ tự động tạo.</div>
                <?php if (isset($_SESSION['errors']['db_name'])): ?>
                <div class="text-danger"><?= $_SESSION['errors']['db_name'] ?></div>
                <?php endif; ?>
            </div>

            <div class="mb-3">
                <label for="db_username" class="form-label">Tên người dùng</label>
                <input type="text" class="form-control" id="db_username" name="db_username" value="<?= isset($_SESSION['input']['db_username']) ? $_SESSION['input']['db_username'] : 'postgres' ?>" required>
                <div class="form-text">Tên người dùng để kết nối đến cơ sở dữ liệu.</div>
                <?php if (isset($_SESSION['errors']['db_username'])): ?>
                <div class="text-danger"><?= $_SESSION['errors']['db_username'] ?></div>
                <?php endif; ?>
            </div>

            <div class="mb-3">
                <label for="db_password" class="form-label">Mật khẩu</label>
                <input type="password" class="form-control" id="db_password" name="db_password" value="<?= isset($_SESSION['input']['db_password']) ? $_SESSION['input']['db_password'] : '' ?>">
                <div class="form-text">Mật khẩu để kết nối đến cơ sở dữ liệu.</div>
                <?php if (isset($_SESSION['errors']['db_password'])): ?>
                <div class="text-danger"><?= $_SESSION['errors']['db_password'] ?></div>
                <?php endif; ?>
            </div>

            <div class="d-flex justify-content-between mt-4">
                <a href="<?= BASE_URL ?>install.php" class="btn btn-outline-secondary">
                    <i class="bi bi-arrow-left-circle me-1"></i> Quay lại
                </a>
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-arrow-right-circle me-1"></i> Tiếp tục
                </button>
            </div>
        </form>
    </div>
</div>

<?php
// Xóa dữ liệu phiên cũ để tránh hiển thị lỗi nhiều lần
if (isset($_SESSION['errors'])) {
    unset($_SESSION['errors']);
}
if (isset($_SESSION['input'])) {
    unset($_SESSION['input']);
}
?>
