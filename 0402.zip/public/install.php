<?php
/**
 * Web Truyện - Installer
 * File cài đặt độc lập giúp khởi tạo hệ thống một cách dễ dàng
 */

// Định nghĩa các đường dẫn quan trọng
define('INSTALLER_VERSION', '1.0');
define('ROOTPATH', realpath(dirname(__FILE__) . '/../') . '/');
define('APPPATH', ROOTPATH . 'app/');
define('VIEWPATH', APPPATH . 'Views/');
define('WRITEPATH', ROOTPATH . 'writable/');

// Khởi tạo session
session_start();

// Thiết lập header và error reporting
header('Content-Type: text/html; charset=UTF-8');
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Định nghĩa các URL và route
$base_url = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == "on") ? "https" : "http");
$base_url .= "://" . $_SERVER['HTTP_HOST'];
$base_url .= str_replace(basename($_SERVER['SCRIPT_NAME']), "", $_SERVER['SCRIPT_NAME']);
define('BASE_URL', $base_url);

// Xác định route hiện tại
$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$uri = str_replace('install.php/', '', $uri);
$uri = trim($uri, '/');
$segments = explode('/', $uri);
$route = isset($segments[1]) ? $segments[1] : 'index';

// Kiểm tra xem hệ thống đã được cài đặt chưa
function isInstalled() {
    return file_exists(ROOTPATH . 'installed.txt');
}

// Kiểm tra yêu cầu hệ thống
function checkRequirements() {
    return [
        [
            'name' => 'PHP Version',
            'required' => '7.4 or higher',
            'current' => PHP_VERSION,
            'status' => version_compare(PHP_VERSION, '7.4.0', '>=')
        ],
        [
            'name' => 'PDO PostgreSQL Extension',
            'required' => 'Enabled',
            'current' => extension_loaded('pdo_pgsql') ? 'Enabled' : 'Disabled',
            'status' => extension_loaded('pdo_pgsql')
        ],
        [
            'name' => 'Fileinfo Extension',
            'required' => 'Enabled',
            'current' => extension_loaded('fileinfo') ? 'Enabled' : 'Disabled',
            'status' => extension_loaded('fileinfo')
        ],
        [
            'name' => 'CURL Extension',
            'required' => 'Enabled',
            'current' => extension_loaded('curl') ? 'Enabled' : 'Disabled',
            'status' => extension_loaded('curl')
        ],
        [
            'name' => 'GD Extension',
            'required' => 'Enabled',
            'current' => extension_loaded('gd') ? 'Enabled' : 'Disabled',
            'status' => extension_loaded('gd')
        ],
        [
            'name' => 'JSON Extension',
            'required' => 'Enabled',
            'current' => extension_loaded('json') ? 'Enabled' : 'Disabled',
            'status' => extension_loaded('json')
        ]
    ];
}

// Kiểm tra quyền thư mục
function checkPermissions() {
    return [
        [
            'name' => 'writable/',
            'required' => 'Writable',
            'current' => is_writable(WRITEPATH) ? 'Writable' : 'Not Writable',
            'status' => is_writable(WRITEPATH)
        ],
        [
            'name' => 'writable/cache/',
            'required' => 'Writable',
            'current' => is_writable(WRITEPATH . 'cache') ? 'Writable' : 'Not Writable',
            'status' => is_writable(WRITEPATH . 'cache')
        ],
        [
            'name' => 'writable/logs/',
            'required' => 'Writable',
            'current' => is_writable(WRITEPATH . 'logs') ? 'Writable' : 'Not Writable',
            'status' => is_writable(WRITEPATH . 'logs')
        ],
        [
            'name' => 'writable/uploads/',
            'required' => 'Writable',
            'current' => is_writable(WRITEPATH . 'uploads') ? 'Writable' : 'Not Writable',
            'status' => is_writable(WRITEPATH . 'uploads')
        ],
        [
            'name' => 'app/Config/Database.php',
            'required' => 'Writable',
            'current' => is_writable(APPPATH . 'Config/Database.php') ? 'Writable' : 'Not Writable',
            'status' => is_writable(APPPATH . 'Config/Database.php')
        ]
    ];
}

// Lưu cấu hình database
function saveDatabaseConfig($hostname, $database, $username, $password, $port) {
    $configPath = APPPATH . 'Config/Database.php';
    $config = file_get_contents($configPath);

    // Replace database settings in config file
    $config = preg_replace("/'hostname' => '.*?'/", "'hostname' => '$hostname'", $config);
    $config = preg_replace("/'database' => '.*?'/", "'database' => '$database'", $config);
    $config = preg_replace("/'username' => '.*?'/", "'username' => '$username'", $config);
    $config = preg_replace("/'password' => '.*?'/", "'password' => '$password'", $config);
    $config = preg_replace("/'port' => .*?,/", "'port' => $port,", $config);

    // Save updated config file
    file_put_contents($configPath, $config);

    // Create a flag file to indicate database is configured
    file_put_contents(ROOTPATH . 'database_configured.txt', date('Y-m-d H:i:s'));
}

// Import database schema
function importDatabaseSchema() {
    try {
        // Kết nối đến database
        $configPath = APPPATH . 'Config/Database.php';
        if (!file_exists($configPath)) {
            throw new Exception('Database configuration file not found.');
        }

        // Parse database config file để lấy thông tin kết nối
        $config = file_get_contents($configPath);
        preg_match("/'hostname' => '(.*?)'/", $config, $hostname);
        preg_match("/'database' => '(.*?)'/", $config, $database);
        preg_match("/'username' => '(.*?)'/", $config, $username);
        preg_match("/'password' => '(.*?)'/", $config, $password);
        preg_match("/'port' => (.*?),/", $config, $port);

        // Kết nối database
        $dsn = "pgsql:host={$hostname[1]};port={$port[1]};dbname={$database[1]}";
        $pdo = new PDO($dsn, $username[1], $password[1]);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Đọc schema thống nhất
        $schema = file_get_contents(ROOTPATH . 'database/unified_schema.sql');

        // Thực thi SQL statement
        $pdo->exec($schema);

        return true;
    } catch (PDOException $e) {
        $_SESSION['error'] = 'Database import error: ' . $e->getMessage();
        return false;
    } catch (Exception $e) {
        $_SESSION['error'] = 'Error: ' . $e->getMessage();
        return false;
    }
}

// Tạo tài khoản admin
function createAdminUser($username, $email, $password) {
    try {
        // Kết nối đến database
        $configPath = APPPATH . 'Config/Database.php';
        $config = file_get_contents($configPath);
        preg_match("/'hostname' => '(.*?)'/", $config, $hostname);
        preg_match("/'database' => '(.*?)'/", $config, $database);
        preg_match("/'username' => '(.*?)'/", $config, $username_db);
        preg_match("/'password' => '(.*?)'/", $config, $password_db);
        preg_match("/'port' => (.*?),/", $config, $port);

        // Kết nối database
        $dsn = "pgsql:host={$hostname[1]};port={$port[1]};dbname={$database[1]}";
        $pdo = new PDO($dsn, $username_db[1], $password_db[1]);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Hash mật khẩu
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Kiểm tra xem người dùng sáng lập đã tồn tại chưa
        $stmt = $pdo->prepare("SELECT * FROM users WHERE role = 3");
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            // Cập nhật người dùng sáng lập nếu đã tồn tại
            $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ?, password = ? WHERE role = 3");
            $stmt->execute([$username, $email, $hashed_password]);
        } else {
            // Tạo người dùng sáng lập mới
            $stmt = $pdo->prepare("INSERT INTO users (username, email, password, role, status, created_at, updated_at) VALUES (?, ?, ?, 3, 'active', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)");
            $stmt->execute([$username, $email, $hashed_password]);
        }

        return true;
    } catch (PDOException $e) {
        $_SESSION['error'] = 'Database error: ' . $e->getMessage();
        return false;
    } catch (Exception $e) {
        $_SESSION['error'] = 'Error: ' . $e->getMessage();
        return false;
    }
}

// Lưu cài đặt trang web
function saveSiteSettings($siteName, $siteDescription) {
    try {
        // Kết nối đến database
        $configPath = APPPATH . 'Config/Database.php';
        $config = file_get_contents($configPath);
        preg_match("/'hostname' => '(.*?)'/", $config, $hostname);
        preg_match("/'database' => '(.*?)'/", $config, $database);
        preg_match("/'username' => '(.*?)'/", $config, $username);
        preg_match("/'password' => '(.*?)'/", $config, $password);
        preg_match("/'port' => (.*?),/", $config, $port);

        // Kết nối database
        $dsn = "pgsql:host={$hostname[1]};port={$port[1]};dbname={$database[1]}";
        $pdo = new PDO($dsn, $username[1], $password[1]);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Lưu settings
        $settings = [
            'site_name' => $siteName,
            'site_description' => $siteDescription,
            'installed_at' => date('Y-m-d H:i:s')
        ];

        foreach ($settings as $name => $value) {
            // Check if setting exists
            $stmt = $pdo->prepare("SELECT id FROM settings WHERE name = ?");
            $stmt->execute([$name]);

            if ($stmt->rowCount() > 0) {
                // Update existing setting
                $stmt = $pdo->prepare("UPDATE settings SET value = ? WHERE name = ?");
                $stmt->execute([$value, $name]);
            } else {
                // Insert new setting
                $stmt = $pdo->prepare("INSERT INTO settings (name, value) VALUES (?, ?)");
                $stmt->execute([$name, $value]);
            }
        }

        return true;
    } catch (PDOException $e) {
        $_SESSION['error'] = 'Database error: ' . $e->getMessage();
        return false;
    } catch (Exception $e) {
        $_SESSION['error'] = 'Error: ' . $e->getMessage();
        return false;
    }
}

// Hoàn thành cài đặt
function completeInstallation() {
    // Tạo flag file để đánh dấu cài đặt hoàn tất
    file_put_contents(ROOTPATH . 'installed.txt', date('Y-m-d H:i:s'));

    // Xóa file chỉ báo cấu hình database nếu tồn tại
    if (file_exists(ROOTPATH . 'database_configured.txt')) {
        @unlink(ROOTPATH . 'database_configured.txt');
    }

    return true;
}

// Xóa file cài đặt
function removeInstallationFiles() {
    // Danh sách file cần xóa
    $filesToRemove = [
        APPPATH . 'Controllers/Install.php',
        APPPATH . 'Views/install/admin.html',
        APPPATH . 'Views/install/complete.html',
        APPPATH . 'Views/install/database.html',
        APPPATH . 'Views/install/index.html',
        ROOTPATH . 'public/install.php',
    ];

    // Xóa các file
    foreach ($filesToRemove as $file) {
        if (file_exists($file)) {
            @unlink($file);
        }
    }

    // Xóa thư mục
    @rmdir(APPPATH . 'Views/install');

    // Xóa các đường dẫn cài đặt từ Routes.php
    removeInstallRoutes();

    return true;
}

// Xóa các route cài đặt
function removeInstallRoutes() {
    $routesFile = APPPATH . 'Config/Routes.php';

    if (file_exists($routesFile)) {
        $content = file_get_contents($routesFile);

        // Tìm và xóa phần route cài đặt
        $pattern = "/\/\/ Installation routes.*?\/\/ Main routes/s";
        $replacement = "// Main routes";

        $updatedContent = preg_replace($pattern, $replacement, $content);

        // Lưu nội dung đã cập nhật
        file_put_contents($routesFile, $updatedContent);
    }

    return true;
}

// Chuyển hướng tới URL
function redirect($url) {
    header('Location: ' . $url);
    exit;
}

// Hiển thị template
function view($template, $data = []) {
    extract($data);

    // Template header
    include 'templates/header.php';

    // Nội dung chính
    include 'templates/' . $template . '.php';

    // Template footer
    include 'templates/footer.php';
}

// Kiểm tra xem đã cài đặt chưa và chuyển hướng nếu cần
if (isInstalled() && $route != 'complete') {
    redirect(BASE_URL);
    exit;
}

// Định nghĩa các template cài đặt
define('TEMPLATE_PATH', __DIR__ . '/templates/');

// Tạo thư mục templates nếu chưa có
if (!is_dir(TEMPLATE_PATH)) {
    mkdir(TEMPLATE_PATH, 0755, true);
}
