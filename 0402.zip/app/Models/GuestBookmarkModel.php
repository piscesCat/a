<?php

namespace App\Models;

use CodeIgniter\Model;

class GuestBookmarkModel extends Model
{
    protected $table = 'guest_bookmarks';
    protected $primaryKey = 'id';
    protected $allowedFields = ['guest_id', 'story_id', 'chapter_id', 'created_at', 'updated_at'];

    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    /**
     * Thêm hoặc xóa bookmark cho khách truy cập (không đăng nhập)
     *
     * @param string $guestId ID khách lưu trong cookie/localStorage
     * @param int $storyId ID truyện
     * @param int|null $chapterId ID chương đang đọc (nếu có)
     * @return bool|array false nếu lỗi, mảng thông tin nếu thành công
     */
    public function toggleBookmark($guestId, $storyId, $chapterId = null)
    {
        // Kiểm tra xem bookmark đã tồn tại chưa
        $existingBookmark = $this->where('guest_id', $guestId)
                                 ->where('story_id', $storyId)
                                 ->first();

        if ($existingBookmark) {
            // Xóa bookmark nếu đã tồn tại
            $this->delete($existingBookmark['id']);
            return [
                'action' => 'removed',
                'message' => 'Đã xóa khỏi danh sách bookmark'
            ];
        } else {
            // Thêm bookmark mới
            $data = [
                'guest_id' => $guestId,
                'story_id' => $storyId,
                'chapter_id' => $chapterId
            ];

            $this->insert($data);
            return [
                'action' => 'added',
                'message' => 'Đã thêm vào danh sách bookmark'
            ];
        }
    }

    /**
     * Lấy danh sách bookmark của khách truy cập
     */
    public function getGuestBookmarks($guestId, $limit = 10, $offset = 0)
    {
        return $this->select('guest_bookmarks.*, stories.title, stories.slug, stories.cover_image')
                    ->join('stories', 'stories.id = guest_bookmarks.story_id')
                    ->where('guest_id', $guestId)
                    ->orderBy('guest_bookmarks.updated_at', 'DESC')
                    ->limit($limit, $offset)
                    ->findAll();
    }

    /**
     * Kiểm tra truyện có trong bookmark của khách hay không
     */
    public function isBookmarked($guestId, $storyId)
    {
        return $this->where('guest_id', $guestId)
                    ->where('story_id', $storyId)
                    ->countAllResults() > 0;
    }

    /**
     * Cập nhật thông tin chương đang đọc cho bookmark
     */
    public function updateChapter($guestId, $storyId, $chapterId)
    {
        $bookmark = $this->where('guest_id', $guestId)
                         ->where('story_id', $storyId)
                         ->first();

        if ($bookmark) {
            return $this->update($bookmark['id'], [
                'chapter_id' => $chapterId,
                'updated_at' => date('Y-m-d H:i:s')
            ]);
        }

        return false;
    }

    /**
     * Di chuyển bookmark từ khách sang người dùng đã đăng nhập
     */
    public function migrateToUser($guestId, $userId)
    {
        $guestBookmarks = $this->where('guest_id', $guestId)->findAll();
        $bookmarkModel = new BookmarkModel();
        $count = 0;

        foreach ($guestBookmarks as $bookmark) {
            // Kiểm tra xem đã có bookmark này cho user chưa
            $existingBookmark = $bookmarkModel->where('user_id', $userId)
                                              ->where('story_id', $bookmark['story_id'])
                                              ->first();

            if (!$existingBookmark) {
                $bookmarkModel->insert([
                    'user_id' => $userId,
                    'story_id' => $bookmark['story_id'],
                    'chapter_id' => $bookmark['chapter_id'],
                    'created_at' => $bookmark['created_at'],
                    'updated_at' => $bookmark['updated_at']
                ]);
                $count++;
            } else {
                // Cập nhật chapter_id nếu bookmark đã tồn tại
                if ($bookmark['chapter_id'] && (!$existingBookmark['chapter_id'] || $bookmark['updated_at'] > $existingBookmark['updated_at'])) {
                    $bookmarkModel->update($existingBookmark['id'], [
                        'chapter_id' => $bookmark['chapter_id'],
                        'updated_at' => date('Y-m-d H:i:s')
                    ]);
                }
            }
        }

        // Xóa tất cả bookmark của khách
        $this->where('guest_id', $guestId)->delete();

        return $count;
    }
}
