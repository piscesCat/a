<?php
namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\CountryModel;
use App\Models\LogModel;
use App\Models\StoryModel;

class CountryManager extends BaseController
{
    protected $countryModel;
    protected $logModel;
    protected $storyModel;

    public function __construct()
    {
        $this->countryModel = new CountryModel();
        $this->logModel = new LogModel();
        $this->storyModel = new StoryModel();
    }

    /**
     * Hiển thị danh sách quốc gia đang được sử dụng
     */
    public function index()
    {
        // Require admin role
        $check = $this->requireAdmin();
        if ($check !== true) {
            return $check;
        }

        $data = [
            'title' => 'Danh sách quốc gia',
            'countries' => $this->countryModel->getCountriesFromStories(),
            'countriesList' => $this->getCountriesJsLibrary(),
        ];

        return $this->renderView('admin/country/index.html', $data);
    }

    /**
     * Lấy danh sách các quốc gia từ thư viện JS
     */
    protected function getCountriesJsLibrary()
    {
        return $this->countryModel->getCountriesFromLibrary();
    }

    /**
     * Hiển thị chi tiết quốc gia và danh sách truyện theo quốc gia
     */
    public function view($id)
    {
        // Require admin role
        $check = $this->requireAdmin();
        if ($check !== true) {
            return $check;
        }

        $country = $this->countryModel->find($id);
        if (!$country) {
            return redirect()->to('/admin/countries')
                ->with('error', 'Quốc gia không tồn tại.');
        }

        // Lấy danh sách truyện của quốc gia này
        $stories = $this->storyModel->where('country_id', $id)
                                   ->findAll();

        $data = [
            'title' => 'Chi tiết quốc gia: ' . $country['name'],
            'country' => $country,
            'stories' => $stories
        ];

        return $this->renderView('admin/country/view.html', $data);
    }
}
