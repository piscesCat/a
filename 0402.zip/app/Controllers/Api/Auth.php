<?php

namespace App\Controllers\Api;

use App\Controllers\BaseController;
use App\Models\UserModel;
use App\Models\TokenModel;
use Firebase\JWT\JWT;
use CodeIgniter\API\ResponseTrait;

class Auth extends BaseController
{
    use ResponseTrait;

    protected $userModel;
    protected $tokenModel;

    public function __construct()
    {
        $this->userModel = new UserModel();
        $this->tokenModel = new TokenModel();
    }

    /**
     * Authenticate with API token
     *
     * This endpoint is used to verify a token and get user information
     */
    public function verify()
    {
        // Get token from request header or request body
        $token = $this->getTokenFromRequest();

        if (!$token) {
            return $this->failUnauthorized('No token provided');
        }

        // Check if it's a JWT token (longer and with periods)
        if (strlen($token) > 100 && strpos($token, '.') !== false) {
            // Validate JWT token
            $user = $this->tokenModel->verifyJwtToken($token);
        } else {
            // Validate simple token
            $user = $this->tokenModel->getUserFromToken($token);
        }

        if (!$user) {
            return $this->failUnauthorized('Invalid or expired token');
        }

        // Remove sensitive data
        unset($user['password']);

        // Return user info with token
        return $this->respond([
            'success' => true,
            'user' => $user,
            'token' => $token
        ]);
    }

    /**
     * Login and get token (deprecated - use Admin Panel to generate tokens instead)
     */
    public function login()
    {
        // Validate request
        $rules = [
            'email' => 'required|valid_email',
            'password' => 'required'
        ];

        if (!$this->validate($rules)) {
            return $this->fail($this->validator->getErrors());
        }

        $email = $this->request->getPost('email');
        $password = $this->request->getPost('password');

        // Check credentials
        $user = $this->userModel->attemptLogin($email, $password);

        if (!$user) {
            return $this->failUnauthorized('Invalid email or password');
        }

        // Generate JWT token
        $jwt = $this->tokenModel->createJwtToken($user);

        // Return user info with token
        return $this->respond([
            'success' => true,
            'message' => 'Login successful. Note: This endpoint is deprecated, please use tokens generated from Admin Panel instead.',
            'user' => $user,
            'token' => $jwt
        ]);
    }

    /**
     * Logout and invalidate token
     */
    public function logout()
    {
        $token = $this->getTokenFromRequest();

        if (!$token) {
            return $this->failUnauthorized('No token provided');
        }

        // Check if it's a JWT token
        if (strlen($token) > 100 && strpos($token, '.') !== false) {
            // For JWT, we need to hash it first
            $token = hash('sha256', $token);
        }

        // Revoke the token
        $this->tokenModel->where('token', $token)->delete();

        return $this->respond([
            'success' => true,
            'message' => 'Logged out successfully'
        ]);
    }

    /**
     * Get token from request headers or request body
     */
    private function getTokenFromRequest()
    {
        // Try to get token from Authorization header
        $authHeader = $this->request->getHeaderLine('Authorization');
        if (!empty($authHeader)) {
            if (preg_match('/Bearer\s+(.*)$/i', $authHeader, $matches)) {
                return $matches[1];
            }
        }

        // Try to get token from request body
        $token = $this->request->getPost('token');
        if (!$token) {
            $token = $this->request->getGet('token');
        }

        // Try to get token from JSON body
        if (!$token && $this->request->getMethod() === 'post') {
            $jsonInput = $this->request->getJSON(true);
            if (isset($jsonInput['token'])) {
                $token = $jsonInput['token'];
            }
        }

        return $token;
    }
}
