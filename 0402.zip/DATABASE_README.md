# Tài liệu Database Schema

## Giới thiệu

File `unified_schema.sql` là kết quả của việc hợp nhất các file SQL riêng lẻ thành một file duy nhất. Việc hợp nhất này giúp dễ dàng quản lý và triển khai cơ sở dữ liệu, đồng thời đảm bảo tính nhất quán giữa các môi trường.

## Các file nguồn đã hợp nhất

File `unified_schema.sql` được tạo bằng cách hợp nhất các file sau:

1. **schema.sql**: Cấu trúc cơ bản của cơ sở dữ liệu, bao gồm các bảng chính và dữ liệu mẫu
2. **update_stories_table.sql**: Cập nhật bảng stories để thêm trường author_name và uploader_id
3. **create_guest_bookmarks_table.sql**: Tạo bảng guest_bookmarks để lưu bookmark cho khách

## Các cải tiến và thay đổi trong file hợp nhất

Trong quá trình hợp nhất, một số cải tiến và thay đổi đã được thực hiện:

1. **Chuẩn hóa hệ quản trị cơ sở dữ liệu**: Đã thống nhất cú pháp cho PostgreSQL, loại bỏ các cú pháp riêng của MySQL như `AUTO_INCREMENT`, `TINYINT(1)`, v.v.

2. **Bổ sung các thuộc tính thiếu**: Đã thêm các trường còn thiếu trong các bảng:
   - Thêm `chapter_id` vào bảng `bookmarks`
   - Thêm `updated_at` vào các bảng cần theo dõi thời gian cập nhật

3. **Tổ chức cấu trúc**: Đã phân nhóm các bảng theo chức năng:
   - Core tables: Các bảng chính (users, countries, categories, stories, chapters)
   - User interaction tables: Các bảng liên quan đến tương tác người dùng (bookmarks, comments)
   - System tables: Các bảng hệ thống (settings, logs, backups)

4. **Bổ sung indexes**: Đã bổ sung các chỉ mục để tăng hiệu suất truy vấn:
   - Thêm index cho trường `is_recommended` trong bảng `stories`
   - Thêm các index cho các bảng mới như `guest_bookmarks`

5. **Bổ sung triggers**: Đã bổ sung các trigger để tự động cập nhật:
   - Trigger cập nhật `updated_at` cho tất cả các bảng
   - Trigger cập nhật `search_vector` cho bảng `stories`

6. **Bổ sung cấu hình mới**: Đã thêm các cấu hình mới vào bảng `settings`:
   - Thêm `max_guest_bookmarks` để giới hạn số lượng bookmark cho khách
   - Thêm `imgur_client_id` để lưu trữ Imgur API key

7. **Thêm bảng theo dõi thay đổi**: Đã thêm bảng `system_changes` để theo dõi các thay đổi cấu trúc hệ thống

## Loại bỏ bảng và trường dư thừa

Để tối ưu hóa cấu trúc cơ sở dữ liệu, một số trường và bảng không còn cần thiết đã được loại bỏ.

### Các trường được loại bỏ

1. **hot_score từ bảng stories**: Trường này đã bị thay thế bởi `is_recommended` và không còn được sử dụng sau khi triển khai thuật toán đề xuất mới.

2. **author_id từ bảng stories**: Trường này đã bị thay thế bởi `author_name` và `uploader_id` để phân biệt rõ ràng giữa tác giả thật của truyện và người đăng truyện.

3. **status từ bảng countries**: Trường này không còn cần thiết vì chức năng quản lý quốc gia đã được đơn giản hóa.

### Script loại bỏ trường thừa

File `remove_unused_db_elements.sql` đã được tạo để loại bỏ các trường thừa từ cơ sở dữ liệu. Script này:

- Kiểm tra sự tồn tại của mỗi trường trước khi xóa
- Xóa ràng buộc khóa ngoại nếu cần
- Cập nhật hàm tìm kiếm full-text để phản ánh việc thay đổi cấu trúc
- Ghi lại thay đổi vào bảng `system_changes`

### Cách sử dụng script loại bỏ trường thừa

```bash
cd database
psql -U username -d database_name -f remove_unused_db_elements.sql
```

Hoặc sử dụng trong quá trình dọn dẹp database:

```bash
./cleanup.sh [tên_database] [tên_người_dùng] [mật_khẩu] --remove-unused
```

### Lợi ích của việc loại bỏ trường thừa

- Giảm không gian lưu trữ
- Tối ưu hiệu suất truy vấn
- Đơn giản hóa cấu trúc cơ sở dữ liệu
- Loại bỏ các trường lỗi thời có thể gây nhầm lẫn

## Cách sử dụng

### Triển khai cơ sở dữ liệu mới

Để triển khai cơ sở dữ liệu mới, sử dụng lệnh sau:

```bash
psql -U username -d database_name -f database/unified_schema.sql
```

### Cập nhật cơ sở dữ liệu hiện có

Nếu bạn đã có cơ sở dữ liệu và chỉ muốn cập nhật, bạn nên sao lưu trước khi thực hiện:

```bash
# Sao lưu
pg_dump -U username -d database_name > backup.sql

# Cập nhật
psql -U username -d database_name -f database/unified_schema.sql
```

## Lưu ý quan trọng

1. **Kiểm tra tính tương thích**: File SQL đã được viết cho PostgreSQL. Nếu bạn sử dụng hệ quản trị khác, có thể cần điều chỉnh cú pháp.

2. **Dữ liệu mẫu**: File chứa dữ liệu mẫu cho một số bảng như `users`, `countries`, `categories` và `settings`. Nếu không muốn sử dụng dữ liệu mẫu, hãy xóa các câu lệnh INSERT tương ứng.

3. **Kiểm tra lỗi**: Nếu gặp lỗi khi triển khai, hãy kiểm tra lỗi và sửa lỗi trong file SQL hoặc sử dụng các câu lệnh SQL riêng lẻ để triển khai từng phần.

4. **Bảo mật**: Mật khẩu mặc định cho tài khoản admin là `admin123`. Nhớ thay đổi sau khi triển khai.

## Cấu trúc cơ sở dữ liệu

### Bảng chính
- `users`: Lưu thông tin người dùng
- `stories`: Lưu thông tin truyện
- `chapters`: Lưu thông tin chương
- `categories`: Lưu thông tin thể loại
- `countries`: Lưu thông tin quốc gia

### Bảng quan hệ
- `story_categories`: Quan hệ nhiều-nhiều giữa truyện và thể loại
- `bookmarks`: Đánh dấu truyện của người dùng
- `guest_bookmarks`: Đánh dấu truyện của khách
- `reading_progress`: Tiến độ đọc truyện của người dùng
- `ratings`: Đánh giá truyện của người dùng
- `comments`: Bình luận của người dùng và khách

### Bảng hệ thống
- `settings`: Cài đặt trang web
- `tokens`: API tokens
- `media`: Quản lý files media
- `backups`: Quản lý backups
- `logs`: Nhật ký hệ thống
- `system_changes`: Theo dõi thay đổi cấu trúc hệ thống

## Các tính năng nổi bật

1. **Hỗ trợ tìm kiếm Full-Text**: Sử dụng `search_vector` và trigger để tự động cập nhật vector tìm kiếm.

2. **Bookmark cho khách**: Cho phép khách không đăng nhập vẫn có thể lưu truyện yêu thích.

3. **Phân biệt tác giả và người đăng**: Lưu trữ riêng biệt thông tin tác giả thật và người đăng truyện.

4. **API Token Authentication**: Hỗ trợ xác thực API bằng tokens.

5. **Truyện đề xuất**: Truyện được đề xuất dựa trên các tiêu chí khác nhau.

6. **Hệ thống phân quyền**: Hỗ trợ 3 cấp phân quyền: Cộng tác viên, Admin, Người sáng lập.

## Dọn dẹp dữ liệu rác trong cơ sở dữ liệu

Để duy trì hiệu suất tốt và giảm không gian lưu trữ, dự án bao gồm chức năng dọn dẹp dữ liệu rác trong cơ sở dữ liệu.

### Loại dữ liệu được dọn dẹp

1. **Guest bookmarks cũ**: Bookmark của khách không đăng nhập không được truy cập trong 90 ngày
2. **Tokens hết hạn**: Các API tokens đã hết hạn
3. **Nhật ký hệ thống cũ**: Logs lưu trữ quá lâu (30 ngày cho logs thông thường, 90 ngày cho logs lỗi)
4. **System changes cũ**: Lịch sử thay đổi cấu trúc hệ thống cũ hơn 1 năm
5. **Backups cũ**: Chỉ giữ lại 10 bản sao lưu mới nhất
6. **Lịch sử hoạt động người dùng cũ**: Dữ liệu hoạt động người dùng cũ hơn 60 ngày
7. **Bình luận mồ côi**: Các bình luận trỏ đến truyện/chương đã bị xóa
8. **Media files không sử dụng**: Các files media không còn liên kết với người dùng nào
9. **Giới hạn bookmark cho khách**: Mỗi khách chỉ được lưu tối đa số lượng bookmark theo cấu hình
10. **Truyện nháp cũ không có chương**: Các truyện nháp cũ hơn 6 tháng không có chương

### Cách sử dụng chức năng dọn dẹp

#### 1. Sử dụng script cleanup.sh

```bash
cd database
./cleanup.sh [tên_database] [tên_người_dùng] [mật_khẩu]
```

Script này sẽ:
- Hiển thị danh sách các hoạt động dọn dẹp sẽ thực hiện
- Hỏi có muốn sao lưu trước khi dọn dẹp
- Thực hiện dọn dẹp dữ liệu
- Hiển thị thống kê sau khi dọn dẹp

#### 2. Sử dụng tùy chọn --cleanup trong install.sh

```bash
cd database
./install.sh --cleanup [tên_database] [tên_người_dùng] [mật_khẩu]
```

#### 3. Dọn dẹp tự động

Để thiết lập dọn dẹp tự động định kỳ, thêm lệnh sau vào crontab:

```bash
0 0 * * 0 /đường_dẫn_đến_thư_mục/database/cleanup.sh tên_database tên_người_dùng mật_khẩu > /path/to/cleanup_log.txt 2>&1
```

Lệnh trên sẽ thực hiện dọn dẹp tự động vào 00:00 mỗi Chủ Nhật.

### Tệp SQL cleanup.sql

File `cleanup.sql` chứa các câu lệnh SQL để dọn dẹp dữ liệu. Bạn có thể chỉnh sửa file này để điều chỉnh các tiêu chí dọn dẹp theo nhu cầu cụ thể.
