# Báo cáo kiểm thử và phân tích mã nguồn

## Tổng quan
Tiến hành kiểm thử và phân tích mã nguồn dự án theo yêu cầu trong file `log.txt`. Báo cáo này tổng hợp các phát hiện, vấn đề, và đề xuất cải tiến.

## 1. Đánh giá phân quyền trong hệ thống

### 1.1 Vấn đề phát hiện
- **Thiếu nhất quán trong kiểm tra quyền**: Kiểm tra phân quyền không được áp dụng đồng bộ trên tất cả các controller. Trong khi `UserManager.php` áp dụng đầy đủ logic phân quyền, nhiều controller khác chưa áp dụng triệt để.

- **Lỗ hổng tiềm ẩn trong `requireResourceOwnership()`**: Phương thức trong `BaseController.php` có một lỗ hổng tiềm ẩn - chức năng sẽ bỏ qua kiểm tra nếu người dùng là admin/founder:

```php
// Admins and founders bypass this check
if ($this->currentUser['role'] >= 2) {
    return true;
}
```

Điều này có thể gây nguy hiểm nếu một controller cụ thể có xử lý đặc biệt sau khi kiểm tra quyền sở hữu.

### 1.2 Đề xuất cải tiến
- **Bổ sung kiểm tra quyền vào tất cả Controller**: Mỗi method trong controller cần có một kiểm tra quyền phù hợp.
- **Xem xét lại cơ chế bypass kiểm tra quyền sở hữu**: Đối với admin, có thể vẫn cần kiểm tra một số điều kiện mặc dù đã có quyền cao.
- **Thêm log chi tiết hơn**: Ghi lại những thông tin quan trọng trong quá trình kiểm tra quyền để dễ dàng phát hiện các hành vi bất thường.

## 2. Đánh giá chức năng BookMark cho khách

### 2.1 Ưu điểm của phương pháp hiện tại
- Đã triển khai tốt việc lưu trữ bookmarks cả ở phía client (localStorage) và server
- Đã đồng bộ bookmark giữa localStorage và server
- Đã xử lý di chuyển bookmarks khi khách đăng nhập

### 2.2 Vấn đề phát hiện
- **Thiếu xử lý khi localStorage đầy**: Không có cơ chế xóa các bookmark cũ khi localStorage đạt giới hạn
- **Thiếu giới hạn số lượng bookmark cho khách**: Không có hạn chế, có thể dẫn đến lượng dữ liệu quá lớn
- **Cần cơ chế xóa tự động Bookmark cũ**: Bookmark của khách cần được dọn dẹp định kỳ

### 2.3 Đề xuất cải tiến
- **Giới hạn số lượng bookmark cho khách**: Thêm cấu hình giới hạn số bookmark cho khách (ví dụ: tối đa 50)
- **Thêm cơ chế xử lý khi localStorage đầy**: Tự động xóa các bookmark cũ khi đạt ngưỡng
- **Thêm cron job dọn dẹp**: Xóa các bookmark khách không được sử dụng sau một khoảng thời gian

## 3. Đánh giá chức năng tích hợp Imgur

### 3.1 Ưu điểm của phương pháp hiện tại
- Tích hợp tốt với TinyMCE Editor
- Đã lưu trữ thông tin để có thể xóa hình ảnh sau này

### 3.2 Vấn đề phát hiện
- **Thiếu cơ chế dự phòng**: Khi Imgur API không khả dụng, không có phương án thay thế
- **Thiếu cơ chế quản lý hình ảnh đã tải lên**: Không có giao diện để xem và quản lý các hình ảnh đã tải lên
- **Thiếu giới hạn kích thước và loại file**: Cần thêm kiểm tra để đảm bảo an toàn

### 3.3 Đề xuất cải tiến
- **Thêm lưu trữ cục bộ dự phòng**: Khi Imgur không khả dụng, lưu file vào thư mục uploads
- **Thêm giao diện quản lý media**: Tạo trang quản lý các hình ảnh đã upload lên Imgur
- **Bổ sung kiểm tra kích thước và loại file**: Giới hạn kích thước tối đa và chỉ cho phép các định dạng hình ảnh an toàn

## 4. Phân tích mã nguồn phát hiện các đoạn code thừa

### 4.1 Code thừa trong StoryModel.php
- Phương thức `getHotStories()` (dòng 709-717) đã được đánh dấu là deprecated và thay thế bằng `getRecommendedStories()`. Nên loại bỏ hoàn toàn.
- Phương thức `calculateHotScore()` (dòng 558-600) chỉ được sử dụng bởi phương thức deprecated `getHotStories()`, nên cũng nên loại bỏ.

### 4.2 Chức năng quốc gia dư thừa
- Phương thức `getCountriesFromLibrary()` trong CountryModel đã thay thế cho các chức năng CRUD quốc gia.
- Tuy nhiên, vẫn còn các template và code liên quan đến việc tạo/sửa/xóa quốc gia như:
  - `app/Views/admin/country/create.html`
  - `app/Views/admin/country/edit.html`

### 4.3 Code không sử dụng trong Controllers
- Method `getStoriesByAuthor()` trong StoryModel.php (dòng 404-422) có tham chiếu đến cột `author` trong khi cột này đã được thay thế bằng `author_name`. Cần cập nhật lại.

## 5. Vấn đề về hiệu suất và bảo mật

### 5.1 Vấn đề hiệu suất
- **Lạm dụng cache settings**: Trong BaseController, cơ chế cache setting chỉ giữ trong 5 phút, có thể tăng lên để cải thiện hiệu suất.
- **Truy vấn database chưa tối ưu**: Một số truy vấn JOIN nhiều bảng có thể được cải thiện bằng cách sử dụng index hoặc tái cấu trúc.

### 5.2 Vấn đề bảo mật
- **Kiểm tra CSRF không đồng nhất**: Cơ chế CSRF đang được áp dụng, nhưng một số endpoints có thể bỏ qua nếu là AJAX, cần xem xét lại.
- **Lỗ hổng XSS trong TinyMCE**: Cần đảm bảo nội dung từ editor được lọc kỹ trước khi lưu và hiển thị.

## 6. Đề xuất cải tiến tổng thể

### 6.1 Cải thiện mã nguồn
1. **Loại bỏ các phương thức thừa**: Xóa các phương thức đã được đánh dấu là deprecated và không còn sử dụng.
2. **Xóa templates không sử dụng**: Dọn dẹp các template liên quan đến chức năng đã bị loại bỏ.
3. **Chuẩn hóa kiểm tra phân quyền**: Áp dụng nhất quán các kiểm tra phân quyền trong mọi controller.

### 6.2 Tối ưu hóa hiệu suất
1. **Tăng thời gian cache**: Điều chỉnh thời gian cache cho settings và dữ liệu tĩnh khác.
2. **Tối ưu hóa truy vấn**: Xem xét và tối ưu các truy vấn phức tạp, đặc biệt là trong các phương thức như `getRecommendedStories()`.
3. **Giảm số lượng truy vấn**: Sử dụng kỹ thuật eager loading để giảm số lượng truy vấn database.

### 6.3 Cải thiện UX/UI
1. **Thêm giao diện quản lý media**: Xây dựng trang quản lý media để người dùng có thể xem và quản lý các hình ảnh đã tải lên.
2. **Cải thiện UX của chức năng bookmark cho khách**: Thêm thông báo và hướng dẫn rõ ràng về cách sử dụng.

## 7. Tổng kết

Hệ thống đã được cải tiến đáng kể với các chức năng mới như phân quyền, bookmark cho khách, và tích hợp Imgur. Tuy nhiên, vẫn còn một số vấn đề cần được giải quyết để nâng cao chất lượng, hiệu suất và bảo mật của hệ thống.

Việc loại bỏ các mã nguồn thừa và tối ưu hóa các phần còn lại sẽ giúp hệ thống hoạt động hiệu quả hơn và dễ bảo trì hơn trong tương lai.
