#!/bin/bash

# Script dọn dẹp dữ liệu không sử dụng trong database
# Sử dụng:
# ./cleanup.sh [tên database] [tên người dùng] [mật khẩu]
# ./cleanup.sh [tên database] [tên người dùng] [mật khẩu] --remove-unused

# Màu sắc để hiển thị
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Kiểm tra tham số xóa trường thừa
REMOVE_UNUSED=0
if [[ "$*" == *"--remove-unused"* ]]; then
    REMOVE_UNUSED=1
    echo -e "${BLUE}=== Chế độ dọn dẹp database và loại bỏ trường thừa ===${NC}"
else
    echo -e "${BLUE}=== Script dọn dẹp database ===${NC}"
fi

echo -e "${YELLOW}Script này sẽ xóa các dữ liệu không sử dụng, cũ hoặc dư thừa trong database${NC}"

# Kiểm tra PostgreSQL
if ! command -v psql &> /dev/null; then
    echo -e "${RED}Không tìm thấy PostgreSQL. Vui lòng cài đặt PostgreSQL trước khi tiếp tục.${NC}"
    exit 1
fi

# Lấy thông tin đầu vào
DB_NAME=${1:-"web_truyen"}
DB_USER=${2:-"postgres"}
DB_PASS=${3:-""}

# Hiển thị thông tin cài đặt
echo -e "${YELLOW}Thông tin kết nối:${NC}"
echo -e "- Database: ${GREEN}$DB_NAME${NC}"
echo -e "- User: ${GREEN}$DB_USER${NC}"

# Hiển thị các hoạt động sẽ được thực hiện
echo -e "${YELLOW}Các hoạt động dọn dẹp sẽ được thực hiện:${NC}"
echo -e "1. Xóa guest bookmarks cũ (>90 ngày)"
echo -e "2. Xóa tokens đã hết hạn"
echo -e "3. Xóa nhật ký hệ thống cũ"
echo -e "4. Xóa lịch sử thay đổi hệ thống cũ (>1 năm)"
echo -e "5. Giữ lại 10 bản sao lưu mới nhất, xóa các bản cũ"
echo -e "6. Xóa lịch sử hoạt động người dùng cũ (>60 ngày)"
echo -e "7. Xóa bình luận mồ côi"
echo -e "8. Xóa media files không sử dụng"
echo -e "9. Giới hạn số lượng bookmark cho mỗi khách"
echo -e "10. Xóa truyện nháp cũ không có chương (>6 tháng)"

if [ $REMOVE_UNUSED -eq 1 ]; then
    echo -e "${YELLOW}Thêm vào đó, các trường thừa sau sẽ bị loại bỏ:${NC}"
    echo -e "1. hot_score từ bảng stories (đã bị thay thế bởi is_recommended)"
    echo -e "2. author_id từ bảng stories (đã bị thay thế bởi author_name và uploader_id)"
    echo -e "3. status từ bảng countries (không còn cần thiết)"
fi

# Hỏi xác nhận
echo -e "${YELLOW}Bạn có muốn tiến hành dọn dẹp database? (y/n)${NC}"
read -r confirm

if [[ $confirm != "y" && $confirm != "Y" ]]; then
    echo -e "${RED}Đã hủy dọn dẹp database.${NC}"
    exit 0
fi

# Hỏi có muốn sao lưu trước khi dọn dẹp không
echo -e "${YELLOW}Bạn có muốn sao lưu database trước khi dọn dẹp? (y/n)${NC}"
read -r backup

if [[ $backup == "y" || $backup == "Y" ]]; then
    BACKUP_FILE="backup_before_cleanup_$(date +%Y%m%d_%H%M%S).sql"
    echo -e "${BLUE}Đang sao lưu database vào file ${BACKUP_FILE}...${NC}"

    if [ -z "$DB_PASS" ]; then
        PGPASSWORD="$DB_PASS" pg_dump -U "$DB_USER" -d "$DB_NAME" > "$BACKUP_FILE"
    else
        pg_dump -U "$DB_USER" -d "$DB_NAME" > "$BACKUP_FILE"
    fi

    if [ $? -ne 0 ]; then
        echo -e "${RED}Lỗi khi sao lưu database.${NC}"
        echo -e "${YELLOW}Bạn có muốn tiếp tục mà không sao lưu? (y/n)${NC}"
        read -r continue_without_backup

        if [[ $continue_without_backup != "y" && $continue_without_backup != "Y" ]]; then
            echo -e "${RED}Đã hủy dọn dẹp database.${NC}"
            exit 1
        fi
    else
        echo -e "${GREEN}Đã sao lưu database thành công vào ${BACKUP_FILE}.${NC}"

        # Thêm vào bảng backups nếu có thể
        echo -e "${BLUE}Đang thêm bản sao lưu vào hệ thống...${NC}"
        BACKUP_SQL="INSERT INTO backups (file_name, file_path, file_size, description, created_at) VALUES ('${BACKUP_FILE}', '$(pwd)/${BACKUP_FILE}', $(stat -c%s "${BACKUP_FILE}"), 'Backup before cleanup', CURRENT_TIMESTAMP);"

        if [ -z "$DB_PASS" ]; then
            PGPASSWORD="$DB_PASS" psql -U "$DB_USER" -d "$DB_NAME" -c "$BACKUP_SQL"
        else
            psql -U "$DB_USER" -d "$DB_NAME" -c "$BACKUP_SQL"
        fi
    fi
fi

# Tiến hành dọn dẹp
echo -e "${BLUE}Tiến hành dọn dẹp database...${NC}"
if [ -z "$DB_PASS" ]; then
    PGPASSWORD="$DB_PASS" psql -U "$DB_USER" -d "$DB_NAME" -f cleanup.sql
else
    psql -U "$DB_USER" -d "$DB_NAME" -f cleanup.sql
fi

if [ $? -ne 0 ]; then
    echo -e "${RED}Lỗi khi dọn dẹp database. Vui lòng kiểm tra file cleanup.sql.${NC}"
    exit 1
fi

echo -e "${GREEN}Đã dọn dẹp database thành công!${NC}"

# Nếu có yêu cầu loại bỏ trường thừa
if [ $REMOVE_UNUSED -eq 1 ]; then
    echo -e "${BLUE}Tiến hành loại bỏ các trường thừa...${NC}"
    if [ -z "$DB_PASS" ]; then
        PGPASSWORD="$DB_PASS" psql -U "$DB_USER" -d "$DB_NAME" -f remove_unused_db_elements.sql
    else
        psql -U "$DB_USER" -d "$DB_NAME" -f remove_unused_db_elements.sql
    fi

    if [ $? -ne 0 ]; then
        echo -e "${RED}Lỗi khi loại bỏ trường thừa. Vui lòng kiểm tra file remove_unused_db_elements.sql.${NC}"
        exit 1
    fi

    echo -e "${GREEN}Đã loại bỏ các trường thừa thành công!${NC}"
fi

# Hiển thị thống kê sau khi dọn dẹp
echo -e "${BLUE}Đang tạo thống kê sau khi dọn dẹp...${NC}"
STATS_SQL="
SELECT 'Tổng số truyện' as item, COUNT(*) as count FROM stories UNION ALL
SELECT 'Tổng số chương', COUNT(*) FROM chapters UNION ALL
SELECT 'Tổng số bookmarks', COUNT(*) FROM bookmarks UNION ALL
SELECT 'Tổng số guest bookmarks', COUNT(*) FROM guest_bookmarks UNION ALL
SELECT 'Tổng số bình luận', COUNT(*) FROM comments UNION ALL
SELECT 'Tổng số media files', COUNT(*) FROM media UNION ALL
SELECT 'Tổng số backups', COUNT(*) FROM backups UNION ALL
SELECT 'Tổng số logs', COUNT(*) FROM logs;
"

echo -e "${YELLOW}Thống kê dữ liệu database sau khi dọn dẹp:${NC}"
if [ -z "$DB_PASS" ]; then
    PGPASSWORD="$DB_PASS" psql -U "$DB_USER" -d "$DB_NAME" -c "$STATS_SQL"
else
    psql -U "$DB_USER" -d "$DB_NAME" -c "$STATS_SQL"
fi

echo -e "${GREEN}Hoàn tất dọn dẹp database!${NC}"
echo -e "${YELLOW}Lưu ý: Để dọn dẹp định kỳ tự động, bạn có thể thêm lệnh này vào crontab:${NC}"
echo -e "${GREEN}0 0 * * 0 $(pwd)/cleanup.sh $DB_NAME $DB_USER $DB_PASS > /path/to/cleanup_log.txt 2>&1${NC}"
echo -e "${YELLOW}Lệnh trên sẽ thực hiện dọn dẹp tự động vào 00:00 mỗi Chủ Nhật.${NC}"
