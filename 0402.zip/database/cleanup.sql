-- Database Cleanup Script
-- Removes unused, old, or redundant data from the database

-- Start a transaction for safety
BEGIN;

-- 1. Remove guest bookmarks older than 3 months (90 days)
DELETE FROM guest_bookmarks
WHERE updated_at < CURRENT_TIMESTAMP - INTERVAL '90 days';

-- 2. Remove expired tokens
DELETE FROM tokens
WHERE expires_at < CURRENT_TIMESTAMP;

-- 3. Remove old system logs (older than 30 days, except 'error' level logs which we keep for 90 days)
DELETE FROM logs
WHERE (level != 'error' AND created_at < CURRENT_TIMESTAMP - INTERVAL '30 days')
   OR (level = 'error' AND created_at < CURRENT_TIMESTAMP - INTERVAL '90 days');

-- 4. Remove old system changes records (older than 1 year)
DELETE FROM system_changes
WHERE created_at < CURRENT_TIMESTAMP - INTERVAL '1 year';

-- 5. Remove old backups (keep only the 10 most recent ones)
DELETE FROM backups
WHERE id NOT IN (
    SELECT id FROM backups
    ORDER BY created_at DESC
    LIMIT 10
);

-- 6. Remove old user activities (older than 60 days)
DELETE FROM activities
WHERE created_at < CURRENT_TIMESTAMP - INTERVAL '60 days';

-- 7. Clean up orphaned comments (comments on deleted stories/chapters)
DELETE FROM comments
WHERE (story_id IS NOT NULL AND story_id NOT IN (SELECT id FROM stories))
   OR (chapter_id IS NOT NULL AND chapter_id NOT IN (SELECT id FROM chapters));

-- 8. Remove unused/orphaned media files
DELETE FROM media
WHERE (user_id IS NULL OR user_id NOT IN (SELECT id FROM users))
  AND created_at < CURRENT_TIMESTAMP - INTERVAL '30 days';

-- 9. Limit guest bookmarks per guest_id to respect max_guest_bookmarks setting
-- First, get the max_guest_bookmarks setting
DO $$
DECLARE
    max_bookmarks INTEGER;
BEGIN
    SELECT CAST(value AS INTEGER) INTO max_bookmarks FROM settings WHERE id = 'max_guest_bookmarks';
    IF max_bookmarks IS NULL THEN
        max_bookmarks := 50; -- Default if setting not found
    END IF;

    -- For each guest with more than max_bookmarks bookmarks, delete the oldest ones
    FOR guest IN SELECT DISTINCT guest_id FROM guest_bookmarks LOOP
        DELETE FROM guest_bookmarks
        WHERE id IN (
            SELECT id FROM guest_bookmarks
            WHERE guest_id = guest.guest_id
            ORDER BY updated_at ASC
            OFFSET max_bookmarks
        );
    END LOOP;
END $$;

-- 10. Remove stories that are in draft status for more than 6 months and have no chapters
DELETE FROM stories
WHERE status = 'draft'
  AND created_at < CURRENT_TIMESTAMP - INTERVAL '180 days'
  AND NOT EXISTS (SELECT 1 FROM chapters WHERE chapters.story_id = stories.id);

-- 11. Remove "hot_score" data (deprecated - no longer used)
-- (We already removed the functions that calculate/use this)
UPDATE stories SET hot_score = 0;

-- Commit the transaction if all is well
COMMIT;

-- Run VACUUM to reclaim storage
VACUUM FULL;
