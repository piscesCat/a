-- Script tạo bảng story_stats nếu chưa tồn tại
-- Bảng này lưu trữ thống kê lượt xem hàng ngày của truyện
-- Dùng để phân tích xu hướng và cung cấp dữ liệu cho các thuật toán

-- Kiểm tra nếu bảng đã tồn tại
CREATE TABLE IF NOT EXISTS story_stats (
    id SERIAL PRIMARY KEY,
    story_id INTEGER NOT NULL REFERENCES stories(id) ON DELETE CASCADE,
    date DATE NOT NULL,
    views INTEGER DEFAULT 0,
    views_daily INTEGER DEFAULT 0,
    views_weekly INTEGER DEFAULT 0,
    views_monthly INTEGER DEFAULT 0,
    ratings_count INTEGER DEFAULT 0,
    ratings_avg DECIMAL(3,2) DEFAULT 0,
    favorites_count INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (story_id, date)
);

-- Tạo index cho truy vấn nhanh
CREATE INDEX IF NOT EXISTS idx_story_stats_story_id ON story_stats(story_id);
CREATE INDEX IF NOT EXISTS idx_story_stats_date ON story_stats(date);

-- Thêm trường is_hot, hot_marked_at, is_featured và publisher_id vào bảng stories nếu chưa có
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'stories' AND column_name = 'is_hot') THEN
        ALTER TABLE stories ADD COLUMN is_hot BOOLEAN DEFAULT FALSE;
    END IF;

    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'stories' AND column_name = 'hot_marked_at') THEN
        ALTER TABLE stories ADD COLUMN hot_marked_at TIMESTAMP;
    END IF;

    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'stories' AND column_name = 'is_featured') THEN
        ALTER TABLE stories ADD COLUMN is_featured BOOLEAN DEFAULT FALSE;
    END IF;

    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'stories' AND column_name = 'publisher_id') THEN
        ALTER TABLE stories ADD COLUMN publisher_id INTEGER REFERENCES users(id);
        -- Cập nhật publisher_id từ author_id hiện tại
        UPDATE stories SET publisher_id = author_id WHERE publisher_id IS NULL;
    END IF;
END
$$;

-- Cập nhật giá trị mặc định cho trạng thái của chương
ALTER TABLE chapters ALTER COLUMN status SET DEFAULT 'active';

-- Thêm các cài đặt mặc định cho thuật toán
INSERT INTO settings (id, value, description)
VALUES
    ('last_reset_daily', NULL, 'Thời gian reset lượt xem theo ngày gần nhất'),
    ('last_reset_weekly', NULL, 'Thời gian reset lượt xem theo tuần gần nhất'),
    ('last_reset_monthly', NULL, 'Thời gian reset lượt xem theo tháng gần nhất'),
    ('algorithm_hot_min_daily_views', '100', 'Số lượt xem tối thiểu trong ngày để đánh dấu là hot'),
    ('algorithm_hot_growth_rate', '30', 'Tỷ lệ tăng trưởng tối thiểu so với ngày trước (%)'),
    ('algorithm_hot_min_new_ratings', '10', 'Số lượng đánh giá mới tối thiểu trong 24h'),
    ('algorithm_hot_cooldown_days', '3', 'Số ngày tự động loại bỏ trạng thái hot'),
    ('cover_upload_type', 'local', 'Loại upload cho ảnh bìa (local, imgur)'),
    ('max_cover_width', '300', 'Chiều rộng tối đa cho ảnh bìa'),
    ('max_cover_height', '450', 'Chiều cao tối đa cho ảnh bìa')
ON CONFLICT (id) DO NOTHING;

-- Xóa các cài đặt không cần thiết liên quan đến template
DELETE FROM settings WHERE id IN ('template_variant', 'template_color_scheme', 'template_font');

-- Thêm các cột cho media để hỗ trợ lưu trữ ngoài (imgur)
ALTER TABLE media ADD COLUMN IF NOT EXISTS is_external BOOLEAN DEFAULT FALSE;
ALTER TABLE media ADD COLUMN IF NOT EXISTS external_type VARCHAR(50) NULL;
ALTER TABLE media ADD COLUMN IF NOT EXISTS external_id VARCHAR(255) NULL;
ALTER TABLE media ADD COLUMN IF NOT EXISTS external_delete_hash VARCHAR(255) NULL;

-- Xóa bảng bookmarks không còn sử dụng
DROP TABLE IF EXISTS bookmarks CASCADE;
DROP TABLE IF EXISTS guest_bookmarks CASCADE;

-- Ghi nhận việc cập nhật database
INSERT INTO system_changes (change_type, description, sql_query, created_at)
VALUES ('structure', 'Updated database structure for version 2.0', 'Added publisher_id, removed bookmarks, updated defaults', CURRENT_TIMESTAMP);
