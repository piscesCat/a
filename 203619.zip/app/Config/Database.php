<?php
// app/Config/Database.php
namespace Config;

use CodeIgniter\Database\Config;

class Database extends Config
{
    public $defaultGroup = 'default';

    public $default = [
        'DSN'      => '',
        'hostname' => 'localhost',  // Giá trị mặc định chỉ dùng cho development
        'username' => 'postgres',   // Giá trị mặc định chỉ dùng cho development
        'password' => 'postgres',   // Giá trị mặc định chỉ dùng cho development
        'database' => 'story_website',
        'DBDriver' => 'Postgre',
        'DBPrefix' => '',
        'pConnect' => false,
        'DBDebug'  => true,
        'charset'  => 'utf8',
        'DBCollat' => 'utf8_general_ci',
        'swapPre'  => '',
        'encrypt'  => false,
        'compress' => false,
        'strictOn' => false,
        'failover' => [],
        'port'     => 5432,
    ];

    public function __construct()
    {
        parent::__construct();

        // Sử dụng biến môi trường cho tất cả các môi trường
        // Throw exception nếu không có biến môi trường trong production
        if (ENVIRONMENT === 'production') {
            if (empty($_ENV['DB_HOSTNAME']) || empty($_ENV['DB_USERNAME']) ||
                empty($_ENV['DB_PASSWORD']) || empty($_ENV['DB_DATABASE'])) {
                throw new \RuntimeException('Database environment variables are not set in production environment');
            }

            // Trong production, luôn sử dụng các giá trị từ biến môi trường
            $this->default['hostname'] = $_ENV['DB_HOSTNAME'];
            $this->default['username'] = $_ENV['DB_USERNAME'];
            $this->default['password'] = $_ENV['DB_PASSWORD'];
            $this->default['database'] = $_ENV['DB_DATABASE'];
            $this->default['port']     = $_ENV['DB_PORT'] ?? $this->default['port'];
        } else {
            // Trong môi trường development và testing, cho phép sử dụng giá trị mặc định
            // Nhưng vẫn ưu tiên sử dụng biến môi trường nếu có
            $this->default['hostname'] = $_ENV['DB_HOSTNAME'] ?? $this->default['hostname'];
            $this->default['username'] = $_ENV['DB_USERNAME'] ?? $this->default['username'];
            $this->default['password'] = $_ENV['DB_PASSWORD'] ?? $this->default['password'];
            $this->default['database'] = $_ENV['DB_DATABASE'] ?? $this->default['database'];
            $this->default['port']     = $_ENV['DB_PORT'] ?? $this->default['port'];

            // Log cảnh báo nếu đang sử dụng giá trị mặc định
            if (empty($_ENV['DB_HOSTNAME']) || empty($_ENV['DB_USERNAME']) ||
                empty($_ENV['DB_PASSWORD']) || empty($_ENV['DB_DATABASE'])) {
                log_message('warning', 'Using default database credentials. This is not recommended for security reasons.');
            }
        }
    }
}
