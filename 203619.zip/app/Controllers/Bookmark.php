<?php

namespace App\Controllers;

use App\Models\StoryModel;
use App\Models\ChapterModel;

class Bookmark extends BaseController
{
    protected $storyModel;
    protected $chapterModel;

    public function __construct()
    {
        $this->storyModel = new StoryModel();
        $this->chapterModel = new ChapterModel();
    }

    /**
     * Hiển thị trang danh sách bookmark
     * Bookmark được xử lý hoàn toàn ở client-side bằng localStorage
     */
    public function index()
    {
        return view('bookmark/index.html');
    }

    /**
     * API endpoint cho việc kiểm tra trạng thái bookmark
     */
    public function checkStatus()
    {
        $storyId = $this->request->getGet('story_id');

        if (!$storyId) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Thiếu thông tin truyện'
            ]);
        }

        // Chỉ kiểm tra xem truyện có tồn tại không
        $story = $this->storyModel->find($storyId);
        if (!$story) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Không tìm thấy truyện'
            ]);
        }

        // Trả về thành công nhưng không có dữ liệu, vì dữ liệu bookmark được xử lý hoàn toàn ở client
        return $this->response->setJSON([
            'success' => true,
            'data' => [
                'story_slug' => $story['slug'],
                'story_title' => $story['title'],
                'publisher_name' => $story['publisher_name'] // Changed from author_name to publisher_name
            ]
        ]);
    }

    /**
     * API endpoint cho việc kiểm tra thông tin chương
     */
    public function checkChapter()
    {
        $chapterId = $this->request->getGet('chapter_id');

        if (!$chapterId) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Thiếu thông tin chương'
            ]);
        }

        // Chỉ kiểm tra xem chương có tồn tại không
        $chapter = $this->chapterModel->find($chapterId);
        if (!$chapter) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Không tìm thấy chương'
            ]);
        }

        // Trả về thông tin chương để client có thể tự cập nhật bookmark
        return $this->response->setJSON([
            'success' => true,
            'data' => [
                'chapter_id' => $chapter['id'],
                'chapter_number' => $chapter['chapter_number'],
                'chapter_title' => $chapter['title'],
                'story_id' => $chapter['story_id']
            ]
        ]);
    }

    /**
     * Lấy thông tin chi tiết cho danh sách bookmarks
     * Phương thức API này nhận danh sách IDs từ client và trả về thông tin đầy đủ từ database
     */
    public function getBookmarksData()
    {
        // Kiểm tra request
        if (!$this->request->isAJAX()) {
            return $this->response->setJSON(['error' => 'Invalid request']);
        }

        // Lấy danh sách story IDs từ request
        $storyIds = $this->request->getPost('ids');
        if (!$storyIds || !is_array($storyIds)) {
            return $this->response->setJSON(['error' => 'No bookmark IDs provided']);
        }

        // Làm sạch danh sách IDs
        $storyIds = array_map('intval', $storyIds);
        $storyIds = array_filter($storyIds); // Loại bỏ các giá trị không hợp lệ (0 hoặc null)

        if (empty($storyIds)) {
            return $this->response->setJSON(['error' => 'Invalid bookmark IDs']);
        }

        // Giới hạn số lượng IDs để tránh quá tải
        $storyIds = array_slice($storyIds, 0, 100);

        // Lấy thông tin chi tiết từ database
        $storyModel = new \App\Models\StoryModel();
        $stories = $storyModel->getStoriesByIds($storyIds);

        // Trả về kết quả
        return $this->response->setJSON([
            'success' => true,
            'stories' => $stories
        ]);
    }

    /**
     * Lấy thông tin chi tiết cho danh sách bookmarks dựa trên slugs
     * Phương thức API này nhận danh sách slugs từ client và trả về thông tin đầy đủ từ database
     */
    public function getBookmarksBySlug()
    {
        // Kiểm tra request
        if (!$this->request->isAJAX()) {
            return $this->response->setJSON(['error' => 'Invalid request']);
        }

        // Lấy danh sách story slugs từ request
        $slugs = $this->request->getPost('slugs');
        if (!$slugs || !is_array($slugs)) {
            return $this->response->setJSON(['error' => 'No bookmark slugs provided']);
        }

        // Làm sạch danh sách slugs
        $slugs = array_filter($slugs, function($slug) {
            return is_string($slug) && !empty($slug) && strlen($slug) <= 200;
        });

        if (empty($slugs)) {
            return $this->response->setJSON(['error' => 'Invalid bookmark slugs']);
        }

        // Giới hạn số lượng slugs để tránh quá tải
        $slugs = array_slice($slugs, 0, 100);

        // Lấy thông tin chi tiết từ database
        $storyModel = new \App\Models\StoryModel();
        $stories = $storyModel->getStoriesBySlugs($slugs);

        // Trả về kết quả
        return $this->response->setJSON([
            'success' => true,
            'stories' => $stories
        ]);
    }

    /**
     * Lấy thông tin chi tiết cho một bookmark
     */
    public function getBookmarkInfo()
    {
        $storyId = $this->request->getGet('story_id');

        if (!$storyId) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Thiếu thông tin truyện'
            ]);
        }

        // Lấy thông tin truyện từ database
        $story = $this->storyModel->find($storyId);
        if (!$story) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Không tìm thấy truyện'
            ]);
        }

        // Trả về thông tin truyện
        return $this->response->setJSON([
            'success' => true,
            'story' => [
                'id' => $story['id'],
                'title' => $story['title'],
                'slug' => $story['slug'],
                'cover_image' => $story['cover_image'],
                'publisher_name' => $story['publisher_name']
            ]
        ]);
    }
}
