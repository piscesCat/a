<?php
namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;

class StoryManager extends BaseController
{
    protected $storyModel;
    protected $userModel;
    protected $categoryModel;

    public function __construct()
    {
        $this->storyModel = new \App\Models\StoryModel();
        $this->userModel = new \App\Models\UserModel();
        $this->categoryModel = new \App\Models\CategoryModel();
    }

    /**
     * Hiển thị danh sách truyện
     */
    public function index()
    {
        $stories = $this->storyModel
                     ->select('stories.*, users.username as publisher_name')
                     ->join('users', 'users.id = stories.publisher_id')
                     ->orderBy('stories.created_at', 'DESC')
                     ->findAll();

        return view('admin/story/index.html', [
            'stories' => $stories
        ]);
    }

    /**
     * Hiển thị form tạo truyện mới
     */
    public function new()
    {
        $users = $this->userModel->findAll();
        $categories = $this->categoryModel->findAll();

        return view('admin/story/create.html', [
            'users' => $users,
            'categories' => $categories
        ]);
    }

    /**
     * Xử lý tạo truyện mới
     */
    public function create()
    {
        // Validate form input
        $rules = [
            'title' => 'required|min_length[3]|max_length[200]',
            'slug' => 'required|alpha_dash|min_length[3]|max_length[200]|is_unique[stories.slug]',
            'description' => 'required',
            'author_name' => 'required|max_length[100]',
            'publisher_id' => 'required|integer',
            'categories' => 'required',
            'country_id' => 'permit_empty|max_length[100]',
            'year' => 'permit_empty|integer|greater_than[1900]|less_than[2100]',
            'type' => 'permit_empty|in_list[short_story,novel,essay,memoir,autobiography,reportage,comics]'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        // Handle image upload
        $coverImage = $this->handleCoverImageUpload();

        // Prepare data
        $data = [
            'title' => $this->request->getPost('title'),
            'slug' => $this->request->getPost('slug'),
            'description' => $this->request->getPost('description'),
            'author_name' => $this->request->getPost('author_name'),
            'publisher_id' => $this->request->getPost('publisher_id'),
            'cover_image' => $coverImage,
            'views' => 0,
            'rating' => 0,
            'country' => $this->request->getPost('country_id') ?: null,
            'year' => $this->request->getPost('year') ?: null,
            'type' => $this->request->getPost('type') ?: null,
            'is_featured' => $this->request->getPost('is_featured') ? 1 : 0,
            'is_hot' => $this->request->getPost('is_hot') ? 1 : 0,
            'is_completed' => $this->request->getPost('is_completed') ? 1 : 0,
            'chapter_count' => 0
        ];

        // Insert record
        $db = \Config\Database::connect();
        $db->transStart();

        $storyId = $this->storyModel->insert($data);

        // Insert categories
        $categories = $this->request->getPost('categories');
        foreach ($categories as $categoryId) {
            $db->table('story_categories')->insert([
                'story_id' => $storyId,
                'category_id' => $categoryId
            ]);
        }

        // Add activity log
        $this->logActivity('created_story', [
            'target_type' => 'story',
            'target_id' => $storyId,
            'target_title' => $data['title'],
            'target_slug' => $data['slug']
        ]);

        $db->transComplete();

        if ($db->transStatus() === false) {
            return redirect()->back()->withInput()->with('error', 'Đã xảy ra lỗi khi thêm truyện.');
        }

        return redirect()->to('/admin/stories')->with('success', 'Truyện đã được thêm thành công.');
    }

    /**
     * Hiển thị form chỉnh sửa truyện
     */
    public function edit($id)
    {
        $story = $this->storyModel->find($id);

        if (!$story) {
            return redirect()->to('/admin/stories')->with('error', 'Truyện không tồn tại.');
        }

        $users = $this->userModel->findAll();
        $categories = $this->categoryModel->findAll();

        // Get selected categories
        $db = \Config\Database::connect();
        $selectedCategories = $db->table('story_categories')
                                 ->where('story_id', $id)
                                 ->get()
                                 ->getResultArray();

        $selectedCategoryIds = array_column($selectedCategories, 'category_id');

        return view('admin/story/edit.html', [
            'story' => $story,
            'users' => $users,
            'categories' => $categories,
            'selected_categories' => $selectedCategoryIds
        ]);
    }

    /**
     * Xử lý cập nhật truyện
     */
    public function update($id)
    {
        // Validate form input
        $rules = [
            'title' => 'required|min_length[3]|max_length[200]',
            'slug' => "required|alpha_dash|min_length[3]|max_length[200]|is_unique[stories.slug,id,$id]",
            'description' => 'required',
            'author_name' => 'required|max_length[100]',
            'publisher_id' => 'required|integer',
            'categories' => 'required',
            'country_id' => 'permit_empty|max_length[100]',
            'year' => 'permit_empty|integer|greater_than[1900]|less_than[2100]',
            'type' => 'permit_empty|in_list[short_story,novel,essay,memoir,autobiography,reportage,comics]'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $story = $this->storyModel->find($id);
        if (!$story) {
            return redirect()->to('/admin/stories')->with('error', 'Truyện không tồn tại.');
        }

        // Handle image upload
        $coverImage = $this->handleCoverImageUpload($story['cover_image']);

        // Prepare data
        $data = [
            'title' => $this->request->getPost('title'),
            'slug' => $this->request->getPost('slug'),
            'description' => $this->request->getPost('description'),
            'author_name' => $this->request->getPost('author_name'),
            'publisher_id' => $this->request->getPost('publisher_id'),
            'country' => $this->request->getPost('country_id') ?: null,
            'year' => $this->request->getPost('year') ?: null,
            'type' => $this->request->getPost('type') ?: null,
            'is_featured' => $this->request->getPost('is_featured') ? 1 : 0,
            'is_hot' => $this->request->getPost('is_hot') ? 1 : 0,
            'is_completed' => $this->request->getPost('is_completed') ? 1 : 0
        ];

        // Only update cover image if a new one was uploaded
        if ($coverImage) {
            $data['cover_image'] = $coverImage;
        }

        // Update record
        $db = \Config\Database::connect();
        $db->transStart();

        $this->storyModel->update($id, $data);

        // Update categories
        $db->table('story_categories')->where('story_id', $id)->delete();

        $categories = $this->request->getPost('categories');
        foreach ($categories as $categoryId) {
            $db->table('story_categories')->insert([
                'story_id' => $id,
                'category_id' => $categoryId
            ]);
        }

        // Add activity log
        $this->logActivity('updated_story', [
            'target_type' => 'story',
            'target_id' => $id,
            'target_title' => $data['title'],
            'target_slug' => $data['slug']
        ]);

        $db->transComplete();

        if ($db->transStatus() === false) {
            return redirect()->back()->withInput()->with('error', 'Đã xảy ra lỗi khi cập nhật truyện.');
        }

        return redirect()->to('/admin/stories')->with('success', 'Truyện đã được cập nhật thành công.');
    }

    /**
     * Xóa truyện
     */
    public function delete($id)
    {
        $story = $this->storyModel->find($id);

        if (!$story) {
            return redirect()->to('/admin/stories')->with('error', 'Truyện không tồn tại.');
        }

        $db = \Config\Database::connect();
        $db->transStart();

        // Delete story categories
        $db->table('story_categories')->where('story_id', $id)->delete();

        // Delete chapters
        $db->table('chapters')->where('story_id', $id)->delete();

        // Delete reading progress
        $db->table('reading_progress')->where('story_id', $id)->delete();

        // Delete ratings
        $db->table('ratings')->where('story_id', $id)->delete();

        // Delete comments
        $db->table('comments')->where('story_id', $id)->delete();

        // Delete the story
        $this->storyModel->delete($id);

        // Add activity log
        $this->logActivity('deleted_story', [
            'target_type' => 'story',
            'target_id' => $id,
            'target_title' => $story['title'],
            'target_slug' => $story['slug']
        ]);

        $db->transComplete();

        if ($db->transStatus() === false) {
            return redirect()->to('/admin/stories')->with('error', 'Đã xảy ra lỗi khi xóa truyện.');
        }

        return redirect()->to('/admin/stories')->with('success', 'Truyện đã được xóa thành công.');
    }

    /**
     * Xử lý upload ảnh bìa
     */
    private function handleCoverImageUpload($currentImage = null)
    {
        // Kiểm tra xem có dữ liệu ảnh đã crop không
        $croppedImage = $this->request->getPost('cropped_cover_image');

        if ($croppedImage) {
            // Xử lý dữ liệu base64 từ ảnh đã crop
            $base64Image = explode(';base64,', $croppedImage);
            if (count($base64Image) < 2) {
                return $currentImage; // Invalid base64 data
            }

            $encodedImg = $base64Image[1];
            $decodedImg = base64_decode($encodedImg);

            if (!$decodedImg) {
                return $currentImage; // Failed to decode base64
            }

            // Lấy cài đặt về kiểu upload
            $settingsModel = new \App\Models\SettingsModel();
            $uploadType = $settingsModel->findById('cover_upload_type')['value'] ?? 'local';

            // Nếu là imgur và có client ID
            if ($uploadType === 'imgur') {
                $imgurClientId = $settingsModel->findById('imgur_client_id')['value'] ?? '';

                if (!empty($imgurClientId)) {
                    // Upload lên imgur
                    $imgurClient = new \App\Libraries\ImgurClient($imgurClientId);
                    $response = $imgurClient->upload($decodedImg);

                    if (isset($response->data->link)) {
                        // Lưu thông tin vào bảng media
                        $mediaModel = new \App\Models\MediaModel();
                        $mediaId = $mediaModel->insert([
                            'file_path' => $response->data->link,
                            'file_name' => basename($response->data->link),
                            'file_type' => 'image/jpeg', // Cropped images are converted to JPEG
                            'file_size' => strlen($decodedImg),
                            'is_external' => true,
                            'external_type' => 'imgur',
                            'external_id' => $response->data->id,
                            'external_delete_hash' => $response->data->deletehash ?? '',
                            'uploaded_by' => session()->get('user')['id'],
                            'created_at' => date('Y-m-d H:i:s')
                        ]);

                        // Xóa ảnh cũ nếu có
                        if ($currentImage && file_exists(FCPATH . $currentImage)) {
                            unlink(FCPATH . $currentImage);
                        }

                        return $response->data->link; // Trả về URL của ảnh
                    }
                }
            }

            // Mặc định: lưu ảnh vào local
            $newName = md5(uniqid() . time()) . '.jpg';

            // Tạo thư mục nếu chưa tồn tại
            if (!is_dir(FCPATH . 'uploads/covers')) {
                mkdir(FCPATH . 'uploads/covers', 0755, true);
            }

            // Lưu file
            file_put_contents(FCPATH . 'uploads/covers/' . $newName, $decodedImg);

            // Xóa ảnh cũ nếu có
            if ($currentImage && file_exists(FCPATH . $currentImage)) {
                unlink(FCPATH . $currentImage);
            }

            return 'uploads/covers/' . $newName;
        }

        // Nếu không có ảnh đã crop, tiếp tục với upload file thông thường
        $coverImage = $this->request->getFile('cover_image');

        if ($coverImage && $coverImage->isValid() && !$coverImage->hasMoved()) {
            // Lấy cài đặt về kiểu upload
            $settingsModel = new \App\Models\SettingsModel();
            $uploadType = $settingsModel->findById('cover_upload_type')['value'] ?? 'local';
            $maxWidth = (int)($settingsModel->findById('max_cover_width')['value'] ?? 300);
            $maxHeight = (int)($settingsModel->findById('max_cover_height')['value'] ?? 450);

            // Nếu là imgur và có client ID
            if ($uploadType === 'imgur') {
                $imgurClientId = $settingsModel->findById('imgur_client_id')['value'] ?? '';

                if (!empty($imgurClientId)) {
                    // Xử lý upload lên imgur
                    $imgurClient = new \App\Libraries\ImgurClient($imgurClientId);

                    // Resize ảnh nếu cần
                    $image = \Config\Services::image();
                    $tmpPath = WRITEPATH . 'temp/' . $coverImage->getRandomName();

                    // Di chuyển file vào thư mục tạm
                    $coverImage->move(WRITEPATH . 'temp', basename($tmpPath));

                    // Resize ảnh nếu cần
                    $image->withFile($tmpPath)
                        ->resize($maxWidth, $maxHeight, true, 'height')
                        ->save($tmpPath);

                    // Upload lên imgur
                    $response = $imgurClient->upload(file_get_contents($tmpPath));

                    // Xóa file tạm
                    unlink($tmpPath);

                    if (isset($response->data->link)) {
                        // Lưu thông tin vào bảng media
                        $mediaModel = new \App\Models\MediaModel();
                        $mediaId = $mediaModel->insert([
                            'file_path' => $response->data->link,
                            'file_name' => basename($response->data->link),
                            'file_type' => $coverImage->getClientMimeType(),
                            'file_size' => $coverImage->getSize(),
                            'is_external' => true,
                            'external_type' => 'imgur',
                            'external_id' => $response->data->id,
                            'external_delete_hash' => $response->data->deletehash ?? '',
                            'uploaded_by' => session()->get('user')['id'],
                            'created_at' => date('Y-m-d H:i:s')
                        });

                        // Xóa ảnh cũ nếu có
                        if ($currentImage && file_exists(FCPATH . $currentImage)) {
                            unlink(FCPATH . $currentImage);
                        }

                        return $response->data->link; // Trả về URL của ảnh
                    }
                }
            }

            // Mặc định hoặc fallback nếu imgur thất bại: lưu ảnh vào local
            $newName = $coverImage->getRandomName();

            // Tạo thư mục nếu chưa tồn tại
            if (!is_dir(FCPATH . 'uploads/covers')) {
                mkdir(FCPATH . 'uploads/covers', 0755, true);
            }

            // Resize ảnh nếu cần
            $image = \Config\Services::image();
            $image->withFile($coverImage->getTempName())
                ->resize($maxWidth, $maxHeight, true, 'height')
                ->save(FCPATH . 'uploads/covers/' . $newName);

            // Xóa ảnh cũ nếu có
            if ($currentImage && file_exists(FCPATH . $currentImage)) {
                unlink(FCPATH . $currentImage);
            }

            return 'uploads/covers/' . $newName;
        }

        return $currentImage;
    }

    /**
     * Ghi log hoạt động
     */
    private function logActivity($action, $details)
    {
        $logModel = new \App\Models\LogModel();

        $logModel->insert([
            'level' => 'info',
            'message' => 'User ' . session()->get('user')['username'] . ' ' . $action . ': ' . $details['target_title'],
            'context' => json_encode(array_merge($details, [
                'user_id' => session()->get('user')['id'],
                'ip_address' => $this->request->getIPAddress()
            ]))
        ]);
    }
}
