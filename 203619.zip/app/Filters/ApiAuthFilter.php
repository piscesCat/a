<?php

namespace App\Filters;

use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use CodeIgniter\Filters\FilterInterface;

class ApiAuthFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        // Chỉ áp dụng filter cho API admin routes, bỏ qua mọi API public
        $uri = $request->getUri();
        $segments = $uri->getSegments();

        // Nếu không phải API admin, cho phép đi qua
        if (count($segments) >= 2 && $segments[0] === 'api' && $segments[1] !== 'admin') {
            return;
        }

        // Lấy API token từ request header
        $token = $request->getHeaderLine('X-API-Token');

        // Nếu không có token
        if (empty($token)) {
            return service('response')->setStatusCode(401)
                ->setJSON(['error' => 'API token không hợp lệ hoặc đã hết hạn', 'code' => 'invalid_token']);
        }

        // Kiểm tra token trong database
        $tokenModel = new \App\Models\TokenModel();
        $validToken = $tokenModel->validateToken($token);

        // Nếu token không hợp lệ
        if (!$validToken) {
            return service('response')->setStatusCode(401)
                ->setJSON(['error' => 'API token không hợp lệ hoặc đã hết hạn', 'code' => 'invalid_token']);
        }

        // Lưu thông tin user trong request
        $request->user = $validToken['user'];
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // Do nothing
    }
}
