<?php
namespace App\Models;

use CodeIgniter\Model;

class StoryModel extends Model
{
    protected $table = 'stories';
    protected $primaryKey = 'id';
    protected $returnType = 'array';

    protected $allowedFields = [
        'title', 'slug', 'description', 'cover_image',
        'author_name', 'publisher_id', 'status', 'type', 'release_year',
        'country', 'views', 'views_day', 'views_week', 'views_month',
        'rating', 'total_ratings', 'total_favorites', 'created_at',
        'updated_at', 'is_featured', 'is_completed', 'search_vector', 'is_recommended', 'is_hot', 'hot_marked_at'
    ];

    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    /**
     * Lấy thông tin truyện kèm theo thông tin liên quan
     */
    public function getStory($slug)
    {
        $builder = $this->db->table('stories s')
            ->select('s.*, u.username as publisher_name')
            ->join('users u', 'u.id = s.publisher_id', 'left')
            ->where('s.slug', $slug);

        $story = $builder->get()->getRowArray();

        if (!$story) {
            return null;
        }

        // Lấy danh sách thể loại của truyện
        $story['categories'] = $this->getStoryCategories($story['id']);

        // Lấy danh sách chương
        $chapterModel = new ChapterModel();
        $story['chapters'] = $chapterModel->where('story_id', $story['id'])
            ->orderBy('chapter_number', 'ASC')
            ->findAll();

        // Lấy thông tin chương mới nhất
        $story['latest_chapter'] = !empty($story['chapters'])
            ? $story['chapters'][count($story['chapters']) - 1]
            : null;

        // Đếm số lượng chương
        $story['chapter_count'] = count($story['chapters']);

        return $story;
    }

    /**
     * Lấy danh sách các thể loại của truyện
     */
    public function getStoryCategories($storyId)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('story_categories sc')
            ->select('c.*')
            ->join('categories c', 'c.id = sc.category_id')
            ->where('sc.story_id', $storyId);

        return $builder->get()->getResultArray();
    }

    /**
     * Lấy danh sách quốc gia có truyện trong hệ thống
     * Bây giờ lấy trực tiếp từ trường country
     */
    public function getCountries()
    {
        $db = \Config\Database::connect();
        $builder = $db->table('stories')
            ->select('country, COUNT(*) as story_count')
            ->where('country IS NOT NULL')
            ->where('country !=', '')
            ->where('status', 'published')
            ->groupBy('country')
            ->orderBy('country', 'ASC');

        return $builder->get()->getResultArray();
    }

    /**
     * Lấy truyện theo quốc gia
     */
    public function getStoriesByCountry($country, $limit = 12, $offset = 0)
    {
        return $this->where('country', $country)
            ->where('status', 'published')
            ->orderBy('created_at', 'DESC')
            ->limit($limit, $offset)
            ->findAll();
    }

    /**
     * Đếm số lượng truyện theo quốc gia
     */
    public function countStoriesByCountry($country)
    {
        return $this->where('country', $country)
            ->where('status', 'published')
            ->countAllResults();
    }

    /**
     * Lấy truyện nổi bật
     */
    public function getFeaturedStories($limit = 6)
    {
        return $this->where('is_featured', true)
                   ->where('status', 'published')
                   ->orderBy('created_at', 'DESC')
                   ->limit($limit)
                   ->find();
    }

    /**
     * Lấy truyện mới cập nhật gần đây
     */
    public function getRecentlyUpdated($limit = 12, $offset = 0, $status = null)
    {
        $builder = $this->where('status', 'published');

        if ($status) {
            if ($status == 'completed') {
                $builder->where('is_completed', true);
            } elseif ($status == 'ongoing') {
                $builder->where('is_completed', false);
            }
        }

        return $builder->orderBy('updated_at', 'DESC')
                      ->limit($limit, $offset)
                      ->find();
    }

    /**
     * Đếm truyện mới cập nhật gần đây
     */
    public function getRecentlyUpdatedCount($status = null)
    {
        $builder = $this->where('status', 'published');

        if ($status) {
            if ($status == 'completed') {
                $builder->where('is_completed', true);
            } elseif ($status == 'ongoing') {
                $builder->where('is_completed', false);
            }
        }

        return $builder->countAllResults();
    }

    /**
     * Lấy truyện phổ biến
     */
    public function getPopularStories($limit = 5)
    {
        return $this->where('status', 'published')
                   ->orderBy('views', 'DESC')
                   ->limit($limit)
                   ->find();
    }

    /**
     * Lấy truyện đã hoàn thành
     */
    public function getCompleted($limit = 6, $offset = 0, $sort = null)
    {
        $builder = $this->where('is_completed', true)
                        ->where('status', 'published');

        if ($sort) {
            switch ($sort) {
                case 'oldest':
                    $builder->orderBy('created_at', 'ASC');
                    break;
                case 'name_asc':
                    $builder->orderBy('title', 'ASC');
                    break;
                case 'name_desc':
                    $builder->orderBy('title', 'DESC');
                    break;
                case 'view':
                    $builder->orderBy('views', 'DESC');
                    break;
                case 'rating':
                    $builder->orderBy('rating', 'DESC');
                    break;
                default:
                    $builder->orderBy('updated_at', 'DESC');
                    break;
            }
        } else {
            $builder->orderBy('updated_at', 'DESC');
        }

        return $builder->limit($limit, $offset)
                      ->find();
    }

    /**
     * Đếm truyện đã hoàn thành
     */
    public function getCompletedCount()
    {
        return $this->where('is_completed', true)
                   ->where('status', 'published')
                   ->countAllResults();
    }

    /**
     * Lấy truyện theo danh mục
     */
    public function getByCategory($categoryId, $limit = 12, $offset = 0, $sort = null, $status = null)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('stories')
                    ->select('stories.*')
                    ->join('story_categories', 'story_categories.story_id = stories.id')
                    ->where('story_categories.category_id', $categoryId)
                    ->where('stories.status', 'published');

        if ($status) {
            if ($status == 'completed') {
                $builder->where('stories.is_completed', true);
            } elseif ($status == 'ongoing') {
                $builder->where('stories.is_completed', false);
            }
        }

        if ($sort) {
            switch ($sort) {
                case 'oldest':
                    $builder->orderBy('stories.created_at', 'ASC');
                    break;
                case 'name_asc':
                    $builder->orderBy('stories.title', 'ASC');
                    break;
                case 'name_desc':
                    $builder->orderBy('stories.title', 'DESC');
                    break;
                case 'view':
                    $builder->orderBy('stories.views', 'DESC');
                    break;
                case 'rating':
                    $builder->orderBy('stories.rating', 'DESC');
                    break;
                default:
                    $builder->orderBy('stories.created_at', 'DESC');
                    break;
            }
        } else {
            $builder->orderBy('stories.created_at', 'DESC');
        }

        $query = $builder->limit($limit, $offset)->get();

        return $query->getResultArray();
    }

    /**
     * Đếm số lượng truyện theo danh mục
     */
    public function getByCategoryCount($categoryId, $status = null)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('stories')
                    ->join('story_categories', 'story_categories.story_id = stories.id')
                    ->where('story_categories.category_id', $categoryId)
                    ->where('stories.status', 'published');

        if ($status) {
            if ($status == 'completed') {
                $builder->where('stories.is_completed', true);
            } elseif ($status == 'ongoing') {
                $builder->where('stories.is_completed', false);
            }
        }

        return $builder->countAllResults();
    }

    /**
     * Lấy truyện hot
     */
    public function getHotStories($limit = 12, $offset = 0, $sort = 'views', $status = null)
    {
        $builder = $this->where('status', 'published')
                        ->where('is_hot', true);

        if ($status) {
            if ($status == 'completed') {
                $builder->where('is_completed', true);
            } elseif ($status == 'ongoing') {
                $builder->where('is_completed', false);
            }
        }

        switch ($sort) {
            case 'latest':
                $builder->orderBy('created_at', 'DESC');
                break;
            case 'oldest':
                $builder->orderBy('created_at', 'ASC');
                break;
            case 'name_asc':
                $builder->orderBy('title', 'ASC');
                break;
            case 'name_desc':
                $builder->orderBy('title', 'DESC');
                break;
            case 'rating':
                $builder->orderBy('rating', 'DESC');
                break;
            default:
                $builder->orderBy('views', 'DESC');
                break;
        }

        return $builder->limit($limit, $offset)
                      ->find();
    }

    /**
     * Đếm truyện hot
     */
    public function getHotStoriesCount($status = null)
    {
        $builder = $this->where('status', 'published')
                        ->where('is_hot', true);

        if ($status) {
            if ($status == 'completed') {
                $builder->where('is_completed', true);
            } elseif ($status == 'ongoing') {
                $builder->where('is_completed', false);
            }
        }

        return $builder->countAllResults();
    }

    /**
     * Lấy truyện mới nhất
     */
    public function getLatest($limit = 12, $offset = 0, $sort = null, $status = null)
    {
        $builder = $this->where('status', 'published');

        if ($status) {
            if ($status == 'completed') {
                $builder->where('is_completed', true);
            } elseif ($status == 'ongoing') {
                $builder->where('is_completed', false);
            }
        }

        if ($sort) {
            switch ($sort) {
                case 'oldest':
                    $builder->orderBy('created_at', 'ASC');
                    break;
                case 'name_asc':
                    $builder->orderBy('title', 'ASC');
                    break;
                case 'name_desc':
                    $builder->orderBy('title', 'DESC');
                    break;
                case 'view':
                    $builder->orderBy('views', 'DESC');
                    break;
                case 'rating':
                    $builder->orderBy('rating', 'DESC');
                    break;
                default:
                    $builder->orderBy('created_at', 'DESC');
                    break;
            }
        } else {
            $builder->orderBy('created_at', 'DESC');
        }

        return $builder->limit($limit, $offset)
                      ->find();
    }

    /**
     * Đếm truyện mới nhất
     */
    public function getLatestCount($status = null)
    {
        $builder = $this->where('status', 'published');

        if ($status) {
            if ($status == 'completed') {
                $builder->where('is_completed', true);
            } elseif ($status == 'ongoing') {
                $builder->where('is_completed', false);
            }
        }

        return $builder->countAllResults();
    }

    /**
     * Lấy truyện được đề xuất
     */
    public function getRecommendedStories($limit = 10)
    {
        return $this->getSmartRecommendations($limit);
    }

    /**
     * Lấy truyện theo tác giả
     */
    public function getByAuthor($authorId, $limit = 12, $offset = 0, $sort = null, $status = null)
    {
        $builder = $this->where('author_id', $authorId)
                        ->where('status', 'published');

        if ($status) {
            if ($status == 'completed') {
                $builder->where('is_completed', true);
            } elseif ($status == 'ongoing') {
                $builder->where('is_completed', false);
            }
        }

        if ($sort) {
            switch ($sort) {
                case 'oldest':
                    $builder->orderBy('created_at', 'ASC');
                    break;
                case 'name_asc':
                    $builder->orderBy('title', 'ASC');
                    break;
                case 'name_desc':
                    $builder->orderBy('title', 'DESC');
                    break;
                case 'view':
                    $builder->orderBy('views', 'DESC');
                    break;
                case 'rating':
                    $builder->orderBy('rating', 'DESC');
                    break;
                default:
                    $builder->orderBy('created_at', 'DESC');
                    break;
            }
        } else {
            $builder->orderBy('created_at', 'DESC');
        }

        return $builder->limit($limit, $offset)
                      ->find();
    }

    /**
     * Đếm truyện theo tác giả
     */
    public function getByAuthorCount($authorId, $status = null)
    {
        $builder = $this->where('author_id', $authorId)
                        ->where('status', 'published');

        if ($status) {
            if ($status == 'completed') {
                $builder->where('is_completed', true);
            } elseif ($status == 'ongoing') {
                $builder->where('is_completed', false);
            }
        }

        return $builder->countAllResults();
    }

    /**
     * Lấy truyện theo tên tác giả
     */
    public function getByAuthorName($authorName, $limit = 12, $offset = 0, $sort = null, $status = null)
    {
        // Giải mã URL để tìm kiếm tên tác giả chính xác
        $decodedAuthorName = urldecode($authorName);

        // Sử dụng builder() và joins với users
        $builder = $this->db->table('stories s');
        $builder->select('s.*')
                ->join('users u', 'u.id = s.publisher_id')
                ->where('u.username', $decodedAuthorName)
                ->where('s.status', 'published');

        if ($status) {
            if ($status == 'completed') {
                $builder->where('s.is_completed', true);
            } elseif ($status == 'ongoing') {
                $builder->where('s.is_completed', false);
            }
        }

        if ($sort) {
            switch ($sort) {
                case 'oldest':
                    $builder->orderBy('s.created_at', 'ASC');
                    break;
                case 'name_asc':
                    $builder->orderBy('s.title', 'ASC');
                    break;
                case 'name_desc':
                    $builder->orderBy('s.title', 'DESC');
                    break;
                case 'view':
                    $builder->orderBy('s.views', 'DESC');
                    break;
                case 'rating':
                    $builder->orderBy('s.rating', 'DESC');
                    break;
                default:
                    $builder->orderBy('s.created_at', 'DESC');
            }
        } else {
            $builder->orderBy('s.created_at', 'DESC');
        }

        return $builder->limit($limit, $offset)->get()->getResultArray();
    }

    /**
     * Đếm số lượng truyện theo tên tác giả
     */
    public function countByAuthorName($authorName, $status = null)
    {
        // Giải mã URL để tìm kiếm tên tác giả chính xác
        $decodedAuthorName = urldecode($authorName);

        // Sử dụng builder() và joins với users
        $builder = $this->db->table('stories s');
        $builder->select('s.id')
                ->join('users u', 'u.id = s.publisher_id')
                ->where('u.username', $decodedAuthorName)
                ->where('s.status', 'published');

        if ($status) {
            if ($status == 'completed') {
                $builder->where('s.is_completed', true);
            } elseif ($status == 'ongoing') {
                $builder->where('s.is_completed', false);
            }
        }

        return $builder->countAllResults();
    }

    /**
     * Tìm kiếm truyện
     */
    public function search($keyword, $limit = 12, $offset = 0)
    {
        return $this->like('title', $keyword)
                    ->orLike('description', $keyword)
                    ->where('status', 'published')
                    ->orderBy('title', 'ASC')
                    ->limit($limit, $offset)
                    ->find();
    }

    /**
     * Tăng lượt xem
     */
    public function incrementViews($id)
    {
        $this->where('id', $id)
             ->set('views', 'views + 1', false)
             ->set('views_day', 'views_day + 1', false)
             ->set('views_week', 'views_week + 1', false)
             ->set('views_month', 'views_month + 1', false)
             ->update();
    }

    /**
     * Reset lượt xem theo ngày
     */
    public function resetDailyViews()
    {
        $statsModel = new StoryStatsModel();
        $logModel = new LogModel();

        try {
            // Lưu thống kê cho ngày hiện tại trước khi reset
            $statsModel->saveStatsForDate();

            // Kiểm tra thời gian reset cuối cùng
            $lastReset = $statsModel->getLastResetDate('daily');
            $today = date('Y-m-d');

            // Chỉ reset nếu đã qua ngày hoặc chưa có thông tin reset trước đó
            if ($lastReset === null || $lastReset < $today) {
                // Thực hiện reset
                $result = $this->set('views_day', 0)->update();

                // Lưu thời gian reset
                $statsModel->updateLastResetDate('daily');

                // Ghi log
                $logModel->info('Reset lượt xem theo ngày', [
                    'previous_reset' => $lastReset,
                    'current_reset' => $today
                ]);

                return $result;
            } else {
                // Đã reset trong ngày, không cần reset lại
                $logModel->info('Đã reset lượt xem theo ngày hôm nay', [
                    'last_reset' => $lastReset
                ]);

                return true;
            }
        } catch (\Exception $e) {
            // Ghi log lỗi
            $logModel->error('Lỗi khi reset lượt xem theo ngày', [
                'error' => $e->getMessage()
            ]);

            return false;
        }
    }

    /**
     * Reset lượt xem theo tuần
     */
    public function resetWeeklyViews()
    {
        $statsModel = new StoryStatsModel();
        $logModel = new LogModel();

        try {
            // Lưu thống kê cho ngày hiện tại trước khi reset
            $statsModel->saveStatsForDate();

            // Kiểm tra thời gian reset cuối cùng
            $lastReset = $statsModel->getLastResetDate('weekly');
            $today = date('Y-m-d');
            $dayOfWeek = date('N'); // 1 (Thứ 2) đến 7 (Chủ nhật)

            // Chỉ reset vào thứ 2 (N=1) hoặc nếu đã qua 7 ngày so với lần reset trước
            if (($dayOfWeek == 1 && ($lastReset === null || $lastReset < $today)) ||
                ($lastReset !== null && strtotime($today) - strtotime($lastReset) >= 7 * 24 * 60 * 60)) {

                // Thực hiện reset
                $result = $this->set('views_week', 0)->update();

                // Lưu thời gian reset
                $statsModel->updateLastResetDate('weekly');

                // Ghi log
                $logModel->info('Reset lượt xem theo tuần', [
                    'previous_reset' => $lastReset,
                    'current_reset' => $today
                ]);

                return $result;
            } else {
                // Chưa đến thời điểm reset
                $logModel->info('Chưa đến thời điểm reset lượt xem theo tuần', [
                    'last_reset' => $lastReset,
                    'day_of_week' => $dayOfWeek
                ]);

                return true;
            }
        } catch (\Exception $e) {
            // Ghi log lỗi
            $logModel->error('Lỗi khi reset lượt xem theo tuần', [
                'error' => $e->getMessage()
            ]);

            return false;
        }
    }

    /**
     * Reset lượt xem theo tháng
     */
    public function resetMonthlyViews()
    {
        $statsModel = new StoryStatsModel();
        $logModel = new LogModel();

        try {
            // Lưu thống kê cho ngày hiện tại trước khi reset
            $statsModel->saveStatsForDate();

            // Kiểm tra thời gian reset cuối cùng
            $lastReset = $statsModel->getLastResetDate('monthly');
            $today = date('Y-m-d');
            $dayOfMonth = date('j'); // 1-31

            // Chỉ reset vào ngày đầu tháng (j=1) hoặc nếu đã qua sang tháng mới so với lần reset trước
            if (($dayOfMonth == 1 && ($lastReset === null || $lastReset < $today)) ||
                ($lastReset !== null && date('Y-m', strtotime($today)) != date('Y-m', strtotime($lastReset)))) {

                // Thực hiện reset
                $result = $this->set('views_month', 0)->update();

                // Lưu thời gian reset
                $statsModel->updateLastResetDate('monthly');

                // Ghi log
                $logModel->info('Reset lượt xem theo tháng', [
                    'previous_reset' => $lastReset,
                    'current_reset' => $today
                ]);

                return $result;
            } else {
                // Chưa đến thời điểm reset
                $logModel->info('Chưa đến thời điểm reset lượt xem theo tháng', [
                    'last_reset' => $lastReset,
                    'day_of_month' => $dayOfMonth
                ]);

                return true;
            }
        } catch (\Exception $e) {
            // Ghi log lỗi
            $logModel->error('Lỗi khi reset lượt xem theo tháng', [
                'error' => $e->getMessage()
            ]);

            return false;
        }
    }

    /**
     * Lấy danh sách truyện
     */
    public function getStoryList($limit = 12, $offset = 0, $sort = null, $status = null)
    {
        $builder = $this->where('status', 'published');

        if ($status) {
            if ($status == 'completed') {
                $builder->where('is_completed', true);
            } elseif ($status == 'ongoing') {
                $builder->where('is_completed', false);
            }
        }

        if ($sort) {
            switch ($sort) {
                case 'oldest':
                    $builder->orderBy('created_at', 'ASC');
                    break;
                case 'name_asc':
                    $builder->orderBy('title', 'ASC');
                    break;
                case 'name_desc':
                    $builder->orderBy('title', 'DESC');
                    break;
                case 'view':
                    $builder->orderBy('views', 'DESC');
                    break;
                case 'rating':
                    $builder->orderBy('rating', 'DESC');
                    break;
                default:
                    $builder->orderBy('created_at', 'DESC');
                    break;
            }
        } else {
            $builder->orderBy('created_at', 'DESC');
        }

        return $builder->limit($limit, $offset)
                      ->find();
    }

    /**
     * Đếm tổng số truyện
     */
    public function getStoryListCount($status = null)
    {
        $builder = $this->where('status', 'published');

        if ($status) {
            if ($status == 'completed') {
                $builder->where('is_completed', true);
            } elseif ($status == 'ongoing') {
                $builder->where('is_completed', false);
            }
        }

        return $builder->countAllResults();
    }

    /**
     * Lấy truyện tương tự dựa trên các danh mục
     */
    public function getSimilarStories($storyId, $categories, $limit = 6)
    {
        return $this->getSmartSimilarStories($storyId, $categories, $limit);
    }

    /**
     * Kiểm tra xem truyện có được đánh dấu theo dõi bởi người dùng không
     * Đã được cập nhật để hỗ trợ localStorage thay vì database
     */
    public function isBookmarked($storyId, $userId = null)
    {
        // Không còn sử dụng database để lưu bookmark
        // Việc kiểm tra bookmark được thực hiện phía client bằng localStorage
        return false;
    }

    /**
     * Lấy tiến trình đọc cho một truyện
     * Đã được điều chỉnh để hoạt động với localStorage
     */
    public function getReadingProgress($storyId, $userId = null)
    {
        if ($userId) {
            // Nếu có user id (đăng nhập) thì lấy từ database
            $db = \Config\Database::connect();
            $builder = $db->table('reading_progress');

            $progress = $builder->select('chapter_id, chapter_number')
                            ->where('story_id', $storyId)
                            ->where('user_id', $userId)
                            ->get()
                            ->getRow();

            return $progress ?: null;
        }

        // Nếu không đăng nhập, trả về null và để client xử lý
        return null;
    }

    /**
     * Lấy đánh giá của người dùng cho một truyện
     */
    public function getUserRating($storyId, $userId = null)
    {
        if ($userId) {
            // Nếu có user id (đăng nhập) thì lấy từ database
            $db = \Config\Database::connect();
            $builder = $db->table('ratings');

            $rating = $builder->select('rating')
                             ->where('story_id', $storyId)
                             ->where('user_id', $userId)
                             ->get()
                             ->getRow();

            return $rating ? $rating->rating : 0;
        }

        // Nếu không đăng nhập, trả về 0 và để client xử lý
        return 0;
    }

    /**
     * Lấy số lượng đánh giá cho một truyện
     */
    public function getRatingsCount($storyId)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('ratings');

        return $builder->where('story_id', $storyId)
                      ->countAllResults();
    }

    /**
     * Đánh giá một truyện
     */
    public function rateStory($storyId, $userId, $rating)
    {
        // Cập nhật cách xử lý để hỗ trợ cả khi không đăng nhập (userId null)
        if ($userId) {
            // Đăng nhập: lưu vào database
            $db = \Config\Database::connect();
            $builder = $db->table('ratings');

            // Kiểm tra xem người dùng đã đánh giá truyện này chưa
            $exists = $builder->where('story_id', $storyId)
                             ->where('user_id', $userId)
                             ->countAllResults();

            if ($exists) {
                // Cập nhật đánh giá hiện có
                $result = $builder->where('story_id', $storyId)
                                 ->where('user_id', $userId)
                                 ->update(['rating' => $rating, 'updated_at' => date('Y-m-d H:i:s')]);
            } else {
                // Thêm đánh giá mới
                $result = $builder->insert([
                    'story_id' => $storyId,
                    'user_id' => $userId,
                    'rating' => $rating,
                    'created_at' => date('Y-m-d H:i:s')
                ]);
            }
        } else {
            // Không đăng nhập: chỉ cần đảm bảo đánh giá được lưu vào tổng đánh giá
            $result = true; // Giả định thành công vì sẽ lưu bên client
        }

        // Cập nhật đánh giá trung bình của truyện
        if ($result) {
            $this->updateRating($storyId);
        }

        return (bool)$result;
    }

    /**
     * Cập nhật đánh giá
     */
    public function updateRating($id)
    {
        $db = \Config\Database::connect();

        // Lấy đánh giá trung bình
        $query = $db->table('ratings')
                    ->selectAvg('rating')
                    ->where('story_id', $id)
                    ->get();

        $result = $query->getRow();
        $avgRating = round($result->rating, 2) ?? 0;

        // Cập nhật đánh giá truyện
        $this->where('id', $id)
             ->set('rating', $avgRating)
             ->update();
    }

    /**
     * Lấy top truyện theo lượt xem
     */
    public function getTopByViews($limit = 10)
    {
        return $this->where('status', 'published')
                    ->orderBy('views', 'DESC')
                    ->limit($limit)
                    ->find();
    }

    /**
     * Lấy top truyện theo lượt xem tuần này
     */
    public function getTopThisWeek($limit = 10)
    {
        return $this->where('status', 'published')
                    ->orderBy('views_week', 'DESC')
                    ->limit($limit)
                    ->find();
    }

    /**
     * Lấy top truyện theo lượt xem tháng này
     */
    public function getTopThisMonth($limit = 10)
    {
        return $this->where('status', 'published')
                    ->orderBy('views_month', 'DESC')
                    ->limit($limit)
                    ->find();
    }

    /**
     * Lấy top truyện theo đánh giá
     */
    public function getTopByRating($limit = 10)
    {
        return $this->where('status', 'published')
                    ->where('total_ratings >', 0)
                    ->orderBy('rating', 'DESC')
                    ->limit($limit)
                    ->find();
    }

    /**
     * Lấy top truyện theo lượt yêu thích
     */
    public function getTopByFavorites($limit = 10)
    {
        return $this->where('status', 'published')
                    ->orderBy('total_favorites', 'DESC')
                    ->limit($limit)
                    ->find();
    }

    /**
     * Lấy truyện được đề xuất thông minh dựa trên sở thích và hoạt động của người dùng
     * Sử dụng các truyện đã xem, đã đánh giá, và đánh dấu của người dùng để đề xuất
     */
    public function getSmartRecommendations($limit = 10)
    {
        // Lấy thông tin đánh giá từ localStorage (client-side)
        // Thay vì dựa vào user_id, chúng ta sẽ hiển thị những truyện hot với cùng thể loại

        // Lấy các truyện có lượt đánh giá cao
        $highlyRated = $this->where('status', 'published')
                          ->where('rating >=', 4)
                          ->orderBy('RAND()')
                          ->limit(ceil($limit/3))
                          ->find();

        // Lấy truyện được cập nhật gần đây
        $recentUpdates = $this->where('status', 'published')
                            ->where('is_completed', false)
                            ->orderBy('updated_at', 'DESC')
                            ->limit(ceil($limit/3))
                            ->find();

        // Lấy truyện hot trong tháng này
        $popularThisMonth = $this->where('status', 'published')
                               ->orderBy('views_month', 'DESC')
                               ->limit(ceil($limit/3))
                               ->find();

        // Kết hợp kết quả và đảm bảo không trùng lặp
        $recommendations = [];
        $seen = [];

        // Hàm helper để thêm truyện vào danh sách đề xuất nếu chưa có
        $addToRecommendations = function($story) use (&$recommendations, &$seen, $limit) {
            if (count($recommendations) >= $limit) {
                return false;
            }

            if (!isset($seen[$story['id']])) {
                $recommendations[] = $story;
                $seen[$story['id']] = true;
                return true;
            }

            return false;
        };

        // Xáo trộn các mảng để tăng tính ngẫu nhiên
        shuffle($highlyRated);
        shuffle($recentUpdates);
        shuffle($popularThisMonth);

        // Thêm vào danh sách đề xuất
        foreach ($highlyRated as $story) {
            $addToRecommendations($story);
        }

        foreach ($recentUpdates as $story) {
            $addToRecommendations($story);
        }

        foreach ($popularThisMonth as $story) {
            $addToRecommendations($story);
        }

        // Nếu chưa đủ, thêm truyện ngẫu nhiên
        if (count($recommendations) < $limit) {
            $randomStories = $this->where('status', 'published')
                                ->whereNotIn('id', array_column($recommendations, 'id'))
                                ->orderBy('RAND()')
                                ->limit($limit - count($recommendations))
                                ->find();

            foreach ($randomStories as $story) {
                $addToRecommendations($story);
            }
        }

        return $recommendations;
    }

    /**
     * Lấy truyện liên quan thông minh dựa trên thể loại và đặc điểm truyện
     */
    public function getSmartSimilarStories($storyId, $categories, $limit = 6)
    {
        // Lấy các ID danh mục
        $categoryIds = array_column($categories, 'id');

        if (empty($categoryIds)) {
            // Nếu không có danh mục, trả về truyện ngẫu nhiên
            return $this->where('id !=', $storyId)
                       ->where('status', 'published')
                       ->orderBy('RAND()')
                       ->limit($limit)
                       ->find();
        }

        // Lấy truyện gốc để so sánh
        $story = $this->find($storyId);

        if (!$story) {
            return [];
        }

        // Lấy truyện cùng thể loại
        $db = \Config\Database::connect();

        // Tạo subquery để đếm số danh mục trùng khớp
        $subquery = $db->table('story_categories sc')
                      ->select('sc.story_id, COUNT(*) as category_match_count')
                      ->whereIn('sc.category_id', $categoryIds)
                      ->groupBy('sc.story_id');

        // Query chính để lấy truyện tương tự
        $builder = $db->table('stories s')
                     ->select('s.*, matched.category_match_count')
                     ->join('(' . $subquery->getCompiledSelect() . ') as matched', 's.id = matched.story_id', 'inner')
                     ->where('s.id !=', $storyId)
                     ->where('s.status', 'published');

        // Thêm điều kiện trùng khớp với quốc gia hoặc tác giả
        if (!empty($story['country'])) {
            $builder->groupStart()
                   ->where('s.country', $story['country'])
                   ->orWhere('matched.category_match_count >', 1)
                   ->groupEnd();
        } else {
            $builder->where('matched.category_match_count >', 1);
        }

        // Sắp xếp theo độ trùng khớp và sau đó theo lượt xem
        $builder->orderBy('matched.category_match_count', 'DESC')
               ->orderBy('s.views', 'DESC')
               ->limit($limit);

        $results = $builder->get()->getResultArray();

        // Nếu chưa đủ kết quả, bổ sung thêm truyện phổ biến
        if (count($results) < $limit) {
            $existingIds = array_column($results, 'id');
            $existingIds[] = $storyId;

            $moreStories = $this->whereNotIn('id', $existingIds)
                              ->where('status', 'published')
                              ->orderBy('views', 'DESC')
                              ->limit($limit - count($results))
                              ->find();

            $results = array_merge($results, $moreStories);
        }

        return $results;
    }

    /**
     * Thuật toán cập nhật trường is_hot (HOT)
     * Tự động đánh dấu một truyện là "hot" dựa vào mức độ phổ biến, lượt xem và sự tăng trưởng đột biến
     *
     * @param int $minDailyViews Số lượt xem tối thiểu trong ngày để đánh dấu là hot (mặc định: 100)
     * @param float $growthRate Tỷ lệ tăng trưởng tối thiểu so với ngày trước (mặc định: 30%)
     * @param int $minNewRatings Số lượng đánh giá mới tối thiểu trong 24h (mặc định: 10)
     * @param int $cooldownDays Số ngày tự động loại bỏ trạng thái hot nếu không còn đáp ứng tiêu chí (mặc định: 3)
     * @return bool Trả về true nếu cập nhật thành công
     */
    public function updateHotStories($minDailyViews = 100, $growthRate = 30, $minNewRatings = 10, $cooldownDays = 3)
    {
        $db = \Config\Database::connect();
        $logModel = new LogModel();
        $updated = 0;
        $reverted = 0;

        try {
            // 1. Đánh dấu truyện là hot nếu có lượt xem/ngày cao
            $highDailyViewsQuery = $this->where('views_day >', $minDailyViews)
                                       ->where('status', 'published')
                                       ->where('is_hot', false)
                                       ->set('is_hot', true)
                                       ->set('hot_marked_at', date('Y-m-d H:i:s'))
                                       ->update();

            $updated += $this->db->affectedRows();

            // 2. Kiểm tra tỷ lệ tăng trưởng đột biến
            // Lấy dữ liệu lượt xem của các truyện từ hôm qua (lưu trong bảng story_stats)
            $statsTable = $db->table('story_stats');
            $yesterday = date('Y-m-d', strtotime('-1 day'));
            $storyStats = $statsTable->where('date', $yesterday)->get()->getResultArray();

            // Chuyển đổi thành mảng id => views để dễ truy xuất
            $yesterdayViews = [];
            foreach ($storyStats as $stat) {
                $yesterdayViews[$stat['story_id']] = $stat['views'];
            }

            // Kiểm tra từng truyện chưa được đánh dấu là hot
            $stories = $this->where('is_hot', false)
                          ->where('status', 'published')
                          ->find();

            foreach ($stories as $story) {
                // Nếu có dữ liệu lượt xem hôm qua
                if (isset($yesterdayViews[$story['id']])) {
                    $yesterdayView = $yesterdayViews[$story['id']];

                    // Nếu lượt xem hôm qua > 0 và có tỷ lệ tăng trưởng lớn
                    if ($yesterdayView > 0 && $story['views_day'] > 0) {
                        $growthPercentage = (($story['views_day'] - $yesterdayView) / $yesterdayView) * 100;

                        // Nếu tỷ lệ tăng trưởng vượt ngưỡng
                        if ($growthPercentage >= $growthRate) {
                            $this->update($story['id'], [
                                'is_hot' => true,
                                'hot_marked_at' => date('Y-m-d H:i:s')
                            ]);
                            $updated++;

                            // Ghi log
                            $logModel->info('Truyện được đánh dấu là hot do tăng trưởng đột biến', [
                                'story_id' => $story['id'],
                                'title' => $story['title'],
                                'growth_rate' => $growthPercentage,
                                'yesterday_views' => $yesterdayView,
                                'today_views' => $story['views_day']
                            ]);
                        }
                    }
                }
            }

            // 3. Kiểm tra số lượng đánh giá mới
            $ratingsTable = $db->table('ratings');
            $last24h = date('Y-m-d H:i:s', strtotime('-24 hours'));

            // Đếm số lượng đánh giá mới cho từng truyện trong 24h qua
            $newRatingsQuery = $ratingsTable->select('story_id, COUNT(*) as new_ratings')
                                          ->where('created_at >', $last24h)
                                          ->groupBy('story_id')
                                          ->having('new_ratings >=', $minNewRatings)
                                          ->get();

            $newRatings = $newRatingsQuery->getResultArray();

            // Đánh dấu hot cho các truyện có nhiều đánh giá mới
            foreach ($newRatings as $rating) {
                $story = $this->find($rating['story_id']);

                if ($story && $story['is_hot'] == false && $story['status'] == 'published') {
                    $this->update($rating['story_id'], [
                        'is_hot' => true,
                        'hot_marked_at' => date('Y-m-d H:i:s')
                    ]);
                    $updated++;

                    // Ghi log
                    $logModel->info('Truyện được đánh dấu là hot do có nhiều đánh giá mới', [
                        'story_id' => $rating['story_id'],
                        'title' => $story['title'],
                        'new_ratings' => $rating['new_ratings']
                    ]);
                }
            }

            // 4. Tự động loại bỏ trạng thái hot sau một thời gian nếu không còn đáp ứng tiêu chí
            $cooldownDate = date('Y-m-d H:i:s', strtotime("-$cooldownDays days"));

            $notHotAnymore = $this->where('is_hot', true)
                                ->where('hot_marked_at <', $cooldownDate)
                                ->where('views_day <', $minDailyViews)
                                ->find();

            foreach ($notHotAnymore as $story) {
                $this->update($story['id'], [
                    'is_hot' => false
                ]);
                $reverted++;

                // Ghi log
                $logModel->info('Truyện không còn được đánh dấu là hot', [
                    'story_id' => $story['id'],
                    'title' => $story['title'],
                    'marked_at' => $story['hot_marked_at'],
                    'current_daily_views' => $story['views_day']
                ]);
            }

            // Ghi log tổng kết
            $logModel->info('Đã cập nhật trạng thái hot cho truyện', [
                'updated' => $updated,
                'reverted' => $reverted,
                'min_daily_views' => $minDailyViews,
                'growth_rate' => $growthRate,
                'min_new_ratings' => $minNewRatings
            ]);

            return true;
        } catch (\Exception $e) {
            // Ghi log lỗi
            $logModel->error('Lỗi khi cập nhật trạng thái hot cho truyện', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);

            return false;
        }
    }

    /**
     * Thuật toán đề xuất các truyện nên được nổi bật (featured)
     * Tính điểm dựa trên lượt xem, đánh giá, số lượng bình luận, độ mới và đa dạng thể loại
     *
     * @param int $limit Số lượng truyện đề xuất tối đa
     * @param array $options Các tùy chọn khác cho thuật toán
     * @return array Danh sách các truyện được đề xuất kèm theo điểm số và lý do
     */
    public function suggestFeaturedStories($limit = 10, $options = [])
    {
        $db = \Config\Database::connect();
        $logModel = new LogModel();

        // Tùy chọn mặc định
        $defaultOptions = [
            'min_rating' => 4.0,                // Đánh giá tối thiểu
            'min_views' => 500,                 // Lượt xem tối thiểu
            'new_story_days' => 30,             // Số ngày để coi là truyện mới
            'view_weight' => 0.3,               // Trọng số cho lượt xem
            'rating_weight' => 0.4,             // Trọng số cho đánh giá
            'comment_weight' => 0.2,            // Trọng số cho bình luận
            'recency_weight' => 0.1,            // Trọng số cho độ mới
            'min_categories_diversity' => 5,    // Số lượng thể loại tối thiểu cần đảm bảo có truyện featured
            'exclude_current_featured' => true, // Loại trừ truyện đã featured
        ];

        // Gộp các tùy chọn
        $options = array_merge($defaultOptions, $options);

        try {
            // Danh sách truyện sẽ được đề xuất
            $suggestedStories = [];

            // 1. Loại trừ các truyện đã được đánh dấu là featured (nếu có yêu cầu)
            $excludedIds = [];
            if ($options['exclude_current_featured']) {
                $currentFeatured = $this->where('is_featured', true)->find();
                $excludedIds = array_column($currentFeatured, 'id');
            }

            // 2. Lấy danh sách truyện tiềm năng dựa trên lượt xem và đánh giá
            $potentialStories = $this->where('status', 'published')
                                    ->where('views >=', $options['min_views'])
                                    ->where('rating >=', $options['min_rating']);

            if (!empty($excludedIds)) {
                $potentialStories->whereNotIn('id', $excludedIds);
            }

            $potentialStories = $potentialStories->find();

            // 3. Tính điểm cho từng truyện
            $storyScores = [];
            $commentCounts = [];
            $categoryUsage = [];

            // Lấy số lượng bình luận cho mỗi truyện
            $commentCountsQuery = $db->table('comments')
                                    ->select('story_id, COUNT(*) as comment_count')
                                    ->groupBy('story_id')
                                    ->get();
            $commentCountsResult = $commentCountsQuery->getResultArray();

            foreach ($commentCountsResult as $count) {
                $commentCounts[$count['story_id']] = $count['comment_count'];
            }

            // Tìm max values để chuẩn hóa
            $maxViews = max(array_column($potentialStories, 'views'));
            $maxComments = !empty($commentCounts) ? max($commentCounts) : 1;
            $newStoryDate = date('Y-m-d H:i:s', strtotime('-' . $options['new_story_days'] . ' days'));

            // Tính điểm cho từng truyện
            foreach ($potentialStories as $story) {
                // Chuẩn hóa các thông số (0-1)
                $viewScore = $maxViews > 0 ? $story['views'] / $maxViews : 0;
                $ratingScore = ($story['rating'] - $options['min_rating']) / (5 - $options['min_rating']);
                $commentScore = isset($commentCounts[$story['id']]) && $maxComments > 0 ?
                                $commentCounts[$story['id']] / $maxComments : 0;

                // Tính điểm độ mới (1 = mới nhất, 0 = cũ nhất)
                $recencyScore = 0;
                if ($story['created_at'] >= $newStoryDate) {
                    $daysSinceCreation = (time() - strtotime($story['created_at'])) / (60 * 60 * 24);
                    $recencyScore = 1 - ($daysSinceCreation / $options['new_story_days']);
                }

                // Tính tổng điểm dựa trên trọng số
                $totalScore = ($viewScore * $options['view_weight']) +
                             ($ratingScore * $options['rating_weight']) +
                             ($commentScore * $options['comment_weight']) +
                             ($recencyScore * $options['recency_weight']);

                // Lấy danh mục của truyện
                $categories = $this->getStoryCategories($story['id']);
                $categoryIds = array_column($categories, 'id');

                // Cập nhật thống kê sử dụng danh mục
                foreach ($categoryIds as $catId) {
                    if (!isset($categoryUsage[$catId])) {
                        $categoryUsage[$catId] = [
                            'count' => 0,
                            'stories' => []
                        };
                    }
                    $categoryUsage[$catId]['count']++;
                    $categoryUsage[$catId]['stories'][] = [
                        'id' => $story['id'],
                        'score' => $totalScore
                    ];
                }

                // Lưu kết quả cùng với thông tin chi tiết để giải thích sau này
                $storyScores[$story['id']] = [
                    'story' => $story,
                    'total_score' => $totalScore,
                    'details' => [
                        'view_score' => $viewScore * $options['view_weight'],
                        'rating_score' => $ratingScore * $options['rating_weight'],
                        'comment_score' => $commentScore * $options['comment_weight'],
                        'recency_score' => $recencyScore * $options['recency_weight'],
                    ],
                    'categories' => $categories,
                    'comment_count' => $commentCounts[$story['id']] ?? 0
                ];
            }

            // Sắp xếp theo điểm giảm dần
            uasort($storyScores, function($a, $b) {
                return $b['total_score'] <=> $a['total_score'];
            });

            // 4. Chọn truyện với điểm cao nhất
            $selectedStories = array_slice($storyScores, 0, $limit);

            // 5. Đảm bảo đa dạng thể loại
            $selectedCategories = [];
            foreach ($selectedStories as $id => $data) {
                foreach ($data['categories'] as $category) {
                    $selectedCategories[$category['id']] = true;
                }
            }

            // Nếu số lượng thể loại chưa đủ đa dạng
            $diversityNeeded = $options['min_categories_diversity'] - count($selectedCategories);

            if ($diversityNeeded > 0) {
                // Sắp xếp danh mục còn thiếu theo thứ tự ưu tiên (nhiều truyện nhất)
                $missingCategories = array_filter($categoryUsage, function($cat, $catId) use ($selectedCategories) {
                    return !isset($selectedCategories[$catId]);
                }, ARRAY_FILTER_USE_BOTH);

                uasort($missingCategories, function($a, $b) {
                    return $b['count'] <=> $a['count'];
                });

                // Thêm truyện từ các danh mục còn thiếu
                foreach ($missingCategories as $catId => $catData) {
                    if ($diversityNeeded <= 0) break;

                    // Sắp xếp truyện trong danh mục này theo điểm
                    usort($catData['stories'], function($a, $b) {
                        return $b['score'] <=> $a['score'];
                    });

                    // Thêm truyện có điểm cao nhất từ danh mục này
                    if (!empty($catData['stories'])) {
                        $bestStoryId = $catData['stories'][0]['id'];

                        // Nếu truyện này chưa được chọn
                        if (!isset($selectedStories[$bestStoryId]) && isset($storyScores[$bestStoryId])) {
                            $selectedStories[$bestStoryId] = $storyScores[$bestStoryId];
                            $diversityNeeded--;
                            $selectedCategories[$catId] = true;
                        }
                    }
                }
            }

            // 6. Format kết quả cuối cùng
            $result = [];
            foreach ($selectedStories as $id => $data) {
                $reasons = [];

                // Chuẩn bị các lý do đề xuất
                if ($data['details']['view_score'] > 0.15) {
                    $reasons[] = 'Lượt xem cao (' . number_format($data['story']['views']) . ' lượt)';
                }

                if ($data['details']['rating_score'] > 0.2) {
                    $reasons[] = 'Đánh giá tốt (' . number_format($data['story']['rating'], 1) . '/5)';
                }

                if ($data['details']['comment_score'] > 0.1) {
                    $reasons[] = 'Nhiều bình luận (' . $data['comment_count'] . ' bình luận)';
                }

                if ($data['details']['recency_score'] > 0.05) {
                    $reasons[] = 'Truyện mới (' . date('d/m/Y', strtotime($data['story']['created_at'])) . ')';
                }

                if (count($data['categories']) > 0) {
                    $categoryNames = array_column($data['categories'], 'name');
                    $reasons[] = 'Thuộc thể loại đa dạng (' . implode(', ', array_slice($categoryNames, 0, 3)) . ')';
                }

                $result[] = [
                    'id' => $data['story']['id'],
                    'title' => $data['story']['title'],
                    'score' => round($data['total_score'] * 100, 2),
                    'reasons' => $reasons,
                    'story' => $data['story'],
                    'details' => $data['details']
                ];
            }

            // 7. Ghi log
            $logModel->info('Đã đề xuất truyện nổi bật', [
                'count' => count($result),
                'top_suggestion' => !empty($result) ? $result[0]['title'] : null,
                'diversity' => count($selectedCategories)
            ]);

            return $result;
        } catch (\Exception $e) {
            // Ghi log lỗi
            $logModel->error('Lỗi khi đề xuất truyện nổi bật', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);

            return [];
        }
    }

    /**
     * Thuật toán cập nhật trường is_recommended (ĐỀ XUẤT)
     * Sử dụng thuật toán đề xuất dựa trên hành vi đọc và đánh giá của người đọc
     *
     * @param int $limit Số lượng truyện đề xuất tối đa
     * @param array $options Các tùy chọn khác cho thuật toán
     * @return bool Trả về true nếu cập nhật thành công
     */
    public function updateRecommendedStories($limit = 20, $options = [])
    {
        $db = \Config\Database::connect();
        $logModel = new LogModel();

        // Tùy chọn mặc định
        $defaultOptions = [
            'min_rating' => 3.5,           // Đánh giá tối thiểu
            'min_rating_count' => 5,       // Số lượng đánh giá tối thiểu
            'recent_days' => 30,           // Số ngày gần đây để ưu tiên
            'max_per_category' => 3,       // Số lượng tối đa mỗi thể loại
            'refresh_rate' => 50,          // Tỷ lệ % cập nhật (50% = đổi 50% danh sách mỗi lần chạy)
        ];

        // Gộp các tùy chọn
        $options = array_merge($defaultOptions, $options);

        try {
            // 1. Lấy danh sách truyện được đánh giá tốt
            $highlyRatedStories = $this->where('status', 'published')
                                     ->where('rating >=', $options['min_rating'])
                                     ->where('total_ratings >=', $options['min_rating_count'])
                                     ->orderBy('rating', 'DESC')
                                     ->find();

            // 2. Lấy danh sách truyện đã được đọc nhiều gần đây
            $recentDate = date('Y-m-d H:i:s', strtotime('-' . $options['recent_days'] . ' days'));
            $recentlyViewedStories = $this->where('status', 'published')
                                        ->where('updated_at >=', $recentDate)
                                        ->orderBy('views_month', 'DESC')
                                        ->find();

            // 3. Phân tích dữ liệu đọc và đánh giá để tìm xu hướng

            // 3.1 Lấy top thể loại có nhiều lượt xem
            $topCategoryQuery = $db->table('story_categories sc')
                                  ->select('c.id, c.name, COUNT(*) as view_count')
                                  ->join('stories s', 's.id = sc.story_id')
                                  ->join('categories c', 'c.id = sc.category_id')
                                  ->where('s.views_month >', 0)
                                  ->groupBy('c.id')
                                  ->orderBy('view_count', 'DESC')
                                  ->limit(10);

            $topCategories = $topCategoryQuery->get()->getResultArray();
            $categoryIds = array_column($topCategories, 'id');

            // 3.2 Lấy top truyện trong các thể loại phổ biến
            $storiesByCategory = [];
            $allRecommendedStories = [];

            foreach ($categoryIds as $categoryId) {
                $storiesInCategory = $db->table('stories s')
                                      ->select('s.*')
                                      ->join('story_categories sc', 's.id = sc.story_id')
                                      ->where('sc.category_id', $categoryId)
                                      ->where('s.status', 'published')
                                      ->where('s.rating >=', $options['min_rating'])
                                      ->orderBy('s.views_month', 'DESC')
                                      ->limit($options['max_per_category'])
                                      ->get()
                                      ->getResultArray();

                $storiesByCategory[$categoryId] = $storiesInCategory;

                // Thêm vào danh sách đề xuất, tránh trùng lặp
                foreach ($storiesInCategory as $story) {
                    if (!isset($allRecommendedStories[$story['id']])) {
                        $allRecommendedStories[$story['id']] = $story;
                    }
                }
            }

            // 3.3 Thêm truyện được đánh giá cao nhưng không thuộc thể loại phổ biến
            foreach ($highlyRatedStories as $story) {
                if (!isset($allRecommendedStories[$story['id']])) {
                    $allRecommendedStories[$story['id']] = $story;

                    // Nếu đã đủ số lượng cần thiết, dừng lại
                    if (count($allRecommendedStories) >= $limit * 1.5) {
                        break;
                    }
                }
            }

            // 3.4 Thêm truyện được xem nhiều gần đây
            foreach ($recentlyViewedStories as $story) {
                if (!isset($allRecommendedStories[$story['id']])) {
                    $allRecommendedStories[$story['id']] = $story;

                    // Nếu đã đủ số lượng cần thiết, dừng lại
                    if (count($allRecommendedStories) >= $limit * 2) {
                        break;
                    }
                }
            }

            // 4. Sắp xếp và đánh giá để chọn truyện tốt nhất
            $scoredStories = [];

            foreach ($allRecommendedStories as $story) {
                // Tính điểm dựa trên nhiều yếu tố
                $viewScore = $story['views_month'] / max(array_column($allRecommendedStories, 'views_month'));
                $ratingScore = $story['rating'] / 5;
                $recencyScore = 0;

                if (strtotime($story['d_at']) >= strtotime($recentDate)) {
                    $daysSinceUpdate = (time() - strtotime($story['updated_at'])) / (60 * 60 * 24);
                    $recencyScore = 1 - ($daysSinceUpdate / $options['recent_days']);
                }

                // Trọng số cho từng yếu tố
                $totalScore = ($viewScore * 0.4) + ($ratingScore * 0.3) + ($recencyScore * 0.3);

                $scoredStories[$story['id']] = [
                    'story' => $story,
                    'score' => $totalScore
                ];
            }

            // Sắp xếp theo điểm giảm dần
            uasort($scoredStories, function($a, $b) {
                return $b['score'] <=> $a['score'];
            });

            // 5. Kết hợp với danh sách đã có để đảm bảo tỷ lệ cập nhật phù hợp

            // Lấy danh sách truyện hiện đang được đề xuất
            $currentRecommended = $this->where('is_recommended', true)->find();
            $currentRecommendedIds = array_column($currentRecommended, 'id');

            // Xác định số lượng cần giữ lại và số lượng cần thay thế
            $keepCount = round(count($currentRecommendedIds) * (1 - $options['refresh_rate'] / 100));
            $replaceCount = $limit - $keepCount;

            // Chọn ngẫu nhiên các truyện để giữ lại
            shuffle($currentRecommendedIds);
            $keepIds = array_slice($currentRecommendedIds, 0, $keepCount);

            // Chọn truyện mới để thêm vào
            $newRecommendedIds = [];

            foreach ($scoredStories as $id => $data) {
                if (!in_array($id, $keepIds) && count($newRecommendedIds) < $replaceCount) {
                    $newRecommendedIds[] = $id;
                }
            }

            // Kết hợp danh sách cuối cùng
            $finalRecommendedIds = array_merge($keepIds, $newRecommendedIds);

            // 6. Cập nhật cơ sở dữ liệu

            // Reset tất cả về false trước
            $this->set('is_recommended', false)->update();

            // Cập nhật các truyện được chọn thành true
            if (!empty($finalRecommendedIds)) {
                $this->whereIn('id', $finalRecommendedIds)
                     ->set('is_recommended', true)
                     ->update();
            }

            // Ghi log
            $logModel->info('Đã cập nhật truyện đề xuất', [
                'kept' => $keepCount,
                'replaced' => count($newRecommendedIds),
                'total' => count($finalRecommendedIds)
            ]);

            return true;
        } catch (\Exception $e) {
            // Ghi log lỗi
            $logModel->error('Lỗi khi cập nhật truyện đề xuất', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);

            return false;
        }
    }

    /**
     * Thuật toán cập nhật trường status (TRẠNG THÁI)
     * Tự động cập nhật trạng thái truyện (draft, published, completed) dựa trên tình trạng và hoạt động của truyện
     *
     * @param array $options Các tùy chọn cho thuật toán
     * @return array Thống kê kết quả cập nhật
     */
    public function updateStoryStatus($options = [])
    {
        $db = \Config\Database::connect();
        $logModel = new LogModel();
        $chapterModel = new \App\Models\ChapterModel();

        // Kết quả thống kê
        $stats = [
            'draft_to_published' => 0,
            'marked_completed' => 0,
            'total_updated' => 0,
            'pending_admin_review' => []
        ];

        // Tùy chọn mặc định
        $defaultOptions = [
            'min_chapters_for_publish' => 3,    // Số lượng chương tối thiểu để được publish
            'inactive_days_for_complete' => 90, // Số ngày không hoạt động để đánh dấu là completed
            'require_admin_approval' => true,   // Yêu cầu admin phê duyệt trước khi thay đổi trạng thái
        ];

        // Gộp các tùy chọn
        $options = array_merge($defaultOptions, $options);

        try {
            // 1. Xử lý truyện nháp (draft) có thể chuyển sang đã xuất bản (published)
            $draftStories = $this->where('status', 'draft')->find();

            foreach ($draftStories as $story) {
                // Đếm số lượng chương của truyện
                $chapterCount = $chapterModel->where('story_id', $story['id'])->countAllResults();

                // Nếu đủ số lượng chương tối thiểu
                if ($chapterCount >= $options['min_chapters_for_publish']) {
                    if ($options['require_admin_approval']) {
                        // Thêm vào danh sách cần phê duyệt
                        $stats['pending_admin_review'][] = [
                            'id' => $story['id'],
                            'title' => $story['title'],
                            'chapter_count' => $chapterCount,
                            'current_status' => 'draft',
                            'suggested_status' => 'published',
                            'reason' => "Truyện có $chapterCount chương, đủ điều kiện để xuất bản"
                        ];

                        // Ghi log
                        $logModel->info('Đề xuất chuyển trạng thái truyện từ draft sang published', [
                            'story_id' => $story['id'],
                            'title' => $story['title'],
                            'chapter_count' => $chapterCount
                        ]);
                    } else {
                        // Tự động cập nhật trạng thái
                        $this->update($story['id'], [
                            'status' => 'published',
                            'updated_at' => date('Y-m-d H:i:s')
                        ]);

                        $stats['draft_to_published']++;
                        $stats['total_updated']++;

                        // Ghi log
                        $logModel->info('Đã chuyển trạng thái truyện từ draft sang published', [
                            'story_id' => $story['id'],
                            'title' => $story['title'],
                            'chapter_count' => $chapterCount
                        ]);
                    }
                }
            }

            // 2. Xử lý truyện đã xuất bản (published) có thể đánh dấu là đã hoàn thành (completed)
            // 2.1 Kiểm tra truyện không cập nhật trong thời gian dài
            $inactiveCutoff = date('Y-m-d H:i:s', strtotime('-' . $options['inactive_days_for_complete'] . ' days'));

            $inactiveStories = $this->where('status', 'published')
                                   ->where('is_completed', false)
                                   ->where('updated_at <', $inactiveCutoff)
                                   ->find();

            foreach ($inactiveStories as $story) {
                // Kiểm tra xem có chương mới không
                $latestChapter = $chapterModel->where('story_id', $story['id'])
                                             ->orderBy('created_at', 'DESC')
                                             ->first();

                // Nếu chương mới nhất cũng cũ (hoặc không có chương)
                if (!$latestChapter || strtotime($latestChapter['created_at']) < strtotime($inactiveCutoff)) {
                    if ($options['require_admin_approval']) {
                        // Thêm vào danh sách cần phê duyệt
                        $stats['pending_admin_review'][] = [
                            'id' => $story['id'],
                            'title' => $story['title'],
                            'last_updated' => $story['updated_at'],
                            'current_status' => 'published (not completed)',
                            'suggested_status' => 'published (completed)',
                            'reason' => "Truyện không cập nhật trong " . $options['inactive_days_for_complete'] . " ngày"
                        ];

                        // Ghi log
                        $logModel->info('Đề xuất đánh dấu truyện là đã hoàn thành do không hoạt động', [
                            'story_id' => $story['id'],
                            'title' => $story['title'],
                            'last_updated' => $story['updated_at']
                        ]);
                    } else {
                        // Tự động cập nhật trạng thái
                        $this->update($story['id'], [
                            'is_completed' => true,
                            'updated_at' => date('Y-m-d H:i:s')
                        ]);

                        $stats['marked_completed']++;
                        $stats['total_updated']++;

                        // Ghi log
                        $logModel->info('Đã đánh dấu truyện là đã hoàn thành do không hoạt động', [
                            'story_id' => $story['id'],
                            'title' => $story['title'],
                            'last_updated' => $story['updated_at']
                        ]);
                    }
                }
            }

            // 3. Ghi log tổng kết
            $logModel->info('Đã cập nhật trạng thái truyện', [
                'draft_to_published' => $stats['draft_to_published'],
                'marked_completed' => $stats['marked_completed'],
                'total_updated' => $stats['total_updated'],
                'pending_admin_review' => count($stats['pending_admin_review'])
            ]);

            return $stats;
        } catch (\Exception $e) {
            // Ghi log lỗi
            $logModel->error('Lỗi khi cập nhật trạng thái truyện', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);

            return [
                'error' => $e->getMessage(),
                'draft_to_published' => 0,
                'marked_completed' => 0,
                'total_updated' => 0,
                'pending_admin_review' => []
            ];
        }
    }

    /**
     * Lấy thông tin nhiều truyện dựa trên danh sách ID
     * Hỗ trợ hệ thống bookmark lấy thông tin từ server
     *
     * @param array $ids Danh sách ID truyện cần lấy thông tin
     * @return array Mảng thông tin truyện
     */
    public function getStoriesByIds(array $ids)
    {
        if (empty($ids)) {
            return [];
        }

        return $this->whereIn('id', $ids)
                   ->where('status', 'published')
                   ->findAll();
    }

    /**
     * Lấy thông tin nhiều truyện dựa trên danh sách slug
     * Hỗ trợ hệ thống bookmark lấy thông tin từ server
     *
     * @param array $slugs Danh sách slug truyện cần lấy thông tin
     * @return array Mảng thông tin truyện
     */
    public function getStoriesBySlugs(array $slugs)
    {
        if (empty($slugs)) {
            return [];
        }

        return $this->whereIn('slug', $slugs)
                   ->where('status', 'published')
                   ->findAll();
    }

    /**
     * Lấy truyện theo tên tác giả thực của truyện (không phải người đăng)
     */
    public function getByRealAuthorName($authorName, $limit = 12, $offset = 0, $sort = null, $status = null)
    {
        // Giải mã URL để tìm kiếm tên tác giả chính xác
        $decodedAuthorName = urldecode($authorName);

        // Sử dụng builder() và tìm theo author_name
        $builder = $this->db->table('stories s');
        $builder->select('s.*')
                ->where('s.author_name', $decodedAuthorName)
                ->where('s.status', 'published');

        if ($status) {
            if ($status == 'completed') {
                $builder->where('s.is_completed', true);
            } elseif ($status == 'ongoing') {
                $builder->where('s.is_completed', false);
            }
        }

        if ($sort) {
            switch ($sort) {
                case 'oldest':
                    $builder->orderBy('s.created_at', 'ASC');
                    break;
                case 'name_asc':
                    $builder->orderBy('s.title', 'ASC');
                    break;
                case 'name_desc':
                    $builder->orderBy('s.title', 'DESC');
                    break;
                case 'view':
                    $builder->orderBy('s.views', 'DESC');
                    break;
                case 'rating':
                    $builder->orderBy('s.rating', 'DESC');
                    break;
                default:
                    $builder->orderBy('s.created_at', 'DESC');
            }
        } else {
            $builder->orderBy('s.created_at', 'DESC');
        }

        return $builder->limit($limit, $offset)->get()->getResultArray();
    }

    /**
     * Đếm số lượng truyện theo tên tác giả thực của truyện (không phải người đăng)
     */
    public function countByRealAuthorName($authorName, $status = null)
    {
        // Giải mã URL để tìm kiếm tên tác giả chính xác
        $decodedAuthorName = urldecode($authorName);

        // Sử dụng builder() và tìm theo author_name
        $builder = $this->db->table('stories s');
        $builder->select('s.id')
                ->where('s.author_name', $decodedAuthorName)
                ->where('s.status', 'published');

        if ($status) {
            if ($status == 'completed') {
                $builder->where('s.is_completed', true);
            } elseif ($status == 'ongoing') {
                $builder->where('s.is_completed', false);
            }
        }

        return $builder->countAllResults();
    }

    /**
     * Lấy danh sách tất cả các tác giả thực có trong hệ thống
     */
    public function getAllRealAuthors()
    {
        $builder = $this->db->table('stories')
                ->select('author_name, COUNT(*) as story_count')
                ->where('author_name IS NOT NULL')
                ->where('author_name !=', '')
                ->where('status', 'published')
                ->groupBy('author_name')
                ->orderBy('author_name', 'ASC');

        return $builder->get()->getResultArray();
    }
}
