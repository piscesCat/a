-- Cập nhật bảng stories nếu cột author_name chưa tồn tại
ALTER TABLE stories
ADD COLUMN IF NOT EXISTS author_name VARCHAR(100);

-- Cập nhật dữ liệu author_name từ username của publisher nếu author_name là NULL
UPDATE stories
SET author_name = (
    SELECT username
    FROM users
    WHERE id = stories.publisher_id
)
WHERE author_name IS NULL OR author_name = '';

-- Cập nhật các trường liên quan đến danh sách chương
-- Thêm trường chapter_count vào bảng stories nếu chưa có
ALTER TABLE stories
ADD COLUMN IF NOT EXISTS chapter_count INTEGER DEFAULT 0;

-- Cập nhật số lượng chương cho tất cả truyện
UPDATE stories s
SET chapter_count = (
    SELECT COUNT(*)
    FROM chapters c
    WHERE c.story_id = s.id
);

-- Cập nhật trigger để tự động cập nhật số lượng chương khi thêm/xóa chương
CREATE OR REPLACE FUNCTION update_story_chapter_count()
RETURNS TRIGGER AS $$
BEGIN
    -- Nếu thêm chương mới
    IF TG_OP = 'INSERT' THEN
        UPDATE stories
        SET chapter_count = chapter_count + 1
        WHERE id = NEW.story_id;

    -- Nếu xóa chương
    ELSIF TG_OP = 'DELETE' THEN
        UPDATE stories
        SET chapter_count = chapter_count - 1
        WHERE id = OLD.story_id;
    END IF;

    RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Xóa trigger cũ nếu đã tồn tại
DROP TRIGGER IF EXISTS update_chapter_count_insert ON chapters;
DROP TRIGGER IF EXISTS update_chapter_count_delete ON chapters;

-- Tạo trigger mới
CREATE TRIGGER update_chapter_count_insert
AFTER INSERT ON chapters
FOR EACH ROW
EXECUTE FUNCTION update_story_chapter_count();

CREATE TRIGGER update_chapter_count_delete
AFTER DELETE ON chapters
FOR EACH ROW
EXECUTE FUNCTION update_story_chapter_count();

-- Cập nhật vector tìm kiếm để bao gồm author_name
CREATE OR REPLACE FUNCTION stories_vector_update() RETURNS TRIGGER AS $$
BEGIN
    NEW.search_vector := to_tsvector('english',
        coalesce(NEW.title, '') || ' ' ||
        coalesce(NEW.description, '') || ' ' ||
        coalesce(NEW.author_name, '')
    );
    RETURN NEW;
END
$$ LANGUAGE plpgsql;
