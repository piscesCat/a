#!/bin/bash

# Script cài đặt cơ sở dữ liệu thống nhất và dọn dẹp dữ liệu không sử dụng
# Sử dụng:
# - ./install.sh [tên database] [tên người dùng] [mật khẩu]
# - ./install.sh --cleanup [tên database] [tên người dùng] [mật khẩu]

# Màu sắc để hiển thị
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Kiểm tra chế độ dọn dẹp
CLEANUP_MODE=0
if [[ "$1" == "--cleanup" ]]; then
    CLEANUP_MODE=1
    shift # Đưa các tham số tiếp theo lên
    echo -e "${BLUE}=== Chế độ dọn dẹp database ===${NC}"
else
    echo -e "${BLUE}=== Script cài đặt cơ sở dữ liệu thống nhất ===${NC}"
    echo -e "${YELLOW}Script này sẽ cài đặt cơ sở dữ liệu thống nhất từ file unified_schema.sql${NC}"
fi

# Kiểm tra PostgreSQL
if ! command -v psql &> /dev/null; then
    echo -e "${RED}Không tìm thấy PostgreSQL. Vui lòng cài đặt PostgreSQL trước khi tiếp tục.${NC}"
    exit 1
fi

# Lấy thông tin đầu vào
DB_NAME=${1:-"web_truyen"}
DB_USER=${2:-"postgres"}
DB_PASS=${3:-""}

# Hiển thị thông tin cài đặt
echo -e "${YELLOW}Thông tin cài đặt:${NC}"
echo -e "- Database: ${GREEN}$DB_NAME${NC}"
echo -e "- User: ${GREEN}$DB_USER${NC}"

# Xử lý dọn dẹp database nếu được yêu cầu
if [ $CLEANUP_MODE -eq 1 ]; then
    echo -e "${YELLOW}Bạn có muốn tiến hành dọn dẹp dữ liệu không sử dụng trong database? (y/n)${NC}"
    read -r confirm

    if [[ $confirm != "y" && $confirm != "Y" ]]; then
        echo -e "${RED}Đã hủy dọn dẹp database.${NC}"
        exit 0
    fi

    echo -e "${BLUE}Tiến hành dọn dẹp database...${NC}"
    if [ -z "$DB_PASS" ]; then
        PGPASSWORD="$DB_PASS" psql -U "$DB_USER" -d "$DB_NAME" -f cleanup.sql
    else
        psql -U "$DB_USER" -d "$DB_NAME" -f cleanup.sql
    fi

    if [ $? -ne 0 ]; then
        echo -e "${RED}Lỗi khi dọn dẹp database. Vui lòng kiểm tra file cleanup.sql.${NC}"
        exit 1
    fi

    echo -e "${GREEN}Đã dọn dẹp database thành công.${NC}"
    exit 0
fi

# Từ đây là phần cài đặt thông thường
# Hỏi xác nhận
echo -e "${YELLOW}Bạn có muốn tiếp tục cài đặt? (y/n)${NC}"
read -r confirm

if [[ $confirm != "y" && $confirm != "Y" ]]; then
    echo -e "${RED}Đã hủy cài đặt.${NC}"
    exit 0
fi

# Tạo backup trước khi thay đổi
echo -e "${BLUE}Tạo backup cho các file SQL gốc...${NC}"
mkdir -p backup
cp -f schema.sql backup/schema.sql.bak
cp -f update_stories_table.sql backup/update_stories_table.sql.bak
cp -f create_guest_bookmarks_table.sql backup/create_guest_bookmarks_table.sql.bak
echo -e "${GREEN}Đã tạo backup thành công.${NC}"

# Kiểm tra database đã tồn tại chưa
echo -e "${BLUE}Kiểm tra database...${NC}"
if [ -z "$DB_PASS" ]; then
    DB_EXISTS=$(PGPASSWORD="$DB_PASS" psql -U "$DB_USER" -lqt | cut -d \| -f 1 | grep -cw "$DB_NAME")
else
    DB_EXISTS=$(psql -U "$DB_USER" -lqt | cut -d \| -f 1 | grep -cw "$DB_NAME")
fi

# Tạo database nếu chưa tồn tại
if [ "$DB_EXISTS" -eq 0 ]; then
    echo -e "${YELLOW}Database $DB_NAME chưa tồn tại. Đang tạo mới...${NC}"
    if [ -z "$DB_PASS" ]; then
        PGPASSWORD="$DB_PASS" psql -U "$DB_USER" -c "CREATE DATABASE $DB_NAME;"
    else
        psql -U "$DB_USER" -c "CREATE DATABASE $DB_NAME;"
    fi

    if [ $? -ne 0 ]; then
        echo -e "${RED}Lỗi khi tạo database. Vui lòng kiểm tra lại thông tin đăng nhập.${NC}"
        exit 1
    fi
    echo -e "${GREEN}Đã tạo database $DB_NAME thành công.${NC}"
else
    echo -e "${YELLOW}Database $DB_NAME đã tồn tại.${NC}"
    echo -e "${YELLOW}Bạn có muốn xóa và tạo lại database? (y/n)${NC}"
    read -r recreate

    if [[ $recreate == "y" || $recreate == "Y" ]]; then
        echo -e "${BLUE}Đang xóa database cũ...${NC}"
        if [ -z "$DB_PASS" ]; then
            PGPASSWORD="$DB_PASS" psql -U "$DB_USER" -c "DROP DATABASE $DB_NAME;"
            PGPASSWORD="$DB_PASS" psql -U "$DB_USER" -c "CREATE DATABASE $DB_NAME;"
        else
            psql -U "$DB_USER" -c "DROP DATABASE $DB_NAME;"
            psql -U "$DB_USER" -c "CREATE DATABASE $DB_NAME;"
        fi

        if [ $? -ne 0 ]; then
            echo -e "${RED}Lỗi khi tạo lại database. Vui lòng kiểm tra lại thông tin đăng nhập.${NC}"
            exit 1
        fi
        echo -e "${GREEN}Đã tạo lại database $DB_NAME thành công.${NC}"
    else
        echo -e "${YELLOW}Sẽ giữ lại database hiện tại và cập nhật schema.${NC}"
    fi
fi

# Cài đặt schema
echo -e "${BLUE}Đang cài đặt schema...${NC}"
if [ -z "$DB_PASS" ]; then
    PGPASSWORD="$DB_PASS" psql -U "$DB_USER" -d "$DB_NAME" -f unified_schema.sql
else
    psql -U "$DB_USER" -d "$DB_NAME" -f unified_schema.sql
fi

if [ $? -ne 0 ]; then
    echo -e "${RED}Lỗi khi cài đặt schema. Vui lòng kiểm tra file unified_schema.sql.${NC}"
    exit 1
fi

echo -e "${GREEN}Đã cài đặt schema thành công.${NC}"
echo -e "${YELLOW}Bạn có muốn dọn dẹp dữ liệu không sử dụng trong database? (y/n)${NC}"
read -r cleanup_option

if [[ $cleanup_option == "y" || $cleanup_option == "Y" ]]; then
    echo -e "${BLUE}Tiến hành dọn dẹp database...${NC}"
    if [ -z "$DB_PASS" ]; then
        PGPASSWORD="$DB_PASS" psql -U "$DB_USER" -d "$DB_NAME" -f cleanup.sql
    else
        psql -U "$DB_USER" -d "$DB_NAME" -f cleanup.sql
    fi

    if [ $? -ne 0 ]; then
        echo -e "${RED}Lỗi khi dọn dẹp database. Vui lòng kiểm tra file cleanup.sql.${NC}"
    else
        echo -e "${GREEN}Đã dọn dẹp database thành công.${NC}"
    fi
fi

echo -e "${BLUE}Cài đặt hoàn tất!${NC}"
echo -e "${YELLOW}Lưu ý: Mật khẩu mặc định cho tài khoản admin là 'admin123'. Hãy thay đổi sau khi đăng nhập.${NC}"
echo -e "${YELLOW}Thông tin đăng nhập:${NC}"
echo -e "- Username: ${GREEN}admin${NC}"
echo -e "- Password: ${GREEN}admin123${NC}"
