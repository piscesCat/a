-- Add author_name field to stories table
ALTER TABLE stories ADD COLUMN IF NOT EXISTS author_name VARCHAR(100) AFTER author_id;

-- Add uploader_id field to stories table
ALTER TABLE stories ADD COLUMN IF NOT EXISTS uploader_id INTEGER REFERENCES users(id) AFTER author_name;

-- Update existing records to set uploader_id equal to author_id
UPDATE stories SET uploader_id = author_id WHERE uploader_id IS NULL;

-- Add index on uploader_id for better performance
CREATE INDEX IF NOT EXISTS stories_uploader_id_idx ON stories(uploader_id);

-- Log the change in the system_changes table if it exists
DO $$
BEGIN
  IF EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'system_changes') THEN
    INSERT INTO system_changes (change_type, description, sql_query, created_at)
    VALUES ('structure', 'Added author_name and uploader_id fields to stories table',
            'ALTER TABLE stories ADD COLUMN author_name VARCHAR(100), ADD COLUMN uploader_id INTEGER REFERENCES users(id);',
            NOW());
  END IF;
END $$;

-- Update the search_vector function to include author_name
CREATE OR REPLACE FUNCTION stories_vector_update() RETURNS TRIGGER AS $$
BEGIN
    NEW.search_vector := to_tsvector('english',
        coalesce(NEW.title, '') || ' ' ||
        coalesce(NEW.description, '') || ' ' ||
        coalesce(NEW.author_name, '')
    );
    RETURN NEW;
END
$$ LANGUAGE plpgsql;
