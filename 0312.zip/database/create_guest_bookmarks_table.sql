-- Create guest_bookmarks table if it doesn't exist
CREATE TABLE IF NOT EXISTS guest_bookmarks (
    id SERIAL PRIMARY KEY,
    guest_id VARCHAR(100) NOT NULL,
    story_id INTEGER NOT NULL REFERENCES stories(id) ON DELETE CASCADE,
    chapter_id INTEGER REFERENCES chapters(id) ON DELETE SET NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Add indexes for faster lookup
CREATE INDEX IF NOT EXISTS guest_bookmarks_guest_id_idx ON guest_bookmarks(guest_id);
CREATE INDEX IF NOT EXISTS guest_bookmarks_story_id_idx ON guest_bookmarks(story_id);
CREATE INDEX IF NOT EXISTS guest_bookmarks_chapter_id_idx ON guest_bookmarks(chapter_id);

-- Add composite unique constraint to prevent duplicates
ALTER TABLE guest_bookmarks DROP CONSTRAINT IF EXISTS guest_bookmarks_guest_story_unique;
ALTER TABLE guest_bookmarks ADD CONSTRAINT guest_bookmarks_guest_story_unique UNIQUE (guest_id, story_id);

-- Log the change in the system_changes table if it exists
DO $$
BEGIN
  IF EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'system_changes') THEN
    INSERT INTO system_changes (change_type, description, sql_query, created_at)
    VALUES ('structure', 'Created guest_bookmarks table',
            'CREATE TABLE guest_bookmarks...',
            NOW());
  END IF;
END $$;
