<?php
namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\ChapterModel;
use App\Models\StoryModel;

class ChapterManager extends BaseController
{
    protected $chapterModel;
    protected $storyModel;

    public function __construct()
    {
        $this->chapterModel = new ChapterModel();
        $this->storyModel = new StoryModel();
    }

    /**
     * Danh sách tất cả chương
     */
    public function index()
    {
        // Kiểm tra quyền admin
        $adminCheck = $this->requireAdmin();
        if ($adminCheck !== true) {
            return $adminCheck;
        }

        $page = $this->request->getGet('page') ?? 1;
        $limit = 20;
        $offset = ($page - 1) * $limit;

        // Các bộ lọc
        $filters = [
            'story_id' => $this->request->getGet('story_id'),
            'search' => $this->request->getGet('search')
        ];

        // Lấy danh sách chương với phân trang
        $chapters = $this->chapterModel->getAdminChaptersList($limit, $offset, $filters);
        $total = $this->chapterModel->getAdminChaptersCount($filters);

        // Lấy danh sách truyện cho dropdown lọc
        $stories = $this->storyModel->findAll();

        return view('admin/chapter/index.html', [
            'chapters' => $chapters,
            'stories' => $stories,
            'filters' => $filters,
            'pager' => [
                'current' => $page,
                'total' => ceil($total / $limit)
            ],
            'total' => $total
        ]);
    }

    /**
     * Tạo chương mới
     */
    public function create()
    {
        // Kiểm tra quyền admin
        $adminCheck = $this->requireAdmin();
        if ($adminCheck !== true) {
            return $adminCheck;
        }

        // Lấy danh sách truyện cho dropdown
        $stories = $this->storyModel->findAll();

        // Story ID từ query string (nếu đang thêm chương cho một truyện cụ thể)
        $storyId = $this->request->getGet('story_id');

        return view('admin/chapter/create.html', [
            'stories' => $stories,
            'selected_story_id' => $storyId
        ]);
    }

    /**
     * Lưu chương mới
     */
    public function save()
    {
        // Kiểm tra quyền admin
        $adminCheck = $this->requireAdmin();
        if ($adminCheck !== true) {
            return $adminCheck;
        }

        // Lấy dữ liệu từ form
        $data = [
            'story_id' => $this->request->getPost('story_id'),
            'chapter_number' => $this->request->getPost('chapter_number'),
            'title' => $this->request->getPost('title'),
            'content' => $this->request->getPost('content'),
            'status' => $this->request->getPost('status')
        ];

        // Validate dữ liệu
        if (empty($data['story_id']) || empty($data['chapter_number']) || empty($data['content'])) {
            $this->session->setFlashdata('error', 'Vui lòng điền đầy đủ thông tin bắt buộc');
            return redirect()->back()->withInput();
        }

        // Kiểm tra trùng số chương
        $existingChapter = $this->chapterModel->where('story_id', $data['story_id'])
            ->where('chapter_number', $data['chapter_number'])
            ->first();

        if ($existingChapter) {
            $this->session->setFlashdata('error', 'Số chương đã tồn tại cho truyện này');
            return redirect()->back()->withInput();
        }

        // Thêm dữ liệu thời gian
        $data['created_at'] = date('Y-m-d H:i:s');
        $data['updated_at'] = date('Y-m-d H:i:s');

        // Lưu vào database
        try {
            $this->chapterModel->insert($data);

            // Cập nhật số chương và thời gian cập nhật cho truyện
            $this->storyModel->updateChapterCount($data['story_id']);

            // Log hoạt động
            $this->logModel->info('Tạo chương mới', [
                'story_id' => $data['story_id'],
                'chapter_number' => $data['chapter_number'],
                'chapter_title' => $data['title'],
                'user_id' => $this->currentUser['id']
            ]);

            $this->session->setFlashdata('success', 'Đã thêm chương mới thành công');
            return redirect()->to(base_url('admin/chapters'));

        } catch (\Exception $e) {
            $this->session->setFlashdata('error', 'Lỗi: ' . $e->getMessage());
            return redirect()->back()->withInput();
        }
    }

    /**
     * Sửa chương
     */
    public function edit($id)
    {
        // Kiểm tra quyền admin
        $adminCheck = $this->requireAdmin();
        if ($adminCheck !== true) {
            return $adminCheck;
        }

        // Lấy thông tin chương
        $chapter = $this->chapterModel->find($id);
        if (!$chapter) {
            $this->session->setFlashdata('error', 'Không tìm thấy chương');
            return redirect()->to(base_url('admin/chapters'));
        }

        // Lấy danh sách truyện cho dropdown
        $stories = $this->storyModel->findAll();

        return view('admin/chapter/edit.html', [
            'chapter' => $chapter,
            'stories' => $stories
        ]);
    }

    /**
     * Cập nhật chương
     */
    public function update($id)
    {
        // Kiểm tra quyền admin
        $adminCheck = $this->requireAdmin();
        if ($adminCheck !== true) {
            return $adminCheck;
        }

        // Lấy thông tin chương hiện tại
        $chapter = $this->chapterModel->find($id);
        if (!$chapter) {
            $this->session->setFlashdata('error', 'Không tìm thấy chương');
            return redirect()->to(base_url('admin/chapters'));
        }

        // Lấy dữ liệu từ form
        $data = [
            'story_id' => $this->request->getPost('story_id'),
            'chapter_number' => $this->request->getPost('chapter_number'),
            'title' => $this->request->getPost('title'),
            'content' => $this->request->getPost('content'),
            'status' => $this->request->getPost('status'),
            'updated_at' => date('Y-m-d H:i:s')
        ];

        // Validate dữ liệu
        if (empty($data['story_id']) || empty($data['chapter_number']) || empty($data['content'])) {
            $this->session->setFlashdata('error', 'Vui lòng điền đầy đủ thông tin bắt buộc');
            return redirect()->back()->withInput();
        }

        // Kiểm tra trùng số chương (nếu thay đổi story_id hoặc chapter_number)
        if ($data['story_id'] != $chapter['story_id'] || $data['chapter_number'] != $chapter['chapter_number']) {
            $existingChapter = $this->chapterModel->where('story_id', $data['story_id'])
                ->where('chapter_number', $data['chapter_number'])
                ->where('id !=', $id)
                ->first();

            if ($existingChapter) {
                $this->session->setFlashdata('error', 'Số chương đã tồn tại cho truyện này');
                return redirect()->back()->withInput();
            }
        }

        // Lưu vào database
        try {
            $this->chapterModel->update($id, $data);

            // Nếu thay đổi story_id, cập nhật số chương cho cả truyện cũ và mới
            if ($data['story_id'] != $chapter['story_id']) {
                $this->storyModel->updateChapterCount($chapter['story_id']);
                $this->storyModel->updateChapterCount($data['story_id']);
            } else {
                // Cập nhật số chương và thời gian cập nhật cho truyện
                $this->storyModel->updateChapterCount($data['story_id']);
            }

            // Log hoạt động
            $this->logModel->info('Cập nhật chương', [
                'chapter_id' => $id,
                'story_id' => $data['story_id'],
                'chapter_number' => $data['chapter_number'],
                'chapter_title' => $data['title'],
                'user_id' => $this->currentUser['id']
            ]);

            $this->session->setFlashdata('success', 'Đã cập nhật chương thành công');
            return redirect()->to(base_url('admin/chapters'));

        } catch (\Exception $e) {
            $this->session->setFlashdata('error', 'Lỗi: ' . $e->getMessage());
            return redirect()->back()->withInput();
        }
    }

    /**
     * Xóa chương (AJAX)
     */
    public function delete()
    {
        // Kiểm tra quyền admin
        if (!$this->isAdmin()) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Không có quyền truy cập'
            ]);
        }

        $id = $this->request->getPost('id');
        if (!$id) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'ID không hợp lệ'
            ]);
        }

        // Lấy thông tin chương
        $chapter = $this->chapterModel->find($id);
        if (!$chapter) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Không tìm thấy chương'
            ]);
        }

        try {
            // Xóa chương
            $this->chapterModel->delete($id);

            // Cập nhật số chương cho truyện
            $this->storyModel->updateChapterCount($chapter['story_id']);

            // Log hoạt động
            $this->logModel->warning('Xóa chương', [
                'chapter_id' => $id,
                'story_id' => $chapter['story_id'],
                'chapter_number' => $chapter['chapter_number'],
                'chapter_title' => $chapter['title'],
                'user_id' => $this->currentUser['id']
            ]);

            return $this->response->setJSON([
                'success' => true,
                'message' => 'Đã xóa chương thành công'
            ]);

        } catch (\Exception $e) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Lỗi: ' . $e->getMessage()
            ]);
        }
    }
}
