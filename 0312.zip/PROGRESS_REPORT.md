# Báo cáo tiến độ dự án

## Tổng quan

Dự án này là một trang web quản lý truyện xây dựng trên framework CodeIgniter 4, sử dụng PostgreSQL làm CSDL và Twig làm template engine. Dự án đang trong quá trình cải tiến với các chức năng mới theo yêu cầu trong file `log.txt`.

## Các chức năng đã hoàn thành

### 1. Quản lý quốc gia
- ✅ Đã loại bỏ hoàn toàn chức năng thêm/sửa/xóa quốc gia trong admin panel
- ✅ Đã thay thế bằng hiển thị danh sách quốc gia bằng thư viện JavaScript
- ✅ Đã thêm chức năng lấy danh sách quốc gia từ truyện đã có trong hệ thống

### 2. Chức năng bookmark nâng cao
- ✅ Đã thêm chức năng bookmark ở cấp độ chương
- ✅ Đã thêm API endpoint để cập nhật và kiểm tra trạng thái bookmark cho cả truyện và chương
- ✅ Đã chuẩn bị cơ sở để bookmark cho người dùng không đăng nhập

### 3. Quản lý API token
- ✅ Đã thêm chức năng quản lý API token trong Admin Panel
- ✅ Đã triển khai JWT làm cơ chế xác thực thay vì user/pass
- ✅ Đã thêm TokenModel và các controller cần thiết

### 4. Thuật toán thông minh cho truyện đề xuất
- ✅ Đã thay đổi "truyện hot" thành "truyện đề xuất"
- ✅ Đã triển khai thuật toán thông minh dựa trên nhiều yếu tố:
  - Lượt xem gần đây
  - Số lượng bình luận
  - Số lượng bookmark
  - Đánh giá trung bình
  - Thời gian cập nhật
  - Chương mới

### 5. Sửa layout admin
- ✅ Đã tách biệt hoàn toàn giao diện template của Views/admin và bên ngoài
- ✅ Đã tạo app/Views/admin/layouts/base.html làm cơ sở riêng cho giao diện admin
- ✅ Đã cập nhật app/Views/admin/layouts/admin.html để kế thừa từ base.html trong thư mục admin
- ✅ Đảm bảo tất cả các template admin chỉ kế thừa từ các template trong thư mục admin

### 6. Sử dụng JWT làm token
- ✅ Đã thêm middleware ApiAuthFilter để xác thực JWT token
- ✅ Đã cập nhật Routes.php để áp dụng filter cho các API endpoints cần xác thực
- ✅ Đã thiết lập Filters.php để đăng ký filter mới

### 7. Phân quyền và bảo mật
- ✅ Đã thêm phương thức kiểm tra quyền sở hữu tài nguyên vào BaseController
- ✅ Đã tạo requireResourceOwnership để ngăn chặn truy cập trái phép vào tài nguyên

### 8. Phân biệt tác giả và người đăng
- ✅ Đã tạo migration thêm trường author_name và uploader_id vào bảng stories
- ✅ Đã update StoryModel để hỗ trợ fields mới
- ✅ Đã cập nhật search_vector để tìm kiếm theo author_name
- ✅ Đã cập nhật form chỉnh sửa truyện để hiển thị rõ ràng phần tác giả và người đăng

### 9. Bookmark không cần đăng nhập
- ✅ Đã tạo guest_bookmark.js để lưu trữ bookmark vào localStorage
- ✅ Đã tạo migration và SQL script để tạo bảng guest_bookmarks
- ✅ Đã triển khai đồng bộ giữa client và server

### 10. Cập nhật UI theo phân quyền
- ✅ Đã triển khai hệ thống 3 cấp phân quyền: Người sáng lập, Admin, Cộng tác viên
- ✅ Đã cập nhật UI hiển thị người dùng theo màu sắc tương ứng với vai trò
- ✅ Đã cập nhật giao diện bình luận để hiển thị người dùng theo phân quyền
- ✅ Đã áp dụng kiểm tra quyền trong controller UserManager

### 11. Tích hợp Imgur API
- ✅ Đã tạo ImgurClient library để tương tác với Imgur API
- ✅ Đã thêm API endpoint cho việc upload ảnh lên Imgur
- ✅ Đã thêm cấu hình Imgur Client ID trong .env và settings

### 12. WYSIWYG Editor
- ✅ Đã tích hợp TinyMCE thay thế Summernote trong form chỉnh sửa truyện và chương
- ✅ Đã tích hợp chức năng upload ảnh lên Imgur trong editor
- ✅ Đã cấu hình TinyMCE với nhiều tính năng: bảng, ảnh, định dạng văn bản, v.v.

## Kết quả kiểm thử và phân tích mã nguồn

### 1. Vấn đề phân quyền
- 🔍 **Phát hiện**: Kiểm tra phân quyền không được áp dụng đồng bộ trên tất cả các controller
- 🔍 **Phát hiện**: Lỗ hổng tiềm ẩn trong `requireResourceOwnership()` - bypass tự động cho admin/founder
- 📋 **Đề xuất**: Chuẩn hóa kiểm tra quyền trên tất cả controllers, cải thiện phương thức requireResourceOwnership

### 2. Vấn đề BookMark cho khách
- 🔍 **Phát hiện**: Thiếu xử lý khi localStorage đầy và thiếu giới hạn số lượng bookmark
- 🔍 **Phát hiện**: Cần cơ chế dọn dẹp định kỳ bookmark cũ
- 📋 **Đề xuất**: Thêm giới hạn số lượng, cơ chế xóa tự động khi đầy và cron job dọn dẹp định kỳ

### 3. Vấn đề tích hợp Imgur
- 🔍 **Phát hiện**: Thiếu cơ chế dự phòng khi Imgur API không khả dụng
- 🔍 **Phát hiện**: Thiếu kiểm tra kích thước và loại file khi upload
- 📋 **Đề xuất**: Thêm cơ chế lưu trữ cục bộ dự phòng và tăng cường bảo mật upload

### 4. Mã nguồn thừa
- 🔍 **Phát hiện**: Các phương thức thừa trong StoryModel.php (getHotStories, calculateHotScore)
- 🔍 **Phát hiện**: Templates thừa cho chức năng quốc gia (create.html, edit.html)
- 🔍 **Phát hiện**: Method getStoriesByAuthor() sử dụng cột author thay vì author_name
- 📋 **Đề xuất**: Loại bỏ mã nguồn thừa và cập nhật các phương thức bị ảnh hưởng

### 5. Vấn đề hiệu suất và bảo mật
- 🔍 **Phát hiện**: Cơ chế cache settings chỉ giữ trong 5 phút
- 🔍 **Phát hiện**: Một số truy vấn JOIN nhiều bảng chưa tối ưu
- 📋 **Đề xuất**: Tăng thời gian cache và tối ưu các truy vấn phức tạp

## Các chức năng đang triển khai

### 1. Loại bỏ mã nguồn thừa
- ✅ Đã loại bỏ các phương thức thừa trong StoryModel.php (getHotStories, calculateHotScore)
- ✅ Đã xóa các templates thừa cho chức năng quốc gia (create.html, edit.html)
- ✅ Đã xác minh getStoriesByAuthor() đang sử dụng trường author_name

### 2. Chuẩn hóa kiểm tra phân quyền
- ✅ Đã cải thiện phương thức requireResourceOwnership trong BaseController.php
- 🔄 Cần áp dụng kiểm tra quyền vào tất cả controllers còn lại

### 3. Tối ưu hiệu suất và cơ chế cache
- ✅ Đã tăng thời gian cache cho settings từ 5 phút lên 1 giờ
- 🔄 Cần tối ưu các truy vấn phức tạp

### 4. Cải thiện chức năng upload và bookmark
- 🔄 Cần thêm cơ chế dự phòng cho ImgurClient
- 🔄 Cần tăng cường bảo mật cho chức năng upload
- 🔄 Cần thêm giới hạn số lượng bookmark cho khách

## Các vấn đề và giải pháp

### Vấn đề phân biệt tác giả và người đăng
- **Vấn đề**: Hiện tại code đang nhầm lẫn giữa tác giả thật của truyện và người đăng truyện
- **Giải pháp**: ✅ Đã thêm trường `author_name` và `uploader_id` vào bảng `stories` để phân biệt rõ ràng và cập nhật form chỉnh sửa
- **Tình trạng**: Đã hoàn thành, nhưng cần cập nhật phương thức getStoriesByAuthor()

### Vấn đề bảo mật vượt quyền hạn
- **Vấn đề**: Chưa có kiểm tra quyền đầy đủ tại các endpoints
- **Giải pháp**:
  1. ✅ Đã triển khai middleware JWT cho API
  2. ✅ Đã triển khai phương thức kiểm tra quyền sở hữu
  3. 🔄 Cần cải thiện phương thức requireResourceOwnership
  4. 🔄 Cần áp dụng kiểm tra quyền cho tất cả controller còn lại

### Vấn đề đồng bộ bookmark cho khách
- **Vấn đề**: Bookmark của khách có thể mất khi xóa cookie/localStorage và thiếu giới hạn số lượng
- **Giải pháp**:
  1. ✅ Đã triển khai kết hợp localStorage và cookie để lưu ID khách
  2. ✅ Đã lưu trữ bookmark trên server với guest_id
  3. 🔄 Cần thêm giới hạn số lượng và cơ chế dọn dẹp định kỳ

### Vấn đề quản lý media trong truyện và chương
- **Vấn đề**: Thiếu cơ chế dự phòng khi Imgur API không khả dụng và kiểm tra bảo mật khi upload
- **Giải pháp**:
  1. ✅ Đã tích hợp TinyMCE WYSIWYG Editor
  2. ✅ Đã tích hợp ImgurClient để xử lý upload ảnh
  3. 🔄 Cần thêm cơ chế dự phòng và tăng cường bảo mật upload

## Khuyến nghị tiếp theo

1. **Ưu tiên cao**:
   - Loại bỏ mã nguồn thừa theo đề xuất trong file CODE_CLEANUP.md
   - Chuẩn hóa kiểm tra quyền trong các controller còn lại
   - Cải thiện phương thức requireResourceOwnership

2. **Ưu tiên trung bình**:
   - Tối ưu hiệu suất và cơ chế cache
   - Thêm cơ chế dự phòng cho ImgurClient
   - Giới hạn số lượng bookmark cho khách và thêm cơ chế dọn dẹp

3. **Ưu tiên thấp**:
   - Thêm giao diện quản lý media
   - Tối ưu hiệu suất truy vấn
   - Thêm unit tests

## Tóm tắt trạng thái

- **Số yêu cầu tổng**: 16 yêu cầu từ file log.txt
- **Đã hoàn thành**: 14 yêu cầu (87.5%)
- **Cần cải thiện**: 6 vấn đề phát hiện từ kiểm thử

Dự án đã tiến triển tốt với 87.5% yêu cầu đã được hoàn thành. Việc kiểm thử đã phát hiện một số vấn đề cần cải thiện để nâng cao chất lượng, hiệu suất và bảo mật của hệ thống.

Tham khảo các file `TODO.md`, `TESTING_REPORT.md` và `CODE_CLEANUP.md` để biết thêm chi tiết.
