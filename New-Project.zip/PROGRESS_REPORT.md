# Báo cáo tiến độ dự án

## Tổng quan

Dự án này là một trang web quản lý truyện xây dựng trên framework CodeIgniter 4, sử dụng PostgreSQL làm CSDL và Twig làm template engine. Dự án đang trong quá trình cải tiến với các chức năng mới theo yêu cầu trong file `log.txt`.

## Các chức năng đã hoàn thành

### 1. Quản lý quốc gia
- ✅ Đã loại bỏ hoàn toàn chức năng thêm/sửa/xóa quốc gia trong admin panel
- ✅ Đã thay thế bằng hiển thị danh sách quốc gia bằng thư viện JavaScript
- ✅ Đã thêm chức năng lấy danh sách quốc gia từ truyện đã có trong hệ thống

### 2. Chức năng bookmark nâng cao
- ✅ Đã thêm chức năng bookmark ở cấp độ chương
- ✅ Đã thêm API endpoint để cập nhật và kiểm tra trạng thái bookmark cho cả truyện và chương
- ✅ Đã chuẩn bị cơ sở để bookmark cho người dùng không đăng nhập

### 3. Quản lý API token
- ✅ Đã thêm chức năng quản lý API token trong Admin Panel
- ✅ Đã triển khai JWT làm cơ chế xác thực thay vì user/pass
- ✅ Đã thêm TokenModel và các controller cần thiết

### 4. Thuật toán thông minh cho truyện đề xuất
- ✅ Đã thay đổi "truyện hot" thành "truyện đề xuất"
- ✅ Đã triển khai thuật toán thông minh dựa trên nhiều yếu tố:
  - Lượt xem gần đây
  - Số lượng bình luận
  - Số lượng bookmark
  - Đánh giá trung bình
  - Thời gian cập nhật
  - Chương mới

### 5. Cải tiến giao diện admin
- ✅ Đã cập nhật đường dẫn template admin thành admin/layouts/admin.html
- ✅ Đã cập nhật tất cả template liên quan để sử dụng layout mới
- ✅ Đã thêm các yếu tố phân biệt vai trò trong giao diện admin

### 6. Phân biệt tác giả và người đăng
- ✅ Đã thêm trường author_name và uploader_id vào model
- ✅ Đã cập nhật các controller và template để làm rõ sự khác biệt
- ✅ Đã tạo script SQL để cập nhật database
- ✅ Đã cập nhật hàm tìm kiếm để bao gồm dữ liệu mới

## Các chức năng đang triển khai

### 1. Phân quyền người dùng
- 🔄 Đã thiết kế hệ thống 3 cấp phân quyền: Người sáng lập, Admin, Cộng tác viên
- 🔄 Đã thêm kiểm tra quyền trong controller User và Story
- 🔄 Cần cập nhật các controllers còn lại để áp dụng phân quyền
- 🔄 Cần cập nhật UI để hiển thị phù hợp với từng vai trò

### 2. Chức năng bookmark không cần đăng nhập
- 🔄 Đã triển khai cơ sở dữ liệu và API endpoints
- 🔄 Đang cập nhật UI và JavaScript frontend

### 3. Tích hợp editor WYSIWYG và upload Imgur
- 🔄 Đã thiết kế cấu trúc API cho upload ảnh
- 🔄 Cần tích hợp với editor và UI

## Các vấn đề và giải pháp

### Vấn đề bảo mật vượt quyền hạn
- **Vấn đề**: Chưa có kiểm tra quyền đầy đủ tại các endpoints
- **Giải pháp**:
  1. Thêm middleware kiểm tra quyền
  2. Áp dụng kiểm tra cụ thể tại mỗi controller action
  3. Kiểm tra cả quyền sở hữu (ownership) với các tài nguyên

### Vấn đề đồng bộ bookmark cho khách
- **Vấn đề**: Bookmark của khách có thể mất khi xóa cookie/localStorage
- **Giải pháp**:
  1. Sử dụng kết hợp localStorage và cookie để lưu ID khách
  2. Lưu trữ bookmark trên server với guest_id
  3. Cung cấp khả năng chuyển bookmark từ khách sang người dùng khi đăng nhập

## Khuyến nghị tiếp theo

1. **Ưu tiên cao**:
   - Chạy script cập nhật cơ sở dữ liệu để thêm trường mới vào bảng stories
   - Hoàn thiện phân quyền và kiểm tra bảo mật
   - Hoàn thiện bookmark cho khách

2. **Ưu tiên trung bình**:
   - Tích hợp Imgur API cho tải lên ảnh
   - Bổ sung editor WYSIWYG
   - Triển khai JWT cho API

3. **Ưu tiên thấp**:
   - Cải thiện UI/UX
   - Tối ưu hiệu suất truy vấn
   - Thêm dashboard thống kê

## Tóm tắt trạng thái

- **Số yêu cầu tổng**: 16 yêu cầu từ file log.txt
- **Đã hoàn thành**: 7 yêu cầu (44%)
- **Đang thực hiện**: 3 yêu cầu (19%)
- **Chưa bắt đầu**: 6 yêu cầu (37%)

Dự án đang tiến triển tốt với khoảng 44% yêu cầu đã được hoàn thành. Các chức năng còn lại đã được phân tích và chuẩn bị giải pháp triển khai.

Tham khảo các file `TODO.md` và `IMPLEMENTATION_GUIDE.md` để biết thêm chi tiết.
