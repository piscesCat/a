# Danh sách công việc cần làm tiếp theo

Dựa trên yêu cầu từ file `log.txt`, danh sách các công việc cần thực hiện:

## Đã hoàn thành
- [x] Xoá bỏ hoàn toàn chức năng tạo quốc gia trong admin panel và hiển thị danh sách quốc gia bằng thư viện js, sau đó truy vấn để hiển thị danh sách quốc gia ở header của những truyện có sẵn
- [x] Thêm bookmark ở chương
- [x] API token sẽ lấy ở Admin Panel thay vì sử dụng api với user pass
- [x] Truyện hot thay đổi thành truyện đề xuất kèm thuật toán thông minh
- [x] Sửa layout admin thành admin/layouts/admin.html
- [x] Cập nhật template theo sự thay đổi trên
- [x] Phân biệt rõ ràng tác giả với người đăng (tài khoản đã đăng truyện) trong code đang bị nhầm lẫn

## Cần thực hiện tiếp theo
- [ ] Cập nhật cơ sở dữ liệu trên server sử dụng script `database/update_stories_table.sql`
- [ ] Thêm chức năng tạo thành viên dưới phân quyền thấp hơn người sáng lập (tài khoản đầu tiên được tạo lúc install) với 3 phân quyền: Người sáng lập, Admin, Cộng tác viên
- [ ] Áp dụng hiển thị và sử dụng chức năng cho từng phân quyền theo màu sắc trên web (ví dụ comments)
- [ ] Chức năng bookmark cho bất kỳ người truy cập nào không cần đăng nhập vì mã nguồn không cho phép users đăng ky, đăng nhập
- [ ] Bảo mật không cho phép thao tác vượt quyền hạn
- [ ] Quốc gia sẽ join để hiển thị danh sách quốc gia thay vì add trong admin panel
- [ ] Hoàn thành các chức năng đang làm dở
- [ ] Bổ sung post ảnh lên imgur qua api và trong mã nguồn
- [ ] Bổ sung bảng editor cho phần viết truyện có tuỳ chọn post ảnh mô tả nội dung
- [ ] Sửa template bao gồm css, jss, views là sửa hẳn nội dung file không bao gồm template của admin panel
- [ ] Phân quyền các chức năng cụ thể cho từng role
- [ ] Sử dụng JWT làm token

## Chi tiết công việc

### 1. Cập nhật cơ sở dữ liệu
Cập nhật bảng `stories` để phân biệt tác giả và người đăng:
- Chạy script SQL `database/update_stories_table.sql` trên server để:
  1. Thêm trường `author_name` VARCHAR(100) sau trường `author_id`
  2. Thêm trường `uploader_id` INTEGER REFERENCES users(id) sau trường `author_name`
  3. Cập nhật các bản ghi hiện có để đặt `uploader_id` bằng `author_id`
  4. Cập nhật hàm tìm kiếm vector để bao gồm trường `author_name`

### 2. Phân quyền
- Tạo middleware hoặc filter cho phân quyền
- Cập nhật các controller để kiểm tra quyền truy cập
- Thêm role vào menu sidebar và chức năng (đã có nháp trong layout)

### 3. Chức năng User Manager
- Cập nhật form tạo và chỉnh sửa người dùng có thêm role
- Cập nhật kiểm tra phân quyền trong các thao tác
- Chỉ người sáng lập mới được gán quyền Admin và quản lý người sáng lập khác

### 4. Editor cho Story và Chapter
- Tích hợp WYSIWYG editor (có thể dùng TinyMCE, CKEditor hoặc Quill)
- Thêm chức năng upload ảnh qua API Imgur
- Lưu token Imgur vào cài đặt hệ thống

### 5. Hoàn thiện JWT Token
- Tích hợp JWT vào các API endpoint
- Cập nhật API middleware để xác thực JWT
- Thêm documentation về cách sử dụng JWT

### 6. Chức năng bookmark không cần đăng nhập
- Hoàn thiện người dùng ẩn danh sử dụng cookie/localStorage
- Cập nhật giao diện bookmark
- Đảm bảo bookmark hoạt động cho cả chapter

## Lưu ý
- Cập nhật file TODO.md sau mỗi lần có tiến độ để theo dõi công việc
- Các công việc có thể cần phân chia nhỏ hơn để quản lý tốt
- Ưu tiên các chức năng quan trọng trước: phân quyền, JWT, bookmark
