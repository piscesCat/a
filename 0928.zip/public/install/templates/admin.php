<div class="alert alert-info">
    <i class="fas fa-info-circle"></i> Thiết lập tài khoản quản trị và thông tin trang web. Tài khoản này sẽ được sử dụng để đăng nhập vào quản trị viên.
</div>

<form method="post" action="">
    <input type="hidden" name="step" value="3">

    <h5 class="mb-3">Thông tin tài khoản quản trị</h5>

    <div class="mb-3">
        <label for="username" class="form-label">Tên đăng nhập:</label>
        <input type="text" class="form-control" id="username" name="username" value="<?= $_SESSION['input']['username'] ?? '' ?>" required>
        <div class="form-text">Chỉ sử dụng chữ cái và số, từ 4-20 ký tự.</div>
    </div>

    <div class="mb-3">
        <label for="email" class="form-label">Email:</label>
        <input type="email" class="form-control" id="email" name="email" value="<?= $_SESSION['input']['email'] ?? '' ?>" required>
    </div>

    <div class="mb-3">
        <label for="password" class="form-label">Mật khẩu:</label>
        <input type="password" class="form-control" id="password" name="password" required>
        <div class="form-text">Ít nhất 6 ký tự.</div>
    </div>

    <div class="mb-3">
        <label for="password_confirm" class="form-label">Xác nhận mật khẩu:</label>
        <input type="password" class="form-control" id="password_confirm" name="password_confirm" required>
    </div>

    <hr class="my-4">

    <h5 class="mb-3">Thông tin trang web</h5>

    <div class="mb-3">
        <label for="site_name" class="form-label">Tên trang web:</label>
        <input type="text" class="form-control" id="site_name" name="site_name" value="<?= $_SESSION['input']['site_name'] ?? 'Web Truyện' ?>" required>
    </div>

    <div class="mb-3">
        <label for="site_description" class="form-label">Mô tả trang web:</label>
        <textarea class="form-control" id="site_description" name="site_description" rows="3"><?= $_SESSION['input']['site_description'] ?? 'Trang web đọc truyện online' ?></textarea>
    </div>

    <div class="alert alert-warning">
        <i class="fas fa-exclamation-triangle"></i> Lưu ý: Khi bạn tiếp tục, quá trình cài đặt sẽ hoàn tất và bạn sẽ có thể đăng nhập vào hệ thống.
    </div>

    <div class="d-flex justify-content-between">
        <a href="<?= BASE_URL ?>install/database" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Quay lại
        </a>

        <button type="submit" class="btn btn-primary">
            Hoàn tất cài đặt <i class="fas fa-check"></i>
        </button>
    </div>
</form>
