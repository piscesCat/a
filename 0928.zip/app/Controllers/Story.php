/**
 * Lưu/xóa bookmark (hoạt động với cả user đăng nhập và không đăng nhập)
 */
public function toggleBookmark()
{
    // Lấy story_id từ request
    $storyId = $this->request->getPost('story_id');
    if (!$storyId) {
        return $this->response->setJSON([
            'status' => 'error',
            'message' => 'ID truyện không hợp lệ'
        ]);
    }

    // Kiểm tra truyện có tồn tại không
    $story = $this->storyModel->find($storyId);
    if (!$story) {
        return $this->response->setJSON([
            'status' => 'error',
            'message' => 'Truyện không tồn tại'
        ]);
    }

    // Xử lý bookmark dựa vào trạng thái đăng nhập
    if (session()->get('isLoggedIn')) {
        // Người dùng đã đăng nhập
        $userId = session()->get('user')['id'];
        return $this->toggleUserBookmark($userId, $storyId);
    } else {
        // Người dùng không đăng nhập, sử dụng cookie
        return $this->toggleCookieBookmark($storyId, $story['title']);
    }
}

/**
 * Xử lý bookmark cho người dùng đã đăng nhập
 */
private function toggleUserBookmark($userId, $storyId)
{
    $db = \Config\Database::connect();
    $builder = $db->table('bookmarks');

    // Kiểm tra bookmark đã tồn tại chưa
    $existing = $builder->where('user_id', $userId)
                        ->where('story_id', $storyId)
                        ->get()
                        ->getRow();

    if ($existing) {
        // Đã có bookmark, xóa đi
        $builder->where('user_id', $userId)
                ->where('story_id', $storyId)
                ->delete();

        return $this->response->setJSON([
            'status' => 'success',
            'action' => 'removed',
            'message' => 'Đã xóa truyện khỏi danh sách theo dõi'
        ]);
    } else {
        // Chưa có bookmark, thêm mới
        $builder->insert([
            'user_id' => $userId,
            'story_id' => $storyId,
            'created_at' => date('Y-m-d H:i:s')
        ]);

        return $this->response->setJSON([
            'status' => 'success',
            'action' => 'added',
            'message' => 'Đã thêm truyện vào danh sách theo dõi'
        ]);
    }
}

/**
 * Xử lý bookmark cho người dùng không đăng nhập (dùng cookie)
 */
private function toggleCookieBookmark($storyId, $storyTitle)
{
    // Cookie sẽ có tên "bookmarks" và chứa danh sách ID truyện được bookmark
    $bookmarks = $this->request->getCookie('bookmarks');
    $bookmarkData = $bookmarks ? json_decode($bookmarks, true) : [];

    // Kiểm tra xem truyện đã được bookmark chưa
    $index = array_search($storyId, array_column($bookmarkData, 'id'));

    if ($index !== false) {
        // Đã có bookmark, xóa đi
        array_splice($bookmarkData, $index, 1);
        $action = 'removed';
        $message = 'Đã xóa truyện khỏi danh sách theo dõi';
    } else {
        // Chưa có bookmark, thêm mới
        // Giới hạn số lượng bookmark trong cookie là 50
        if (count($bookmarkData) >= 50) {
            array_shift($bookmarkData); // Xóa bookmark cũ nhất
        }

        $bookmarkData[] = [
            'id' => $storyId,
            'title' => $storyTitle,
            'date' => date('Y-m-d H:i:s')
        ];

        $action = 'added';
        $message = 'Đã thêm truyện vào danh sách theo dõi';
    }

    // Lưu lại vào cookie, có thời hạn 90 ngày
    $this->response->setCookie(
        'bookmarks',
        json_encode($bookmarkData),
        time() + 60 * 60 * 24 * 90, // 90 ngày
        '/',
        '',
        false,
        true // httpOnly
    );

    return $this->response->setJSON([
        'status' => 'success',
        'action' => $action,
        'message' => $message
    ]);
}

/**
 * Hiển thị danh sách bookmark của người dùng hiện tại
 */
public function bookmarks()
{
    if (session()->get('isLoggedIn')) {
        // Người dùng đã đăng nhập, lấy bookmarks từ database
        $userId = session()->get('user')['id'];
        $bookmarks = $this->getUserBookmarks($userId);

        return view('story/bookmarks.html', [
            'bookmarks' => $bookmarks,
            'title' => 'Truyện đang theo dõi',
            'type' => 'user'
        ]);
    } else {
        // Người dùng không đăng nhập, lấy bookmarks từ cookie
        $bookmarks = $this->getCookieBookmarks();

        return view('story/bookmarks.html', [
            'bookmarks' => $bookmarks,
            'title' => 'Truyện đang theo dõi',
            'type' => 'guest'
        ]);
    }
}

/**
 * Lấy danh sách bookmark của người dùng đã đăng nhập
 */
private function getUserBookmarks($userId)
{
    $db = \Config\Database::connect();
    $builder = $db->table('bookmarks');

    return $builder->select('stories.*, bookmarks.created_at as bookmarked_at')
                   ->join('stories', 'stories.id = bookmarks.story_id')
                   ->where('bookmarks.user_id', $userId)
                   ->orderBy('bookmarks.created_at', 'DESC')
                   ->get()
                   ->getResultArray();
}

/**
 * Lấy danh sách bookmark từ cookie cho người dùng không đăng nhập
 */
private function getCookieBookmarks()
{
    $bookmarks = $this->request->getCookie('bookmarks');
    if (!$bookmarks) {
        return [];
    }

    $bookmarkData = json_decode($bookmarks, true);
    if (!$bookmarkData) {
        return [];
    }

    // Lấy thông tin chi tiết của các truyện
    $storyIds = array_column($bookmarkData, 'id');
    if (empty($storyIds)) {
        return [];
    }

    $stories = $this->storyModel->whereIn('id', $storyIds)->findAll();

    // Sắp xếp theo thứ tự trong cookie
    $result = [];
    foreach ($bookmarkData as $bookmark) {
        foreach ($stories as $story) {
            if ($story['id'] == $bookmark['id']) {
                $story['bookmarked_at'] = $bookmark['date'];
                $result[] = $story;
                break;
            }
        }
    }

    return $result;
}

/**
 * Show recommended stories
 */
public function recommended()
{
    $storyModel = new \App\Models\StoryModel();
    $settingsModel = new \App\Models\SettingsModel();

    // Get limit from settings or use default
    $limit = (int)($settingsModel->getSetting('max_recommended_stories') ?? 20);
    $page = $this->request->getGet('page') ? (int)$this->request->getGet('page') : 1;
    $offset = ($page - 1) * $limit;

    // Get recommended stories
    $stories = $storyModel->where('is_recommended', true)
                      ->orderBy('updated_at', 'DESC')
                      ->limit($limit, $offset)
                      ->findAll();

    // Count total for pagination
    $total = $storyModel->where('is_recommended', true)->countAllResults();

    // Set up pagination
    $pager = \Config\Services::pager();
    $pager_links = $pager->makeLinks($page, $limit, $total, 'default_full');

    return $this->renderView('story/recommended.html', [
        'stories' => $stories,
        'total' => $total,
        'pager' => $pager_links,
        'title' => 'Truyện Đề Xuất',
        'meta_description' => 'Danh sách truyện đề xuất hay nhất, được chọn lọc dựa trên đánh giá và lượt xem',
        'meta_keywords' => 'truyện đề xuất, truyện hay nhất, truyện chọn lọc'
    ]);
}

/**
 * Show latest stories
 */
public function latest()
{
    $storyModel = new \App\Models\StoryModel();
    $settingsModel = new \App\Models\SettingsModel();

    // Get limit from settings or use default
    $limit = (int)($settingsModel->getSetting('max_latest_stories') ?? 20);
    $page = $this->request->getGet('page') ? (int)$this->request->getGet('page') : 1;
    $offset = ($page - 1) * $limit;

    // Get latest stories
    $stories = $storyModel->where('status', 'published')
                      ->orderBy('created_at', 'DESC')
                      ->limit($limit, $offset)
                      ->findAll();

    // Count total for pagination
    $total = $storyModel->where('status', 'published')->countAllResults();

    // Set up pagination
    $pager = \Config\Services::pager();
    $pager_links = $pager->makeLinks($page, $limit, $total, 'default_full');

    return $this->renderView('story/latest.html', [
        'stories' => $stories,
        'total' => $total,
        'pager' => $pager_links,
        'title' => 'Truyện Mới Cập Nhật',
        'meta_description' => 'Danh sách truyện mới cập nhật, liên tục được cập nhật hàng ngày',
        'meta_keywords' => 'truyện mới, truyện mới cập nhật, truyện hay'
    ]);
}

/**
 * Show completed stories
 */
public function completed()
{
    $storyModel = new \App\Models\StoryModel();
    $settingsModel = new \App\Models\SettingsModel();

    // Get limit from settings or use default
    $limit = (int)($settingsModel->getSetting('max_completed_stories') ?? 20);
    $page = $this->request->getGet('page') ? (int)$this->request->getGet('page') : 1;
    $offset = ($page - 1) * $limit;

    // Get completed stories
    $stories = $storyModel->where('is_completed', true)
                      ->where('status', 'published')
                      ->orderBy('updated_at', 'DESC')
                      ->limit($limit, $offset)
                      ->findAll();

    // Count total for pagination
    $total = $storyModel->where('is_completed', true)
                     ->where('status', 'published')
                     ->countAllResults();

    // Set up pagination
    $pager = \Config\Services::pager();
    $pager_links = $pager->makeLinks($page, $limit, $total, 'default_full');

    return $this->renderView('story/completed.html', [
        'stories' => $stories,
        'total' => $total,
        'pager' => $pager_links,
        'title' => 'Truyện Đã Hoàn Thành',
        'meta_description' => 'Danh sách truyện đã hoàn thành, đọc trọn bộ không phải đợi cập nhật',
        'meta_keywords' => 'truyện hoàn thành, truyện full, truyện trọn bộ'
    ]);
}
