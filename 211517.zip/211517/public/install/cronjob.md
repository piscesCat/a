# Hướng dẫn cài đặt Cronjob

Hệ thống sử dụng nhiều tác vụ tự động được chạy theo lịch để cập nhật dữ liệu và đảm bảo trang web hoạt động hiệu quả. Dưới đây là hướng dẫn cài đặt các cronjob cần thiết.

## Danh sách các Cronjob cần thiết

### 1. Cập nhật truyện Hot (UpdateHotStories)
Cập nhật danh sách truyện hot dựa vào các tiêu chí như lượt xem, đánh giá, bình luận mới.
```
0 */3 * * * php /đường/dẫn/đến/website/public/index.php stories:update-hot
```
Cú pháp này sẽ chạy cứ mỗi 3 giờ (vào đầu giờ).

### 2. Cập nhật truyện Đề xuất (UpdateRecommendedStories)
Cập nhật danh sách truyện được đề xuất dựa trên thuật toán thông minh.
```
0 */6 * * * php /đường/dẫn/đến/website/public/index.php stories:update-recommended
```
Cú pháp này sẽ chạy cứ mỗi 6 giờ (vào đầu giờ).

### 3. Cập nhật trạng thái truyện (UpdateStoryStatus)
Cập nhật trạng thái hoàn thành/đang tiến hành của truyện dựa vào thời gian cập nhật.
```
0 0 * * * php /đường/dẫn/đến/website/public/index.php stories:update-status
```
Cú pháp này sẽ chạy mỗi ngày vào lúc 00:00.

### 4. Đề xuất truyện nổi bật (SuggestFeaturedStories)
Tạo danh sách đề xuất truyện nổi bật cho admin.
```
0 0 * * 1 php /đường/dẫn/đến/website/public/index.php stories:suggest-featured
```
Cú pháp này sẽ chạy mỗi tuần vào thứ 2 lúc 00:00.

### 5. Reset lượt xem (ResetViews)
Reset lượt xem theo ngày, tuần, tháng.
```
0 0 * * * php /đường/dẫn/đến/website/public/index.php stories:reset-daily-views
0 0 * * 0 php /đường/dẫn/đến/website/public/index.php stories:reset-weekly-views
0 0 1 * * php /đường/dẫn/đến/website/public/index.php stories:reset-monthly-views
```
- Cú pháp đầu tiên sẽ chạy mỗi ngày vào lúc 00:00.
- Cú pháp thứ hai sẽ chạy mỗi Chủ nhật vào lúc 00:00.
- Cú pháp thứ ba sẽ chạy vào ngày đầu tiên của mỗi tháng lúc 00:00.

### 6. Bảo trì hệ thống (Maintenance)
Thực hiện các tác vụ bảo trì hệ thống như dọn dẹp file tạm, tối ưu database.
```
0 3 * * 0 php /đường/dẫn/đến/website/public/index.php maintenance:run
```
Cú pháp này sẽ chạy mỗi Chủ nhật lúc 3 giờ sáng.

## Cách cài đặt Cronjob

### Trên Linux/Unix (VPS hoặc Dedicated Server)

1. Đăng nhập vào server qua SSH
2. Mở crontab để chỉnh sửa:
   ```
   crontab -e
   ```
3. Thêm các dòng cronjob ở trên, thay thế `/đường/dẫn/đến/website` bằng đường dẫn thực tế tới thư mục gốc của trang web.
   ví dụ: `/var/www/html/tenwebsite`
4. Lưu và thoát bằng cách nhấn `Ctrl + X`, sau đó nhấn `Y` và `Enter`.
5. Kiểm tra xem cronjob đã được cài đặt chưa:
   ```
   crontab -l
   ```

### Trên Shared Hosting

1. Đăng nhập vào Control Panel (cPanel, Plesk, DirectAdmin...)
2. Tìm phần quản lý Cronjob/Scheduled Tasks/Cron Jobs
3. Thêm các cronjob theo hướng dẫn trên giao diện, sử dụng các lệnh đã cung cấp
4. Đối với cPanel:
   - Chọn "Cron Jobs" từ dashboard
   - Chọn tần suất từ menu dropdown hoặc nhập biểu thức cron thủ công
   - Trong phần command, nhập lệnh PHP phù hợp với đường dẫn đến website của bạn

### Thử nghiệm Cronjob

Để kiểm tra xem cronjob có hoạt động đúng không, bạn có thể chạy lệnh thủ công và kiểm tra kết quả:

```
php /đường/dẫn/đến/website/public/index.php stories:update-hot
```

Nếu lệnh chạy thành công, bạn sẽ thấy kết quả tương ứng.

## Sử dụng Master Cronjob (Đề xuất)

Để đơn giản hóa việc quản lý, bạn có thể sử dụng master cronjob để tự động chạy tất cả các tác vụ cần thiết:

```
* * * * * php /đường/dẫn/đến/website/public/index.php master-cron
```

MasterCron sẽ tự động quản lý việc chạy các tác vụ con theo lịch phù hợp, giảm thiểu số lượng cronjob cần cài đặt.

### Cài đặt thông qua Master Cronjob

1. Chỉ cần thêm một dòng cronjob duy nhất như trên vào crontab
2. MasterCron sẽ tự động kiểm tra và chạy các tác vụ cần thiết dựa trên cài đặt thời gian trong cơ sở dữ liệu
3. Bạn có thể thay đổi lịch chạy các tác vụ thông qua giao diện quản trị mà không cần chỉnh sửa crontab

## Xử lý lỗi thường gặp

1. **Permission Denied**: Đảm bảo rằng người dùng chạy cronjob có quyền thực thi các file PHP
   ```
   chmod +x /đường/dẫn/đến/website/public/index.php
   ```

2. **Command Not Found**: Đảm bảo rằng đường dẫn đến PHP và file index.php là chính xác
   ```
   which php  # để tìm đường dẫn chính xác đến PHP
   ```

3. **No output**: Thêm đường dẫn để log output
   ```
   * * * * * php /đường/dẫn/đến/website/public/index.php master-cron >> /path/to/logfile.log 2>&1
   ```

## Ghi chú quan trọng

- Đảm bảo múi giờ server khớp với múi giờ sử dụng trong ứng dụng
- Kiểm tra log hệ thống nếu cronjob không hoạt động như mong đợi
- Đối với shared hosting, một số nhà cung cấp có thể giới hạn tần suất chạy cronjob
