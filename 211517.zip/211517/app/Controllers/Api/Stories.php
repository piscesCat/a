<?php

namespace App\Controllers\Api;

use App\Controllers\BaseController;
use App\Models\StoryModel;
use App\Models\CategoryModel;

class Stories extends BaseController
{
    protected $storyModel;
    protected $categoryModel;

    public function __construct()
    {
        $this->storyModel = new StoryModel();
        $this->categoryModel = new CategoryModel();
    }

    /**
     * API tạo truyện mới
     */
    public function create()
    {
        // Kiểm tra xác thực API (token)
        $user = $this->verifyApiToken();
        if (!$user || $user['role'] < 2) { // Chỉ admin và người sáng lập mới được tạo truyện
            return $this->response->setStatusCode(403)->setJSON([
                'success' => false,
                'message' => 'Không có quyền thực hiện hành động này'
            ]);
        }

        // Validate dữ liệu
        $rules = [
            'title' => 'required|min_length[3]|max_length[200]',
            'slug' => 'required|alpha_dash|min_length[3]|max_length[200]|is_unique[stories.slug]',
            'description' => 'required',
            'categories' => 'required',
            'status' => 'required|in_list[draft,published,completed]'
        ];

        $data = $this->request->getJSON(true);

        if (!$this->validate($rules)) {
            return $this->response->setStatusCode(400)->setJSON([
                'success' => false,
                'message' => 'Dữ liệu không hợp lệ',
                'errors' => $this->validator->getErrors()
            ]);
        }

        // Chuẩn bị dữ liệu
        $storyData = [
            'title' => $data['title'],
            'slug' => $data['slug'],
            'description' => $data['description'],
            'author_id' => $user['id'],
            'status' => $data['status'],
            'cover_image' => $data['cover_image'] ?? null,
            'country_id' => $data['country_id'] ?? null,
            'year' => $data['year'] ?? null,
            'type' => $data['type'] ?? 'series',
            'is_featured' => $data['is_featured'] ?? 0,
            'is_hot' => $data['is_hot'] ?? 0,
            'is_completed' => $data['is_completed'] ?? 0,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];

        // Lưu vào database
        $db = \Config\Database::connect();
        $db->transStart();

        try {
            $storyId = $this->storyModel->insert($storyData);

            // Lưu thể loại
            if (!empty($data['categories']) && is_array($data['categories'])) {
                foreach ($data['categories'] as $categoryId) {
                    $db->table('story_categories')->insert([
                        'story_id' => $storyId,
                        'category_id' => $categoryId
                    ]);
                }
            }

            $db->transComplete();

            if ($db->transStatus() === false) {
                return $this->response->setStatusCode(500)->setJSON([
                    'success' => false,
                    'message' => 'Đã xảy ra lỗi khi lưu truyện'
                ]);
            }

            // Lấy thông tin truyện đã tạo
            $story = $this->storyModel->find($storyId);

            return $this->response->setJSON([
                'success' => true,
                'message' => 'Truyện đã được tạo thành công',
                'data' => $story
            ]);
        } catch (\Exception $e) {
            return $this->response->setStatusCode(500)->setJSON([
                'success' => false,
                'message' => 'Đã xảy ra lỗi: ' . $e->getMessage()
            ]);
        }
    }

    /**
     * API cập nhật truyện
     */
    public function update($id)
    {
        // Kiểm tra xác thực API (token)
        $user = $this->verifyApiToken();
        if (!$user || $user['role'] < 2) { // Chỉ admin và người sáng lập mới được cập nhật truyện
            return $this->response->setStatusCode(403)->setJSON([
                'success' => false,
                'message' => 'Không có quyền thực hiện hành động này'
            ]);
        }

        // Kiểm tra truyện tồn tại
        $story = $this->storyModel->find($id);
        if (!$story) {
            return $this->response->setStatusCode(404)->setJSON([
                'success' => false,
                'message' => 'Không tìm thấy truyện'
            ]);
        }

        // Validate dữ liệu
        $rules = [
            'title' => 'required|min_length[3]|max_length[200]',
            'slug' => "required|alpha_dash|min_length[3]|max_length[200]|is_unique[stories.slug,id,$id]",
            'description' => 'required',
            'categories' => 'required',
            'status' => 'required|in_list[draft,published,completed]'
        ];

        $data = $this->request->getJSON(true);

        if (!$this->validate($rules)) {
            return $this->response->setStatusCode(400)->setJSON([
                'success' => false,
                'message' => 'Dữ liệu không hợp lệ',
                'errors' => $this->validator->getErrors()
            ]);
        }

        // Chuẩn bị dữ liệu
        $storyData = [
            'title' => $data['title'],
            'slug' => $data['slug'],
            'description' => $data['description'],
            'status' => $data['status'],
            'country_id' => $data['country_id'] ?? null,
            'year' => $data['year'] ?? null,
            'type' => $data['type'] ?? 'series',
            'is_featured' => $data['is_featured'] ?? 0,
            'is_hot' => $data['is_hot'] ?? 0,
            'is_completed' => $data['is_completed'] ?? 0,
            'updated_at' => date('Y-m-d H:i:s')
        ];

        // Cập nhật hình ảnh nếu có
        if (!empty($data['cover_image'])) {
            $storyData['cover_image'] = $data['cover_image'];
        }

        // Lưu vào database
        $db = \Config\Database::connect();
        $db->transStart();

        try {
            $this->storyModel->update($id, $storyData);

            // Cập nhật thể loại
            if (!empty($data['categories']) && is_array($data['categories'])) {
                // Xóa thể loại cũ
                $db->table('story_categories')->where('story_id', $id)->delete();

                // Thêm thể loại mới
                foreach ($data['categories'] as $categoryId) {
                    $db->table('story_categories')->insert([
                        'story_id' => $id,
                        'category_id' => $categoryId
                    ]);
                }
            }

            $db->transComplete();

            if ($db->transStatus() === false) {
                return $this->response->setStatusCode(500)->setJSON([
                    'success' => false,
                    'message' => 'Đã xảy ra lỗi khi cập nhật truyện'
                ]);
            }

            // Lấy thông tin truyện đã cập nhật
            $story = $this->storyModel->find($id);

            return $this->response->setJSON([
                'success' => true,
                'message' => 'Truyện đã được cập nhật thành công',
                'data' => $story
            ]);
        } catch (\Exception $e) {
            return $this->response->setStatusCode(500)->setJSON([
                'success' => false,
                'message' => 'Đã xảy ra lỗi: ' . $e->getMessage()
            ]);
        }
    }

    /**
     * Tăng lượt xem cho một truyện sau khi người dùng ở lại trang ít nhất 5 giây
     */
    public function incrementView()
    {
        // Kiểm tra request có phải là AJAX không
        if (!$this->request->isAJAX()) {
            return $this->response->setStatusCode(403)->setJSON([
                'success' => false,
                'message' => 'Access forbidden'
            ]);
        }

        // Validate input
        $rules = [
            'storyId' => 'required|numeric',
            'viewDuration' => 'required|numeric'
        ];

        if (!$this->validate($rules)) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Dữ liệu không hợp lệ'
            ]);
        }

        $storyId = $this->request->getPost('storyId');
        $viewDuration = $this->request->getPost('viewDuration');

        // Kiểm tra thời gian xem có đủ điều kiện không (ít nhất 5 giây)
        if ($viewDuration < 5) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Thời gian xem chưa đủ để tính lượt xem'
            ]);
        }

        // Tăng lượt xem cho truyện
        $storyModel = new \App\Models\StoryModel();
        $storyModel->incrementViews($storyId);

        return $this->response->setJSON([
            'success' => true,
            'message' => 'Đã tăng lượt xem cho truyện'
        ]);
    }

    /**
     * Xác thực token API
     */
    protected function verifyApiToken()
    {
        $authHeader = $this->request->getHeaderLine('Authorization');
        if (empty($authHeader) || !preg_match('/Bearer\s+(.*)$/i', $authHeader, $matches)) {
            return null;
        }

        $token = $matches[1];
        $tokenModel = new \App\Models\TokenModel();

        return $tokenModel->getUserFromToken($token);
    }
}
