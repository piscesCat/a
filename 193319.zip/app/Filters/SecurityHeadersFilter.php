<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

class SecurityHeadersFilter implements FilterInterface
{
    /**
     * Filter trước khi controller được gọi
     */
    public function before(RequestInterface $request, $arguments = null)
    {
        // Không làm gì cả trước khi controller được gọi
    }

    /**
     * Filter sau khi controller được gọi
     * Thêm các security headers vào response
     */
    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // Thêm Content-Security-Policy header
        $response->setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval' https://cdnjs.cloudflare.com https://cdn.jsdelivr.net; style-src 'self' 'unsafe-inline' https://cdnjs.cloudflare.com https://cdn.jsdelivr.net https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' data: https: http:; connect-src 'self' https://api.imgur.com; frame-src 'self'; object-src 'none';");

        // Thêm X-XSS-Protection header
        $response->setHeader('X-XSS-Protection', '1; mode=block');

        // Thêm X-Content-Type-Options header
        $response->setHeader('X-Content-Type-Options', 'nosniff');

        // Thêm X-Frame-Options header
        $response->setHeader('X-Frame-Options', 'SAMEORIGIN');

        // Thêm Referrer-Policy header
        $response->setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');

        // Thêm Permissions-Policy header
        $response->setHeader('Permissions-Policy', 'geolocation=(), microphone=(), camera=()');

        // Thêm Strict-Transport-Security header trong production
        if (ENVIRONMENT === 'production') {
            $response->setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains; preload');
        }

        return $response;
    }
}
