<?php
use PHPUnit\Framework\TestCase;
use App\Services\AuthService;

class AuthServiceTest extends TestCase {
    public function testValidateFail() {
        $auth = new AuthService();
        $this->assertFalse($auth->validate('',''));
    }
    public function testValidatePass() {
        $auth = new AuthService();
        // giả lập thông tin đúng
        $this->assertTrue($auth->validate('admin','admin123'));
    }
}
