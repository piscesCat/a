<?php
namespace App\Controllers;

use App\Models\StoryModel;
use App\Models\ChapterModel;
use App\Models\CommentModel;
use App\Models\SettingsModel;
use App\Models\CategoryModel;
use App\Models\BookmarkModel;
use App\Models\GuestBookmarkModel;

class Chapter extends BaseController
{
    protected $storyModel;
    protected $chapterModel;
    protected $commentModel;
    protected $settingsModel;
    protected $categoryModel;
    protected $bookmarkModel;
    protected $guestBookmarkModel;

    public function __construct()
    {
        $this->storyModel = new StoryModel();
        $this->chapterModel = new ChapterModel();
        $this->commentModel = new CommentModel();
        $this->settingsModel = new SettingsModel();
        $this->categoryModel = new CategoryModel();
        $this->bookmarkModel = new BookmarkModel();
        $this->guestBookmarkModel = new GuestBookmarkModel();
    }

    /**
     * Xem một chương cụ thể
     */
    public function view($storySlug, $chapterNumber)
    {
        // Trích xuất số chương từ định dạng URL (chuong-X)
        if (preg_match('/chuong-(\d+)/', $chapterNumber, $matches)) {
            $chapterNumber = $matches[1];
        } else {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        // Lấy thông tin chi tiết truyện
        $story = $this->storyModel->getStory($storySlug);

        if (!$story) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        // Lấy thông tin chi tiết chương
        $chapter = $this->chapterModel->getChapter($story['id'], $chapterNumber);

        if (!$chapter) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        // Định dạng tiêu đề và mô tả chương sử dụng mẫu
        $titleTemplate = $this->settingsModel->getSetting('chapter_title_template', 'Chương [number]: [title] - [story_title]');
        $descTemplate = $this->settingsModel->getSetting('chapter_description_template', 'Đọc chương [number]: [title] của truyện [story_title]');

        // Lấy danh mục của truyện
        $categories = $story['categories'] ?? [];

        // Lấy danh mục dưới dạng chuỗi
        $categoryNames = array_column($categories, 'name');
        $categoryString = implode(', ', $categoryNames);

        // Thay thế placeholder trong mẫu
        $replacements = [
            '[number]' => $chapter['chapter_number'],
            '[title]' => $chapter['title'],
            '[story_title]' => $story['title'],
            '[story_author]' => $story['author_name'] ?? '',
            '[story_categories]' => $categoryString
        ];

        $formattedTitle = str_replace(array_keys($replacements), array_values($replacements), $titleTemplate);
        $formattedDescription = str_replace(array_keys($replacements), array_values($replacements), $descTemplate);

        // Không tăng lượt xem ngay lập tức - sẽ được thực hiện bởi JavaScript sau 5 giây
        // $this->chapterModel->incrementViews($chapter['id']);

        // Lấy chương kế tiếp và chương trước đó
        $nextChapter = $this->chapterModel->getNextChapter($story['id'], $chapterNumber);
        $prevChapter = $this->chapterModel->getPreviousChapter($story['id'], $chapterNumber);

        // Lấy bình luận của chương (phân trang)
        $commentsPage = $this->request->getGet('comments_page') ?? 1;
        $commentsPerPage = 10;
        $commentsOffset = ($commentsPage - 1) * $commentsPerPage;

        // Lấy bình luận cho chương
        $comments = $this->commentModel->getChapterComments($chapter['id'], $commentsPerPage, $commentsOffset);
        $totalComments = $this->commentModel->countChapterComments($chapter['id']);
        $commentsTotalPages = ceil($totalComments / $commentsPerPage);

        // Lấy replies cho mỗi bình luận
        foreach ($comments as &$comment) {
            $comment['replies'] = $this->commentModel->getCommentReplies($comment['id']);
        }

        return $this->renderView('chapter/view.html', [
            'story' => $story,
            'chapter' => $chapter,
            'next_chapter' => $nextChapter,
            'prev_chapter' => $prevChapter,
            'comments' => $comments,
            'comments_page' => (int)$commentsPage,
            'comments_total_pages' => $commentsTotalPages,
            'current_url' => current_url(),
            'formatted_title' => $formattedTitle,
            'formatted_description' => $formattedDescription
        ]);
    }

    /**
     * Liệt kê tất cả các chương của một truyện
     */
    public function list($storySlug)
    {
        // Lấy thông tin chi tiết truyện
        $story = $this->storyModel->getStory($storySlug);

        if (!$story) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        // Lấy tất cả các chương
        $chapters = $this->chapterModel->getChaptersByStory($story['id'], 1000, 0); // Lấy tất cả các chương

        return $this->renderView('chapter/list.html', [
            'story' => $story,
            'chapters' => $chapters
        ]);
    }

    /**
     * Lưu tiến trình đọc của người dùng
     */
    protected function saveReadingProgress($storyId, $chapterId, $chapterNumber)
    {
        // Không cần kiểm tra đăng nhập nữa
        // if (!session()->get('isLoggedIn')) {
        //     return false;
        // }

        // Dùng ID người dùng nếu có, ngược lại dùng null và lưu vào cookie
        $userId = session()->get('user')['id'] ?? null;
        if (!$userId) {
            // Xử lý nếu người dùng không đăng nhập - có thể tạo cookie ID hoặc trả về false
            return false;
        }

        $data = [
            'user_id' => $userId,
            'story_id' => $storyId,
            'chapter_id' => $chapterId,
            'last_read' => date('Y-m-d H:i:s')
        ];

        $db = \Config\Database::connect();

        // Kiểm tra xem đã có bản ghi chưa
        $existing = $db->table('reading_progress')
            ->where('user_id', $userId)
            ->where('story_id', $storyId)
            ->get()
            ->getRow();

        if ($existing) {
            // Cập nhật bản ghi hiện có
            return $db->table('reading_progress')
                ->where('user_id', $userId)
                ->where('story_id', $storyId)
                ->update($data);
        } else {
            // Chèn bản ghi mới
            return $db->table('reading_progress')
                ->insert($data);
        }
    }

    /**
     * Báo cáo lỗi trong một chương
     */
    public function reportError()
    {
        if (!$this->request->isAJAX()) {
            return $this->response->setStatusCode(403);
        }

        $rules = [
            'story_id' => 'required|numeric',
            'chapter_id' => 'required|numeric',
            'error_type' => 'required|in_list[typo,missing,wrong_order,other]',
            'error_detail' => 'required|min_length[10]'
        ];

        if (!$this->validate($rules)) {
            return $this->response->setJSON(['success' => false, 'message' => 'Dữ liệu không hợp lệ.']);
        }

        $data = [
            'story_id' => $this->request->getPost('story_id'),
            'chapter_id' => $this->request->getPost('chapter_id'),
            'error_type' => $this->request->getPost('error_type'),
            'error_detail' => $this->request->getPost('error_detail'),
            'user_id' => session()->get('isLoggedIn') ? session()->get('user')['id'] : null,
            'created_at' => date('Y-m-d H:i:s')
        ];

        $db = \Config\Database::connect();
        $result = $db->table('reported_errors')->insert($data);

        return $this->response->setJSON(['success' => (bool)$result]);
    }

    /**
     * Đánh dấu một chương
     */
    public function bookmarkChapter()
    {
        if (!$this->request->isAJAX()) {
            return $this->response->setStatusCode(403);
        }

        $rules = [
            'story_id' => 'required|numeric',
            'chapter_id' => 'required|numeric'
        ];

        if (!$this->validate($rules)) {
            return $this->response->setJSON(['success' => false, 'message' => 'Dữ liệu không hợp lệ.']);
        }

        $data = $this->request->getJSON(true);
        $storyId = $data['story_id'];
        $chapterId = $data['chapter_id'];

        // Xử lý đánh dấu cho khách
        $guestId = $this->getGuestId();

        // Chuyển đổi trạng thái đánh dấu cho khách
        $result = $this->guestBookmarkModel->toggleBookmark($guestId, $storyId, $chapterId);

        return $this->response->setJSON([
            'success' => true,
            'bookmarked' => ($result['action'] === 'added'),
            'message' => $result['message']
        ]);
    }

    /**
     * Lấy hoặc tạo ID khách cho theo dõi đánh dấu
     */
    protected function getGuestId()
    {
        $guestId = $this->request->getCookie('guest_id');

        if (!$guestId) {
            $guestId = md5(uniqid() . $_SERVER['REMOTE_ADDR'] . time());
            $cookieOptions = [
                'expires' => time() + (86400 * 365), // 1 năm
                'path' => '/',
                'secure' => false,
                'httponly' => true
            ];

            setCookie('guest_id', $guestId, $cookieOptions);

            // Lưu trong request hiện tại
            $_COOKIE['guest_id'] = $guestId;
        }

        return $guestId;
    }
}
