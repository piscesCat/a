-- =========================================
-- DEFAULT DATA
-- =========================================
-- File chứa dữ liệu mặc định cho hệ thống

-- Kiểm tra xem các bảng đã được tạo và dữ liệu mặc định đã được nhập chưa
DO $$
BEGIN
    -- Kiểm tra xem bảng system_changes đã có dữ liệu chưa
    IF EXISTS (SELECT 1 FROM system_changes WHERE description = 'Dữ liệu mặc định đã được nhập') THEN
        RAISE NOTICE 'Dữ liệu mặc định đã được nhập, bỏ qua';
        RETURN;
    END IF;

    -- Kiểm tra các bảng cần thiết đã tồn tại chưa
    IF NOT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = 'public' AND table_name = 'users') OR
       NOT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = 'public' AND table_name = 'categories') OR
       NOT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = 'public' AND table_name = 'settings') THEN
        RAISE NOTICE 'Các bảng cần thiết chưa được tạo, không thể nhập dữ liệu mặc định';
        RETURN;
    END IF;

    -- Insert default admin user (password: admin123) với vai trò người sáng lập (role=3)
    INSERT INTO users (username, email, password, role, status)
    VALUES ('admin', 'admin@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 3, 'active')
    ON CONFLICT (username) DO NOTHING;
    RAISE NOTICE 'Đã tạo tài khoản admin mặc định';

    -- Insert danh mục mặc định
    INSERT INTO categories (name, slug, description)
    VALUES
        ('Tình Cảm', 'tinh-cam', 'Truyện tình cảm'),
        ('Phiêu Lưu', 'phieu-luu', 'Truyện phiêu lưu'),
        ('Hài Hước', 'hai-huoc', 'Truyện hài hước'),
        ('Kinh Dị', 'kinh-di', 'Truyện kinh dị'),
        ('Tâm Lý', 'tam-ly', 'Truyện tâm lý')
    ON CONFLICT (slug) DO NOTHING;
    RAISE NOTICE 'Đã tạo các danh mục mặc định';

    -- Insert thiết lập mặc định
    INSERT INTO settings (id, value, description)
    VALUES
        ('site_name', 'Web Truyện', 'Tên trang web'),
        ('site_description', 'Trang web truyện hay, cập nhật thông tin truyện mới nhất', 'Mô tả trang web'),
        ('site_keywords', 'truyện, truyện hay, truyện mới', 'Từ khóa trang web'),
        ('site_logo', '/assets/images/logo.png', 'Logo trang web'),
        ('site_favicon', '/assets/images/favicon.ico', 'Favicon trang web'),
        ('site_header', '<h1>Web Truyện</h1>', 'Tiêu đề header mặc định'),
        ('site_footer', '© 2025 Web Truyện - Tất cả quyền được bảo lưu', 'Nội dung footer mặc định'),
        ('story_title_template', '[title] - [year] | [country]', 'Mẫu tiêu đề mặc định cho truyện'),
        ('story_description_template', 'Truyện [title] [year] - [country] thuộc thể loại [categories]. Truyện do [author] đánh giá.', 'Mẫu mô tả mặc định cho truyện'),
        ('chapter_title_template', 'Chương [number]: [title] - [story_title]', 'Mẫu tiêu đề mặc định cho chương'),
        ('chapter_description_template', 'Đọc chương [number]: [title] của truyện [story_title]', 'Mẫu mô tả mặc định cho chương'),
        ('max_featured_stories', '6', 'Số lượng truyện nổi bật hiển thị trên trang chủ'),
        ('max_latest_stories', '12', 'Số lượng truyện mới nhất hiển thị trên trang chủ'),
        ('max_popular_stories', '5', 'Số lượng truyện phổ biến hiển thị trên trang chủ'),
        ('max_completed_stories', '6', 'Số lượng truyện đã hoàn thành hiển thị trên trang chủ'),
        ('max_guest_bookmarks', '50', 'Số lượng bookmark tối đa cho khách'),
        ('max_client_favorites', '50', 'Số lượng truyện yêu thích tối đa cho mỗi người dùng'),
        ('max_client_bookmarks', '50', 'Số lượng bookmark tối đa cho mỗi người dùng'),
        ('smtp_host', '', 'SMTP host'),
        ('smtp_port', '587', 'SMTP port'),
        ('smtp_user', '', 'SMTP username'),
        ('smtp_pass', '', 'SMTP password'),
        ('smtp_from', '', 'SMTP from email'),
        ('maintenance_mode', 'off', 'Chế độ bảo trì'),
        ('register_enabled', 'off', 'Cho phép đăng ký tài khoản mới'),
        ('comments_enabled', 'on', 'Cho phép bình luận'),
        ('guest_comments_enabled', 'on', 'Cho phép bình luận không cần đăng nhập'),
        ('analytics_code', '', 'Mã Google Analytics'),
        ('recaptcha_site_key', '', 'Google reCAPTCHA site key'),
        ('recaptcha_secret_key', '', 'Google reCAPTCHA secret key'),
        ('social_facebook', '', 'Đường dẫn Facebook'),
        ('social_twitter', '', 'Đường dẫn Twitter'),
        ('social_youtube', '', 'Đường dẫn YouTube'),
        ('social_instagram', '', 'Đường dẫn Instagram'),
        ('imgur_client_id', '', 'Imgur Client ID'),
        ('last_reset_daily', NULL, 'Thời gian reset lượt xem theo ngày gần nhất'),
        ('last_reset_weekly', NULL, 'Thời gian reset lượt xem theo tuần gần nhất'),
        ('last_reset_monthly', NULL, 'Thời gian reset lượt xem theo tháng gần nhất'),
        ('algorithm_hot_min_daily_views', '100', 'Số lượt xem tối thiểu trong ngày để đánh dấu là hot'),
        ('algorithm_hot_growth_rate', '30', 'Tỷ lệ tăng trưởng tối thiểu so với ngày trước (%)'),
        ('algorithm_hot_min_new_ratings', '10', 'Số lượng đánh giá mới tối thiểu trong 24h'),
        ('algorithm_hot_cooldown_days', '3', 'Số ngày tự động loại bỏ trạng thái hot'),
        ('algorithm_featured_limit', '10', 'Số lượng đề xuất truyện nổi bật tối đa'),
        ('algorithm_featured_min_rating', '4.0', 'Đánh giá tối thiểu cho truyện nổi bật'),
        ('algorithm_recommended_limit', '20', 'Số lượng truyện đề xuất tối đa'),
        ('algorithm_status_min_chapters', '3', 'Số chương tối thiểu để chuyển từ draft sang published'),
        ('algorithm_websocket_enabled', 'false', 'Bật/tắt websocket cho cron job')
    ON CONFLICT (id) DO UPDATE SET
        value = EXCLUDED.value,
        description = EXCLUDED.description;
    RAISE NOTICE 'Đã tạo các thiết lập mặc định';

    -- Ghi nhận việc nhập dữ liệu mặc định
    INSERT INTO system_changes (change_type, description, sql_query, created_at)
    VALUES ('data', 'Dữ liệu mặc định đã được nhập', 'Nhập dữ liệu mặc định từ quá trình cài đặt', CURRENT_TIMESTAMP);
    RAISE NOTICE 'Đã ghi nhận nhập dữ liệu mặc định';
END $$;
