<div class="mb-4">
    <h4>Cài đặt hoàn tất</h4>
    <p>Xin chúc mừng! Hệ thống Web Truyện đã được cài đặt thành công và sẵn sàng sử dụng.</p>
    <div class="alert alert-success mb-4">
        <i class="fas fa-check-circle me-2"></i> Bạn có thể truy cập trang quản trị tại: <a href="<?= rtrim(BASE_URL, '/install') ?>/admin" class="alert-link fw-bold"><?= rtrim(BASE_URL, '/install') ?>/admin</a>
    </div>
</div>

<div class="card mb-4">
    <div class="card-header bg-primary text-white">
        <h5 class="mb-0">Cấu hình máy chủ</h5>
    </div>
    <div class="card-body">
        <?php
        // Đảm bảo các biến session tồn tại
        $serverType = $_SESSION['server_type'] ?? 'unknown';
        $serverConfigs = $_SESSION['server_configs'] ?? [
            'apache' => file_exists(INSTALL_PATH . 'server_configs/apache.txt') ? file_get_contents(INSTALL_PATH . 'server_configs/apache.txt') : 'Cấu hình không khả dụng',
            'nginx' => file_exists(INSTALL_PATH . 'server_configs/nginx.txt') ? file_get_contents(INSTALL_PATH . 'server_configs/nginx.txt') : 'Cấu hình không khả dụng',
            'openlitespeed' => file_exists(INSTALL_PATH . 'server_configs/openlitespeed.txt') ? file_get_contents(INSTALL_PATH . 'server_configs/openlitespeed.txt') : 'Cấu hình không khả dụng'
        ];

        // Nếu serverConfigs chỉ có một phần tử 'config', chuyển đổi nó sang định dạng mới
        if (isset($serverConfigs['config'])) {
            if ($serverType != 'unknown') {
                $serverConfigs = [$serverType => $serverConfigs['config']];
            } else {
                $serverConfigs = ['apache' => $serverConfigs['config']];
            }
        }

        // Xác định tab mặc định
        $defaultTab = 'apache';
        if ($serverType == 'nginx') {
            $defaultTab = 'nginx';
        } elseif ($serverType == 'openlitespeed') {
            $defaultTab = 'litespeed';
        }
        ?>

        <p>Hệ thống đã phát hiện bạn đang sử dụng: <strong><?= ucfirst($serverType) ?></strong></p>

        <ul class="nav nav-tabs mb-3" id="serverTabs" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link <?= ($defaultTab == 'apache') ? 'active' : '' ?>" id="apache-tab" data-bs-toggle="tab" data-bs-target="#apache" type="button" role="tab" aria-controls="apache" aria-selected="<?= ($defaultTab == 'apache') ? 'true' : 'false' ?>">Apache</button>
            </li>

            <li class="nav-item" role="presentation">
                <button class="nav-link <?= ($defaultTab == 'nginx') ? 'active' : '' ?>" id="nginx-tab" data-bs-toggle="tab" data-bs-target="#nginx" type="button" role="tab" aria-controls="nginx" aria-selected="<?= ($defaultTab == 'nginx') ? 'true' : 'false' ?>">Nginx</button>
            </li>

            <li class="nav-item" role="presentation">
                <button class="nav-link <?= ($defaultTab == 'litespeed') ? 'active' : '' ?>" id="litespeed-tab" data-bs-toggle="tab" data-bs-target="#litespeed" type="button" role="tab" aria-controls="litespeed" aria-selected="<?= ($defaultTab == 'litespeed') ? 'true' : 'false' ?>">OpenLiteSpeed</button>
            </li>
        </ul>

        <div class="tab-content" id="serverTabsContent">
            <div class="tab-pane fade <?= ($defaultTab == 'apache') ? 'show active' : '' ?>" id="apache" role="tabpanel" aria-labelledby="apache-tab">
                <div class="alert alert-info">
                    <i class="fas fa-info-circle me-2"></i>
                    <?php if ($serverType == 'apache'): ?>
                        File <code>.htaccess</code> đã được tự động tạo trong thư mục <code>public</code>.
                    <?php else: ?>
                        Sao chép nội dung dưới đây vào file <code>.htaccess</code> trong thư mục <code>public</code>.
                    <?php endif; ?>
                </div>
                <pre class="p-3 bg-light rounded"><code><?= htmlspecialchars($serverConfigs['apache'] ?? '') ?></code></pre>
            </div>

            <div class="tab-pane fade <?= ($defaultTab == 'nginx') ? 'show active' : '' ?>" id="nginx" role="tabpanel" aria-labelledby="nginx-tab">
                <div class="alert alert-info">
                    <i class="fas fa-info-circle me-2"></i> Sao chép nội dung dưới đây vào file cấu hình của Nginx và điều chỉnh các giá trị theo máy chủ của bạn.
                </div>
                <pre class="p-3 bg-light rounded"><code><?= htmlspecialchars($serverConfigs['nginx'] ?? '') ?></code></pre>
            </div>

            <div class="tab-pane fade <?= ($defaultTab == 'litespeed') ? 'show active' : '' ?>" id="litespeed" role="tabpanel" aria-labelledby="litespeed-tab">
                <div class="alert alert-info">
                    <i class="fas fa-info-circle me-2"></i> Sao chép nội dung dưới đây vào file cấu hình của OpenLiteSpeed.
                </div>
                <pre class="p-3 bg-light rounded"><code><?= htmlspecialchars($serverConfigs['openlitespeed'] ?? '') ?></code></pre>
            </div>
        </div>
    </div>
</div>

<div class="row mb-4">
    <div class="col-md-6">
        <div class="card h-100">
            <div class="card-header bg-light">
                <h5 class="mb-0">Các bước tiếp theo</h5>
            </div>
            <div class="card-body">
                <ul class="list-group list-group-flush">
                    <li class="list-group-item"><i class="fas fa-check text-success me-2"></i> Đăng nhập vào <a href="<?= rtrim(BASE_URL, '/install') ?>/admin">trang quản trị</a></li>
                    <li class="list-group-item"><i class="fas fa-cog text-secondary me-2"></i> Cấu hình các thiết lập chung của hệ thống</li>
                    <li class="list-group-item"><i class="fas fa-plus text-primary me-2"></i> Thêm nội dung truyện và thể loại</li>
                    <li class="list-group-item"><i class="fas fa-users text-info me-2"></i> Quản lý người dùng và phân quyền</li>
                </ul>
            </div>
        </div>
    </div>

    <div class="col-md-6">
        <div class="card h-100">
            <div class="card-header bg-light">
                <h5 class="mb-0">Tài nguyên hỗ trợ</h5>
            </div>
            <div class="card-body">
                <div class="d-grid gap-2">
                    <a href="https://example.com/documentation" target="_blank" class="btn btn-outline-primary">
                        <i class="fas fa-book me-2"></i> Tài liệu hướng dẫn
                    </a>
                    <a href="https://example.com/forum" target="_blank" class="btn btn-outline-secondary">
                        <i class="fas fa-comments me-2"></i> Diễn đàn hỗ trợ
                    </a>
                    <a href="https://example.com/tutorials" target="_blank" class="btn btn-outline-info">
                        <i class="fas fa-graduation-cap me-2"></i> Hướng dẫn và thủ thuật
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="text-center mt-4">
    <a href="<?= rtrim(BASE_URL, '/install') ?>" class="btn btn-primary btn-lg">
        <i class="fas fa-home me-2"></i> Truy cập trang chủ
    </a>
    <a href="<?= rtrim(BASE_URL, '/install') ?>/admin" class="btn btn-success btn-lg ms-2">
        <i class="fas fa-cog me-2"></i> Đến trang quản trị
    </a>
</div>
