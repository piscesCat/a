<?php if (isset($huongdan)): ?>
<div class="alert alert-warning"><i class="fa fa-info-circle me-2"></i><?= $huongdan ?></div>
<?php endif; ?>

<div class="mb-4">
    <h4>Cấu hình máy chủ Web</h4>
    <p>Chọn tab tương ứng để xem hướng dẫn và cấu hình từng loại máy chủ web.</p>
</div>

<?php
// Đọc nội dung cấu hình cho từng loại máy chủ
$apache = file_exists(INSTALL_PATH . 'server_configs/apache.txt') ? file_get_contents(INSTALL_PATH . 'server_configs/apache.txt') : 'Không có cấu hình Apache.';
$nginx = file_exists(INSTALL_PATH . 'server_configs/nginx.txt') ? file_get_contents(INSTALL_PATH . 'server_configs/nginx.txt') : 'Không có cấu hình Nginx.';
$ols = file_exists(INSTALL_PATH . 'server_configs/openlitespeed.txt') ? file_get_contents(INSTALL_PATH . 'server_configs/openlitespeed.txt') : 'Không có cấu hình OpenLiteSpeed.';
?>

<ul class="nav nav-tabs mb-3" id="serverTabs" role="tablist">
    <li class="nav-item" role="presentation">
        <button class="nav-link active" id="apache-tab" data-bs-toggle="tab" data-bs-target="#apache" type="button" role="tab" aria-controls="apache" aria-selected="true">Apache</button>
    </li>
    <li class="nav-item" role="presentation">
        <button class="nav-link" id="nginx-tab" data-bs-toggle="tab" data-bs-target="#nginx" type="button" role="tab" aria-controls="nginx" aria-selected="false">Nginx</button>
    </li>
    <li class="nav-item" role="presentation">
        <button class="nav-link" id="ols-tab" data-bs-toggle="tab" data-bs-target="#ols" type="button" role="tab" aria-controls="ols" aria-selected="false">OpenLiteSpeed</button>
    </li>
</ul>
<div class="tab-content" id="serverTabsContent">
    <div class="tab-pane fade show active" id="apache" role="tabpanel" aria-labelledby="apache-tab">
        <div class="alert alert-secondary"><strong>Hướng dẫn:</strong> Sao chép đoạn dưới đây dán vào file <code>.htaccess</code> trong thư mục <code>public</code> của web.<br>Nếu cài Apache, file này nên tự động tạo; nếu không có hãy tạo thủ công.</div>
        <pre class="p-3 bg-light rounded"><code id="apacheCode"><?= htmlspecialchars($apache) ?></code></pre>
        <button class="btn btn-outline-primary copy-code-btn" data-target="#apacheCode"><i class="fa fa-copy"></i> Sao chép</button>
    </div>
    <div class="tab-pane fade" id="nginx" role="tabpanel" aria-labelledby="nginx-tab">
        <div class="alert alert-info"><strong>Hướng dẫn:</strong> Sao chép đoạn dưới đây vào block <code>server</code> trong cấu hình nginx máy chủ của bạn (<code>/etc/nginx/sites-available/...</code>).<br>Đọc kỹ và đổi đường dẫn cho hợp lý.</div>
        <pre class="p-3 bg-light rounded"><code id="nginxCode"><?= htmlspecialchars($nginx) ?></code></pre>
        <button class="btn btn-outline-primary copy-code-btn" data-target="#nginxCode"><i class="fa fa-copy"></i> Sao chép</button>
    </div>
    <div class="tab-pane fade" id="ols" role="tabpanel" aria-labelledby="ols-tab">
        <div class="alert alert-warning"><strong>Hướng dẫn:</strong> Sao chép vào cấu hình Virtual Host cho OpenLiteSpeed. Đọc chú thích trực tiếp trong file để thay đổi giá trị phù hợp với server của bạn.</div>
        <pre class="p-3 bg-light rounded"><code id="olsCode"><?= htmlspecialchars($ols) ?></code></pre>
        <button class="btn btn-outline-primary copy-code-btn" data-target="#olsCode"><i class="fa fa-copy"></i> Sao chép</button>
    </div>
</div>

<script>
// Nút copy code
const copyBtns = document.querySelectorAll('.copy-code-btn');
copyBtns.forEach(btn => {
    btn.addEventListener('click', function() {
        const codeBlock = document.querySelector(btn.getAttribute('data-target'));
        if (codeBlock) {
            navigator.clipboard.writeText(codeBlock.textContent.trim());
            btn.innerHTML = '<i class="fa fa-check"></i> Đã sao chép';
            setTimeout(()=>btn.innerHTML='<i class="fa fa-copy"></i> Sao chép',2000);
        }
    });
});
</script>
