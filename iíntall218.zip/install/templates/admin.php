<div class="mb-4">
    <h4>Tạo tài khoản quản trị</h4>
    <p>Hãy tạo tài khoản quản trị viên và cấu hình các thiết lập cơ bản cho trang web của bạn.</p>
</div>

<form method="post" action="<?= BASE_URL ?>">
    <input type="hidden" name="step" value="admin">

    <div class="row">
        <div class="col-lg-6">
            <div class="card mb-4">
                <div class="card-header bg-light">
                    <h5 class="mb-0">Thông tin tài khoản</h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label for="admin_username" class="form-label">Tên đăng nhập:</label>
                        <input type="text" class="form-control" id="admin_username" name="admin_username" value="<?= $_SESSION['input']['admin_username'] ?? 'admin' ?>" required>
                        <div class="form-text">Tên đăng nhập dùng để truy cập hệ thống.</div>
                    </div>

                    <div class="mb-3">
                        <label for="admin_email" class="form-label">Email:</label>
                        <input type="email" class="form-control" id="admin_email" name="admin_email" value="<?= $_SESSION['input']['admin_email'] ?? '' ?>" required>
                        <div class="form-text">Email dùng để khôi phục mật khẩu và nhận thông báo.</div>
                    </div>

                    <div class="mb-3">
                        <label for="admin_password" class="form-label">Mật khẩu:</label>
                        <div class="input-group">
                            <input type="password" class="form-control" id="admin_password" name="admin_password" value="<?= $_SESSION['input']['admin_password'] ?? '' ?>" required minlength="6">
                            <button class="btn btn-outline-secondary toggle-password" type="button" data-target="#admin_password">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                        <div class="form-text">Mật khẩu phải có ít nhất 6 ký tự.</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-6">
            <div class="card mb-4">
                <div class="card-header bg-light">
                    <h5 class="mb-0">Thông tin trang web</h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label for="site_name" class="form-label">Tên trang web:</label>
                        <input type="text" class="form-control" id="site_name" name="site_name" value="<?= $_SESSION['input']['site_name'] ?? 'Web Truyện' ?>" required>
                        <div class="form-text">Tên hiển thị trên tiêu đề và các phần giao diện.</div>
                    </div>

                    <div class="mb-3">
                        <label for="site_description" class="form-label">Mô tả trang web:</label>
                        <textarea class="form-control" id="site_description" name="site_description" rows="3"><?= $_SESSION['input']['site_description'] ?? 'Trang web đọc truyện online miễn phí với nhiều thể loại truyện đa dạng' ?></textarea>
                        <div class="form-text">Mô tả ngắn gọn về trang web của bạn, hiển thị ở trang chủ và meta description.</div>
                    </div>

                    <div class="form-check form-switch mt-4">
                        <input class="form-check-input" type="checkbox" id="register_enabled" name="register_enabled" value="1" <?= isset($_SESSION['input']['register_enabled']) ? 'checked' : '' ?>>
                        <label class="form-check-label" for="register_enabled">Cho phép đăng ký tài khoản mới</label>
                    </div>

                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" id="comments_enabled" name="comments_enabled" value="1" checked>
                        <label class="form-check-label" for="comments_enabled">Cho phép bình luận</label>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Thêm phần cấu hình môi trường -->
    <div class="card mb-4">
        <div class="card-header bg-light">
            <h5 class="mb-0">Cấu hình môi trường (.env)</h5>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="app_url" class="form-label">URL ứng dụng:</label>
                        <input type="text" class="form-control" id="app_url" name="app_url" value="<?= $_SESSION['input']['app_url'] ?? rtrim(BASE_URL, '/install') ?>" required>
                        <div class="form-text">Địa chỉ đầy đủ đến trang web, không có dấu / ở cuối.</div>
                    </div>

                    <div class="mb-3">
                        <label for="timezone" class="form-label">Múi giờ:</label>
                        <select class="form-select" id="timezone" name="timezone">
                            <option value="Asia/Ho_Chi_Minh" <?= ($_SESSION['input']['timezone'] ?? 'Asia/Ho_Chi_Minh') == 'Asia/Ho_Chi_Minh' ? 'selected' : '' ?>>Việt Nam (UTC+7)</option>
                            <option value="Asia/Bangkok" <?= ($_SESSION['input']['timezone'] ?? '') == 'Asia/Bangkok' ? 'selected' : '' ?>>Thái Lan (UTC+7)</option>
                            <option value="Asia/Singapore" <?= ($_SESSION['input']['timezone'] ?? '') == 'Asia/Singapore' ? 'selected' : '' ?>>Singapore (UTC+8)</option>
                            <option value="Asia/Tokyo" <?= ($_SESSION['input']['timezone'] ?? '') == 'Asia/Tokyo' ? 'selected' : '' ?>>Nhật Bản (UTC+9)</option>
                            <option value="Europe/London" <?= ($_SESSION['input']['timezone'] ?? '') == 'Europe/London' ? 'selected' : '' ?>>London (UTC+0)</option>
                            <option value="America/New_York" <?= ($_SESSION['input']['timezone'] ?? '') == 'America/New_York' ? 'selected' : '' ?>>New York (UTC-5)</option>
                            <option value="UTC" <?= ($_SESSION['input']['timezone'] ?? '') == 'UTC' ? 'selected' : '' ?>>UTC</option>
                        </select>
                        <div class="form-text">Chọn múi giờ phù hợp với vị trí của bạn.</div>
                    </div>

                    <div class="mb-3">
                        <label for="default_locale" class="form-label">Ngôn ngữ mặc định:</label>
                        <select class="form-select" id="default_locale" name="default_locale">
                            <option value="vi" <?= ($_SESSION['input']['default_locale'] ?? 'vi') == 'vi' ? 'selected' : '' ?>>Tiếng Việt</option>
                            <option value="en" <?= ($_SESSION['input']['default_locale'] ?? '') == 'en' ? 'selected' : '' ?>>English</option>
                        </select>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="imgur_client_id" class="form-label">Imgur Client ID (tùy chọn):</label>
                        <input type="text" class="form-control" id="imgur_client_id" name="imgur_client_id" value="<?= $_SESSION['input']['imgur_client_id'] ?? '' ?>">
                        <div class="form-text">Client ID từ Imgur API để upload ảnh lên Imgur.</div>
                    </div>

                    <div class="mb-3">
                        <label for="imgur_client_secret" class="form-label">Imgur Client Secret (tùy chọn):</label>
                        <input type="text" class="form-control" id="imgur_client_secret" name="imgur_client_secret" value="<?= $_SESSION['input']['imgur_client_secret'] ?? '' ?>">
                        <div class="form-text">Client Secret từ Imgur API.</div>
                    </div>

                    <div class="mb-3">
                        <label for="app_key" class="form-label">App Key (bảo mật):</label>
                        <div class="input-group">
                            <input type="text" class="form-control" id="app_key" name="app_key" value="<?= $_SESSION['input']['app_key'] ?? bin2hex(random_bytes(16)) ?>">
                            <button class="btn btn-outline-secondary" type="button" onclick="document.getElementById('app_key').value = '<?= bin2hex(random_bytes(16)) ?>'">
                                <i class="fas fa-sync"></i>
                            </button>
                        </div>
                        <div class="form-text">Khóa bảo mật cho ứng dụng, được tạo ngẫu nhiên.</div>
                    </div>
                </div>
            </div>

            <!-- Thêm tab hiển thị tùy chọn nâng cao -->
            <div class="mt-3">
                <a class="btn btn-sm btn-outline-secondary" data-bs-toggle="collapse" href="#advancedEnvOptions" role="button" aria-expanded="false" aria-controls="advancedEnvOptions">
                    <i class="fas fa-cog me-1"></i> Tùy chọn nâng cao
                </a>

                <div class="collapse mt-3" id="advancedEnvOptions">
                    <div class="card card-body bg-light">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="app_debug" class="form-label">Chế độ Debug:</label>
                                    <select class="form-select" id="app_debug" name="app_debug">
                                        <option value="false" <?= ($_SESSION['input']['app_debug'] ?? 'false') == 'false' ? 'selected' : '' ?>>Tắt (khuyến nghị cho môi trường production)</option>
                                        <option value="true" <?= ($_SESSION['input']['app_debug'] ?? '') == 'true' ? 'selected' : '' ?>>Bật (chỉ dành cho phát triển)</option>
                                    </select>
                                </div>

                                <div class="mb-3">
                                    <label for="log_level" class="form-label">Mức độ ghi log:</label>
                                    <select class="form-select" id="log_level" name="log_level">
                                        <option value="error" <?= ($_SESSION['input']['log_level'] ?? 'error') == 'error' ? 'selected' : '' ?>>Error (chỉ lỗi nghiêm trọng)</option>
                                        <option value="warning" <?= ($_SESSION['input']['log_level'] ?? '') == 'warning' ? 'selected' : '' ?>>Warning (cảnh báo và lỗi)</option>
                                        <option value="info" <?= ($_SESSION['input']['log_level'] ?? '') == 'info' ? 'selected' : '' ?>>Info (thông tin chung)</option>
                                        <option value="debug" <?= ($_SESSION['input']['log_level'] ?? '') == 'debug' ? 'selected' : '' ?>>Debug (chi tiết, chỉ dành cho phát triển)</option>
                                    </select>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="cache_driver" class="form-label">Driver cache:</label>
                                    <select class="form-select" id="cache_driver" name="cache_driver">
                                        <option value="file" <?= ($_SESSION['input']['cache_driver'] ?? 'file') == 'file' ? 'selected' : '' ?>>File</option>
                                        <option value="redis" <?= ($_SESSION['input']['cache_driver'] ?? '') == 'redis' ? 'selected' : '' ?>>Redis</option>
                                        <option value="memcached" <?= ($_SESSION['input']['cache_driver'] ?? '') == 'memcached' ? 'selected' : '' ?>>Memcached</option>
                                    </select>
                                </div>

                                <div class="mb-3">
                                    <label for="session_driver" class="form-label">Driver session:</label>
                                    <select class="form-select" id="session_driver" name="session_driver">
                                        <option value="file" <?= ($_SESSION['input']['session_driver'] ?? 'file') == 'file' ? 'selected' : '' ?>>File</option>
                                        <option value="database" <?= ($_SESSION['input']['session_driver'] ?? '') == 'database' ? 'selected' : '' ?>>Database</option>
                                        <option value="redis" <?= ($_SESSION['input']['session_driver'] ?? '') == 'redis' ? 'selected' : '' ?>>Redis</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="alert alert-info mt-3">
        <i class="fas fa-info-circle me-2"></i> Sau khi hoàn tất cài đặt, bạn có thể truy cập trang quản trị tại đường dẫn <code><?= rtrim(BASE_URL, '/install') ?>/admin</code>
    </div>

    <div class="d-flex justify-content-between mt-4">
        <a href="?step=database" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-2"></i> Quay lại
        </a>

        <button type="submit" class="btn btn-primary">
            Tiếp tục <i class="fas fa-arrow-right ms-2"></i>
        </button>
    </div>
</form>
