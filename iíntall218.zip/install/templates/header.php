<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?? 'Cài đặt hệ thống' ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .card {
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            border: none;
        }
        .navbar-brand {
            font-weight: 700;
        }
        .steps {
            display: flex;
            margin-bottom: 30px;
            position: relative;
        }
        .steps::before {
            content: '';
            position: absolute;
            top: 20px;
            left: 0;
            right: 0;
            height: 2px;
            background: #e9ecef;
            z-index: 0;
        }
        .step {
            flex: 1;
            text-align: center;
            padding: 10px;
            position: relative;
            color: #6c757d;
            z-index: 1;
        }
        .step.active {
            color: #0d6efd;
            font-weight: 700;
        }
        .step.completed {
            color: #198754;
        }
        .step-number {
            display: inline-block;
            width: 40px;
            height: 40px;
            line-height: 40px;
            border-radius: 50%;
            background-color: #fff;
            border: 1px solid #ced4da;
            margin-bottom: 10px;
            position: relative;
            z-index: 2;
        }
        .step.active .step-number {
            background-color: #0d6efd;
            color: #fff;
            border-color: #0d6efd;
        }
        .step.completed .step-number {
            background-color: #198754;
            color: #fff;
            border-color: #198754;
        }
        .card-title {
            font-weight: 600;
            color: #1a1a1a;
        }
        .alert {
            border-radius: 8px;
        }
        .form-control:focus, .form-select:focus {
            box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.15);
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
        <div class="container">
            <a class="navbar-brand" href="#">Web Truyện Installer</a>
            <span class="navbar-text text-white">
                <i class="fas fa-code"></i> v<?= INSTALLER_VERSION ?>
            </span>
        </div>
    </nav>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-10">
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="steps">
                            <div class="step <?= $step >= 1 ? 'active' : '' ?> <?= $step > 1 ? 'completed' : '' ?>">
                                <div class="step-number"><?= $step > 1 ? '<i class="fas fa-check"></i>' : '1' ?></div>
                                <div class="step-title">Kiểm tra yêu cầu</div>
                            </div>
                            <div class="step <?= $step >= 2 ? 'active' : '' ?> <?= $step > 2 ? 'completed' : '' ?>">
                                <div class="step-number"><?= $step > 2 ? '<i class="fas fa-check"></i>' : '2' ?></div>
                                <div class="step-title">Cấu hình cơ sở dữ liệu</div>
                            </div>
                            <div class="step <?= $step >= 3 ? 'active' : '' ?> <?= $step > 3 ? 'completed' : '' ?>">
                                <div class="step-number"><?= $step > 3 ? '<i class="fas fa-check"></i>' : '3' ?></div>
                                <div class="step-title">Cấu hình quản trị</div>
                            </div>
                            <div class="step <?= $step >= 4 ? 'active' : '' ?>">
                                <div class="step-number"><?= $step > 4 ? '<i class="fas fa-check"></i>' : '4' ?></div>
                                <div class="step-title">Cấu hình máy chủ</div>
                            </div>
                            <div class="step <?= $step >= 5 ? 'active' : '' ?>">
                                <div class="step-number"><?= $step > 5 ? '<i class="fas fa-check"></i>' : '5' ?></div>
                                <div class="step-title">Hoàn tất</div>
                            </div>
                        </div>

                        <?php if (isset($_SESSION['error'])): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <i class="fas fa-exclamation-triangle me-2"></i> <?= $_SESSION['error'] ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                        <?php unset($_SESSION['error']); endif; ?>

                        <?php if (isset($_SESSION['success'])): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <i class="fas fa-check-circle me-2"></i> <?= $_SESSION['success'] ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                        <?php unset($_SESSION['success']); endif; ?>

                        <h2 class="card-title mb-4"><?= $title ?></h2>
