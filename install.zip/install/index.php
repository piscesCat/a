<?php
/**
 * Web Truyện - Installer
 * File cài đặt mã nguồn đơn giản và hiệu quả
 * Phiên bản 1.0.1
 */

// Định nghĩa các đường dẫn quan trọng
define('INSTALLER_VERSION', '1.0.1');
define('ROOTPATH', realpath(dirname(dirname(__FILE__)) . '/../') . '/');
define('APPPATH', ROOTPATH . 'app/');
define('VIEWPATH', APPPATH . 'Views/');
define('WRITEPATH', ROOTPATH . 'writable/');
define('INSTALL_PATH', __DIR__ . '/');

// Khởi tạo session
session_start();

// Thiết lập header và error reporting
header('Content-Type: text/html; charset=UTF-8');
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Xây dựng BASE_URL dựa trên thông tin request hiện tại
$base_url = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == "on") ? "https" : "http");
$base_url .= "://" . $_SERVER['HTTP_HOST'];
$base_url .= rtrim(dirname($_SERVER['PHP_SELF']), '/') . '/';
define('BASE_URL', $base_url);

// Xác định phương thức request hiện tại
$request_method = $_SERVER['REQUEST_METHOD'];

// Xác định bước cài đặt dựa trên tham số GET
$step = isset($_GET['step']) ? $_GET['step'] : 'welcome';

// Thiết lập giá trị step cho template (1-4)
$step_number = 1;
switch ($step) {
    case 'welcome':
        $step_number = 1;
        break;
    case 'database':
        $step_number = 2;
        break;
    case 'admin':
        $step_number = 3;
        break;
    case 'complete':
        $step_number = 4;
        break;
}

// Kiểm tra xem hệ thống đã được cài đặt chưa
function isInstalled() {
    return file_exists(INSTALL_PATH . 'installed.txt');
}

/**
 * ===================================================
 * SYSTEM CHECKS
 * ===================================================
 */

// Kiểm tra yêu cầu hệ thống
function checkRequirements() {
    return [
        [
            'name' => 'PHP Version',
            'required' => '7.4 or higher',
            'current' => PHP_VERSION,
            'status' => version_compare(PHP_VERSION, '7.4.0', '>=')
        ],
        [
            'name' => 'PDO PostgreSQL Extension',
            'required' => 'Enabled',
            'current' => extension_loaded('pdo_pgsql') ? 'Enabled' : 'Disabled',
            'status' => extension_loaded('pdo_pgsql')
        ],
        [
            'name' => 'Fileinfo Extension',
            'required' => 'Enabled',
            'current' => extension_loaded('fileinfo') ? 'Enabled' : 'Disabled',
            'status' => extension_loaded('fileinfo')
        ],
        [
            'name' => 'CURL Extension',
            'required' => 'Enabled',
            'current' => extension_loaded('curl') ? 'Enabled' : 'Disabled',
            'status' => extension_loaded('curl')
        ],
        [
            'name' => 'GD Extension',
            'required' => 'Enabled',
            'current' => extension_loaded('gd') ? 'Enabled' : 'Disabled',
            'status' => extension_loaded('gd')
        ],
        [
            'name' => 'JSON Extension',
            'required' => 'Enabled',
            'current' => extension_loaded('json') ? 'Enabled' : 'Disabled',
            'status' => extension_loaded('json')
        ]
    ];
}

// Kiểm tra quyền thư mục
function checkPermissions() {
    return [
        [
            'name' => 'writable/cache/',
            'required' => 'Writable',
            'current' => is_writable(WRITEPATH . 'cache') ? 'Writable' : 'Not Writable',
            'status' => is_writable(WRITEPATH . 'cache')
        ],
        [
            'name' => 'writable/logs/',
            'required' => 'Writable',
            'current' => is_writable(WRITEPATH . 'logs') ? 'Writable' : 'Not Writable',
            'status' => is_writable(WRITEPATH . 'logs')
        ],
        [
            'name' => 'writable/uploads/',
            'required' => 'Writable',
            'current' => is_writable(WRITEPATH . 'uploads') ? 'Writable' : 'Not Writable',
            'status' => is_writable(WRITEPATH . 'uploads')
        ],
        [
            'name' => 'public/',
            'required' => 'Writable',
            'current' => is_writable(ROOTPATH . 'public') ? 'Writable' : 'Not Writable',
            'status' => is_writable(ROOTPATH . 'public')
        ],
        [
            'name' => 'public/install/',
            'required' => 'Writable',
            'current' => is_writable(INSTALL_PATH) ? 'Writable' : 'Not Writable',
            'status' => is_writable(INSTALL_PATH)
        ]
    ];
}

/**
 * ===================================================
 * DATABASE FUNCTIONS
 * ===================================================
 */

// Lưu cấu hình database
function saveDatabaseConfig($hostname, $database, $username, $password, $port) {
    $configPath = APPPATH . 'Config/Database.php';
    $config = file_get_contents($configPath);

    // Replace database settings in config file
    $config = preg_replace("/'hostname' => '.*?'/", "'hostname' => '$hostname'", $config);
    $config = preg_replace("/'database' => '.*?'/", "'database' => '$database'", $config);
    $config = preg_replace("/'username' => '.*?'/", "'username' => '$username'", $config);
    $config = preg_replace("/'password' => '.*?'/", "'password' => '$password'", $config);
    $config = preg_replace("/'port' => .*?,/", "'port' => $port,", $config);

    // Save updated config file
    file_put_contents($configPath, $config);

    // Create a flag file to indicate database is configured
    file_put_contents(ROOTPATH . 'database_configured.txt', date('Y-m-d H:i:s'));

    return true;
}

// Tạo file .env từ cấu hình người dùng đã nhập
function createEnvFile($appName, $appUrl, $appKey, $imgurClientId, $imgurClientSecret, $dbHostname, $dbPort, $dbName, $dbUsername, $dbPassword) {
    $envContent = "# Tệp cấu hình môi trường (Environment Configuration)
# Được tạo tự động bởi quá trình cài đặt

# Thông tin ứng dụng
APP_NAME=\"$appName\"
APP_ENV=production
APP_KEY=$appKey
APP_DEBUG=false
APP_URL=$appUrl

# Cấu hình Cơ sở dữ liệu
DB_CONNECTION=pgsql
DB_HOSTNAME=$dbHostname
DB_PORT=$dbPort
DB_DATABASE=$dbName
DB_USERNAME=$dbUsername
DB_PASSWORD=$dbPassword

# Cấu hình API Imgur
IMGUR_CLIENT_ID=$imgurClientId
IMGUR_CLIENT_SECRET=$imgurClientSecret

# Thời gian JWT Token hết hạn (phút)
JWT_EXPIRE=60

# Các thiết lập khác
DEFAULT_LOCALE=vi
TIMEZONE=Asia/Ho_Chi_Minh
LOG_LEVEL=error
CACHE_DRIVER=file
SESSION_DRIVER=file
COOKIE_SECURE=false

# Cấu hình uploads
UPLOADS_PATH=writable/uploads
UPLOADS_MAX_SIZE=5M
UPLOADS_ALLOWED_TYPES=jpg,jpeg,png,gif,webp

# Cấu hình SEO
SEO_TITLE_MAX_LENGTH=70
SEO_DESCRIPTION_MAX_LENGTH=160
SEO_DEFAULT_IMAGE=/assets/images/default-share.jpg
";

    // Lưu file .env vào thư mục gốc
    file_put_contents(ROOTPATH . '.env', $envContent);

    // Tạo file .env.example nếu chưa có
    if (!file_exists(ROOTPATH . '.env.example')) {
        file_put_contents(ROOTPATH . '.env.example', $envContent);
    }

    return true;
}

// Import database schema
function importDatabaseSchema() {
    try {
        // Kết nối đến database
        $configPath = APPPATH . 'Config/Database.php';
        if (!file_exists($configPath)) {
            throw new Exception('Database configuration file not found.');
        }

        // Parse database config file để lấy thông tin kết nối
        $config = file_get_contents($configPath);
        preg_match("/'hostname' => '(.*?)'/", $config, $hostname);
        preg_match("/'database' => '(.*?)'/", $config, $database);
        preg_match("/'username' => '(.*?)'/", $config, $username);
        preg_match("/'password' => '(.*?)'/", $config, $password);
        preg_match("/'port' => (.*?),/", $config, $port);

        if (empty($hostname[1]) || empty($database[1]) || empty($username[1])) {
            throw new Exception('Database configuration is incomplete.');
        }

        // Kết nối database
        $dsn = "pgsql:host={$hostname[1]};port={$port[1]};dbname={$database[1]}";
        $pdo = new PDO($dsn, $username[1], $password[1]);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Kiểm tra xem database đã có bảng nào chưa
        $stmt = $pdo->query("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = 'public'");
        $tableCount = $stmt->fetchColumn();
        $databaseEmpty = ($tableCount == 0);

        // Xử lý trường hợp database không trống theo tùy chọn người dùng
        $dbHandleExisting = $_SESSION['input']['db_handle_existing'] ?? 'update';

        if (!$databaseEmpty) {
            if ($dbHandleExisting == 'recreate') {
                // Xóa toàn bộ bảng nếu người dùng chọn tạo lại
                $pdo->exec("DROP SCHEMA public CASCADE; CREATE SCHEMA public; GRANT ALL ON SCHEMA public TO PUBLIC;");
                $databaseEmpty = true;

                // Cần kết nối lại vì schema đã bị xóa
                $pdo = new PDO($dsn, $username[1], $password[1]);
                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            }
        }

        // Đọc file SQL cấu trúc
        $schema = file_get_contents(INSTALL_PATH . 'unified_schema.sql');
        if (empty($schema)) {
            throw new Exception('Schema file is empty or could not be read.');
        }

        // Thực thi SQL cấu trúc database
        $pdo->exec($schema);

        // Đọc và thực thi file dữ liệu mặc định
        $default_data = file_get_contents(INSTALL_PATH . 'default_data.sql');
        if (!empty($default_data)) {
            $pdo->exec($default_data);
        }

        return true;
    } catch (PDOException $e) {
        error_log('Database error in importDatabaseSchema: ' . $e->getMessage());
        $_SESSION['error'] = 'Database import error: ' . $e->getMessage();
        return false;
    } catch (Exception $e) {
        error_log('General error in importDatabaseSchema: ' . $e->getMessage());
        $_SESSION['error'] = 'Error: ' . $e->getMessage();
        return false;
    }
}

/**
 * ===================================================
 * USER & SETTINGS FUNCTIONS
 * ===================================================
 */

// Tạo tài khoản admin
function createAdminUser($username, $email, $password) {
    try {
        // Kết nối đến database
        $configPath = APPPATH . 'Config/Database.php';
        $config = file_get_contents($configPath);
        preg_match("/'hostname' => '(.*?)'/", $config, $hostname_db);
        preg_match("/'database' => '(.*?)'/", $config, $database_db);
        preg_match("/'username' => '(.*?)'/", $config, $username_db);
        preg_match("/'password' => '(.*?)'/", $config, $password_db);
        preg_match("/'port' => (.*?),/", $config, $port_db);

        // Kết nối database
        $dsn = "pgsql:host={$hostname_db[1]};port={$port_db[1]};dbname={$database_db[1]}";
        $pdo = new PDO($dsn, $username_db[1], $password_db[1]);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Hash mật khẩu
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Kiểm tra xem người dùng sáng lập đã tồn tại chưa
        $stmt = $pdo->prepare("SELECT * FROM users WHERE role = 3");
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            // Cập nhật người dùng sáng lập nếu đã tồn tại
            $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ?, password = ? WHERE role = 3");
            $stmt->execute([$username, $email, $hashed_password]);
        } else {
            // Tạo người dùng sáng lập mới
            $stmt = $pdo->prepare("INSERT INTO users (username, email, password, role, status, created_at, updated_at) VALUES (?, ?, ?, 3, 'active', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)");
            $stmt->execute([$username, $email, $hashed_password]);
        }

        return true;
    } catch (PDOException $e) {
        $_SESSION['error'] = 'Database error: ' . $e->getMessage();
        return false;
    } catch (Exception $e) {
        $_SESSION['error'] = 'Error: ' . $e->getMessage();
        return false;
    }
}

// Lưu cài đặt trang web
function saveSiteSettings($siteName, $siteDescription) {
    try {
        // Kết nối đến database
        $configPath = APPPATH . 'Config/Database.php';
        $config = file_get_contents($configPath);
        preg_match("/'hostname' => '(.*?)'/", $config, $hostname);
        preg_match("/'database' => '(.*?)'/", $config, $database);
        preg_match("/'username' => '(.*?)'/", $config, $username_db);
        preg_match("/'password' => '(.*?)'/", $config, $password_db);
        preg_match("/'port' => (.*?),/", $config, $port);

        // Kết nối database
        $dsn = "pgsql:host={$hostname[1]};port={$port[1]};dbname={$database[1]}";
        $pdo = new PDO($dsn, $username_db[1], $password_db[1]);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Lưu settings
        $settings = [
            'site_name' => $siteName,
            'site_description' => $siteDescription,
            'installed_at' => date('Y-m-d H:i:s')
        ];

        foreach ($settings as $name => $value) {
            // Check if setting exists
            $stmt = $pdo->prepare("SELECT id FROM settings WHERE id = ?");
            $stmt->execute([$name]);

            if ($stmt->rowCount() > 0) {
                // Update existing setting
                $stmt = $pdo->prepare("UPDATE settings SET value = ? WHERE id = ?");
                $stmt->execute([$value, $name]);
            } else {
                // Insert new setting
                $stmt = $pdo->prepare("INSERT INTO settings (id, value) VALUES (?, ?)");
                $stmt->execute([$name, $value]);
            }
        }

        return true;
    } catch (PDOException $e) {
        $_SESSION['error'] = 'Database error: ' . $e->getMessage();
        return false;
    } catch (Exception $e) {
        $_SESSION['error'] = 'Error: ' . $e->getMessage();
        return false;
    }
}

/**
 * ===================================================
 * SERVER & COMPLETION FUNCTIONS
 * ===================================================
 */

// Hoàn thành cài đặt
function completeInstallation($siteName = null, $siteDescription = null) {
    // Tạo flag file để đánh dấu cài đặt hoàn tất
    file_put_contents(INSTALL_PATH . 'installed.txt', date('Y-m-d H:i:s'));

    // Xóa file chỉ báo cấu hình database nếu tồn tại
    if (file_exists(ROOTPATH . 'database_configured.txt')) {
        @unlink(ROOTPATH . 'database_configured.txt');
    }

    // Cập nhật file .env nếu có thông tin trang web
    if ($siteName && file_exists(ROOTPATH . '.env')) {
        $envContent = file_get_contents(ROOTPATH . '.env');

        // Cập nhật tên ứng dụng
        $envContent = preg_replace('/APP_NAME=\".*?\"/', 'APP_NAME="' . addslashes($siteName) . '"', $envContent);

        // Đặt lại chế độ debug thành false cho môi trường sản xuất
        $envContent = preg_replace('/APP_DEBUG=.*/', 'APP_DEBUG=false', $envContent);

        // Lưu file .env đã cập nhật
        file_put_contents(ROOTPATH . '.env', $envContent);
    }

    // Phát hiện kiểu máy chủ web
    $serverType = detectWebServer();

    // Nếu là Apache, tự động áp dụng cấu hình
    if ($serverType === 'apache') {
        applyApacheConfig();
    }

    // Lưu thông tin kiểu máy chủ web vào session để hiển thị ở trang hoàn tất
    $_SESSION['server_type'] = $serverType;
    $_SESSION['server_configs'] = getServerConfig($serverType);

    return true;
}

// Tự động phát hiện loại máy chủ web
function detectWebServer() {
    $server_software = $_SERVER['SERVER_SOFTWARE'] ?? '';

    if (stripos($server_software, 'apache') !== false) {
        return 'apache';
    } elseif (stripos($server_software, 'nginx') !== false) {
        return 'nginx';
    } elseif (stripos($server_software, 'litespeed') !== false) {
        return 'openlitespeed';
    } else {
        // Không thể xác định chính xác
        return 'unknown';
    }
}

// Lấy nội dung cấu hình máy chủ dựa trên loại
function getServerConfig($type) {
    $configPath = INSTALL_PATH . 'server_configs/';

    switch ($type) {
        case 'apache':
            return [
                'config' => file_get_contents($configPath . 'apache.txt')
            ];
        case 'nginx':
            return [
                'config' => file_get_contents($configPath . 'nginx.txt')
            ];
        case 'openlitespeed':
            return [
                'config' => file_get_contents($configPath . 'openlitespeed.txt')
            ];
        default:
            return [
                'apache' => file_get_contents($configPath . 'apache.txt'),
                'nginx' => file_get_contents($configPath . 'nginx.txt'),
                'openlitespeed' => file_get_contents($configPath . 'openlitespeed.txt')
            ];
    }
}

// Áp dụng cấu hình Apache
function applyApacheConfig() {
    $configPath = INSTALL_PATH . 'server_configs/';
    $serverConfig = file_get_contents($configPath . 'apache.txt');

    // Viết file .htaccess vào thư mục public
    if (is_writable(ROOTPATH . 'public')) {
        file_put_contents(ROOTPATH . 'public/.htaccess', $serverConfig);
    }

    return true;
}

// Hàm hiển thị template
function view($template, $data = []) {
    extract($data);

    // Đảm bảo thư mục template tồn tại
    $templateDir = INSTALL_PATH . 'templates/';
    if (!is_dir($templateDir)) {
        mkdir($templateDir, 0755, true);
    }

    // Kiểm tra xem file template tồn tại không
    $templatePath = $templateDir . $template . '.php';
    if (!file_exists($templatePath)) {
        die("Template $template không tồn tại");
    }

    // Include template header
    include INSTALL_PATH . 'templates/header.php';

    // Include template chính
    include INSTALL_PATH . 'templates/' . $template . '.php';

    // Include template footer
    include INSTALL_PATH . 'templates/footer.php';
}

/**
 * ===================================================
 * HANDLE REQUEST
 * ===================================================
 */

// Nếu hệ thống đã được cài đặt và không phải trang hoàn thành, chuyển hướng đến trang chính
if (isInstalled() && $step != 'complete') {
    header('Location: ' . BASE_URL . '?step=complete');
    exit;
}

// Xử lý các POST request
if ($request_method === 'POST') {
    // Lưu input vào session để dữ liệu được lưu giữ giữa các bước
    if (isset($_POST)) {
        $_SESSION['input'] = $_POST;
    }

    // Xử lý theo bước hiện tại
    switch ($step) {
        case 'database':
            // Validate input
            if (empty($_POST['db_hostname']) || empty($_POST['db_name']) || empty($_POST['db_username'])) {
                $_SESSION['error'] = 'Vui lòng điền đầy đủ thông tin kết nối cơ sở dữ liệu.';
                header('Location: ' . BASE_URL . '?step=database');
                exit;
            }

            // Thử kết nối đến database
            try {
                $dsn = "pgsql:host={$_POST['db_hostname']};port={$_POST['db_port']};dbname={$_POST['db_name']}";
                $pdo = new PDO($dsn, $_POST['db_username'], $_POST['db_password']);
                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                // Lưu cấu hình database
                saveDatabaseConfig(
                    $_POST['db_hostname'],
                    $_POST['db_name'],
                    $_POST['db_username'],
                    $_POST['db_password'],
                    $_POST['db_port']
                );

                // Tạo file .env
                createEnvFile(
                    $_POST['app_name'],
                    $_POST['app_url'],
                    $_POST['app_key'],
                    $_POST['imgur_client_id'],
                    $_POST['imgur_client_secret'],
                    $_POST['db_hostname'],
                    $_POST['db_port'],
                    $_POST['db_name'],
                    $_POST['db_username'],
                    $_POST['db_password']
                );

                // Import database schema
                if (!importDatabaseSchema()) {
                    $_SESSION['error'] = 'Gặp lỗi khi import cấu trúc cơ sở dữ liệu.';
                    header('Location: ' . BASE_URL . '?step=database');
                    exit;
                }

                // Redirect to next step
                $_SESSION['success'] = 'Đã kết nối thành công đến cơ sở dữ liệu và import cấu trúc.';
                header('Location: ' . BASE_URL . '?step=admin');
                exit;
            } catch (PDOException $e) {
                $_SESSION['error'] = 'Không thể kết nối đến cơ sở dữ liệu: ' . $e->getMessage();
                header('Location: ' . BASE_URL . '?step=database');
                exit;
            }
            break;

        case 'admin':
            // Validate input
            if (empty($_POST['admin_username']) || empty($_POST['admin_email']) || empty($_POST['admin_password'])) {
                $_SESSION['error'] = 'Vui lòng điền đầy đủ thông tin tài khoản quản trị.';
                header('Location: ' . BASE_URL . '?step=admin');
                exit;
            }

            // Validate password length
            if (strlen($_POST['admin_password']) < 6) {
                $_SESSION['error'] = 'Mật khẩu phải có ít nhất 6 ký tự.';
                header('Location: ' . BASE_URL . '?step=admin');
                exit;
            }

            // Tạo tài khoản quản trị
            if (!createAdminUser($_POST['admin_username'], $_POST['admin_email'], $_POST['admin_password'])) {
                header('Location: ' . BASE_URL . '?step=admin');
                exit;
            }

            // Lưu cài đặt trang web
            saveSiteSettings($_POST['site_name'], $_POST['site_description']);

            // Hoàn thành cài đặt
            completeInstallation($_POST['site_name'], $_POST['site_description']);

            // Redirect to complete step
            $_SESSION['success'] = 'Đã cài đặt thành công hệ thống!';
            header('Location: ' . BASE_URL . '?step=complete');
            exit;
            break;
    }
}

// Hiển thị template tương ứng với bước hiện tại
$title = '';
switch ($step) {
    case 'welcome':
        $title = 'Chào mừng đến với Cài đặt Web Truyện';
        $requirements = checkRequirements();
        $permissions = checkPermissions();
        view('welcome', [
            'title' => $title,
            'step' => $step_number,
            'requirements' => $requirements,
            'permissions' => $permissions
        ]);
        break;

    case 'database':
        $title = 'Cấu hình Cơ sở dữ liệu';
        view('database', [
            'title' => $title,
            'step' => $step_number
        ]);
        break;

    case 'admin':
        $title = 'Tạo tài khoản quản trị';
        view('admin', [
            'title' => $title,
            'step' => $step_number
        ]);
        break;

    case 'complete':
        $title = 'Hoàn tất Cài đặt';
        view('complete', [
            'title' => $title,
            'step' => $step_number
        ]);
        break;

    default:
        // Redirect to welcome page for invalid steps
        header('Location: ' . BASE_URL);
        exit;
}
