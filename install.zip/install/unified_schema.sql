-- =========================================
-- KIỂM TRA TRẠNG THÁI DATABASE
-- =========================================

-- Function kiểm tra database có trống không
CREATE OR REPLACE FUNCTION check_database_empty() RETURNS BOOLEAN AS $$
DECLARE
    table_count INTEGER;
BEGIN
    -- Đếm số bảng trong schema public
    SELECT COUNT(*) INTO table_count
    FROM information_schema.tables
    WHERE table_schema = 'public';

    -- Trả về TRUE nếu không có bảng nào
    RETURN table_count = 0;
END;
$$ LANGUAGE plpgsql;

-- Kiểm tra nếu database không trống
DO $$$
BEGIN
    IF NOT check_database_empty() THEN
        -- Thông báo và thoát nếu database đã có dữ liệu
        RAISE NOTICE 'Database không trống. Tiếp tục quá trình cài đặt sẽ kiểm tra và cập nhật cấu trúc nếu cần.';
    ELSE
        RAISE NOTICE 'Database trống. Tiến hành tạo cấu trúc cơ sở dữ liệu mới.';
    END IF;
END $$$$;

-- Hàm kiểm tra sự tồn tại của bảng
CREATE OR REPLACE FUNCTION table_exists(tablename TEXT) RETURNS BOOLEAN AS $$
DECLARE
    exists BOOLEAN;
BEGIN
    SELECT COUNT(*) > 0 INTO exists
    FROM information_schema.tables
    WHERE table_schema = 'public'
    AND table_name = tablename;

    RETURN exists;
END;
$$ LANGUAGE plpgsql;

-- Hàm kiểm tra sự tồn tại của cột trong bảng
CREATE OR REPLACE FUNCTION column_exists(tablename TEXT, columnname TEXT) RETURNS BOOLEAN AS $$
DECLARE
    exists BOOLEAN;
BEGIN
    SELECT COUNT(*) > 0 INTO exists
    FROM information_schema.columns
    WHERE table_schema = 'public'
    AND table_name = tablename
    AND column_name = columnname;

    RETURN exists;
END;
$$ LANGUAGE plpgsql;

-- =========================================
-- DATABASE SCHEMA
-- =========================================

-- CORE TABLES
-- =========================================

-- Tạo bảng users nếu chưa tồn tại
DO $$
BEGIN
    IF NOT table_exists('users') THEN
        CREATE TABLE users (
            id SERIAL PRIMARY KEY,
            username VARCHAR(50) NOT NULL UNIQUE,
            email VARCHAR(100) NOT NULL UNIQUE,
            password VARCHAR(255) NOT NULL,
            role SMALLINT NOT NULL DEFAULT 1, -- 1: Cộng tác viên, 2: Admin, 3: Người sáng lập
            status VARCHAR(20) NOT NULL DEFAULT 'active',
            avatar VARCHAR(255),
            bio TEXT,
            last_login TIMESTAMP,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        RAISE NOTICE 'Đã tạo bảng users';
    ELSE
        RAISE NOTICE 'Bảng users đã tồn tại, bỏ qua';
    END IF;
END $$$;

-- Tạo bảng categories nếu chưa tồn tại
DO $$
BEGIN
    IF NOT table_exists('categories') THEN
        CREATE TABLE categories (
            id SERIAL PRIMARY KEY,
            name VARCHAR(50) NOT NULL,
            slug VARCHAR(50) NOT NULL UNIQUE,
            description TEXT,
            parent_id INTEGER REFERENCES categories(id) ON DELETE SET NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        RAISE NOTICE 'Đã tạo bảng categories';
    ELSE
        RAISE NOTICE 'Bảng categories đã tồn tại, bỏ qua';
    END IF;
END $$$;

-- Tạo bảng stories nếu chưa tồn tại
DO $$
BEGIN
    IF NOT table_exists('stories') THEN
        CREATE TABLE stories (
            id SERIAL PRIMARY KEY,
            title VARCHAR(200) NOT NULL,
            slug VARCHAR(200) NOT NULL UNIQUE,
            description TEXT,
            cover_image VARCHAR(255),
            author_name VARCHAR(100), -- Tên tác giả thật của tác phẩm
            publisher_id INTEGER REFERENCES users(id) ON DELETE SET NULL, -- Người đăng/xuất bản truyện lên hệ thống
            status VARCHAR(20) NOT NULL DEFAULT 'draft',
            views INTEGER DEFAULT 0,
            views_day INTEGER DEFAULT 0, -- Lượt xem trong ngày
            views_week INTEGER DEFAULT 0, -- Lượt xem trong tuần
            views_month INTEGER DEFAULT 0, -- Lượt xem trong tháng
            rating DECIMAL(3,2) DEFAULT 0,
            total_ratings INTEGER DEFAULT 0, -- Tổng số đánh giá
            total_favorites INTEGER DEFAULT 0, -- Tổng số yêu thích
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            type VARCHAR(50), -- Loại truyện (phim lẻ, phim bộ, review)
            country VARCHAR(100), -- Quốc gia (thay thế cho country_id)
            release_year INTEGER, -- Năm phát hành
            is_featured BOOLEAN DEFAULT FALSE, -- Nổi bật
            is_recommended BOOLEAN DEFAULT FALSE, -- Đề xuất
            is_completed BOOLEAN DEFAULT FALSE, -- Hoàn thành
            is_hot BOOLEAN DEFAULT FALSE, -- Truyện HOT
            chapter_count INTEGER DEFAULT 0 -- Số lượng chương
        );
        RAISE NOTICE 'Đã tạo bảng stories';
    ELSE
        -- Kiểm tra và thêm cột chapter_count nếu chưa tồn tại
        IF NOT column_exists('stories', 'chapter_count') THEN
            ALTER TABLE stories ADD COLUMN chapter_count INTEGER DEFAULT 0;
            RAISE NOTICE 'Đã thêm cột chapter_count vào bảng stories';

            -- Cập nhật số lượng chương cho tất cả truyện
            UPDATE stories s
            SET chapter_count = (
                SELECT COUNT(*)
                FROM chapters c
                WHERE c.story_id = s.id
            );
            RAISE NOTICE 'Đã cập nhật số lượng chương cho tất cả truyện';
        END IF;

        RAISE NOTICE 'Bảng stories đã tồn tại, đã kiểm tra và cập nhật cấu trúc nếu cần';
    END IF;
END $$$;

-- Tạo bảng story_categories nếu chưa tồn tại
DO $$
BEGIN
    IF NOT table_exists('story_categories') THEN
        CREATE TABLE story_categories (
            story_id INTEGER REFERENCES stories(id) ON DELETE CASCADE,
            category_id INTEGER REFERENCES categories(id) ON DELETE CASCADE,
            PRIMARY KEY (story_id, category_id)
        );
        RAISE NOTICE 'Đã tạo bảng story_categories';
    ELSE
        RAISE NOTICE 'Bảng story_categories đã tồn tại, bỏ qua';
    END IF;
END $$$;

-- Tạo bảng chapters nếu chưa tồn tại
DO $$
BEGIN
    IF NOT table_exists('chapters') THEN
        CREATE TABLE chapters (
            id SERIAL PRIMARY KEY,
            story_id INTEGER REFERENCES stories(id) ON DELETE CASCADE,
            chapter_number INTEGER NOT NULL,
            title VARCHAR(200) NOT NULL,
            content TEXT NOT NULL,
            views INTEGER DEFAULT 0,
            status VARCHAR(20) NOT NULL DEFAULT 'draft',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE (story_id, chapter_number)
        );
        RAISE NOTICE 'Đã tạo bảng chapters';
    ELSE
        RAISE NOTICE 'Bảng chapters đã tồn tại, bỏ qua';
    END IF;
END $$$;

-- =========================================
-- USER INTERACTION TABLES
-- =========================================

-- Tạo bảng reading_progress nếu chưa tồn tại
DO $$
BEGIN
    IF NOT table_exists('reading_progress') THEN
        CREATE TABLE reading_progress (
            id SERIAL PRIMARY KEY,
            user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
            story_id INTEGER REFERENCES stories(id) ON DELETE CASCADE,
            chapter_id INTEGER REFERENCES chapters(id) ON DELETE CASCADE,
            last_read TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE (user_id, story_id)
        );
        RAISE NOTICE 'Đã tạo bảng reading_progress';
    ELSE
        RAISE NOTICE 'Bảng reading_progress đã tồn tại, bỏ qua';
    END IF;
END $$;

-- Tạo bảng ratings nếu chưa tồn tại
DO $$
BEGIN
    IF NOT table_exists('ratings') THEN
        CREATE TABLE ratings (
            id SERIAL PRIMARY KEY,
            user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
            story_id INTEGER REFERENCES stories(id) ON DELETE CASCADE,
            rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE (user_id, story_id)
        );
        RAISE NOTICE 'Đã tạo bảng ratings';
    ELSE
        RAISE NOTICE 'Bảng ratings đã tồn tại, bỏ qua';
    END IF;
END $$;

-- Tạo bảng comments nếu chưa tồn tại
DO $$
BEGIN
    IF NOT table_exists('comments') THEN
        CREATE TABLE comments (
            id SERIAL PRIMARY KEY,
            user_id INTEGER REFERENCES users(id) ON DELETE SET NULL, -- Cho phép bình luận không cần đăng nhập (NULL)
            story_id INTEGER REFERENCES stories(id) ON DELETE CASCADE,
            chapter_id INTEGER REFERENCES chapters(id) ON DELETE CASCADE,
            content TEXT NOT NULL,
            guest_name VARCHAR(100), -- Tên người bình luận khách
            guest_email VARCHAR(100), -- Email người bình luận khách
            parent_id INTEGER REFERENCES comments(id) ON DELETE CASCADE, -- ID bình luận cha (nếu là reply)
            is_admin_reply BOOLEAN DEFAULT FALSE, -- Đánh dấu nếu là reply từ admin
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        RAISE NOTICE 'Đã tạo bảng comments';
    ELSE
        RAISE NOTICE 'Bảng comments đã tồn tại, bỏ qua';
    END IF;
END $$;

-- Tạo bảng activities nếu chưa tồn tại
DO $$
BEGIN
    IF NOT table_exists('activities') THEN
        CREATE TABLE activities (
            id SERIAL PRIMARY KEY,
            user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
            action VARCHAR(100) NOT NULL,
            details JSONB,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        RAISE NOTICE 'Đã tạo bảng activities';
    ELSE
        RAISE NOTICE 'Bảng activities đã tồn tại, bỏ qua';
    END IF;
END $$;

-- =========================================
-- SYSTEM TABLES
-- =========================================

-- Tạo bảng settings nếu chưa tồn tại
DO $$
BEGIN
    IF NOT table_exists('settings') THEN
        CREATE TABLE settings (
            id VARCHAR(50) PRIMARY KEY,
            value TEXT NOT NULL,
            description TEXT,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        RAISE NOTICE 'Đã tạo bảng settings';
    ELSE
        RAISE NOTICE 'Bảng settings đã tồn tại, bỏ qua';
    END IF;
END $$;

-- Tạo bảng tokens nếu chưa tồn tại
DO $$
BEGIN
    IF NOT table_exists('tokens') THEN
        CREATE TABLE tokens (
            id SERIAL PRIMARY KEY,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            token VARCHAR(255) NOT NULL UNIQUE,
            expires_at TIMESTAMP NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        RAISE NOTICE 'Đã tạo bảng tokens';
    ELSE
        RAISE NOTICE 'Bảng tokens đã tồn tại, bỏ qua';
    END IF;
END $$;

-- Tạo bảng media nếu chưa tồn tại
DO $$
BEGIN
    IF NOT table_exists('media') THEN
        CREATE TABLE media (
            id SERIAL PRIMARY KEY,
            file_name VARCHAR(255) NOT NULL,
            file_path VARCHAR(255) NOT NULL,
            file_type VARCHAR(50) NOT NULL,
            file_size INTEGER NOT NULL,
            user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
            uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        RAISE NOTICE 'Đã tạo bảng media';
    ELSE
        RAISE NOTICE 'Bảng media đã tồn tại, bỏ qua';
    END IF;
END $$;

-- Tạo bảng backups nếu chưa tồn tại
DO $$
BEGIN
    IF NOT table_exists('backups') THEN
        CREATE TABLE backups (
            id SERIAL PRIMARY KEY,
            file_name VARCHAR(255) NOT NULL,
            file_path VARCHAR(255) NOT NULL,
            file_size INTEGER NOT NULL,
            description TEXT,
            user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        RAISE NOTICE 'Đã tạo bảng backups';
    ELSE
        RAISE NOTICE 'Bảng backups đã tồn tại, bỏ qua';
    END IF;
END $$;

-- Tạo bảng logs nếu chưa tồn tại
DO $$
BEGIN
    IF NOT table_exists('logs') THEN
        CREATE TABLE logs (
            id SERIAL PRIMARY KEY,
            level VARCHAR(20) NOT NULL,
            message TEXT NOT NULL,
            context JSONB,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        RAISE NOTICE 'Đã tạo bảng logs';
    ELSE
        RAISE NOTICE 'Bảng logs đã tồn tại, bỏ qua';
    END IF;
END $$;

-- Tạo bảng system_changes nếu chưa tồn tại
DO $$
BEGIN
    IF NOT table_exists('system_changes') THEN
        CREATE TABLE system_changes (
            id SERIAL PRIMARY KEY,
            change_type VARCHAR(50) NOT NULL,
            description TEXT NOT NULL,
            sql_query TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        RAISE NOTICE 'Đã tạo bảng system_changes';
    ELSE
        RAISE NOTICE 'Bảng system_changes đã tồn tại, bỏ qua';
    END IF;
END $$;

-- Tạo bảng story_stats nếu chưa tồn tại
DO $$
BEGIN
    IF NOT table_exists('story_stats') THEN
        CREATE TABLE story_stats (
            id SERIAL PRIMARY KEY,
            story_id INTEGER NOT NULL REFERENCES stories(id) ON DELETE CASCADE,
            date DATE NOT NULL,
            views INTEGER DEFAULT 0,
            views_daily INTEGER DEFAULT 0,
            views_weekly INTEGER DEFAULT 0,
            views_monthly INTEGER DEFAULT 0,
            ratings_count INTEGER DEFAULT 0,
            ratings_avg DECIMAL(3,2) DEFAULT 0,
            favorites_count INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE (story_id, date)
        );
        RAISE NOTICE 'Đã tạo bảng story_stats';
    ELSE
        RAISE NOTICE 'Bảng story_stats đã tồn tại, bỏ qua';
    END IF;
END $$;

-- =========================================
-- INDEXES
-- =========================================

-- Tạo các indexes nếu chưa tồn tại
DO $$
BEGIN
    -- Indexes for stories table
    IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_stories_slug') THEN
        CREATE INDEX idx_stories_slug ON stories(slug);
        RAISE NOTICE 'Đã tạo index idx_stories_slug';
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_stories_publisher_id') THEN
        CREATE INDEX idx_stories_publisher_id ON stories(publisher_id);
        RAISE NOTICE 'Đã tạo index idx_stories_publisher_id';
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_stories_is_recommended') THEN
        CREATE INDEX idx_stories_is_recommended ON stories(is_recommended);
        RAISE NOTICE 'Đã tạo index idx_stories_is_recommended';
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_stories_country') THEN
        CREATE INDEX idx_stories_country ON stories(country);
        RAISE NOTICE 'Đã tạo index idx_stories_country';
    END IF;

    -- Indexes for chapters table
    IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_chapters_story') THEN
        CREATE INDEX idx_chapters_story ON chapters(story_id);
        RAISE NOTICE 'Đã tạo index idx_chapters_story';
    END IF;

    -- Indexes for categories table
    IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_categories_slug') THEN
        CREATE INDEX idx_categories_slug ON categories(slug);
        RAISE NOTICE 'Đã tạo index idx_categories_slug';
    END IF;

    -- Indexes for reading_progress table
    IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_reading_progress_user') THEN
        CREATE INDEX idx_reading_progress_user ON reading_progress(user_id);
        RAISE NOTICE 'Đã tạo index idx_reading_progress_user';
    END IF;

    -- Indexes for comments table
    IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_comments_story') THEN
        CREATE INDEX idx_comments_story ON comments(story_id);
        RAISE NOTICE 'Đã tạo index idx_comments_story';
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_comments_chapter') THEN
        CREATE INDEX idx_comments_chapter ON comments(chapter_id);
        RAISE NOTICE 'Đã tạo index idx_comments_chapter';
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_comments_parent') THEN
        CREATE INDEX idx_comments_parent ON comments(parent_id);
        RAISE NOTICE 'Đã tạo index idx_comments_parent';
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_comments_user_id') THEN
        CREATE INDEX idx_comments_user_id ON comments(user_id);
        RAISE NOTICE 'Đã tạo index idx_comments_user_id';
    END IF;

    -- Indexes for activities table
    IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_activities_user') THEN
        CREATE INDEX idx_activities_user ON activities(user_id);
        RAISE NOTICE 'Đã tạo index idx_activities_user';
    END IF;

    -- Indexes for tokens table
    IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_tokens_user_id') THEN
        CREATE INDEX idx_tokens_user_id ON tokens(user_id);
        RAISE NOTICE 'Đã tạo index idx_tokens_user_id';
    END IF;

    -- Indexes for media table
    IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_media_user_id') THEN
        CREATE INDEX idx_media_user_id ON media(user_id);
        RAISE NOTICE 'Đã tạo index idx_media_user_id';
    END IF;

    -- Indexes for backups table
    IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_backups_user_id') THEN
        CREATE INDEX idx_backups_user_id ON backups(user_id);
        RAISE NOTICE 'Đã tạo index idx_backups_user_id';
    END IF;

    -- Indexes for story_stats table
    IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_story_stats_story_id') THEN
        CREATE INDEX idx_story_stats_story_id ON story_stats(story_id);
        RAISE NOTICE 'Đã tạo index idx_story_stats_story_id';
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_story_stats_date') THEN
        CREATE INDEX idx_story_stats_date ON story_stats(date);
        RAISE NOTICE 'Đã tạo index idx_story_stats_date';
    END IF;
END $$;

-- =========================================
-- TRIGGERS
-- =========================================

-- Tạo trigger function để cập nhật thời gian updated_at
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_proc WHERE proname = 'update_updated_at_column') THEN
        CREATE OR REPLACE FUNCTION update_updated_at_column()
        RETURNS TRIGGER AS $$
        BEGIN
            NEW.updated_at = CURRENT_TIMESTAMP;
            RETURN NEW;
        END;
        $$ LANGUAGE plpgsql;
        RAISE NOTICE 'Đã tạo function update_updated_at_column';
    END IF;
END $$;

-- Tạo trigger cho bảng stories
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'update_stories_updated_at') THEN
        CREATE TRIGGER update_stories_updated_at
        BEFORE UPDATE ON stories
        FOR EACH ROW
        EXECUTE FUNCTION update_updated_at_column();
        RAISE NOTICE 'Đã tạo trigger update_stories_updated_at';
    END IF;
END $$;

-- Tạo trigger cho bảng chapters
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'update_chapters_updated_at') THEN
        CREATE TRIGGER update_chapters_updated_at
        BEFORE UPDATE ON chapters
        FOR EACH ROW
        EXECUTE FUNCTION update_updated_at_column();
        RAISE NOTICE 'Đã tạo trigger update_chapters_updated_at';
    END IF;
END $$;

-- Tạo trigger cho bảng users
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'update_users_updated_at') THEN
        CREATE TRIGGER update_users_updated_at
        BEFORE UPDATE ON users
        FOR EACH ROW
        EXECUTE FUNCTION update_updated_at_column();
        RAISE NOTICE 'Đã tạo trigger update_users_updated_at';
    END IF;
END $$;

-- Tạo trigger cho bảng comments
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'update_comments_updated_at') THEN
        CREATE TRIGGER update_comments_updated_at
        BEFORE UPDATE ON comments
        FOR EACH ROW
        EXECUTE FUNCTION update_updated_at_column();
        RAISE NOTICE 'Đã tạo trigger update_comments_updated_at';
    END IF;
END $$;

-- Tạo trigger function để cập nhật số lượng chương
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_proc WHERE proname = 'update_story_chapter_count') THEN
        CREATE OR REPLACE FUNCTION update_story_chapter_count()
        RETURNS TRIGGER AS $$
        BEGIN
            -- Nếu thêm chương mới
            IF TG_OP = 'INSERT' THEN
                UPDATE stories
                SET chapter_count = chapter_count + 1
                WHERE id = NEW.story_id;

            -- Nếu xóa chương
            ELSIF TG_OP = 'DELETE' THEN
                UPDATE stories
                SET chapter_count = chapter_count - 1
                WHERE id = OLD.story_id;
            END IF;

            RETURN NULL;
        END;
        $$ LANGUAGE plpgsql;
        RAISE NOTICE 'Đã tạo function update_story_chapter_count';
    END IF;
END $$;

-- Tạo trigger cho việc thêm chương
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'update_chapter_count_insert') THEN
        CREATE TRIGGER update_chapter_count_insert
        AFTER INSERT ON chapters
        FOR EACH ROW
        EXECUTE FUNCTION update_story_chapter_count();
        RAISE NOTICE 'Đã tạo trigger update_chapter_count_insert';
    END IF;
END $$;

-- Tạo trigger cho việc xóa chương
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'update_chapter_count_delete') THEN
        CREATE TRIGGER update_chapter_count_delete
        AFTER DELETE ON chapters
        FOR EACH ROW
        EXECUTE FUNCTION update_story_chapter_count();
        RAISE NOTICE 'Đã tạo trigger update_chapter_count_delete';
    END IF;
END $$;

-- =========================================
-- CLEANUP PROCEDURES
-- =========================================

-- Tạo procedure dọn dẹp database
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_proc WHERE proname = 'cleanup_database') THEN
        CREATE OR REPLACE PROCEDURE cleanup_database()
        LANGUAGE plpgsql
        AS $$
        BEGIN
            -- 1. Remove expired tokens
            DELETE FROM tokens
            WHERE expires_at < CURRENT_TIMESTAMP;

            -- 2. Remove old system logs (older than 30 days, except 'error' level logs which we keep for 90 days)
            DELETE FROM logs
            WHERE (level != 'error' AND created_at < CURRENT_TIMESTAMP - INTERVAL '30 days')
               OR (level = 'error' AND created_at < CURRENT_TIMESTAMP - INTERVAL '90 days');

            -- 3. Remove old system changes records (older than 1 year)
            DELETE FROM system_changes
            WHERE created_at < CURRENT_TIMESTAMP - INTERVAL '1 year';

            -- 4. Remove old backups (keep only the 10 most recent ones)
            DELETE FROM backups
            WHERE id NOT IN (
                SELECT id FROM backups
                ORDER BY created_at DESC
                LIMIT 10
            );

            -- 5. Remove old user activities (older than 60 days)
            DELETE FROM activities
            WHERE created_at < CURRENT_TIMESTAMP - INTERVAL '60 days';

            -- 6. Clean up orphaned comments (comments on deleted stories/chapters)
            DELETE FROM comments
            WHERE (story_id IS NOT NULL AND story_id NOT IN (SELECT id FROM stories))
               OR (chapter_id IS NOT NULL AND chapter_id NOT IN (SELECT id FROM chapters));

            -- 7. Remove unused/orphaned media files
            DELETE FROM media
            WHERE (user_id IS NULL OR user_id NOT IN (SELECT id FROM users))
              AND created_at < CURRENT_TIMESTAMP - INTERVAL '30 days';

            -- 8. Remove stories that are in draft status for more than 6 months and have no chapters
            DELETE FROM stories
            WHERE status = 'draft'
              AND created_at < CURRENT_TIMESTAMP - INTERVAL '180 days'
              AND NOT EXISTS (SELECT 1 FROM chapters WHERE chapters.story_id = stories.id);

            -- Log the cleanup action
            INSERT INTO logs (level, message, context, created_at)
            VALUES ('info', 'Database cleanup procedure executed', '{\"automatic\": true}', CURRENT_TIMESTAMP);
        END;
        $$;
        RAISE NOTICE 'Đã tạo procedure cleanup_database';
    END IF;
END $$;
