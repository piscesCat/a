</div>
                </div>

                <div class="text-center text-muted mb-4">
                    <small>&copy;<?= date('Y') ?> Web Truyện - Mã nguồn được viết bởi Khải Phan</small>
                    <div class="mt-1">
                        <small>Phiên bản cài đặt: <?= INSTALLER_VERSION ?></small>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
    <script>
        // Xử lý sự kiện ẩn/hiện mật khẩu trong form
        document.addEventListener('DOMContentLoaded', function() {
            const togglePasswordBtns = document.querySelectorAll('.toggle-password');
            if (togglePasswordBtns) {
                togglePasswordBtns.forEach(function(btn) {
                    btn.addEventListener('click', function() {
                        const passwordField = document.querySelector(this.getAttribute('data-target'));
                        if (passwordField) {
                            const type = passwordField.getAttribute('type') === 'password' ? 'text' : 'password';
                            passwordField.setAttribute('type', type);

                            // Toggle icon
                            const icon = this.querySelector('i');
                            if (icon) {
                                if (type === 'text') {
                                    icon.classList.remove('fa-eye');
                                    icon.classList.add('fa-eye-slash');
                                } else {
                                    icon.classList.remove('fa-eye-slash');
                                    icon.classList.add('fa-eye');
                                }
                            }
                        }
                    });
                });
            }

            // Copy code blocks
            const copyButtons = document.querySelectorAll('.copy-code-btn');
            if (copyButtons) {
                copyButtons.forEach(function(btn) {
                    btn.addEventListener('click', function() {
                        const codeBlock = document.querySelector(this.getAttribute('data-target'));
                        if (codeBlock) {
                            const textarea = document.createElement('textarea');
                            textarea.value = codeBlock.textContent;
                            document.body.appendChild(textarea);
                            textarea.select();
                            document.execCommand('copy');
                            document.body.removeChild(textarea);

                            // Show copied message
                            const originalText = this.innerHTML;
                            this.innerHTML = '<i class="fas fa-check"></i> Đã sao chép';
                            setTimeout(() => {
                                this.innerHTML = originalText;
                            }, 2000);
                        }
                    });
                });
            }
        });
    </script>
</body>
</html>
