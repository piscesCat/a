<div class="text-center mb-4">
    <i class="fas fa-check-circle text-success" style="font-size: 80px;"></i>
    <h3 class="mt-3">Cài đặt hoàn tất!</h3>
    <p class="lead">Hệ thống Web Truyện đã được cài đặt thành công.</p>
</div>

<div class="alert alert-success">
    <i class="fas fa-info-circle"></i> Giờ đây bạn có thể truy cập vào trang chủ hoặc đăng nhập vào trang quản trị.
</div>

<div class="row mt-4">
    <div class="col-md-6">
        <div class="card h-100">
            <div class="card-body text-center">
                <i class="fas fa-home mb-3" style="font-size: 48px;"></i>
                <h5>Trang chủ</h5>
                <p>Truy cập trang chủ để bắt đầu sử dụng hệ thống.</p>
                <a href="<?php echo rtrim(preg_replace('/\/install.*$/', '', BASE_URL), '/') . '/'; ?>" class="btn btn-primary">Đi đến trang chủ</a>
            </div>
        </div>
    </div>

    <div class="col-md-6">
        <div class="card h-100">
            <div class="card-body text-center">
                <i class="fas fa-user-shield mb-3" style="font-size: 48px;"></i>
                <h5>Trang quản trị</h5>
                <p>Đăng nhập vào trang quản trị để quản lý nội dung.</p>
                <a href="<?php echo rtrim(preg_replace('/\/install.*$/', '', BASE_URL), '/') . '/admin'; ?>" class="btn btn-primary">Đăng nhập quản trị</a>
            </div>
        </div>
    </div>
</div>

<div class="alert alert-warning mt-4">
    <i class="fas fa-exclamation-triangle"></i> <strong>Quan trọng:</strong> Vì lý do bảo mật, các tệp cài đặt sẽ được xóa tự động. Nếu bạn cần cài đặt lại, vui lòng sao lưu các tệp cài đặt trước.
</div>

<script>
    // Tự động xóa các tệp cài đặt sau 3 giây
    setTimeout(function() {
        // Sử dụng BASE_URL để xây dựng URL cleanup
        var cleanupUrl = '<?= BASE_URL ?>cleanup';

        fetch(cleanupUrl, {
            method: 'POST'
        }).then(function(response) {
            console.log('Installation files cleaned up');
        }).catch(function(error) {
            console.error('Error during cleanup:', error);
        });
    }, 3000);
</script>
