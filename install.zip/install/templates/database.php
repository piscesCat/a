<div class="alert alert-info">
    <i class="fas fa-info-circle me-2"></i> Vui lòng nhập thông tin kết nối đến cơ sở dữ liệu PostgreSQL. Bạn cần tạo cơ sở dữ liệu trước khi thực hiện bước này.
</div>

<form method="post" action="<?= BASE_URL ?>">
    <input type="hidden" name="step" value="database">

    <div class="row">
        <div class="col-lg-6">
            <h5 class="mb-3">Cấu hình Cơ sở dữ liệu</h5>

            <div class="mb-3">
                <label for="db_hostname" class="form-label">Hostname:</label>
                <input type="text" class="form-control" id="db_hostname" name="db_hostname" value="<?= $_SESSION['input']['db_hostname'] ?? 'localhost' ?>" required>
                <div class="form-text">Thường là "localhost" hoặc địa chỉ IP của máy chủ PostgreSQL.</div>
            </div>

            <div class="mb-3">
                <label for="db_port" class="form-label">Port:</label>
                <input type="number" class="form-control" id="db_port" name="db_port" value="<?= $_SESSION['input']['db_port'] ?? '5432' ?>" required>
                <div class="form-text">Port mặc định của PostgreSQL là 5432.</div>
            </div>

            <div class="mb-3">
                <label for="db_name" class="form-label">Tên database:</label>
                <input type="text" class="form-control" id="db_name" name="db_name" value="<?= $_SESSION['input']['db_name'] ?? '' ?>" required>
                <div class="form-text">Database phải được tạo trước khi cài đặt.</div>
            </div>

            <div class="mb-3">
                <label for="db_username" class="form-label">Tên đăng nhập:</label>
                <input type="text" class="form-control" id="db_username" name="db_username" value="<?= $_SESSION['input']['db_username'] ?? 'postgres' ?>" required>
            </div>

            <div class="mb-3">
                <label for="db_password" class="form-label">Mật khẩu:</label>
                <div class="input-group">
                    <input type="password" class="form-control" id="db_password" name="db_password" value="<?= $_SESSION['input']['db_password'] ?? '' ?>">
                    <button class="btn btn-outline-secondary toggle-password" type="button" data-target="#db_password">
                        <i class="fas fa-eye"></i>
                    </button>
                </div>
            </div>

            <div class="mb-3">
                <label class="form-label">Tùy chọn xử lý nếu database đã được sử dụng trước đó:</label>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="db_handle_existing" id="db_handle_update" value="update" <?= ($_SESSION['input']['db_handle_existing'] ?? 'update') == 'update' ? 'checked' : '' ?>>
                    <label class="form-check-label" for="db_handle_update">
                        <i class="fas fa-sync-alt me-1"></i> Cập nhật cấu trúc - giữ nguyên dữ liệu hiện có và cập nhật cấu trúc database
                    </label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="db_handle_existing" id="db_handle_recreate" value="recreate" <?= ($_SESSION['input']['db_handle_existing'] ?? '') == 'recreate' ? 'checked' : '' ?>>
                    <label class="form-check-label text-danger" for="db_handle_recreate">
                        <i class="fas fa-exclamation-triangle me-1"></i> <strong>Xóa và tạo lại</strong> - xóa toàn bộ dữ liệu hiện có và tạo mới database từ đầu
                    </label>
                </div>
                <div class="form-text">Chọn cách xử lý nếu database đã có dữ liệu.</div>
            </div>
        </div>

        <div class="col-lg-6">
            <h5 class="mb-3">Cấu hình Upload và API (File .env)</h5>

            <div class="mb-3">
                <label for="app_name" class="form-label">Tên ứng dụng:</label>
                <input type="text" class="form-control" id="app_name" name="app_name" value="<?= $_SESSION['input']['app_name'] ?? 'Web Truyện' ?>">
                <div class="form-text">Tên ứng dụng sẽ được sử dụng trong các email và thông báo.</div>
            </div>

            <div class="mb-3">
                <label for="app_url" class="form-label">URL ứng dụng:</label>
                <input type="text" class="form-control" id="app_url" name="app_url" value="<?= $_SESSION['input']['app_url'] ?? rtrim(BASE_URL, '/install') ?>">
                <div class="form-text">URL đầy đủ đến trang web của bạn, không có dấu / ở cuối.</div>
            </div>

            <div class="mb-3">
                <label for="imgur_client_id" class="form-label">Imgur Client ID (tùy chọn):</label>
                <input type="text" class="form-control" id="imgur_client_id" name="imgur_client_id" value="<?= $_SESSION['input']['imgur_client_id'] ?? '' ?>">
                <div class="form-text">Client ID từ Imgur API để upload ảnh lên Imgur (không bắt buộc).</div>
            </div>

            <div class="mb-3">
                <label for="imgur_client_secret" class="form-label">Imgur Client Secret (tùy chọn):</label>
                <input type="text" class="form-control" id="imgur_client_secret" name="imgur_client_secret" value="<?= $_SESSION['input']['imgur_client_secret'] ?? '' ?>">
                <div class="form-text">Client Secret từ Imgur API (không bắt buộc).</div>
            </div>

            <div class="mb-3">
                <label for="app_key" class="form-label">App Key (bảo mật):</label>
                <div class="input-group">
                    <input type="text" class="form-control" id="app_key" name="app_key" value="<?= $_SESSION['input']['app_key'] ?? bin2hex(random_bytes(16)) ?>">
                    <button class="btn btn-outline-secondary" type="button" onclick="document.getElementById('app_key').value = '<?= bin2hex(random_bytes(16)) ?>'">
                        <i class="fas fa-sync"></i>
                    </button>
                </div>
                <div class="form-text">Khóa bảo mật cho ứng dụng, được tạo ngẫu nhiên.</div>
            </div>
        </div>
    </div>

    <div class="alert alert-warning mt-4">
        <i class="fas fa-exclamation-triangle me-2"></i> Lưu ý: Khi bạn tiếp tục, hệ thống sẽ tạo các bảng cần thiết trong database và file cấu hình .env. Hãy đảm bảo rằng bạn đã sao lưu dữ liệu quan trọng (nếu có).
    </div>

    <div class="d-flex justify-content-between mt-4">
        <a href="<?= BASE_URL ?>" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-2"></i> Quay lại
        </a>

        <button type="submit" class="btn btn-primary">
            Tiếp tục <i class="fas fa-arrow-right ms-2"></i>
        </button>
    </div>
</form>
