<?php
// Trang chào mừng - trang đầu tiên của quá trình cài đặt
?>
<div class="container">
    <h2>Chào mừng đến với Cài đặt Hệ thống Truyện Online</h2>

    <?php if (isset($_SESSION['error'])): ?>
    <div class="alert alert-danger">
        <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
    </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header">
            <h3>Kiểm tra yêu cầu hệ thống</h3>
        </div>
        <div class="card-body">
            <table class="table">
                <thead>
                    <tr>
                        <th>Yêu cầu</th>
                        <th>Cần thiết</th>
                        <th>Hiện tại</th>
                        <th>Trạng thái</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($requirements as $requirement): ?>
                    <tr class="<?php echo $requirement['status'] ? 'success' : 'danger'; ?>">
                        <td><?php echo $requirement['name']; ?></td>
                        <td><?php echo $requirement['required']; ?></td>
                        <td><?php echo $requirement['current']; ?></td>
                        <td>
                            <?php if ($requirement['status']): ?>
                                <span style="color:green">✓ Đạt</span>
                            <?php else: ?>
                                <span style="color:red">✗ Không đạt</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card mt-4">
        <div class="card-header">
            <h3>Kiểm tra quyền thư mục</h3>
        </div>
        <div class="card-body">
            <table class="table">
                <thead>
                    <tr>
                        <th>Thư mục</th>
                        <th>Cần thiết</th>
                        <th>Hiện tại</th>
                        <th>Trạng thái</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($permissions as $permission): ?>
                    <tr class="<?php echo $permission['status'] ? 'success' : 'danger'; ?>">
                        <td><?php echo $permission['name']; ?></td>
                        <td><?php echo $permission['required']; ?></td>
                        <td><?php echo $permission['current']; ?></td>
                        <td>
                            <?php if ($permission['status']): ?>
                                <span style="color:green">✓ Đạt</span>
                            <?php else: ?>
                                <span style="color:red">✗ Không đạt</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <?php
    // Kiểm tra xem tất cả các yêu cầu có đạt không
    $allRequirementsMet = true;
    foreach ($requirements as $requirement) {
        if (!$requirement['status']) {
            $allRequirementsMet = false;
            break;
        }
    }

    // Kiểm tra xem tất cả các quyền thư mục có đạt không
    $allPermissionsMet = true;
    foreach ($permissions as $permission) {
        if (!$permission['status']) {
            $allPermissionsMet = false;
            break;
        }
    }

    $canProceed = $allRequirementsMet && $allPermissionsMet;
    ?>

    <div class="mt-4">
        <?php if ($canProceed): ?>
            <a href="?step=database" class="btn btn-primary btn-lg">Tiếp tục cài đặt</a>
        <?php else: ?>
            <div class="alert alert-warning">
                <strong>Cảnh báo:</strong> Vui lòng khắc phục các vấn đề trên trước khi tiếp tục.
            </div>
        <?php endif; ?>
    </div>
</div>
