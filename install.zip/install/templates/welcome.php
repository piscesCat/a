<div class="container">
    <div class="mb-4">
        <p class="lead">Trình cài đặt sẽ giúp bạn cấu hình ứng dụng Web Truyện để sẵn sàng sử dụng.</p>
    </div>

    <div class="card mb-4">
        <div class="card-header bg-light">
            <h3 class="h5 mb-0">Kiểm tra yêu cầu hệ thống</h3>
        </div>
        <div class="card-body">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Yêu cầu</th>
                        <th>Cần thiết</th>
                        <th>Hiện tại</th>
                        <th width="100">Trạng thái</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($requirements as $requirement): ?>
                    <tr class="<?php echo $requirement['status'] ? 'table-success' : 'table-danger'; ?>">
                        <td><?php echo $requirement['name']; ?></td>
                        <td><?php echo $requirement['required']; ?></td>
                        <td><?php echo $requirement['current']; ?></td>
                        <td>
                            <?php if ($requirement['status']): ?>
                                <span class="badge bg-success rounded-pill"><i class="fas fa-check"></i> Đạt</span>
                            <?php else: ?>
                                <span class="badge bg-danger rounded-pill"><i class="fas fa-times"></i> Không đạt</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card mb-4">
        <div class="card-header bg-light">
            <h3 class="h5 mb-0">Kiểm tra quyền thư mục</h3>
        </div>
        <div class="card-body">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Thư mục</th>
                        <th>Cần thiết</th>
                        <th>Hiện tại</th>
                        <th width="100">Trạng thái</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($permissions as $permission): ?>
                    <tr class="<?php echo $permission['status'] ? 'table-success' : 'table-danger'; ?>">
                        <td><?php echo $permission['name']; ?></td>
                        <td><?php echo $permission['required']; ?></td>
                        <td><?php echo $permission['current']; ?></td>
                        <td>
                            <?php if ($permission['status']): ?>
                                <span class="badge bg-success rounded-pill"><i class="fas fa-check"></i> Đạt</span>
                            <?php else: ?>
                                <span class="badge bg-danger rounded-pill"><i class="fas fa-times"></i> Không đạt</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <?php
    // Kiểm tra xem tất cả các yêu cầu có đạt không
    $allRequirementsMet = true;
    foreach ($requirements as $requirement) {
        if (!$requirement['status']) {
            $allRequirementsMet = false;
            break;
        }
    }

    // Kiểm tra xem tất cả các quyền thư mục có đạt không
    $allPermissionsMet = true;
    foreach ($permissions as $permission) {
        if (!$permission['status']) {
            $allPermissionsMet = false;
            break;
        }
    }

    $canProceed = $allRequirementsMet && $allPermissionsMet;
    ?>

    <div class="mt-4 d-flex justify-content-between">
        <?php if ($canProceed): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle me-2"></i> Tất cả yêu cầu đã được đáp ứng. Bạn có thể tiếp tục quá trình cài đặt.
            </div>
            <a href="?step=database" class="btn btn-primary btn-lg">
                Tiếp tục <i class="fas fa-arrow-right ms-2"></i>
            </a>
        <?php else: ?>
            <div class="alert alert-warning w-100">
                <i class="fas fa-exclamation-triangle me-2"></i> <strong>Cảnh báo:</strong> Vui lòng khắc phục các vấn đề được đánh dấu màu đỏ trước khi tiếp tục.
                <hr>
                <ul class="mb-0">
                    <?php if (!$allRequirementsMet): ?>
                        <li>Cài đặt các extension PHP còn thiếu hoặc nâng cấp phiên bản PHP</li>
                    <?php endif; ?>
                    <?php if (!$allPermissionsMet): ?>
                        <li>Cấp quyền ghi (chmod 755 hoặc 777) cho các thư mục được đánh dấu "Not Writable"</li>
                    <?php endif; ?>
                </ul>
            </div>
        <?php endif; ?>
    </div>
</div>
