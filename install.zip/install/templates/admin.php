<div class="mb-4">
    <h4>Tạo tài khoản quản trị</h4>
    <p>Hãy tạo tài khoản quản trị viên - người quản lý toàn bộ hệ thống Web Truyện của bạn.</p>
</div>

<form method="post" action="<?= BASE_URL ?>">
    <input type="hidden" name="step" value="admin">

    <div class="row">
        <div class="col-lg-6">
            <div class="card mb-4">
                <div class="card-header bg-light">
                    <h5 class="mb-0">Thông tin tài khoản</h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label for="admin_username" class="form-label">Tên đăng nhập:</label>
                        <input type="text" class="form-control" id="admin_username" name="admin_username" value="<?= $_SESSION['input']['admin_username'] ?? 'admin' ?>" required>
                        <div class="form-text">Tên đăng nhập dùng để truy cập hệ thống.</div>
                    </div>

                    <div class="mb-3">
                        <label for="admin_email" class="form-label">Email:</label>
                        <input type="email" class="form-control" id="admin_email" name="admin_email" value="<?= $_SESSION['input']['admin_email'] ?? '' ?>" required>
                        <div class="form-text">Email dùng để khôi phục mật khẩu và nhận thông báo.</div>
                    </div>

                    <div class="mb-3">
                        <label for="admin_password" class="form-label">Mật khẩu:</label>
                        <div class="input-group">
                            <input type="password" class="form-control" id="admin_password" name="admin_password" value="<?= $_SESSION['input']['admin_password'] ?? '' ?>" required minlength="6">
                            <button class="btn btn-outline-secondary toggle-password" type="button" data-target="#admin_password">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                        <div class="form-text">Mật khẩu phải có ít nhất 6 ký tự.</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-6">
            <div class="card mb-4">
                <div class="card-header bg-light">
                    <h5 class="mb-0">Thông tin trang web</h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label for="site_name" class="form-label">Tên trang web:</label>
                        <input type="text" class="form-control" id="site_name" name="site_name" value="<?= $_SESSION['input']['site_name'] ?? 'Web Truyện' ?>" required>
                        <div class="form-text">Tên hiển thị trên tiêu đề và các phần giao diện.</div>
                    </div>

                    <div class="mb-3">
                        <label for="site_description" class="form-label">Mô tả trang web:</label>
                        <textarea class="form-control" id="site_description" name="site_description" rows="3"><?= $_SESSION['input']['site_description'] ?? 'Trang web đọc truyện online miễn phí với nhiều thể loại truyện đa dạng' ?></textarea>
                        <div class="form-text">Mô tả ngắn gọn về trang web của bạn, hiển thị ở trang chủ và meta description.</div>
                    </div>

                    <div class="form-check form-switch mt-4">
                        <input class="form-check-input" type="checkbox" id="register_enabled" name="register_enabled" value="1" <?= isset($_SESSION['input']['register_enabled']) ? 'checked' : '' ?>>
                        <label class="form-check-label" for="register_enabled">Cho phép đăng ký tài khoản mới</label>
                    </div>

                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" id="comments_enabled" name="comments_enabled" value="1" checked>
                        <label class="form-check-label" for="comments_enabled">Cho phép bình luận</label>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="alert alert-info mt-3">
        <i class="fas fa-info-circle me-2"></i> Sau khi hoàn tất cài đặt, bạn có thể truy cập trang quản trị tại đường dẫn <code><?= rtrim(BASE_URL, '/install') ?>/admin</code>
    </div>

    <div class="d-flex justify-content-between mt-4">
        <a href="?step=database" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-2"></i> Quay lại
        </a>

        <button type="submit" class="btn btn-primary">
            Tiếp tục <i class="fas fa-arrow-right ms-2"></i>
        </button>
    </div>
</form>
