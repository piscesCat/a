<?php
namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\UserModel;
use App\Models\LogModel;

class UserManager extends BaseController
{
    protected $userModel;
    protected $logModel;
    protected $currentUser;

    public function __construct()
    {
        $this->userModel = new UserModel();
        $this->logModel = new LogModel();
        $this->currentUser = session()->get('user');

        // Chỉ người sáng lập (role=3) và admin (role=2) mới có quyền quản lý người dùng
        if (!$this->currentUser || $this->currentUser['role'] < 2) {
            return redirect()->to('/')->with('error', 'Bạn không có quyền truy cập trang này');
        }
    }

    public function index()
    {
        $page = $this->request->getGet('page') ?? 1;
        $limit = 20;
        $offset = ($page - 1) * $limit;

        $users = $this->userModel->findAll($limit, $offset);
        $total = $this->userModel->countAllResults();

        // Chỉ người sáng lập mới thấy được tất cả người dùng, admin chỉ thấy cộng tác viên và admin khác
        if ($this->currentUser['role'] < 3) {
            $users = array_filter($users, function($user) {
                return $user['role'] <= $this->currentUser['role'];
            });
        }

        return view('admin/user/index.html', [
            'users' => $users,
            'current_user' => $this->currentUser,
            'pager' => [
                'current' => $page,
                'total' => ceil($total / $limit)
            ]
        ]);
    }

    public function create()
    {
        $roleOptions = $this->getRoleOptions();

        return view('admin/user/create.html', [
            'roles' => $roleOptions
        ]);
    }

    public function save()
    {
        // Validate input
        $rules = [
            'username' => 'required|min_length[3]|max_length[50]|is_unique[users.username]',
            'email' => 'required|valid_email|is_unique[users.email]',
            'password' => 'required|min_length[6]',
            'display_name' => 'required|min_length[3]|max_length[100]',
            'role' => 'required|integer|in_list[1,2,3]'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()
                ->withInput()
                ->with('error', implode('<br>', $this->validator->getErrors()));
        }

        // Kiểm tra quyền tạo người dùng (không thể tạo người dùng với quyền cao hơn mình)
        $requestedRole = (int)$this->request->getPost('role');
        if ($requestedRole > $this->currentUser['role']) {
            return redirect()->back()
                ->withInput()
                ->with('error', 'Bạn không thể tạo người dùng với quyền cao hơn bạn');
        }

        // Hash mật khẩu
        $password = password_hash($this->request->getPost('password'), PASSWORD_DEFAULT);

        // Tạo người dùng mới
        $data = [
            'username' => $this->request->getPost('username'),
            'email' => $this->request->getPost('email'),
            'password' => $password,
            'display_name' => $this->request->getPost('display_name'),
            'role' => $requestedRole,
            'status' => 'active',
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];

        $userId = $this->userModel->insert($data);

        // Log hành động
        $this->logModel->info('Tạo người dùng mới', [
            'user_id' => $this->currentUser['id'],
            'target_id' => $userId,
            'username' => $data['username'],
            'role' => $data['role']
        ]);

        return redirect()->to('/admin/users')
            ->with('success', 'Người dùng mới đã được tạo thành công');
    }

    public function edit($id)
    {
        $user = $this->userModel->find($id);
        if (!$user) {
            return redirect()->to('/admin/users')
                ->with('error', 'Không tìm thấy người dùng');
        }

        // Kiểm tra quyền chỉnh sửa (chỉ có thể chỉnh sửa người dùng có quyền thấp hơn hoặc bằng)
        if ($user['role'] > $this->currentUser['role'] || ($user['role'] == 3 && $user['id'] != $this->currentUser['id'])) {
            return redirect()->to('/admin/users')
                ->with('error', 'Bạn không có quyền chỉnh sửa người dùng này');
        }

        $roleOptions = $this->getRoleOptions();

        return view('admin/user/edit.html', [
            'user' => $user,
            'roles' => $roleOptions,
            'current_user' => $this->currentUser
        ]);
    }

    public function update($id)
    {
        $user = $this->userModel->find($id);
        if (!$user) {
            return redirect()->to('/admin/users')
                ->with('error', 'Không tìm thấy người dùng');
        }

        // Kiểm tra quyền cập nhật
        if ($user['role'] > $this->currentUser['role'] || ($user['role'] == 3 && $user['id'] != $this->currentUser['id'])) {
            return redirect()->to('/admin/users')
                ->with('error', 'Bạn không có quyền cập nhật người dùng này');
        }

        // Validate input
        $rules = [
            'username' => "required|min_length[3]|max_length[50]|is_unique[users.username,id,$id]",
            'email' => "required|valid_email|is_unique[users.email,id,$id]",
            'display_name' => 'required|min_length[3]|max_length[100]',
            'status' => 'required|in_list[active,inactive,banned]'
        ];

        // Chỉ cho phép thay đổi role nếu người dùng hiện tại là người sáng lập
        // hoặc người dùng cần sửa có role thấp hơn người dùng hiện tại
        $canChangeRole = $this->currentUser['role'] == 3 || $user['role'] < $this->currentUser['role'];
        if ($canChangeRole) {
            $rules['role'] = 'required|integer|in_list[1,2,3]';
        }

        if ($this->request->getPost('password')) {
            $rules['password'] = 'min_length[6]';
        }

        if (!$this->validate($rules)) {
            return redirect()->back()
                ->withInput()
                ->with('error', implode('<br>', $this->validator->getErrors()));
        }

        // Chuẩn bị dữ liệu cập nhật
        $data = [
            'username' => $this->request->getPost('username'),
            'email' => $this->request->getPost('email'),
            'display_name' => $this->request->getPost('display_name'),
            'status' => $this->request->getPost('status'),
            'updated_at' => date('Y-m-d H:i:s')
        ];

        // Cập nhật role nếu có quyền
        if ($canChangeRole) {
            $requestedRole = (int)$this->request->getPost('role');
            // Không cho phép set role cao hơn người dùng hiện tại
            if ($requestedRole > $this->currentUser['role']) {
                return redirect()->back()
                    ->withInput()
                    ->with('error', 'Bạn không thể set quyền cao hơn quyền của bạn');
            }
            $data['role'] = $requestedRole;
        }

        // Cập nhật mật khẩu nếu có
        if ($this->request->getPost('password')) {
            $data['password'] = password_hash($this->request->getPost('password'), PASSWORD_DEFAULT);
        }

        $this->userModel->update($id, $data);

        // Log hành động
        $this->logModel->info('Cập nhật thông tin người dùng', [
            'user_id' => $this->currentUser['id'],
            'target_id' => $id,
            'username' => $data['username']
        ]);

        return redirect()->to('/admin/users')
            ->with('success', 'Thông tin người dùng đã được cập nhật thành công');
    }

    public function delete()
    {
        $id = $this->request->getPost('id');
        if (!$id) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'ID không hợp lệ'
            ]);
        }

        $user = $this->userModel->find($id);
        if (!$user) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Không tìm thấy người dùng'
            ]);
        }

        // Không thể xóa chính mình
        if ($id == $this->currentUser['id']) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Bạn không thể xóa tài khoản của chính mình'
            ]);
        }

        // Kiểm tra quyền xóa (chỉ có thể xóa người dùng có quyền thấp hơn)
        if ($user['role'] >= $this->currentUser['role']) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Bạn không có quyền xóa người dùng này'
            ]);
        }

        // Log trước khi xóa
        $this->logModel->info('Xóa người dùng', [
            'user_id' => $this->currentUser['id'],
            'target_id' => $id,
            'username' => $user['username'],
            'email' => $user['email']
        ]);

        $this->userModel->delete($id);

        return $this->response->setJSON([
            'success' => true,
            'message' => 'Người dùng đã được xóa thành công'
        ]);
    }

    public function updateStatus()
    {
        $id = $this->request->getPost('id');
        $status = $this->request->getPost('status');

        if (!$id || !in_array($status, ['active', 'inactive', 'banned'])) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Dữ liệu không hợp lệ'
            ]);
        }

        $user = $this->userModel->find($id);
        if (!$user) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Không tìm thấy người dùng'
            ]);
        }

        // Kiểm tra quyền cập nhật (chỉ có thể cập nhật người dùng có quyền thấp hơn)
        if ($user['role'] >= $this->currentUser['role']) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Bạn không có quyền thay đổi trạng thái của người dùng này'
            ]);
        }

        $this->userModel->update($id, ['status' => $status]);

        // Log hành động
        $this->logModel->info('Cập nhật trạng thái người dùng', [
            'user_id' => $this->currentUser['id'],
            'target_id' => $id,
            'status' => $status
        ]);

        return $this->response->setJSON([
            'success' => true,
            'message' => 'Trạng thái người dùng đã được cập nhật thành công'
        ]);
    }

    /**
     * Lấy danh sách quyền người dùng theo quyền hiện tại
     */
    private function getRoleOptions()
    {
        $roles = [
            '1' => 'Cộng tác viên',
            '2' => 'Admin',
            '3' => 'Người sáng lập'
        ];

        // Người dùng chỉ có thể tạo người dùng có quyền thấp hơn hoặc bằng
        return array_filter($roles, function($key) {
            return $key <= $this->currentUser['role'];
        }, ARRAY_FILTER_USE_KEY);
    }
}
