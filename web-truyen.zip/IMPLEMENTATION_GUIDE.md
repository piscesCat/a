# Hướng dẫn triển khai các chức năng còn lại

Tài liệu này cung cấp hướng dẫn chi tiết để triển khai các chức năng còn lại trong dự án. Tham khảo TODO.md để xem danh sách đầy đủ các việc cần làm.

## 1. Tổng quan về kiến trúc dự án

Dự án sử dụng framework CodeIgniter 4 với mô hình MVC:
- `app/Controllers`: Chứa controllers xử lý logic
- `app/Models`: Chứa các models tương tác với cơ sở dữ liệu
- `app/Views`: Chứa templates Twig để hiển thị giao diện
- `app/Config`: Chứa cấu hình ứng dụng

## 2. Sửa layout admin

### Các bước thực hiện:
1. Hoàn thiện file `app/Views/admin/layouts/admin.html` với Twig template
2. Kiểm tra và sửa tất cả các tệp view trong `app/Views/admin/` để sử dụng layout mới
3. Đảm bảo các block được đặt đúng
4. Thêm stylesheet và script cần thiết

### Code mẫu của layout admin:
```html
{% extends "layouts/base.html" %}

{% block content %}
<div class="admin-container">
    {% include "admin/partials/sidebar.html" %}
    <div class="admin-content">
        {% block admin_content %}{% endblock %}
    </div>
</div>
{% endblock %}
```

## 3. Triển khai phân quyền

### Mô hình phân quyền:
- **Người sáng lập (Role 3)**: Toàn quyền trên hệ thống, bao gồm quản lý admin
- **Admin (Role 2)**: Quản lý nội dung, cài đặt, người dùng thấp hơn
- **Cộng tác viên (Role 1)**: Thêm/sửa/xóa nội dung, giới hạn một số chức năng

### Triển khai trong controller:
```php
// Kiểm tra quyền truy cập
protected function requireRole($requiredRole)
{
    // Kiểm tra đăng nhập
    $loginCheck = $this->requireLogin();
    if ($loginCheck !== true) {
        return $loginCheck;
    }

    // Kiểm tra role
    if (!$this->hasRole($requiredRole)) {
        $this->session->setFlashdata('error', 'Bạn không có đủ quyền truy cập');
        return redirect()->to('/');
    }

    return true;
}
```

## 4. Triển khai JWT Token cho API

### Cài đặt JWT:
```
composer require firebase/php-jwt
```

### Middleware xác thực API:
1. Tạo file `app/Filters/ApiAuthFilter.php`:
```php
<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

class ApiAuthFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        $tokenModel = new \App\Models\TokenModel();
        $authHeader = $request->getServer('HTTP_AUTHORIZATION');

        if (!$authHeader || !preg_match('/Bearer\s+(.*)$/i', $authHeader, $matches)) {
            return service('response')->setJSON([
                'error' => 'Unauthorized'
            ])->setStatusCode(401);
        }

        $token = $matches[1];

        // Verify token
        if (!$tokenModel->verifyToken($token)) {
            return service('response')->setJSON([
                'error' => 'Invalid or expired token'
            ])->setStatusCode(401);
        }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // No action needed
    }
}
```

### Cập nhật routes.php:
```php
// API routes with JWT auth
$routes->group('api', ['filter' => 'api-auth'], function($routes) {
    // Protected API endpoints here
});
```

## 5. Triển khai Imgur API Integration

### Tạo Imgur Client:
```php
<?php

namespace App\Libraries;

class ImgurClient
{
    protected $clientId;
    protected $clientSecret;

    public function __construct()
    {
        $this->clientId = getenv('IMGUR_CLIENT_ID');
        $this->clientSecret = getenv('IMGUR_CLIENT_SECRET');
    }

    public function uploadImage($imageData)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://api.imgur.com/3/image');
        curl_setopt($ch, CURLOPT_POST, TRUE);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Client-ID ' . $this->clientId
        ]);
        curl_setopt($ch, CURLOPT_POSTFIELDS, [
            'image' => base64_encode($imageData)
        ]);

        $response = curl_exec($ch);
        curl_close($ch);

        return json_decode($response, true);
    }
}
```

### Tích hợp với editor:
```javascript
// Frontend code for integration with TinyMCE
tinymce.init({
    selector: 'textarea.editor',
    plugins: 'image',
    toolbar: 'image',
    images_upload_handler: function (blobInfo, success, failure) {
        var xhr = new XMLHttpRequest();
        xhr.open('POST', '/api/uploads/imgur');

        xhr.onload = function() {
            if (xhr.status === 200) {
                var json = JSON.parse(xhr.responseText);
                success(json.data.link);
            } else {
                failure('HTTP Error: ' + xhr.status);
            }
        };

        var formData = new FormData();
        formData.append('file', blobInfo.blob(), blobInfo.filename());

        xhr.send(formData);
    }
});
```

## 6. Phân biệt tác giả và người đăng truyện

### Cập nhật bảng stories:
```sql
ALTER TABLE stories
ADD COLUMN author_name VARCHAR(100) AFTER author_id,
ADD COLUMN uploader_id INTEGER REFERENCES users(id);

UPDATE stories SET uploader_id = author_id;
```

### Cập nhật model:
```php
// Updated Story model
protected $allowedFields = [
    'title', 'slug', 'description', 'cover_image',
    'author_id', 'author_name', 'uploader_id',
    'status', 'views', 'rating', 'created_at',
    'updated_at', 'is_featured', 'is_completed'
];
```

## 7. Bookmark cho người dùng không đăng nhập

### Lưu trữ trên localStorage:
```javascript
// Frontend code for guest bookmarks
const GuestBookmark = {
    add: function(storyId, chapterId) {
        let bookmarks = this.getAll();
        bookmarks[storyId] = {
            id: storyId,
            title: storyTitle,
            chapter_id: chapterId,
            time: new Date().toISOString()
        };
        localStorage.setItem('guest_bookmarks', JSON.stringify(bookmarks));

        // Also send to server for persistence
        fetch('/bookmarks/toggle', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ story_id: storyId, chapter_id: chapterId })
        });
    },

    getAll: function() {
        const data = localStorage.getItem('guest_bookmarks');
        return data ? JSON.parse(data) : {};
    }
};
```

## 8. Bảo mật phòng chống vượt quyền hạn

### Nguyên tắc bảo mật:
1. Luôn kiểm tra quyền truy cập ở controller
2. Không tin tưởng dữ liệu từ client
3. Áp dụng CSRF protection
4. Sử dụng prepared statements cho truy vấn SQL

### Kiểm tra quyền trong action:
```php
public function delete($id)
{
    // Check permission
    if (!$this->hasRole(2)) { // Require Admin role
        return $this->response->setJSON([
            'success' => false,
            'message' => 'Không đủ quyền'
        ]);
    }

    // Check ownership (for contributors)
    if ($this->currentUser['role'] == 1) { // Contributor
        $story = $this->storyModel->find($id);
        if ($story['uploader_id'] != $this->currentUser['id']) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Bạn không có quyền xóa truyện này'
            ]);
        }
    }

    // Proceed with deletion
    $this->storyModel->delete($id);

    return $this->response->setJSON([
        'success' => true
    ]);
}
```

## 9. Hoàn thiện

### Kiểm tra và test:
1. Chạy test tất cả các chức năng đã triển khai
2. Kiểm tra bảo mật, thử thao tác vượt quyền hạn
3. Kiểm tra hiển thị UI cho từng loại người dùng
4. Kiểm tra API với JWT token

### Kiểm tra cuối cùng:
1. Tạo backup cơ sở dữ liệu
2. Lưu trữ README.md và tài liệu đầy đủ
3. Cập nhật file composer.json với các dependencies mới

## 10. Phụ lục

### Các công cụ và thư viện gợi ý:
- TinyMCE hoặc CKEditor cho Rich Text Editor
- firebase/php-jwt cho xác thực JWT
- datatables.net cho hiển thị bảng dữ liệu
- select2 cho dropdown nâng cao
- Chart.js cho biểu đồ thống kê

### Thông tin tham khảo:
- [CodeIgniter 4 Documentation](https://codeigniter.com/user_guide/index.html)
- [Twig Documentation](https://twig.symfony.com/doc/3.x/)
- [JWT Authentication Best Practices](https://jwt.io/introduction)
- [Imgur API Documentation](https://apidocs.imgur.com/)
