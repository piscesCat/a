<?php

namespace App\Controllers;

use App\Models\BookmarkModel;
use App\Models\GuestBookmarkModel;
use App\Models\StoryModel;

class Bookmark extends BaseController
{
    protected $bookmarkModel;
    protected $guestBookmarkModel;
    protected $storyModel;

    public function __construct()
    {
        $this->bookmarkModel = new BookmarkModel();
        $this->guestBookmarkModel = new GuestBookmarkModel();
        $this->storyModel = new StoryModel();
    }

    /**
     * Hiển thị trang danh sách bookmark
     */
    public function index()
    {
        $page = $this->request->getGet('page') ?? 1;
        $limit = 10;
        $offset = ($page - 1) * $limit;

        // Kiểm tra có đăng nhập hay không
        $isLoggedIn = session()->get('isLoggedIn');
        $bookmarks = [];
        $totalBookmarks = 0;

        if ($isLoggedIn) {
            // Lấy bookmark cho người dùng đã đăng nhập
            $userId = session()->get('user')['id'];
            $bookmarks = $this->bookmarkModel->getUserBookmarks($userId, $limit, $offset);
            $totalBookmarks = $this->bookmarkModel->where('user_id', $userId)->countAllResults();
        } else {
            // Lấy bookmark cho khách
            $guestId = $this->getGuestId();
            $bookmarks = $this->guestBookmarkModel->getGuestBookmarks($guestId, $limit, $offset);
            $totalBookmarks = $this->guestBookmarkModel->where('guest_id', $guestId)->countAllResults();
        }

        return view('bookmark/index.html', [
            'bookmarks' => $bookmarks,
            'pager' => [
                'current' => $page,
                'total' => ceil($totalBookmarks / $limit)
            ],
            'total' => $totalBookmarks
        ]);
    }

    /**
     * Endpoint API để thêm/xóa bookmark
     */
    public function toggle()
    {
        $storyId = $this->request->getPost('story_id');
        $chapterId = $this->request->getPost('chapter_id');

        if (!$storyId) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Thiếu thông tin truyện'
            ]);
        }

        // Kiểm tra truyện tồn tại
        $story = $this->storyModel->find($storyId);
        if (!$story) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Không tìm thấy truyện'
            ]);
        }

        // Xử lý dựa trên trạng thái đăng nhập
        $isLoggedIn = session()->get('isLoggedIn');
        if ($isLoggedIn) {
            $userId = session()->get('user')['id'];
            $result = $this->bookmarkModel->toggleBookmark($userId, $storyId, $chapterId);
        } else {
            $guestId = $this->getGuestId();
            $result = $this->guestBookmarkModel->toggleBookmark($guestId, $storyId, $chapterId);
        }

        return $this->response->setJSON([
            'success' => true,
            'data' => $result
        ]);
    }

    /**
     * Kiểm tra trạng thái bookmark
     */
    public function checkStatus()
    {
        $storyId = $this->request->getGet('story_id');

        if (!$storyId) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Thiếu thông tin truyện'
            ]);
        }

        $isLoggedIn = session()->get('isLoggedIn');
        $isBookmarked = false;

        if ($isLoggedIn) {
            $userId = session()->get('user')['id'];
            $isBookmarked = $this->bookmarkModel->isBookmarked($userId, $storyId);
        } else {
            $guestId = $this->getGuestId();
            $isBookmarked = $this->guestBookmarkModel->isBookmarked($guestId, $storyId);
        }

        return $this->response->setJSON([
            'success' => true,
            'data' => [
                'is_bookmarked' => $isBookmarked
            ]
        ]);
    }

    /**
     * Cập nhật thông tin chương đang đọc
     */
    public function updateChapter()
    {
        $storyId = $this->request->getPost('story_id');
        $chapterId = $this->request->getPost('chapter_id');

        if (!$storyId || !$chapterId) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Thiếu thông tin truyện hoặc chương'
            ]);
        }

        $isLoggedIn = session()->get('isLoggedIn');
        $updated = false;

        if ($isLoggedIn) {
            $userId = session()->get('user')['id'];
            // Kiểm tra nếu đã bookmark rồi thì cập nhật, không thì tạo mới
            if ($this->bookmarkModel->isBookmarked($userId, $storyId)) {
                $updated = $this->bookmarkModel->updateChapter($userId, $storyId, $chapterId);
            } else {
                $result = $this->bookmarkModel->toggleBookmark($userId, $storyId, $chapterId);
                $updated = ($result['action'] === 'added');
            }
        } else {
            $guestId = $this->getGuestId();
            // Kiểm tra nếu đã bookmark rồi thì cập nhật, không thì tạo mới
            if ($this->guestBookmarkModel->isBookmarked($guestId, $storyId)) {
                $updated = $this->guestBookmarkModel->updateChapter($guestId, $storyId, $chapterId);
            } else {
                $result = $this->guestBookmarkModel->toggleBookmark($guestId, $storyId, $chapterId);
                $updated = ($result['action'] === 'added');
            }
        }

        return $this->response->setJSON([
            'success' => $updated,
            'message' => $updated ? 'Đã cập nhật tiến trình đọc' : 'Không thể cập nhật tiến trình đọc'
        ]);
    }

    /**
     * Tạo hoặc lấy ID khách từ cookie
     */
    protected function getGuestId()
    {
        $guestId = $this->request->getCookie('guest_id');

        if (!$guestId) {
            $guestId = md5(uniqid() . $_SERVER['REMOTE_ADDR'] . time());
            $cookieOptions = [
                'expires' => time() + (86400 * 365), // 1 năm
                'path' => '/',
                'secure' => false,
                'httponly' => true
            ];

            setCookie('guest_id', $guestId, $cookieOptions);

            // Lưu vào session hiện tại để dùng ngay lập tức
            $_COOKIE['guest_id'] = $guestId;
        }

        return $guestId;
    }
}
