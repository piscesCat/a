<?php
namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\CountryModel;
use App\Models\LogModel;

class CountryManager extends BaseController
{
    protected $countryModel;
    protected $logModel;

    public function __construct()
    {
        $this->countryModel = new CountryModel();
        $this->logModel = new LogModel();
    }

    /**
     * Hiển thị danh sách quốc gia đang được sử dụng
     */
    public function index()
    {
        // Require admin role
        $check = $this->requireAdmin();
        if ($check !== true) {
            return $check;
        }

        $data = [
            'title' => 'Quản lý quốc gia',
            'countries' => $this->countryModel->getCountriesWithCount(),
            'available_countries' => $this->getAvailableCountries()
        ];

        return $this->renderView('admin/country/index.html', $data);
    }

    /**
     * Hiển thị form chọn quốc gia từ danh sách có sẵn
     */
    public function select()
    {
        // Require admin role
        $check = $this->requireAdmin();
        if ($check !== true) {
            return $check;
        }

        $data = [
            'title' => 'Chọn quốc gia',
            'available_countries' => $this->getAvailableCountries()
        ];

        return $this->renderView('admin/country/select.html', $data);
    }

    /**
     * Xử lý thêm quốc gia từ danh sách có sẵn
     */
    public function addSelected()
    {
        // Require admin role
        $check = $this->requireAdmin();
        if ($check !== true) {
            return $check;
        }

        $selectedCountries = $this->request->getPost('countries');

        if (empty($selectedCountries)) {
            return redirect()->back()
                ->with('error', 'Vui lòng chọn ít nhất một quốc gia.');
        }

        $availableCountries = $this->getAvailableCountries();
        $addedCount = 0;

        foreach ($selectedCountries as $countryCode) {
            // Kiểm tra xem quốc gia đã có trong danh sách chưa
            $existingCountry = $this->countryModel->where('code', $countryCode)->first();

            if (!$existingCountry && isset($availableCountries[$countryCode])) {
                $country = $availableCountries[$countryCode];

                $this->countryModel->insert([
                    'name' => $country['name'],
                    'code' => $countryCode,
                    'slug' => $this->createSlug($country['name']),
                    'flag_image' => $country['flag_image'] ?? null,
                    'region' => $country['region'] ?? null,
                    'description' => 'Truyện ' . $country['name']
                ]);

                $addedCount++;

                // Ghi log
                $this->logModel->info('Quốc gia mới đã được thêm: ' . $country['name'], [
                    'user_id' => $this->currentUser['id'] ?? null,
                    'country_id' => $this->countryModel->getInsertID(),
                    'ip_address' => $this->request->getIPAddress()
                ]);
            }
        }

        if ($addedCount > 0) {
            return redirect()->to('/admin/countries')
                ->with('success', "Đã thêm $addedCount quốc gia vào hệ thống.");
        } else {
            return redirect()->to('/admin/countries')
                ->with('info', 'Không có quốc gia mới nào được thêm vào hệ thống.');
        }
    }

    /**
     * Hiển thị form chỉnh sửa quốc gia
     */
    public function edit($id)
    {
        // Require admin role
        $check = $this->requireAdmin();
        if ($check !== true) {
            return $check;
        }

        $country = $this->countryModel->find($id);
        if (!$country) {
            return redirect()->to('/admin/countries')
                ->with('error', 'Quốc gia không tồn tại.');
        }

        $data = [
            'title' => 'Chỉnh sửa quốc gia',
            'country' => $country
        ];

        return $this->renderView('admin/country/edit.html', $data);
    }

    /**
     * Xử lý cập nhật quốc gia
     */
    public function update($id)
    {
        // Require admin role
        $check = $this->requireAdmin();
        if ($check !== true) {
            return $check;
        }

        $country = $this->countryModel->find($id);
        if (!$country) {
            return redirect()->to('/admin/countries')
                ->with('error', 'Quốc gia không tồn tại.');
        }

        $rules = [
            'name' => 'required|min_length[2]|max_length[100]',
            'slug' => 'required|min_length[2]|max_length[100]|is_unique[countries.slug,id,' . $id . ']',
            'description' => 'permit_empty'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()
                ->withInput()
                ->with('errors', $this->validator->getErrors());
        }

        $data = [
            'name' => $this->request->getPost('name'),
            'slug' => $this->request->getPost('slug'),
            'description' => $this->request->getPost('description')
        ];

        // Xử lý upload ảnh cờ mới nếu có
        $flagImage = $this->request->getFile('flag_image');
        if ($flagImage && $flagImage->isValid() && !$flagImage->hasMoved()) {
            $newName = $flagImage->getRandomName();
            $flagImage->move(FCPATH . 'uploads/flags', $newName);

            // Xóa ảnh cũ nếu có
            if (!empty($country['flag_image']) && file_exists(FCPATH . $country['flag_image'])) {
                unlink(FCPATH . $country['flag_image']);
            }

            $data['flag_image'] = 'uploads/flags/' . $newName;
        }

        $this->countryModel->update($id, $data);

        // Ghi log
        $this->logModel->info('Quốc gia đã được cập nhật: ' . $data['name'], [
            'user_id' => $this->currentUser['id'] ?? null,
            'country_id' => $id,
            'ip_address' => $this->request->getIPAddress()
        ]);

        return redirect()->to('/admin/countries')
            ->with('success', 'Quốc gia đã được cập nhật thành công.');
    }

    /**
     * Ẩn quốc gia (thay vì xóa hoàn toàn)
     */
    public function toggle($id)
    {
        // Require admin role
        $check = $this->requireAdmin();
        if ($check !== true) {
            return $check;
        }

        $country = $this->countryModel->find($id);
        if (!$country) {
            return redirect()->to('/admin/countries')
                ->with('error', 'Quốc gia không tồn tại.');
        }

        // Toggle status
        $newStatus = ($country['status'] === 'active') ? 'inactive' : 'active';
        $this->countryModel->update($id, ['status' => $newStatus]);

        // Ghi log
        $this->logModel->info('Trạng thái quốc gia đã được thay đổi: ' . $country['name'] . ' -> ' . $newStatus, [
            'user_id' => $this->currentUser['id'] ?? null,
            'country_id' => $id,
            'ip_address' => $this->request->getIPAddress()
        ]);

        return redirect()->to('/admin/countries')
            ->with('success', 'Trạng thái quốc gia đã được thay đổi thành công.');
    }

    /**
     * Lấy danh sách các quốc gia có sẵn
     */
    protected function getAvailableCountries()
    {
        // Danh sách quốc gia phổ biến cho ứng dụng truyện
        return [
            'VN' => [
                'name' => 'Việt Nam',
                'region' => 'Asia',
                'flag_image' => '/assets/images/flags/vn.png'
            ],
            'CN' => [
                'name' => 'Trung Quốc',
                'region' => 'Asia',
                'flag_image' => '/assets/images/flags/cn.png'
            ],
            'JP' => [
                'name' => 'Nhật Bản',
                'region' => 'Asia',
                'flag_image' => '/assets/images/flags/jp.png'
            ],
            'KR' => [
                'name' => 'Hàn Quốc',
                'region' => 'Asia',
                'flag_image' => '/assets/images/flags/kr.png'
            ],
            'US' => [
                'name' => 'Mỹ',
                'region' => 'North America',
                'flag_image' => '/assets/images/flags/us.png'
            ],
            'GB' => [
                'name' => 'Anh',
                'region' => 'Europe',
                'flag_image' => '/assets/images/flags/gb.png'
            ],
            'FR' => [
                'name' => 'Pháp',
                'region' => 'Europe',
                'flag_image' => '/assets/images/flags/fr.png'
            ],
            'DE' => [
                'name' => 'Đức',
                'region' => 'Europe',
                'flag_image' => '/assets/images/flags/de.png'
            ],
            'IT' => [
                'name' => 'Ý',
                'region' => 'Europe',
                'flag_image' => '/assets/images/flags/it.png'
            ],
            'ES' => [
                'name' => 'Tây Ban Nha',
                'region' => 'Europe',
                'flag_image' => '/assets/images/flags/es.png'
            ],
            'TH' => [
                'name' => 'Thái Lan',
                'region' => 'Asia',
                'flag_image' => '/assets/images/flags/th.png'
            ],
            'HK' => [
                'name' => 'Hồng Kông',
                'region' => 'Asia',
                'flag_image' => '/assets/images/flags/hk.png'
            ],
            'TW' => [
                'name' => 'Đài Loan',
                'region' => 'Asia',
                'flag_image' => '/assets/images/flags/tw.png'
            ],
            'IN' => [
                'name' => 'Ấn Độ',
                'region' => 'Asia',
                'flag_image' => '/assets/images/flags/in.png'
            ],
            'RU' => [
                'name' => 'Nga',
                'region' => 'Europe',
                'flag_image' => '/assets/images/flags/ru.png'
            ],
            'CA' => [
                'name' => 'Canada',
                'region' => 'North America',
                'flag_image' => '/assets/images/flags/ca.png'
            ],
            'AU' => [
                'name' => 'Úc',
                'region' => 'Oceania',
                'flag_image' => '/assets/images/flags/au.png'
            ],
            'BR' => [
                'name' => 'Brazil',
                'region' => 'South America',
                'flag_image' => '/assets/images/flags/br.png'
            ],
            'OTHER' => [
                'name' => 'Khác',
                'region' => 'Other',
                'flag_image' => '/assets/images/flags/other.png'
            ]
        ];
    }

    /**
     * Tạo slug từ tên quốc gia
     */
    protected function createSlug($name)
    {
        $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $name)));

        // Kiểm tra slug đã tồn tại chưa
        $count = 0;
        $originalSlug = $slug;

        while ($this->countryModel->where('slug', $slug)->first()) {
            $count++;
            $slug = $originalSlug . '-' . $count;
        }

        return $slug;
    }
}
