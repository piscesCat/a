<?php
namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\TokenModel;
use App\Models\UserModel;
use Firebase\JWT\JWT;

class ApiTokens extends BaseController
{
    protected $tokenModel;
    protected $userModel;

    public function __construct()
    {
        $this->tokenModel = new TokenModel();
        $this->userModel = new UserModel();
    }

    /**
     * List all API tokens
     */
    public function index()
    {
        // Require admin role
        $check = $this->requireAdmin();
        if ($check !== true) {
            return $check;
        }

        // Get tokens with user information
        $db = \Config\Database::connect();
        $tokens = $db->table('tokens')
                    ->select('tokens.*, users.username, users.display_name, users.role')
                    ->join('users', 'users.id = tokens.user_id')
                    ->orderBy('tokens.created_at', 'DESC')
                    ->get()
                    ->getResultArray();

        // Format dates for display
        foreach ($tokens as &$token) {
            $token['created_at_formatted'] = $this->formatDate($token['created_at']);
            $token['expires_at_formatted'] = $this->formatDate($token['expires_at']);
            $token['role_text'] = $this->userModel->getRoleText($token['role']);
            $token['role_color'] = $this->userModel->getRoleColor($token['role']);

            // Only show first 8 characters of token for security
            $token['token_preview'] = substr($token['token'], 0, 8) . '...';
        }

        // Get users for dropdown
        $users = $this->userModel->findAll();

        return $this->renderView('admin/api_tokens/index.html', [
            'tokens' => $tokens,
            'users' => $users,
            'current_user' => $this->currentUser
        ]);
    }

    /**
     * Create a new API token
     */
    public function create()
    {
        // Require admin role
        $check = $this->requireAdmin();
        if ($check !== true) {
            return $check;
        }

        if ($this->request->getMethod() !== 'post') {
            return redirect()->to('/admin/api_tokens');
        }

        // Validate request
        $rules = [
            'user_id' => 'required|integer|is_natural_no_zero',
            'expiry_days' => 'required|integer|greater_than[0]|less_than[366]'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()
                ->with('error', implode('<br>', $this->validator->getErrors()));
        }

        $userId = $this->request->getPost('user_id');
        $expiryDays = $this->request->getPost('expiry_days');

        // Check if user exists
        $user = $this->userModel->find($userId);
        if (!$user) {
            return redirect()->back()
                ->with('error', 'Người dùng không tồn tại');
        }

        // Verify permissions - Admin can create tokens for Contributors,
        // Founder can create tokens for all roles
        if ($this->currentUser['role'] < 3 && $user['role'] >= $this->currentUser['role']) {
            return redirect()->back()
                ->with('error', 'Bạn không có quyền tạo token cho người dùng này');
        }

        // Generate token
        $tokenValue = $this->tokenModel->createTokenWithExpiry($userId, $expiryDays);

        // Log the action
        $this->logModel->info('Tạo API token mới', [
            'user_id' => $this->currentUser['id'],
            'target_user_id' => $userId,
            'expires_in_days' => $expiryDays
        ]);

        return redirect()->to('/admin/api_tokens')
            ->with('success', 'Token đã được tạo thành công. Vui lòng lưu lại token: ' . $tokenValue);
    }

    /**
     * Revoke an API token
     */
    public function revoke($id = null)
    {
        // Require admin role
        $check = $this->requireAdmin();
        if ($check !== true) {
            return $check;
        }

        if (!$id) {
            return redirect()->to('/admin/api_tokens')
                ->with('error', 'ID token không hợp lệ');
        }

        // Get token with user info
        $db = \Config\Database::connect();
        $token = $db->table('tokens')
                  ->select('tokens.*, users.role as user_role')
                  ->join('users', 'users.id = tokens.user_id')
                  ->where('tokens.id', $id)
                  ->get()
                  ->getRowArray();

        if (!$token) {
            return redirect()->to('/admin/api_tokens')
                ->with('error', 'Token không tồn tại');
        }

        // Verify permissions - Admin can revoke tokens from Contributors,
        // Founder can revoke all tokens
        if ($this->currentUser['role'] < 3 && $token['user_role'] >= $this->currentUser['role']) {
            return redirect()->to('/admin/api_tokens')
                ->with('error', 'Bạn không có quyền thu hồi token này');
        }

        // Revoke token
        $this->tokenModel->delete($id);

        // Log the action
        $this->logModel->info('Thu hồi API token', [
            'user_id' => $this->currentUser['id'],
            'token_id' => $id,
            'target_user_id' => $token['user_id']
        ]);

        return redirect()->to('/admin/api_tokens')
            ->with('success', 'Token đã được thu hồi thành công');
    }

    /**
     * View token details
     */
    public function view($id = null)
    {
        // Require admin role
        $check = $this->requireAdmin();
        if ($check !== true) {
            return $check;
        }

        if (!$id) {
            return redirect()->to('/admin/api_tokens')
                ->with('error', 'ID token không hợp lệ');
        }

        // Get token with user info
        $db = \Config\Database::connect();
        $token = $db->table('tokens')
                  ->select('tokens.*, users.username, users.display_name, users.role')
                  ->join('users', 'users.id = tokens.user_id')
                  ->where('tokens.id', $id)
                  ->get()
                  ->getRowArray();

        if (!$token) {
            return redirect()->to('/admin/api_tokens')
                ->with('error', 'Token không tồn tại');
        }

        // Format dates
        $token['created_at_formatted'] = $this->formatDate($token['created_at']);
        $token['expires_at_formatted'] = $this->formatDate($token['expires_at']);
        $token['role_text'] = $this->userModel->getRoleText($token['role']);

        // Verify permissions - Admin can view tokens from Contributors,
        // Founder can view all tokens
        if ($this->currentUser['role'] < 3 && $token['role'] >= $this->currentUser['role']) {
            return redirect()->to('/admin/api_tokens')
                ->with('error', 'Bạn không có quyền xem chi tiết token này');
        }

        return $this->renderView('admin/api_tokens/view.html', [
            'token' => $token,
            'current_user' => $this->currentUser
        ]);
    }

    /**
     * Regenerate token for a user
     */
    public function regenerate($id = null)
    {
        // Require admin role
        $check = $this->requireAdmin();
        if ($check !== true) {
            return $check;
        }

        if (!$id) {
            return redirect()->to('/admin/api_tokens')
                ->with('error', 'ID token không hợp lệ');
        }

        // Get token with user info
        $db = \Config\Database::connect();
        $token = $db->table('tokens')
                  ->select('tokens.*, users.role as user_role')
                  ->join('users', 'users.id = tokens.user_id')
                  ->where('tokens.id', $id)
                  ->get()
                  ->getRowArray();

        if (!$token) {
            return redirect()->to('/admin/api_tokens')
                ->with('error', 'Token không tồn tại');
        }

        // Verify permissions - Admin can regenerate tokens for Contributors,
        // Founder can regenerate all tokens
        if ($this->currentUser['role'] < 3 && $token['user_role'] >= $this->currentUser['role']) {
            return redirect()->to('/admin/api_tokens')
                ->with('error', 'Bạn không có quyền tái tạo token này');
        }

        // Calculate expiry days from current token
        $expiryDate = new \DateTime($token['expires_at']);
        $now = new \DateTime();
        $interval = $now->diff($expiryDate);
        $expiryDays = $interval->days ?: 30; // Default to 30 days if expired

        // Delete old token
        $this->tokenModel->delete($id);

        // Create new token
        $tokenValue = $this->tokenModel->createTokenWithExpiry($token['user_id'], $expiryDays);

        // Log the action
        $this->logModel->info('Tái tạo API token', [
            'user_id' => $this->currentUser['id'],
            'target_user_id' => $token['user_id'],
            'expires_in_days' => $expiryDays
        ]);

        return redirect()->to('/admin/api_tokens')
            ->with('success', 'Token đã được tái tạo thành công. Vui lòng lưu lại token mới: ' . $tokenValue);
    }
}
