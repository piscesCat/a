<?php

namespace App\Models;

use CodeIgniter\Model;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;

class TokenModel extends Model
{
    protected $table = 'tokens';
    protected $primaryKey = 'id';
    protected $allowedFields = ['user_id', 'token', 'expires_at', 'created_at'];

    /**
     * Tạo token mới cho người dùng
     *
     * @param int $userId ID người dùng
     * @return string Token được tạo
     */
    public function createToken($userId)
    {
        // Tạo token ngẫu nhiên
        $token = bin2hex(random_bytes(32));

        // Thời gian hết hạn (30 ngày)
        $expiresAt = date('Y-m-d H:i:s', strtotime('+30 days'));

        // Lưu vào database
        $data = [
            'user_id' => $userId,
            'token' => $token,
            'expires_at' => $expiresAt,
            'created_at' => date('Y-m-d H:i:s')
        ];

        $this->insert($data);

        return $token;
    }

    /**
     * Tạo token mới với thời gian hết hạn tùy chỉnh
     *
     * @param int $userId ID người dùng
     * @param int $expiryDays Số ngày token có hiệu lực
     * @return string Token được tạo
     */
    public function createTokenWithExpiry($userId, $expiryDays = 30)
    {
        // Tạo token ngẫu nhiên
        $token = bin2hex(random_bytes(32));

        // Thời gian hết hạn tùy chỉnh
        $expiresAt = date('Y-m-d H:i:s', strtotime("+{$expiryDays} days"));

        // Lưu vào database
        $data = [
            'user_id' => $userId,
            'token' => $token,
            'expires_at' => $expiresAt,
            'created_at' => date('Y-m-d H:i:s')
        ];

        $this->insert($data);

        return $token;
    }

    /**
     * Tạo JWT token dựa trên thông tin user
     *
     * @param array $user Thông tin người dùng
     * @param int $expiryDays Số ngày token có hiệu lực
     * @return string JWT token
     */
    public function createJwtToken($user, $expiryDays = 30)
    {
        $key = getenv('JWT_SECRET_KEY') ?: 'your-secure-jwt-secret-key';
        $time = time();
        $expire = $time + (86400 * $expiryDays); // 86400 = 1 day

        $payload = [
            'iss' => 'story_app',               // Issuer
            'aud' => 'story_app_api_users',     // Audience
            'iat' => $time,                     // Issued at time
            'nbf' => $time,                     // Not before time
            'exp' => $expire,                   // Expiration time
            'sub' => $user['id'],               // Subject (user ID)
            'uid' => $user['id'],               // User ID
            'uname' => $user['username'],       // Username
            'role' => $user['role']             // User role
        ];

        $jwt = JWT::encode($payload, $key, 'HS256');

        // Save token reference to database for revocation capability
        $data = [
            'user_id' => $user['id'],
            'token' => hash('sha256', $jwt), // Save hash of JWT for security
            'expires_at' => date('Y-m-d H:i:s', $expire),
            'created_at' => date('Y-m-d H:i:s')
        ];

        $this->insert($data);

        return $jwt;
    }

    /**
     * Xác thực JWT token
     *
     * @param string $jwt JWT token to verify
     * @return array|null User data if valid, null if invalid
     */
    public function verifyJwtToken($jwt)
    {
        $key = getenv('JWT_SECRET_KEY') ?: 'your-secure-jwt-secret-key';

        try {
            // Decode JWT
            $decoded = JWT::decode($jwt, new Key($key, 'HS256'));

            // Check if token exists in database and not revoked
            $hashedToken = hash('sha256', $jwt);
            $tokenExists = $this->where('token', $hashedToken)
                               ->where('expires_at >', date('Y-m-d H:i:s'))
                               ->first();

            if (!$tokenExists) {
                return null; // Token revoked or expired
            }

            // Get user data
            $userModel = new UserModel();
            $user = $userModel->find($decoded->uid);

            if (!$user) {
                return null;
            }

            return $user;
        } catch (\Exception $e) {
            // Token is invalid
            log_message('error', 'JWT validation error: ' . $e->getMessage());
            return null;
        }
    }

    /**
     * Lấy thông tin người dùng từ token
     *
     * @param string $token Token chuỗi
     * @return array|null Thông tin người dùng hoặc null nếu không tìm thấy
     */
    public function getUserFromToken($token)
    {
        // Tìm token trong database
        $tokenData = $this->where('token', $token)
                         ->where('expires_at >', date('Y-m-d H:i:s'))
                         ->first();

        if (!$tokenData) {
            return null;
        }

        // Lấy thông tin người dùng
        $userModel = new UserModel();
        $user = $userModel->find($tokenData['user_id']);

        if (!$user) {
            return null;
        }

        return $user;
    }

    /**
     * Xóa token
     *
     * @param string $token Token cần xóa
     * @return bool Kết quả xóa
     */
    public function deleteToken($token)
    {
        return $this->where('token', $token)->delete();
    }

    /**
     * Xóa tất cả token của người dùng
     *
     * @param int $userId ID người dùng
     * @return bool Kết quả xóa
     */
    public function deleteUserTokens($userId)
    {
        return $this->where('user_id', $userId)->delete();
    }

    /**
     * Xóa token hết hạn
     *
     * @return bool Kết quả xóa
     */
    public function deleteExpiredTokens()
    {
        return $this->where('expires_at <', date('Y-m-d H:i:s'))->delete();
    }
}
