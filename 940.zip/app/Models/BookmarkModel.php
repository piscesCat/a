<?php

namespace App\Models;

use CodeIgniter\Model;

class BookmarkModel extends Model
{
    protected $table = 'bookmarks';
    protected $primaryKey = 'id';
    protected $allowedFields = ['user_id', 'story_id', 'chapter_id', 'created_at', 'updated_at'];

    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    /**
     * Thêm hoặc xóa bookmark cho người dùng đã đăng nhập
     *
     * @param int $userId ID người dùng
     * @param int $storyId ID truyện
     * @param int|null $chapterId ID chương đang đọc (nếu có)
     * @return bool|array false nếu lỗi, mảng thông tin nếu thành công
     */
    public function toggleBookmark($userId, $storyId, $chapterId = null)
    {
        // Kiểm tra xem bookmark đã tồn tại chưa
        $existingBookmark = $this->where('user_id', $userId)
                                 ->where('story_id', $storyId)
                                 ->first();

        if ($existingBookmark) {
            // Xóa bookmark nếu đã tồn tại
            $this->delete($existingBookmark['id']);
            return [
                'action' => 'removed',
                'message' => 'Đã xóa khỏi danh sách bookmark'
            ];
        } else {
            // Thêm bookmark mới
            $data = [
                'user_id' => $userId,
                'story_id' => $storyId,
                'chapter_id' => $chapterId
            ];

            $this->insert($data);
            return [
                'action' => 'added',
                'message' => 'Đã thêm vào danh sách bookmark'
            ];
        }
    }

    /**
     * Lấy danh sách bookmark của người dùng đã đăng nhập
     */
    public function getUserBookmarks($userId, $limit = 10, $offset = 0)
    {
        return $this->select('bookmarks.*, stories.title, stories.slug, stories.cover_image')
                    ->join('stories', 'stories.id = bookmarks.story_id')
                    ->where('user_id', $userId)
                    ->orderBy('bookmarks.updated_at', 'DESC')
                    ->limit($limit, $offset)
                    ->findAll();
    }

    /**
     * Kiểm tra truyện có trong bookmark của người dùng hay không
     */
    public function isBookmarked($userId, $storyId)
    {
        return $this->where('user_id', $userId)
                    ->where('story_id', $storyId)
                    ->countAllResults() > 0;
    }

    /**
     * Cập nhật thông tin chương đang đọc cho bookmark
     */
    public function updateChapter($userId, $storyId, $chapterId)
    {
        $bookmark = $this->where('user_id', $userId)
                         ->where('story_id', $storyId)
                         ->first();

        if ($bookmark) {
            return $this->update($bookmark['id'], [
                'chapter_id' => $chapterId,
                'updated_at' => date('Y-m-d H:i:s')
            ]);
        }

        return false;
    }
}
