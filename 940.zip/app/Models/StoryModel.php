<?php
namespace App\Models;

use CodeIgniter\Model;

class StoryModel extends Model
{
    protected $table = 'stories';
    protected $primaryKey = 'id';
    protected $returnType = 'array';

    protected $allowedFields = [
        'title', 'slug', 'description', 'cover_image',
        'author', 'status', 'type', 'release_year',
        'country_id', 'views', 'views_day', 'views_week', 'views_month',
        'rating', 'total_ratings', 'total_favorites', 'created_at',
        'updated_at', 'is_featured', 'is_completed', 'search_vector'
    ];

    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    /**
     * Lấy thông tin truyện kèm theo thông tin liên quan
     */
    public function getStory($slug)
    {
        $builder = $this->db->table('stories s')
            ->select('s.*, c.name as country_name, c.slug as country_slug')
            ->join('countries c', 's.country_id = c.id', 'left')
            ->where('s.slug', $slug);

        $story = $builder->get()->getRowArray();

        if (!$story) {
            return null;
        }

        // Lấy danh sách thể loại của truyện
        $story['categories'] = $this->getStoryCategories($story['id']);

        // Lấy danh sách chương
        $chapterModel = new ChapterModel();
        $story['chapters'] = $chapterModel->where('story_id', $story['id'])
            ->orderBy('chapter_number', 'ASC')
            ->findAll();

        // Lấy thông tin chương mới nhất
        $story['latest_chapter'] = !empty($story['chapters'])
            ? end($story['chapters'])
            : null;

        return $story;
    }

    /**
     * Lấy danh sách truyện mới nhất
     */
    public function getLatestStories($limit = 10)
    {
        return $this->orderBy('created_at', 'DESC')
            ->limit($limit)
            ->find();
    }

    /**
     * Lấy danh sách truyện phổ biến dựa trên thuật toán kết hợp
     * Công thức: (lượt xem tuần * 0.5) + (lượt xem ngày * 0.3) + (lượt yêu thích * 0.2)
     */
    public function getPopularStories($limit = 10)
    {
        $builder = $this->db->table('stories')
            ->select('*, (views_week * 0.5 + views_day * 0.3 + total_favorites * 0.2) as popularity_score')
            ->orderBy('popularity_score', 'DESC')
            ->limit($limit);

        return $builder->get()->getResultArray();
    }

    /**
     * Lấy danh sách truyện xem nhiều nhất theo thời gian
     */
    public function getMostViewedStories($period = 'all', $limit = 10)
    {
        $builder = $this->db->table('stories');

        switch ($period) {
            case 'day':
                $builder->orderBy('views_day', 'DESC');
                break;
            case 'week':
                $builder->orderBy('views_week', 'DESC');
                break;
            case 'month':
                $builder->orderBy('views_month', 'DESC');
                break;
            default:
                $builder->orderBy('views', 'DESC');
                break;
        }

        return $builder->limit($limit)->get()->getResultArray();
    }

    /**
     * Lấy truyện được đánh giá cao nhất
     */
    public function getTopRatedStories($limit = 10)
    {
        // Chỉ lấy truyện có ít nhất 5 lượt đánh giá
        return $this->where('total_ratings >=', 5)
            ->orderBy('rating', 'DESC')
            ->limit($limit)
            ->find();
    }

    /**
     * Lấy truyện hoàn thành
     */
    public function getCompletedStories($limit = 10)
    {
        return $this->where('is_completed', 1)
            ->orderBy('updated_at', 'DESC')
            ->limit($limit)
            ->find();
    }

    /**
     * Lấy truyện nổi bật
     */
    public function getFeaturedStories($limit = 5)
    {
        return $this->where('is_featured', 1)
            ->orderBy('updated_at', 'DESC')
            ->limit($limit)
            ->find();
    }

    /**
     * Tìm kiếm truyện sử dụng PostgreSQL Full-Text Search
     */
    public function searchStories($keyword, $limit = 20, $offset = 0, $filters = [])
    {
        // Chuẩn bị từ khóa tìm kiếm
        $keyword = trim($keyword);

        // Kiểm tra nếu bảng stories chưa có cột vector_search thì thêm vào
        $this->ensureSearchVectorColumn();

        $builder = $this->db->table('stories s')
            ->select('s.*, c.name as country_name')
            ->join('countries c', 's.country_id = c.id', 'left');

        // Chuyển đổi để sử dụng Full-Text Search của PostgreSQL
        if ($keyword) {
            // Chuẩn bị query string phù hợp với PostgreSQL
            $tsQuery = str_replace(' ', ' & ', $keyword);
            // Dùng để_tsvector (Vietnamese) nếu có
            $hasVietnameseDict = $this->checkVietnameseDictExists();

            if ($hasVietnameseDict) {
                $builder->where("s.search_vector @@ to_tsquery('vietnamese', ?)", [$tsQuery]);
                $builder->orderBy("ts_rank(s.search_vector, to_tsquery('vietnamese', '$tsQuery'))", 'DESC');
            } else {
                // Fallback to simple search if Vietnamese dictionary is not available
                $builder->where("s.search_vector @@ plainto_tsquery('simple', ?)", [$keyword]);
                $builder->orderBy("ts_rank(s.search_vector, plainto_tsquery('simple', '$keyword'))", 'DESC');
            }
        }

        // Áp dụng các bộ lọc
        if (!empty($filters)) {
            if (!empty($filters['category'])) {
                $builder->join('story_categories sc', 's.id = sc.story_id')
                      ->join('categories cat', 'sc.category_id = cat.id')
                      ->where('cat.slug', $filters['category']);
            }

            if (!empty($filters['status'])) {
                if ($filters['status'] === 'completed') {
                    $builder->where('s.is_completed', 1);
                } elseif ($filters['status'] === 'ongoing') {
                    $builder->where('s.is_completed', 0);
                }
            }

            if (!empty($filters['country'])) {
                $builder->where('c.slug', $filters['country']);
            }

            if (!empty($filters['year'])) {
                $builder->where('s.release_year', $filters['year']);
            }
        }

        // Đếm tổng số kết quả
        $total = $builder->countAllResults(false);

        // Lấy kết quả với phân trang
        $result = $builder->limit($limit, $offset)
                        ->get()
                        ->getResultArray();

        return [
            'total' => $total,
            'stories' => $result
        ];
    }

    /**
     * Gợi ý tìm kiếm sử dụng Full-Text Search
     */
    public function getSearchSuggestions($keyword, $limit = 10)
    {
        // Chuẩn bị từ khóa tìm kiếm
        $keyword = trim($keyword);

        // Đảm bảo cột search_vector tồn tại
        $this->ensureSearchVectorColumn();

        $builder = $this->db->table('stories');

        // Sử dụng Full-Text Search nếu từ khóa đủ dài
        if (strlen($keyword) >= 2) {
            // Kiểm tra từ điển tiếng Việt
            $hasVietnameseDict = $this->checkVietnameseDictExists();

            if ($hasVietnameseDict) {
                $tsQuery = str_replace(' ', ' & ', $keyword);
                $builder->where("search_vector @@ to_tsquery('vietnamese', ?)", [$tsQuery])
                       ->orderBy("ts_rank(search_vector, to_tsquery('vietnamese', '$tsQuery'))", 'DESC');
            } else {
                // Fallback to simple search if Vietnamese dictionary is not available
                $builder->where("search_vector @@ plainto_tsquery('simple', ?)", [$keyword])
                       ->orderBy("ts_rank(search_vector, plainto_tsquery('simple', '$keyword'))", 'DESC');
            }
        } else {
            // Fallback to basic LIKE search for short queries
            $builder->like('title', $keyword)
                   ->orderBy('views', 'DESC');
        }

        return $builder->select('id, title, slug, cover_image')
                      ->limit($limit)
                      ->get()
                      ->getResultArray();
    }

    /**
     * Đảm bảo rằng bảng stories có cột search_vector để dùng Full-Text Search
     */
    private function ensureSearchVectorColumn()
    {
        // Kiểm tra xem cột search_vector đã tồn tại chưa
        $query = $this->db->query("
            SELECT column_name
            FROM information_schema.columns
            WHERE table_name = 'stories' AND column_name = 'search_vector'
        ");

        if (count($query->getResultArray()) === 0) {
            // Cột chưa tồn tại, tạo mới
            $this->db->query("
                ALTER TABLE stories
                ADD COLUMN search_vector tsvector
            ");

            // Cập nhật giá trị ban đầu
            $this->updateSearchVectors();

            // Tạo index GIN cho cột search_vector
            $this->db->query("
                CREATE INDEX stories_search_idx
                ON stories
                USING GIN(search_vector)
            ");

            // Tạo trigger để tự động cập nhật search_vector khi dữ liệu thay đổi
            $this->db->query("
                CREATE OR REPLACE FUNCTION stories_vector_update() RETURNS TRIGGER AS $$
                BEGIN
                    NEW.search_vector := to_tsvector('english',
                        coalesce(NEW.title, '') || ' ' ||
                        coalesce(NEW.description, '') || ' ' ||
                        coalesce(NEW.author, '')
                    );
                    RETURN NEW;
                END
                $$ LANGUAGE plpgsql;
            ");

            $this->db->query("
                CREATE TRIGGER stories_vector_update
                BEFORE INSERT OR UPDATE ON stories
                FOR EACH ROW EXECUTE FUNCTION stories_vector_update();
            ");
        }
    }

    /**
     * Cập nhật giá trị search_vector cho tất cả các dòng hiện có
     */
    public function updateSearchVectors()
    {
        $this->db->query("
            UPDATE stories
            SET search_vector = to_tsvector('english',
                coalesce(title, '') || ' ' ||
                coalesce(description, '') || ' ' ||
                coalesce(author, '')
            )
        ");
    }

    /**
     * Kiểm tra xem từ điển tiếng Việt có tồn tại trong PostgreSQL không
     */
    private function checkVietnameseDictExists()
    {
        $query = $this->db->query("
            SELECT cfgname
            FROM pg_ts_config
            WHERE cfgname = 'vietnamese'
        ");

        return count($query->getResultArray()) > 0;
    }

    /**
     * Lấy truyện theo thể loại
     */
    public function getStoriesByCategory($categorySlug, $limit = 20, $offset = 0)
    {
        $builder = $this->db->table('stories s')
            ->select('s.*, c.name as country_name')
            ->join('story_categories sc', 's.id = sc.story_id')
            ->join('categories cat', 'sc.category_id = cat.id')
            ->join('countries c', 's.country_id = c.id', 'left')
            ->where('cat.slug', $categorySlug);

        $total = $builder->countAllResults(false);

        $result = $builder->orderBy('s.updated_at', 'DESC')
            ->limit($limit, $offset)
            ->get()
            ->getResultArray();

        return [
            'total' => $total,
            'stories' => $result
        ];
    }

    /**
     * Lấy truyện theo quốc gia
     */
    public function getStoriesByCountry($countrySlug, $limit = 20, $offset = 0)
    {
        $builder = $this->db->table('stories s')
            ->select('s.*, c.name as country_name')
            ->join('countries c', 's.country_id = c.id')
            ->where('c.slug', $countrySlug);

        $total = $builder->countAllResults(false);

        $result = $builder->orderBy('s.updated_at', 'DESC')
            ->limit($limit, $offset)
            ->get()
            ->getResultArray();

        return [
            'total' => $total,
            'stories' => $result
        ];
    }

    /**
     * Lấy truyện theo năm phát hành
     */
    public function getStoriesByYear($year, $limit = 20, $offset = 0)
    {
        $builder = $this->db->table('stories s')
            ->select('s.*, c.name as country_name')
            ->join('countries c', 's.country_id = c.id', 'left')
            ->where('s.release_year', $year);

        $total = $builder->countAllResults(false);

        $result = $builder->orderBy('s.views', 'DESC')
            ->limit($limit, $offset)
            ->get()
            ->getResultArray();

        return [
            'total' => $total,
            'stories' => $result
        ];
    }

    /**
     * Lấy truyện theo tác giả
     */
    public function getStoriesByAuthor($author, $limit = 20, $offset = 0)
    {
        $builder = $this->db->table('stories s')
            ->select('s.*, c.name as country_name')
            ->join('countries c', 's.country_id = c.id', 'left')
            ->where('s.author', $author);

        $total = $builder->countAllResults(false);

        $result = $builder->orderBy('s.views', 'DESC')
            ->limit($limit, $offset)
            ->get()
            ->getResultArray();

        return [
            'total' => $total,
            'stories' => $result
        ];
    }

    /**
     * Lấy thể loại của truyện
     */
    public function getStoryCategories($storyId)
    {
        $builder = $this->db->table('categories c')
            ->select('c.id, c.name, c.slug')
            ->join('story_categories sc', 'c.id = sc.category_id')
            ->where('sc.story_id', $storyId)
            ->orderBy('c.name', 'ASC');

        return $builder->get()->getResultArray();
    }

    /**
     * Lấy truyện liên quan (cùng thể loại)
     */
    public function getRelatedStories($storyId, $limit = 6)
    {
        // Lấy danh sách thể loại của truyện hiện tại
        $categoryIds = $this->db->table('story_categories')
            ->select('category_id')
            ->where('story_id', $storyId)
            ->get()
            ->getResultArray();

        if (empty($categoryIds)) {
            return [];
        }

        $categoryIds = array_column($categoryIds, 'category_id');

        // Lấy truyện có cùng thể loại
        $builder = $this->db->table('stories s')
            ->select('DISTINCT s.id, s.title, s.slug, s.cover_image, s.views, s.rating')
            ->join('story_categories sc', 's.id = sc.story_id')
            ->where('s.id !=', $storyId)
            ->whereIn('sc.category_id', $categoryIds)
            ->orderBy('s.views', 'DESC')
            ->limit($limit);

        return $builder->get()->getResultArray();
    }

    /**
     * Cập nhật lượt xem cho truyện
     */
    public function updateViews($storyId)
    {
        // Cập nhật tổng lượt xem
        $this->db->table('stories')
            ->where('id', $storyId)
            ->set('views', 'views + 1', false)
            ->set('views_day', 'views_day + 1', false)
            ->set('views_week', 'views_week + 1', false)
            ->set('views_month', 'views_month + 1', false)
            ->update();
    }

    /**
     * Reset lượt xem theo ngày (chạy mỗi ngày)
     */
    public function resetDailyViews()
    {
        $this->db->table('stories')
            ->set('views_day', 0)
            ->update();
    }

    /**
     * Reset lượt xem theo tuần (chạy mỗi tuần)
     */
    public function resetWeeklyViews()
    {
        $this->db->table('stories')
            ->set('views_week', 0)
            ->update();
    }

    /**
     * Reset lượt xem theo tháng (chạy mỗi tháng)
     */
    public function resetMonthlyViews()
    {
        $this->db->table('stories')
            ->set('views_month', 0)
            ->update();
    }

    /**
     * Cập nhật đánh giá cho truyện
     */
    public function updateRating($storyId, $rating)
    {
        // Lấy thông tin truyện hiện tại
        $story = $this->find($storyId);

        if (!$story) {
            return false;
        }

        // Tính toán rating mới
        $totalRatings = $story['total_ratings'] + 1;
        $newRating = (($story['rating'] * $story['total_ratings']) + $rating) / $totalRatings;

        // Cập nhật vào database
        return $this->update($storyId, [
            'rating' => round($newRating, 1),
            'total_ratings' => $totalRatings
        ]);
    }

    /**
     * Lấy bảng xếp hạng truyện
     */
    public function getRankings()
    {
        $rankings = [
            'most_viewed' => $this->getMostViewedStories('all', 10),
            'daily' => $this->getMostViewedStories('day', 10),
            'weekly' => $this->getMostViewedStories('week', 10),
            'monthly' => $this->getMostViewedStories('month', 10),
            'top_rated' => $this->getTopRatedStories(10),
            'most_favorited' => $this->orderBy('total_favorites', 'DESC')->limit(10)->find(),
            'completed' => $this->getCompletedStories(10)
        ];

        return $rankings;
    }

    /**
     * Tính điểm hot cho truyện
     * Công thức: (lượt xem tuần * 0.5) + (số bình luận * 2) + (lượt yêu thích * 3) + (đánh giá * 10) + recency_bonus
     */
    public function calculateHotScore()
    {
        // Tính số bình luận cho mỗi truyện
        $commentCounts = $this->db->table('comments')
            ->select('story_id, COUNT(*) as comment_count')
            ->where('created_at >=', date('Y-m-d H:i:s', strtotime('-30 days')))
            ->groupBy('story_id')
            ->get()
            ->getResultArray();

        // Tạo map để lookup nhanh số bình luận
        $commentMap = [];
        foreach ($commentCounts as $item) {
            $commentMap[$item['story_id']] = $item['comment_count'];
        }

        // Lấy danh sách tất cả truyện
        $stories = $this->findAll();

        // Tính hot_score cho từng truyện
        foreach ($stories as $story) {
            $storyId = $story['id'];
            $commentCount = $commentMap[$storyId] ?? 0;

            // Tính recency_bonus dựa trên thời gian cập nhật
            $updatedTimestamp = strtotime($story['updated_at']);
            $currentTimestamp = time();
            $daysDiff = ($currentTimestamp - $updatedTimestamp) / (60 * 60 * 24);

            // Truyện càng mới càng được ưu tiên, tối đa 50 điểm cho truyện cập nhật trong ngày
            $recencyBonus = max(0, 50 - ($daysDiff * 5));

            // Tính hot_score theo công thức
            $hotScore = ($story['views_week'] * 0.5) +
                        ($commentCount * 2) +
                        ($story['total_favorites'] * 3) +
                        ($story['rating'] * 10) +
                        $recencyBonus;

            // Cập nhật hot_score
            $this->update($storyId, ['hot_score' => $hotScore]);
        }
    }

    /**
     * Lấy truyện đề xuất dựa trên thuật toán thông minh
     * Thuật toán kết hợp:
     * - Độ phổ biến (lượt xem, yêu thích)
     * - Chất lượng nội dung (đánh giá, bình luận)
     * - Tính thời sự (thời gian cập nhật)
     * - Độ tương tác (tốc độ tăng lượt xem)
     * - Độ phù hợp với xu hướng hiện tại
     */
    public function getRecommendedStories($limit = 10)
    {
        // Lấy thời gian hiện tại
        $now = time();

        // Tính điểm xu hướng cho các truyện
        $stories = $this->findAll();
        $trendScores = [];

        foreach ($stories as $story) {
            $storyId = $story['id'];

            // 1. Tính điểm tính thời sự (tối đa 100 điểm)
            $updatedTimestamp = strtotime($story['updated_at']);
            $daysSinceUpdate = ($now - $updatedTimestamp) / (60 * 60 * 24);
            $recencyScore = min(100, max(0, 100 - ($daysSinceUpdate * 10))); // Giảm 10 điểm/ngày

            // 2. Tính điểm tăng trưởng từ lượt xem (tối đa 100 điểm)
            $viewsGrowth = 0;
            if ($story['views'] > 0) {
                $dailyRatio = $story['views_day'] / max(1, $story['views']) * 100;
                $weeklyRatio = $story['views_week'] / max(1, $story['views']) * 100;
                $viewsGrowth = min(100, ($dailyRatio * 0.7) + ($weeklyRatio * 0.3));
            }

            // 3. Tính điểm chất lượng (tối đa 100 điểm)
            $qualityScore = 0;
            if ($story['total_ratings'] > 0) {
                // Điểm đánh giá (0-5) chuyển thành thang điểm 0-100
                $ratingScore = ($story['rating'] / 5) * 100;
                $qualityScore = $ratingScore;
            } else {
                // Nếu chưa có đánh giá, dùng tỷ lệ lượt thích
                $qualityScore = min(80, ($story['total_favorites'] / max(1, $story['views'])) * 1000);
            }

            // 4. Tính điểm phổ biến (tối đa 100 điểm)
            $popularityScore = min(100,
                (log10(max(1, $story['views_week'])) * 20) +
                (log10(max(1, $story['total_favorites'])) * 10)
            );

            // 5. Tính điểm hoàn thiện (truyện đã hoàn thành được cộng thêm điểm)
            $completionScore = $story['is_completed'] ? 20 : 0;

            // Cân bằng các yếu tố với trọng số khác nhau để tính điểm tổng
            $trendScore =
                ($recencyScore * 0.35) +       // 35% tính thời sự
                ($viewsGrowth * 0.25) +        // 25% tốc độ tăng trưởng
                ($qualityScore * 0.20) +       // 20% chất lượng
                ($popularityScore * 0.15) +    // 15% độ phổ biến
                ($completionScore * 0.05);     // 5% trạng thái hoàn thành

            $trendScores[$storyId] = $trendScore;
        }

        // Sắp xếp truyện theo điểm giảm dần
        arsort($trendScores);

        // Lấy top N truyện có điểm cao nhất
        $topStoryIds = array_slice(array_keys($trendScores), 0, $limit * 2);

        if (empty($topStoryIds)) {
            return [];
        }

        // Lấy thông tin đầy đủ của truyện và thêm một chút ngẫu nhiên để đa dạng kết quả
        $recommendedStories = $this->whereIn('id', $topStoryIds)->findAll();

        // Sắp xếp lại theo điểm tính toán
        usort($recommendedStories, function($a, $b) use ($trendScores) {
            return $trendScores[$b['id']] - $trendScores[$a['id']];
        });

        // Thêm yếu tố ngẫu nhiên: 80% top stories + 20% ngẫu nhiên từ top stories
        $result = array_slice($recommendedStories, 0, (int)($limit * 0.8));
        $remaining = array_slice($recommendedStories, (int)($limit * 0.8));

        // Trộn ngẫu nhiên phần còn lại và chọn ra số lượng còn thiếu
        shuffle($remaining);
        $randomPicks = array_slice($remaining, 0, $limit - count($result));

        return array_merge($result, $randomPicks);
    }

    /**
     * Lấy truyện hot dựa trên hot_score (phương thức cũ)
     * @deprecated Dùng getRecommendedStories thay thế
     */
    public function getHotStories($limit = 10)
    {
        // Đảm bảo hot_score được cập nhật
        $this->calculateHotScore();

        return $this->orderBy('hot_score', 'DESC')
            ->limit($limit)
            ->find();
    }

    /**
     * Gợi ý truyện cho người dùng dựa trên lịch sử đọc
     */
    public function getSuggestedStories($userId, $limit = 10)
    {
        if (!$userId) {
            // Nếu không có user_id, trả về truyện đề xuất
            return $this->getRecommendedStories($limit);
        }

        // Lấy thể loại từ lịch sử đọc
        $readCategories = $this->db->table('reading_history rh')
            ->select('sc.category_id, COUNT(*) as category_count')
            ->join('stories s', 'rh.story_id = s.id')
            ->join('story_categories sc', 's.id = sc.story_id')
            ->where('rh.user_id', $userId)
            ->groupBy('sc.category_id')
            ->orderBy('category_count', 'DESC')
            ->limit(5)
            ->get()
            ->getResultArray();

        if (empty($readCategories)) {
            // Nếu không có lịch sử đọc, trả về truyện đề xuất
            return $this->getRecommendedStories($limit);
        }

        $categoryIds = array_column($readCategories, 'category_id');

        // Lấy truyện có thể loại tương tự với lịch sử đọc
        $readStoryIds = $this->db->table('reading_history')
            ->select('story_id')
            ->where('user_id', $userId)
            ->get()
            ->getResultArray();

        $readStoryIds = array_column($readStoryIds, 'story_id');

        $builder = $this->db->table('stories s')
            ->select('s.*, COUNT(sc.category_id) as matching_categories')
            ->join('story_categories sc', 's.id = sc.story_id')
            ->whereIn('sc.category_id', $categoryIds);

        // Loại bỏ truyện đã đọc
        if (!empty($readStoryIds)) {
            $builder->whereNotIn('s.id', $readStoryIds);
        }

        return $builder->groupBy('s.id')
            ->orderBy('matching_categories', 'DESC')
            ->orderBy('s.views', 'DESC')
            ->limit($limit)
            ->get()
            ->getResultArray();
    }
}
