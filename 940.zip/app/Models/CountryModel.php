<?php
namespace App\Models;

use CodeIgniter\Model;

class CountryModel extends Model
{
    protected $table = 'countries';
    protected $primaryKey = 'id';
    protected $returnType = 'array';
    protected $allowedFields = [
        'name', 'slug', 'description', 'flag_image',
        'code', 'region', 'status'
    ];

    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    /**
     * Lấy tất cả quốc gia kèm số lượng truyện
     */
    public function getCountriesWithCount()
    {
        $db = \Config\Database::connect();
        $builder = $db->table('countries')
                      ->select('countries.*, COUNT(stories.id) as story_count')
                      ->join('stories', 'stories.country_id = countries.id', 'left')
                      ->groupBy('countries.id')
                      ->orderBy('countries.name', 'ASC');

        return $builder->get()->getResultArray();
    }

    /**
     * Lấy quốc gia theo slug
     */
    public function getCountryBySlug($slug)
    {
        return $this->where('slug', $slug)->first();
    }

    /**
     * Lấy quốc gia theo mã
     */
    public function getCountryByCode($code)
    {
        return $this->where('code', $code)->first();
    }

    /**
     * Lấy quốc gia phổ biến (nhiều truyện nhất)
     */
    public function getPopularCountries($limit = 10)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('countries')
                      ->select('countries.*, COUNT(stories.id) as story_count')
                      ->join('stories', 'stories.country_id = countries.id', 'left')
                      ->where('countries.status', 'active')
                      ->groupBy('countries.id')
                      ->orderBy('story_count', 'DESC')
                      ->limit($limit);

        return $builder->get()->getResultArray();
    }

    /**
     * Lấy tất cả quốc gia đang hoạt động
     */
    public function getActiveCountries()
    {
        return $this->where('status', 'active')
                   ->orderBy('name', 'ASC')
                   ->findAll();
    }

    /**
     * Lấy danh sách quốc gia theo khu vực
     */
    public function getCountriesByRegion()
    {
        $countries = $this->where('status', 'active')
                        ->orderBy('region', 'ASC')
                        ->orderBy('name', 'ASC')
                        ->findAll();

        $result = [];

        foreach ($countries as $country) {
            $region = $country['region'] ?? 'Other';
            if (!isset($result[$region])) {
                $result[$region] = [];
            }
            $result[$region][] = $country;
        }

        return $result;
    }
}
