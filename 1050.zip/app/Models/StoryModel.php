<?php
namespace App\Models;

use CodeIgniter\Model;

class StoryModel extends Model
{
    protected $table = 'stories';
    protected $primaryKey = 'id';
    protected $returnType = 'array';

    protected $allowedFields = [
        'title', 'slug', 'description', 'cover_image',
        'author_id', 'author_name', 'uploader_id', 'status', 'type', 'release_year',
        'country', 'views', 'views_day', 'views_week', 'views_month',
        'rating', 'total_ratings', 'total_favorites', 'created_at',
        'updated_at', 'is_featured', 'is_completed', 'search_vector', 'is_recommended'
    ];

    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    /**
     * Lấy thông tin truyện kèm theo thông tin liên quan
     */
    public function getStory($slug)
    {
        $builder = $this->db->table('stories s')
            ->select('s.*')
            ->where('s.slug', $slug);

        $story = $builder->get()->getRowArray();

        if (!$story) {
            return null;
        }

        // Lấy danh sách thể loại của truyện
        $story['categories'] = $this->getStoryCategories($story['id']);

        // Lấy danh sách chương
        $chapterModel = new ChapterModel();
        $story['chapters'] = $chapterModel->where('story_id', $story['id'])
            ->orderBy('chapter_number', 'ASC')
            ->findAll();

        // Lấy thông tin chương mới nhất
        $story['latest_chapter'] = !empty($story['chapters'])
            ? $story['chapters'][count($story['chapters']) - 1]
            : null;

        return $story;
    }

    /**
     * Lấy danh sách các thể loại của truyện
     */
    public function getStoryCategories($storyId)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('story_categories sc')
            ->select('c.*')
            ->join('categories c', 'c.id = sc.category_id')
            ->where('sc.story_id', $storyId);

        return $builder->get()->getResultArray();
    }

    /**
     * Lấy danh sách quốc gia có truyện trong hệ thống
     * Bây giờ lấy trực tiếp từ trường country
     */
    public function getCountries()
    {
        $db = \Config\Database::connect();
        $builder = $db->table('stories')
            ->select('country, COUNT(*) as story_count')
            ->where('country IS NOT NULL')
            ->where('country !=', '')
            ->where('status', 'published')
            ->groupBy('country')
            ->orderBy('country', 'ASC');

        return $builder->get()->getResultArray();
    }

    /**
     * Lấy truyện theo quốc gia
     */
    public function getStoriesByCountry($country, $limit = 12, $offset = 0)
    {
        return $this->where('country', $country)
            ->where('status', 'published')
            ->orderBy('created_at', 'DESC')
            ->limit($limit, $offset)
            ->findAll();
    }

    /**
     * Đếm số lượng truyện theo quốc gia
     */
    public function countStoriesByCountry($country)
    {
        return $this->where('country', $country)
            ->where('status', 'published')
            ->countAllResults();
    }

    /**
     * Get featured stories
     */
    public function getFeaturedStories($limit = 6)
    {
        return $this->where('is_featured', true)
                   ->where('status', 'published')
                   ->orderBy('created_at', 'DESC')
                   ->limit($limit)
                   ->find();
    }

    /**
     * Get recently updated stories
     */
    public function getRecentlyUpdated($limit = 12, $offset = 0, $status = null)
    {
        $builder = $this->where('status', 'published');

        if ($status) {
            if ($status == 'completed') {
                $builder->where('is_completed', true);
            } elseif ($status == 'ongoing') {
                $builder->where('is_completed', false);
            }
        }

        return $builder->orderBy('updated_at', 'DESC')
                      ->limit($limit, $offset)
                      ->find();
    }

    /**
     * Count recently updated stories
     */
    public function getRecentlyUpdatedCount($status = null)
    {
        $builder = $this->where('status', 'published');

        if ($status) {
            if ($status == 'completed') {
                $builder->where('is_completed', true);
            } elseif ($status == 'ongoing') {
                $builder->where('is_completed', false);
            }
        }

        return $builder->countAllResults();
    }

    /**
     * Get popular stories
     */
    public function getPopularStories($limit = 5)
    {
        return $this->where('status', 'published')
                   ->orderBy('views', 'DESC')
                   ->limit($limit)
                   ->find();
    }

    /**
     * Get completed stories
     */
    public function getCompleted($limit = 6, $offset = 0, $sort = null)
    {
        $builder = $this->where('is_completed', true)
                        ->where('status', 'published');

        if ($sort) {
            switch ($sort) {
                case 'oldest':
                    $builder->orderBy('created_at', 'ASC');
                    break;
                case 'name_asc':
                    $builder->orderBy('title', 'ASC');
                    break;
                case 'name_desc':
                    $builder->orderBy('title', 'DESC');
                    break;
                case 'view':
                    $builder->orderBy('views', 'DESC');
                    break;
                case 'rating':
                    $builder->orderBy('rating', 'DESC');
                    break;
                default:
                    $builder->orderBy('updated_at', 'DESC');
                    break;
            }
        } else {
            $builder->orderBy('updated_at', 'DESC');
        }

        return $builder->limit($limit, $offset)
                      ->find();
    }

    /**
     * Count completed stories
     */
    public function getCompletedCount()
    {
        return $this->where('is_completed', true)
                   ->where('status', 'published')
                   ->countAllResults();
    }

    /**
     * Get stories by category
     */
    public function getByCategory($categoryId, $limit = 12, $offset = 0, $sort = null, $status = null)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('stories')
                    ->select('stories.*')
                    ->join('story_categories', 'story_categories.story_id = stories.id')
                    ->where('story_categories.category_id', $categoryId)
                    ->where('stories.status', 'published');

        if ($status) {
            if ($status == 'completed') {
                $builder->where('stories.is_completed', true);
            } elseif ($status == 'ongoing') {
                $builder->where('stories.is_completed', false);
            }
        }

        if ($sort) {
            switch ($sort) {
                case 'oldest':
                    $builder->orderBy('stories.created_at', 'ASC');
                    break;
                case 'name_asc':
                    $builder->orderBy('stories.title', 'ASC');
                    break;
                case 'name_desc':
                    $builder->orderBy('stories.title', 'DESC');
                    break;
                case 'view':
                    $builder->orderBy('stories.views', 'DESC');
                    break;
                case 'rating':
                    $builder->orderBy('stories.rating', 'DESC');
                    break;
                default:
                    $builder->orderBy('stories.created_at', 'DESC');
                    break;
            }
        } else {
            $builder->orderBy('stories.created_at', 'DESC');
        }

        $query = $builder->limit($limit, $offset)->get();

        return $query->getResultArray();
    }

    /**
     * Get count of stories by category
     */
    public function getByCategoryCount($categoryId, $status = null)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('stories')
                    ->join('story_categories', 'story_categories.story_id = stories.id')
                    ->where('story_categories.category_id', $categoryId)
                    ->where('stories.status', 'published');

        if ($status) {
            if ($status == 'completed') {
                $builder->where('stories.is_completed', true);
            } elseif ($status == 'ongoing') {
                $builder->where('stories.is_completed', false);
            }
        }

        return $builder->countAllResults();
    }

    /**
     * Get hot stories
     */
    public function getHotStories($limit = 12, $offset = 0, $sort = 'views', $status = null)
    {
        $builder = $this->where('status', 'published')
                        ->where('is_hot', true);

        if ($status) {
            if ($status == 'completed') {
                $builder->where('is_completed', true);
            } elseif ($status == 'ongoing') {
                $builder->where('is_completed', false);
            }
        }

        switch ($sort) {
            case 'latest':
                $builder->orderBy('created_at', 'DESC');
                break;
            case 'oldest':
                $builder->orderBy('created_at', 'ASC');
                break;
            case 'name_asc':
                $builder->orderBy('title', 'ASC');
                break;
            case 'name_desc':
                $builder->orderBy('title', 'DESC');
                break;
            case 'rating':
                $builder->orderBy('rating', 'DESC');
                break;
            default:
                $builder->orderBy('views', 'DESC');
                break;
        }

        return $builder->limit($limit, $offset)
                      ->find();
    }

    /**
     * Count hot stories
     */
    public function getHotStoriesCount($status = null)
    {
        $builder = $this->where('status', 'published')
                        ->where('is_hot', true);

        if ($status) {
            if ($status == 'completed') {
                $builder->where('is_completed', true);
            } elseif ($status == 'ongoing') {
                $builder->where('is_completed', false);
            }
        }

        return $builder->countAllResults();
    }

    /**
     * Get latest stories
     */
    public function getLatest($limit = 12, $offset = 0, $sort = null, $status = null)
    {
        $builder = $this->where('status', 'published');

        if ($status) {
            if ($status == 'completed') {
                $builder->where('is_completed', true);
            } elseif ($status == 'ongoing') {
                $builder->where('is_completed', false);
            }
        }

        if ($sort) {
            switch ($sort) {
                case 'oldest':
                    $builder->orderBy('created_at', 'ASC');
                    break;
                case 'name_asc':
                    $builder->orderBy('title', 'ASC');
                    break;
                case 'name_desc':
                    $builder->orderBy('title', 'DESC');
                    break;
                case 'view':
                    $builder->orderBy('views', 'DESC');
                    break;
                case 'rating':
                    $builder->orderBy('rating', 'DESC');
                    break;
                default:
                    $builder->orderBy('created_at', 'DESC');
                    break;
            }
        } else {
            $builder->orderBy('created_at', 'DESC');
        }

        return $builder->limit($limit, $offset)
                      ->find();
    }

    /**
     * Count latest stories
     */
    public function getLatestCount($status = null)
    {
        $builder = $this->where('status', 'published');

        if ($status) {
            if ($status == 'completed') {
                $builder->where('is_completed', true);
            } elseif ($status == 'ongoing') {
                $builder->where('is_completed', false);
            }
        }

        return $builder->countAllResults();
    }

    /**
     * Get recommended stories
     */
    public function getRecommended($limit = 12, $offset = 0, $sort = null, $status = null)
    {
        $builder = $this->where('status', 'published')
                        ->where('is_recommended', true);

        if ($status) {
            if ($status == 'completed') {
                $builder->where('is_completed', true);
            } elseif ($status == 'ongoing') {
                $builder->where('is_completed', false);
            }
        }

        if ($sort) {
            switch ($sort) {
                case 'oldest':
                    $builder->orderBy('created_at', 'ASC');
                    break;
                case 'name_asc':
                    $builder->orderBy('title', 'ASC');
                    break;
                case 'name_desc':
                    $builder->orderBy('title', 'DESC');
                    break;
                case 'view':
                    $builder->orderBy('views', 'DESC');
                    break;
                case 'rating':
                    $builder->orderBy('rating', 'DESC');
                    break;
                default:
                    $builder->orderBy('created_at', 'DESC');
                    break;
            }
        } else {
            $builder->orderBy('created_at', 'DESC');
        }

        return $builder->limit($limit, $offset)
                      ->find();
    }

    /**
     * Count recommended stories
     */
    public function getRecommendedCount($status = null)
    {
        $builder = $this->where('status', 'published')
                        ->where('is_recommended', true);

        if ($status) {
            if ($status == 'completed') {
                $builder->where('is_completed', true);
            } elseif ($status == 'ongoing') {
                $builder->where('is_completed', false);
            }
        }

        return $builder->countAllResults();
    }

    /**
     * Get stories by author
     */
    public function getByAuthor($authorId, $limit = 12, $offset = 0, $sort = null, $status = null)
    {
        $builder = $this->where('author_id', $authorId)
                        ->where('status', 'published');

        if ($status) {
            if ($status == 'completed') {
                $builder->where('is_completed', true);
            } elseif ($status == 'ongoing') {
                $builder->where('is_completed', false);
            }
        }

        if ($sort) {
            switch ($sort) {
                case 'oldest':
                    $builder->orderBy('created_at', 'ASC');
                    break;
                case 'name_asc':
                    $builder->orderBy('title', 'ASC');
                    break;
                case 'name_desc':
                    $builder->orderBy('title', 'DESC');
                    break;
                case 'view':
                    $builder->orderBy('views', 'DESC');
                    break;
                case 'rating':
                    $builder->orderBy('rating', 'DESC');
                    break;
                default:
                    $builder->orderBy('created_at', 'DESC');
                    break;
            }
        } else {
            $builder->orderBy('created_at', 'DESC');
        }

        return $builder->limit($limit, $offset)
                      ->find();
    }

    /**
     * Count stories by author
     */
    public function getByAuthorCount($authorId, $status = null)
    {
        $builder = $this->where('author_id', $authorId)
                        ->where('status', 'published');

        if ($status) {
            if ($status == 'completed') {
                $builder->where('is_completed', true);
            } elseif ($status == 'ongoing') {
                $builder->where('is_completed', false);
            }
        }

        return $builder->countAllResults();
    }

    /**
     * Search stories
     */
    public function search($keyword, $limit = 12, $offset = 0)
    {
        return $this->like('title', $keyword)
                    ->orLike('description', $keyword)
                    ->where('status', 'published')
                    ->orderBy('title', 'ASC')
                    ->limit($limit, $offset)
                    ->find();
    }

    /**
     * Increment views
     */
    public function incrementViews($id)
    {
        $this->where('id', $id)
             ->set('views', 'views + 1', false)
             ->update();
    }

    /**
     * Get list of stories
     */
    public function getStoryList($limit = 12, $offset = 0, $sort = null, $status = null)
    {
        $builder = $this->where('status', 'published');

        if ($status) {
            if ($status == 'completed') {
                $builder->where('is_completed', true);
            } elseif ($status == 'ongoing') {
                $builder->where('is_completed', false);
            }
        }

        if ($sort) {
            switch ($sort) {
                case 'oldest':
                    $builder->orderBy('created_at', 'ASC');
                    break;
                case 'name_asc':
                    $builder->orderBy('title', 'ASC');
                    break;
                case 'name_desc':
                    $builder->orderBy('title', 'DESC');
                    break;
                case 'view':
                    $builder->orderBy('views', 'DESC');
                    break;
                case 'rating':
                    $builder->orderBy('rating', 'DESC');
                    break;
                default:
                    $builder->orderBy('created_at', 'DESC');
                    break;
            }
        } else {
            $builder->orderBy('created_at', 'DESC');
        }

        return $builder->limit($limit, $offset)
                      ->find();
    }

    /**
     * Count total stories
     */
    public function getStoryListCount($status = null)
    {
        $builder = $this->where('status', 'published');

        if ($status) {
            if ($status == 'completed') {
                $builder->where('is_completed', true);
            } elseif ($status == 'ongoing') {
                $builder->where('is_completed', false);
            }
        }

        return $builder->countAllResults();
    }

    /**
     * Get similar stories based on categories
     */
    public function getSimilarStories($storyId, $categories, $limit = 6)
    {
        if (empty($categories)) {
            return [];
        }

        $categoryIds = array_column($categories, 'id');

        $db = \Config\Database::connect();
        $builder = $db->table('stories s')
                    ->select('s.*, COUNT(sc.category_id) as category_match')
                    ->join('story_categories sc', 's.id = sc.story_id')
                    ->where('s.id !=', $storyId)
                    ->where('s.status', 'published')
                    ->whereIn('sc.category_id', $categoryIds)
                    ->groupBy('s.id')
                    ->orderBy('category_match', 'DESC')
                    ->orderBy('s.rating', 'DESC')
                    ->limit($limit);

        return $builder->get()->getResultArray();
    }

    /**
     * Check if story is bookmarked by user
     */
    public function isBookmarked($storyId, $userId)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('bookmarks');

        $result = $builder->where('story_id', $storyId)
                         ->where('user_id', $userId)
                         ->countAllResults();

        return $result > 0;
    }

    /**
     * Get user rating for a story
     */
    public function getUserRating($storyId, $userId)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('ratings');

        $rating = $builder->select('rating')
                         ->where('story_id', $storyId)
                         ->where('user_id', $userId)
                         ->get()
                         ->getRow();

        return $rating ? $rating->rating : 0;
    }

    /**
     * Get reading progress for a story
     */
    public function getReadingProgress($storyId, $userId)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('reading_progress');

        $progress = $builder->select('chapter_id, chapter_number')
                           ->where('story_id', $storyId)
                           ->where('user_id', $userId)
                           ->get()
                           ->getRow();

        return $progress ?: null;
    }

    /**
     * Get ratings count for a story
     */
    public function getRatingsCount($storyId)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('ratings');

        return $builder->where('story_id', $storyId)
                      ->countAllResults();
    }

    /**
     * Get bookmarks count for a story
     */
    public function getBookmarksCount($storyId)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('bookmarks');

        return $builder->where('story_id', $storyId)
                      ->countAllResults();
    }

    /**
     * Rate a story
     */
    public function rateStory($storyId, $userId, $rating)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('ratings');

        // Check if user already rated this story
        $exists = $builder->where('story_id', $storyId)
                         ->where('user_id', $userId)
                         ->countAllResults();

        if ($exists) {
            // Update existing rating
            $result = $builder->where('story_id', $storyId)
                             ->where('user_id', $userId)
                             ->update(['rating' => $rating, 'updated_at' => date('Y-m-d H:i:s')]);
        } else {
            // Add new rating
            $result = $builder->insert([
                'story_id' => $storyId,
                'user_id' => $userId,
                'rating' => $rating,
                'created_at' => date('Y-m-d H:i:s')
            ]);
        }

        // Update story's average rating
        if ($result) {
            $this->updateRating($storyId);
        }

        return (bool)$result;
    }

    /**
     * Update rating
     */
    public function updateRating($id)
    {
        $db = \Config\Database::connect();

        // Get average rating
        $query = $db->table('ratings')
                    ->selectAvg('rating')
                    ->where('story_id', $id)
                    ->get();

        $result = $query->getRow();
        $avgRating = round($result->rating, 2) ?? 0;

        // Update story rating
        $this->where('id', $id)
             ->set('rating', $avgRating)
             ->update();
    }

    /**
     * Get top stories by views
     */
    public function getTopByViews($limit = 10)
    {
        return $this->where('status', 'published')
                    ->orderBy('views', 'DESC')
                    ->limit($limit)
                    ->find();
    }

    /**
     * Get top stories by views this week
     */
    public function getTopThisWeek($limit = 10)
    {
        return $this->where('status', 'published')
                    ->orderBy('views_week', 'DESC')
                    ->limit($limit)
                    ->find();
    }

    /**
     * Get top stories by views this month
     */
    public function getTopThisMonth($limit = 10)
    {
        return $this->where('status', 'published')
                    ->orderBy('views_month', 'DESC')
                    ->limit($limit)
                    ->find();
    }

    /**
     * Get top stories by rating
     */
    public function getTopByRating($limit = 10)
    {
        return $this->where('status', 'published')
                    ->where('total_ratings >', 0)
                    ->orderBy('rating', 'DESC')
                    ->limit($limit)
                    ->find();
    }

    /**
     * Get top stories by favorites
     */
    public function getTopByFavorites($limit = 10)
    {
        return $this->where('status', 'published')
                    ->orderBy('total_favorites', 'DESC')
                    ->limit($limit)
                    ->find();
    }
}
