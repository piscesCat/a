<?php
namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\UserModel;
use App\Models\GuestBookmarkModel;

class Auth extends BaseController
{
    protected $userModel;
    protected $guestBookmarkModel;

    public function __construct()
    {
        $this->userModel = new UserModel();
        $this->guestBookmarkModel = new GuestBookmarkModel();
    }

    // Phương thức hiển thị trang đăng nhập
    public function login()
    {
        if (session()->get('isLoggedIn')) {
            return redirect()->to('/');
        }
        return $this->render('auth/login.html');
    }

    // Phương thức xử lý đăng nhập
    public function attemptLogin()
    {
        $email = $this->request->getPost('email');
        $password = $this->request->getPost('password');

        $user = $this->userModel->attemptLogin($email, $password);

        if (!$user) {
            return redirect()->back()
                ->with('error', 'Email hoặc mật khẩu không chính xác');
        }

        session()->set([
            'isLoggedIn' => true,
            'user' => $user
        ]);

        // Merge guest bookmarks to user bookmarks after login
        $guestId = $this->request->getCookie('guest_id');
        if ($guestId) {
            $bookmarksMigrated = $this->guestBookmarkModel->migrateToUser($guestId, $user['id']);
            if ($bookmarksMigrated > 0) {
                session()->setFlashdata('bookmark_message', 'Đã chuyển ' . $bookmarksMigrated . ' bookmark từ phiên khách vào tài khoản của bạn.');
            }
        }

        return redirect()->to('/')->with('success', 'Đăng nhập thành công');
    }

    // Phương thức đăng xuất
    public function logout()
    {
        session()->destroy();
        return redirect()->to('/');
    }

    // Phương thức xử lý đặt lại mật khẩu (chỉ dùng cho admin)
    public function resetPassword()
    {
        // Kiểm tra người dùng đã đăng nhập và có quyền admin
        if (!session()->get('isLoggedIn') || session()->get('user')['role'] < 2) {
            return redirect()->to('/')->with('error', 'Bạn không có quyền thực hiện chức năng này');
        }

        $userId = $this->request->getPost('user_id');
        $newPassword = $this->request->getPost('new_password');
        $confirmPassword = $this->request->getPost('confirm_password');

        // Validate
        if (!$userId || !$newPassword || !$confirmPassword) {
            return redirect()->back()->with('error', 'Vui lòng nhập đầy đủ thông tin');
        }

        if ($newPassword !== $confirmPassword) {
            return redirect()->back()->with('error', 'Mật khẩu xác nhận không khớp');
        }

        if (strlen($newPassword) < 6) {
            return redirect()->back()->with('error', 'Mật khẩu phải có ít nhất 6 ký tự');
        }

        // Cập nhật mật khẩu
        $result = $this->userModel->updateUserPassword($userId, $newPassword);

        if (!$result) {
            return redirect()->back()->with('error', 'Không thể cập nhật mật khẩu');
        }

        return redirect()->to('/admin/users')->with('success', 'Đã đặt lại mật khẩu thành công');
    }
}
