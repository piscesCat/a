<?php
namespace App\Controllers;

use App\Models\StoryModel;
use App\Models\CategoryModel;
use App\Models\ChapterModel;

class Home extends BaseController
{
    public function index()
    {
        // Get StoryModel instance
        $storyModel = new StoryModel();

        // Get featured stories
        $featuredStories = $storyModel->getFeaturedStories(6);

        // Get latest updated stories
        $latestUpdatedStories = $storyModel->getRecentlyUpdated(12);

        // Get recommended stories
        $recommendedStories = $storyModel->getRecommended(5);

        // Get completed stories
        $completedStories = $storyModel->getCompleted(6);

        // Get top authors
        $userModel = new \App\Models\UserModel();
        $db = \Config\Database::connect();
        $query = $db->table('users')
                    ->select('users.id, users.username, users.avatar, COUNT(stories.id) as story_count')
                    ->join('stories', 'stories.author_id = users.id')
                    ->where('stories.status', 'published')
                    ->groupBy('users.id')
                    ->orderBy('story_count', 'DESC')
                    ->limit(5)
                    ->get();
        $topAuthors = $query->getResultArray();

        // Get categories with story count
        $categoryModel = new CategoryModel();
        $categories = $categoryModel->getCategoriesWithCount();

        // Get latest chapters
        $chapterModel = new ChapterModel();
        $latestChapters = $chapterModel->getLatestChapters(15);

        // Render the view with data
        return $this->renderView('home.html', [
            'featured_stories' => $featuredStories,
            'latest_updated_stories' => $latestUpdatedStories,
            'recommended_stories' => $recommendedStories,
            'completed_stories' => $completedStories,
            'top_authors' => $topAuthors,
            'categories' => $categories,
            'latest_chapters' => $latestChapters
        ]);
    }

    /**
     * Lấy danh sách quốc gia từ trường country trong bảng story
     */
    public function getCountries()
    {
        $storyModel = new \App\Models\StoryModel();
        $countries = $storyModel->getCountries();

        return $this->response->setJSON([
            'status' => 'success',
            'data' => $countries
        ]);
    }
}
