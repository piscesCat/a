<?php
// public/index.php
define('FCPATH', __DIR__ . DIRECTORY_SEPARATOR);
chdir(FCPATH);

// Check if the system is already installed
if (!file_exists(realpath(dirname(__FILE__) . '/../') . '/installed.txt')) {
    header('Location: ' . 'install/');
    exit;
}

require FCPATH . '../vendor/autoload.php';

$app = require FCPATH . '../app/Config/Boot/production.php';
$kernel = $app->getKernel();
$kernel->boot();

$app->run();
