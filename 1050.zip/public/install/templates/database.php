<div class="alert alert-info">
    <i class="fas fa-info-circle"></i> Vui lòng nhập thông tin kết nối đến cơ sở dữ liệu PostgreSQL. Bạn cần tạo cơ sở dữ liệu trước khi thực hiện bước này.
</div>

<form method="post" action="">
    <input type="hidden" name="step" value="2">

    <div class="mb-3">
        <label for="db_hostname" class="form-label">Hostname:</label>
        <input type="text" class="form-control" id="db_hostname" name="db_hostname" value="<?= $_SESSION['input']['db_hostname'] ?? 'localhost' ?>" required>
        <div class="form-text">Thường là "localhost" hoặc địa chỉ IP của máy chủ PostgreSQL.</div>
    </div>

    <div class="mb-3">
        <label for="db_port" class="form-label">Port:</label>
        <input type="number" class="form-control" id="db_port" name="db_port" value="<?= $_SESSION['input']['db_port'] ?? '5432' ?>" required>
        <div class="form-text">Port mặc định của PostgreSQL là 5432.</div>
    </div>

    <div class="mb-3">
        <label for="db_name" class="form-label">Tên database:</label>
        <input type="text" class="form-control" id="db_name" name="db_name" value="<?= $_SESSION['input']['db_name'] ?? '' ?>" required>
        <div class="form-text">Database phải được tạo trước khi cài đặt.</div>
    </div>

    <div class="mb-3">
        <label for="db_username" class="form-label">Tên đăng nhập:</label>
        <input type="text" class="form-control" id="db_username" name="db_username" value="<?= $_SESSION['input']['db_username'] ?? 'postgres' ?>" required>
    </div>

    <div class="mb-3">
        <label for="db_password" class="form-label">Mật khẩu:</label>
        <input type="password" class="form-control" id="db_password" name="db_password" value="<?= $_SESSION['input']['db_password'] ?? '' ?>">
    </div>

    <div class="alert alert-warning">
        <i class="fas fa-exclamation-triangle"></i> Lưu ý: Khi bạn tiếp tục, hệ thống sẽ tạo các bảng cần thiết trong database. Hãy đảm bảo rằng bạn đã sao lưu dữ liệu quan trọng (nếu có).
    </div>

    <div class="d-flex justify-content-between">
        <a href="<?= BASE_URL ?>install" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Quay lại
        </a>

        <button type="submit" class="btn btn-primary">
            Tiếp tục <i class="fas fa-arrow-right"></i>
        </button>
    </div>
</form>
