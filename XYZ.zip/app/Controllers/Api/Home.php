<?php

namespace App\Controllers\Api;

use App\Controllers\BaseController;
use App\Models\StoryModel;
use App\Models\CategoryModel;
use App\Models\CountryModel;
use App\Models\SettingsModel;

class Home extends BaseController
{
    protected $storyModel;
    protected $categoryModel;
    protected $countryModel;
    protected $settingsModel;

    public function __construct()
    {
        $this->storyModel = new StoryModel();
        $this->categoryModel = new CategoryModel();
        $this->countryModel = new CountryModel();
        $this->settingsModel = new SettingsModel();
    }

    /**
     * Lấy dữ liệu cho trang chủ ứng dụng di động
     */
    public function index()
    {
        $data = [
            'featured' => $this->storyModel->getFeaturedStories(6),
            'hot' => $this->storyModel->getHotStories(8),
            'latest' => $this->storyModel->getLatestStories(8),
            'completed' => $this->storyModel->getCompletedStories(8),
            'popular' => $this->storyModel->getPopularStories(8),
            'settings' => $this->getSettings()
        ];

        return $this->response->setJSON([
            'success' => true,
            'data' => $data
        ]);
    }

    /**
     * Lấy danh sách thể loại
     */
    public function categories()
    {
        $categories = $this->categoryModel->findAll();

        return $this->response->setJSON([
            'success' => true,
            'data' => $categories
        ]);
    }

    /**
     * Lấy danh sách quốc gia
     */
    public function countries()
    {
        $countries = $this->countryModel->findAll();

        return $this->response->setJSON([
            'success' => true,
            'data' => $countries
        ]);
    }

    /**
     * Lấy thiết lập hệ thống
     */
    private function getSettings()
    {
        $settings = [
            'site_name' => $this->settingsModel->getSetting('site_name', 'Web Truyện'),
            'site_description' => $this->settingsModel->getSetting('site_description', 'Đọc truyện online miễn phí'),
            'site_logo' => $this->settingsModel->getSetting('site_logo', '/assets/images/logo.png'),
            'site_favicon' => $this->settingsModel->getSetting('site_favicon', '/assets/images/favicon.ico'),
            'allow_guest_comments' => $this->settingsModel->getSetting('guest_comments_enabled', 'on') === 'on',
            'app_version' => '1.0.0',
            'app_min_version' => '1.0.0',
            'maintenance_mode' => $this->settingsModel->getSetting('maintenance_mode', 'off') === 'on'
        ];

        return $settings;
    }
}
