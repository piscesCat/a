<?php

namespace App\Controllers\Api;

use App\Controllers\BaseController;
use App\Models\StoryModel;
use App\Models\ChapterModel;
use App\Models\CommentModel;
use App\Models\CategoryModel;

class Stories extends BaseController
{
    protected $storyModel;
    protected $chapterModel;
    protected $commentModel;
    protected $categoryModel;

    public function __construct()
    {
        $this->storyModel = new StoryModel();
        $this->chapterModel = new ChapterModel();
        $this->commentModel = new CommentModel();
        $this->categoryModel = new CategoryModel();
    }

    /**
     * Lấy danh sách truyện hot
     */
    public function hot()
    {
        $page = $this->request->getGet('page') ?? 1;
        $limit = $this->request->getGet('limit') ?? 20;
        $offset = ($page - 1) * $limit;

        $stories = $this->storyModel->getHotStories($limit, $offset);
        $total = $this->storyModel->where('hot_score >', 0)->countAllResults();

        return $this->response->setJSON([
            'success' => true,
            'data' => [
                'stories' => $stories,
                'pagination' => [
                    'current_page' => (int)$page,
                    'total_pages' => ceil($total / $limit),
                    'total_items' => $total,
                    'per_page' => (int)$limit
                ]
            ]
        ]);
    }

    /**
     * Lấy danh sách truyện mới cập nhật
     */
    public function latest()
    {
        $page = $this->request->getGet('page') ?? 1;
        $limit = $this->request->getGet('limit') ?? 20;
        $offset = ($page - 1) * $limit;

        $stories = $this->storyModel->orderBy('updated_at', 'DESC')
            ->limit($limit)
            ->offset($offset)
            ->find();

        $total = $this->storyModel->countAllResults();

        return $this->response->setJSON([
            'success' => true,
            'data' => [
                'stories' => $stories,
                'pagination' => [
                    'current_page' => (int)$page,
                    'total_pages' => ceil($total / $limit),
                    'total_items' => $total,
                    'per_page' => (int)$limit
                ]
            ]
        ]);
    }

    /**
     * Lấy danh sách truyện đã hoàn thành
     */
    public function completed()
    {
        $page = $this->request->getGet('page') ?? 1;
        $limit = $this->request->getGet('limit') ?? 20;
        $offset = ($page - 1) * $limit;

        $stories = $this->storyModel->where('is_completed', 1)
            ->orderBy('updated_at', 'DESC')
            ->limit($limit)
            ->offset($offset)
            ->find();

        $total = $this->storyModel->where('is_completed', 1)->countAllResults();

        return $this->response->setJSON([
            'success' => true,
            'data' => [
                'stories' => $stories,
                'pagination' => [
                    'current_page' => (int)$page,
                    'total_pages' => ceil($total / $limit),
                    'total_items' => $total,
                    'per_page' => (int)$limit
                ]
            ]
        ]);
    }

    /**
     * Xem chi tiết truyện
     */
    public function view($slug)
    {
        // Lấy thông tin truyện
        $story = $this->storyModel->getStory($slug);

        if (!$story) {
            return $this->response->setStatusCode(404)->setJSON([
                'success' => false,
                'message' => 'Không tìm thấy truyện'
            ]);
        }

        // Cập nhật lượt xem
        $this->storyModel->updateViews($story['id']);

        // Lấy danh sách chương (giới hạn 10 chương mới nhất)
        $chapters = $this->chapterModel->where('story_id', $story['id'])
            ->orderBy('chapter_number', 'DESC')
            ->limit(10)
            ->find();

        // Lấy số lượng bình luận
        $commentCount = $this->commentModel->where('story_id', $story['id'])
            ->where('chapter_id IS NULL')
            ->countAllResults();

        // Lấy tổng số chương
        $chapterCount = $this->chapterModel->where('story_id', $story['id'])->countAllResults();

        // Lấy truyện liên quan
        $relatedStories = $this->storyModel->getRelatedStories($story['id'], 6);

        // Thêm các thông tin bổ sung
        $story['latest_chapters'] = $chapters;
        $story['comment_count'] = $commentCount;
        $story['chapter_count'] = $chapterCount;
        $story['related_stories'] = $relatedStories;

        return $this->response->setJSON([
            'success' => true,
            'data' => $story
        ]);
    }

    /**
     * Lấy danh sách truyện theo thể loại
     */
    public function category($slug)
    {
        $page = $this->request->getGet('page') ?? 1;
        $limit = $this->request->getGet('limit') ?? 20;
        $offset = ($page - 1) * $limit;

        // Lấy thông tin thể loại
        $category = $this->categoryModel->where('slug', $slug)->first();

        if (!$category) {
            return $this->response->setStatusCode(404)->setJSON([
                'success' => false,
                'message' => 'Không tìm thấy thể loại'
            ]);
        }

        // Lấy truyện theo thể loại
        $result = $this->storyModel->getStoriesByCategory($slug, $limit, $offset);

        return $this->response->setJSON([
            'success' => true,
            'data' => [
                'category' => $category,
                'stories' => $result['stories'],
                'pagination' => [
                    'current_page' => (int)$page,
                    'total_pages' => ceil($result['total'] / $limit),
                    'total_items' => $result['total'],
                    'per_page' => (int)$limit
                ]
            ]
        ]);
    }

    /**
     * Lấy danh sách truyện theo quốc gia
     */
    public function country($slug)
    {
        $page = $this->request->getGet('page') ?? 1;
        $limit = $this->request->getGet('limit') ?? 20;
        $offset = ($page - 1) * $limit;

        // Lấy thông tin quốc gia
        $countryModel = new \App\Models\CountryModel();
        $country = $countryModel->where('slug', $slug)->first();

        if (!$country) {
            return $this->response->setStatusCode(404)->setJSON([
                'success' => false,
                'message' => 'Không tìm thấy quốc gia'
            ]);
        }

        // Lấy truyện theo quốc gia
        $result = $this->storyModel->getStoriesByCountry($slug, $limit, $offset);

        return $this->response->setJSON([
            'success' => true,
            'data' => [
                'country' => $country,
                'stories' => $result['stories'],
                'pagination' => [
                    'current_page' => (int)$page,
                    'total_pages' => ceil($result['total'] / $limit),
                    'total_items' => $result['total'],
                    'per_page' => (int)$limit
                ]
            ]
        ]);
    }
}
