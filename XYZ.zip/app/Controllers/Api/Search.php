<?php

namespace App\Controllers\Api;

use App\Controllers\BaseController;
use App\Models\StoryModel;

class Search extends BaseController
{
    protected $storyModel;

    public function __construct()
    {
        $this->storyModel = new StoryModel();
    }

    /**
     * Tìm kiếm truyện với nhiều bộ lọc
     */
    public function index()
    {
        $query = $this->request->getGet('q') ?? '';
        $page = $this->request->getGet('page') ?? 1;
        $limit = $this->request->getGet('limit') ?? 20;
        $offset = ($page - 1) * $limit;

        // Các bộ lọc tìm kiếm
        $filters = [
            'sort' => $this->request->getGet('sort') ?? 'relevance',
            'status' => $this->request->getGet('status') ?? '',
            'category' => $this->request->getGet('category') ?? '',
            'country' => $this->request->getGet('country') ?? '',
            'year' => $this->request->getGet('year') ?? '',
        ];

        // Thực hiện tìm kiếm
        $result = $this->storyModel->searchStories($query, $limit, $offset, $filters);

        // Lưu từ khóa tìm kiếm để thống kê (nếu không rỗng)
        if (!empty($query)) {
            $this->saveSearchQuery($query, 'api');
        }

        return $this->response->setJSON([
            'success' => true,
            'data' => [
                'query' => $query,
                'stories' => $result['stories'],
                'pagination' => [
                    'current_page' => (int)$page,
                    'total_pages' => ceil($result['total'] / $limit),
                    'total_items' => $result['total'],
                    'per_page' => (int)$limit
                ],
                'filters' => $filters
            ]
        ]);
    }

    /**
     * Lấy gợi ý từ khóa tìm kiếm
     */
    public function suggestions()
    {
        $query = $this->request->getGet('q') ?? '';

        if (empty($query) || strlen($query) < 2) {
            return $this->response->setJSON([
                'success' => true,
                'data' => []
            ]);
        }

        // Lấy gợi ý tìm kiếm
        $suggestions = $this->storyModel->getSearchSuggestions($query, 10);

        // Lưu từ khóa tìm kiếm để thống kê
        $this->saveSearchQuery($query, 'api_suggestion');

        return $this->response->setJSON([
            'success' => true,
            'data' => $suggestions
        ]);
    }

    /**
     * Lấy từ khóa tìm kiếm phổ biến
     */
    public function trending()
    {
        $limit = $this->request->getGet('limit') ?? 10;

        // Lấy từ khóa tìm kiếm nhiều trong 7 ngày qua
        $db = \Config\Database::connect();
        $result = $db->table('search_queries')
            ->select('query, count')
            ->where('last_searched >=', date('Y-m-d H:i:s', strtotime('-7 days')))
            ->where('search_type', 'api')
            ->orderBy('count', 'DESC')
            ->limit($limit)
            ->get()
            ->getResultArray();

        return $this->response->setJSON([
            'success' => true,
            'data' => $result
        ]);
    }

    /**
     * Lưu từ khóa tìm kiếm vào database
     */
    private function saveSearchQuery($query, $type = 'api')
    {
        // Bỏ qua các truy vấn ngắn hoặc chỉ chứa ký tự đặc biệt
        if (strlen($query) < 2 || !preg_match('/[a-zA-Z0-9\p{L}]/u', $query)) {
            return false;
        }

        $db = \Config\Database::connect();

        // Kiểm tra xem từ khóa đã tồn tại chưa
        $existing = $db->table('search_queries')
            ->where('query', $query)
            ->where('search_type', $type)
            ->get()
            ->getRow();

        $currentTime = date('Y-m-d H:i:s');
        $userId = null; // API không có thông tin người dùng trừ khi có token
        $ipAddress = $this->request->getIPAddress();

        if ($existing) {
            // Cập nhật số lượt tìm và thời gian
            return $db->table('search_queries')
                ->where('query', $query)
                ->where('search_type', $type)
                ->update([
                    'count' => $existing->count + 1,
                    'last_searched' => $currentTime,
                    'ip_address' => $ipAddress
                ]);
        } else {
            // Thêm từ khóa mới
            return $db->table('search_queries')
                ->insert([
                    'query' => $query,
                    'count' => 1,
                    'last_searched' => $currentTime,
                    'created_at' => $currentTime,
                    'user_id' => $userId,
                    'ip_address' => $ipAddress,
                    'search_type' => $type
                ]);
        }
    }
}
