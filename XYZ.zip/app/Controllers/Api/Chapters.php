<?php

namespace App\Controllers\Api;

use App\Controllers\BaseController;
use App\Models\StoryModel;
use App\Models\ChapterModel;
use App\Models\CommentModel;

class Chapters extends BaseController
{
    protected $storyModel;
    protected $chapterModel;
    protected $commentModel;

    public function __construct()
    {
        $this->storyModel = new StoryModel();
        $this->chapterModel = new ChapterModel();
        $this->commentModel = new CommentModel();
    }

    /**
     * Xem chương theo slug truyện và số chương
     */
    public function view($storySlug, $chapterNumber)
    {
        // Lấy thông tin truyện
        $story = $this->storyModel->getBySlug($storySlug);

        if (!$story) {
            return $this->response->setStatusCode(404)->setJSON([
                'success' => false,
                'message' => 'Không tìm thấy truyện'
            ]);
        }

        // Lấy thông tin chương
        $chapter = $this->chapterModel->getChapter($story->id, $chapterNumber);

        if (!$chapter) {
            return $this->response->setStatusCode(404)->setJSON([
                'success' => false,
                'message' => 'Không tìm thấy chương'
            ]);
        }

        // Cập nhật lượt xem
        $this->chapterModel->incrementViews($chapter['id']);

        // Lấy chương trước và chương sau
        $nextChapter = $this->chapterModel->getNextChapter($story->id, $chapterNumber);
        $prevChapter = $this->chapterModel->getPreviousChapter($story->id, $chapterNumber);

        // Lấy số lượng bình luận
        $commentCount = $this->commentModel->where('chapter_id', $chapter['id'])->countAllResults();

        // Thêm các thông tin bổ sung
        $chapter['story_info'] = $story;
        $chapter['next_chapter'] = $nextChapter;
        $chapter['prev_chapter'] = $prevChapter;
        $chapter['comment_count'] = $commentCount;

        // Lưu tiến trình đọc nếu có userId (từ token)
        $userId = $this->getUserIdFromToken();
        if ($userId) {
            $this->saveReadingProgress($userId, $story->id, $chapter['id'], $chapterNumber);
        }

        return $this->response->setJSON([
            'success' => true,
            'data' => $chapter
        ]);
    }

    /**
     * Lấy danh sách chương của một truyện
     */
    public function listByStory($storySlug)
    {
        // Lấy thông tin truyện
        $story = $this->storyModel->getBySlug($storySlug);

        if (!$story) {
            return $this->response->setStatusCode(404)->setJSON([
                'success' => false,
                'message' => 'Không tìm thấy truyện'
            ]);
        }

        // Tham số phân trang
        $page = $this->request->getGet('page') ?? 1;
        $limit = $this->request->getGet('limit') ?? 100; // Mặc định lấy 100 chương
        $offset = ($page - 1) * $limit;
        $sort = $this->request->getGet('sort') ?? 'asc'; // asc: cũ đến mới, desc: mới đến cũ

        // Lấy danh sách chương
        $chapters = $this->chapterModel
            ->where('story_id', $story->id)
            ->orderBy('chapter_number', $sort)
            ->limit($limit)
            ->offset($offset)
            ->findAll();

        // Đếm tổng số chương
        $total = $this->chapterModel->where('story_id', $story->id)->countAllResults();

        return $this->response->setJSON([
            'success' => true,
            'data' => [
                'story' => $story,
                'chapters' => $chapters,
                'pagination' => [
                    'current_page' => (int)$page,
                    'total_pages' => ceil($total / $limit),
                    'total_items' => $total,
                    'per_page' => (int)$limit
                ]
            ]
        ]);
    }

    /**
     * Lấy user ID từ token (nếu có)
     */
    private function getUserIdFromToken()
    {
        $authHeader = $this->request->getHeaderLine('Authorization');
        if (empty($authHeader)) {
            return null;
        }

        // Xử lý token và lấy userId
        // Đây là code mẫu, bạn cần cài đặt thực tế theo hệ thống xác thực của mình
        if (preg_match('/Bearer\s+(.*)$/i', $authHeader, $matches)) {
            $token = $matches[1];

            // TODO: Xác thực token và lấy userId

            return null; // Trả về userId nếu token hợp lệ
        }

        return null;
    }

    /**
     * Lưu tiến trình đọc của người dùng
     */
    private function saveReadingProgress($userId, $storyId, $chapterId, $chapterNumber)
    {
        $data = [
            'user_id' => $userId,
            'story_id' => $storyId,
            'chapter_id' => $chapterId,
            'last_read' => date('Y-m-d H:i:s')
        ];

        $db = \Config\Database::connect();

        // Kiểm tra xem đã có bản ghi chưa
        $existing = $db->table('reading_progress')
            ->where('user_id', $userId)
            ->where('story_id', $storyId)
            ->get()
            ->getRow();

        if ($existing) {
            // Cập nhật bản ghi hiện có
            return $db->table('reading_progress')
                ->where('user_id', $userId)
                ->where('story_id', $storyId)
                ->update($data);
        } else {
            // Thêm bản ghi mới
            return $db->table('reading_progress')->insert($data);
        }
    }
}
