<?php
namespace App\Controllers;

use App\Models\StoryModel;
use App\Models\CategoryModel;
use App\Models\CountryModel;
use App\Models\CommentModel;

class Story extends BaseController
{
    protected $storyModel;
    protected $categoryModel;
    protected $countryModel;
    protected $commentModel;

    public function __construct()
    {
        $this->storyModel = new StoryModel();
        $this->categoryModel = new CategoryModel();
        $this->countryModel = new CountryModel();
        $this->commentModel = new CommentModel();
    }

    /**
     * Trang chủ danh sách truyện
     */
    public function index()
    {
        $page = $this->request->getGet('page') ?? 1;
        $limit = 24;
        $offset = ($page - 1) * $limit;

        $stories = $this->storyModel->orderBy('created_at', 'DESC')
            ->findAll($limit, $offset);

        $total = $this->storyModel->countAllResults();

        return $this->renderView('story/index', [
            'stories' => $stories,
            'pager' => [
                'current' => $page,
                'total' => ceil($total / $limit)
            ],
            'page_title' => 'Danh sách truyện',
            'page_description' => 'Danh sách tất cả các truyện'
        ]);
    }

    /**
     * Xem chi tiết truyện
     */
    public function view($slug)
    {
        $story = $this->storyModel->getStory($slug);

        if (!$story) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        // Cập nhật lượt xem
        $this->storyModel->updateViews($story['id']);

        // Lấy truyện liên quan
        $relatedStories = $this->storyModel->getRelatedStories($story['id'], 6);

        // Lấy bình luận cho truyện
        $comments = $this->commentModel->getStoryComments($story['id'], 10);
        $commentCount = $this->commentModel->countStoryComments($story['id']);

        return $this->renderView('story/view', [
            'story' => $story,
            'related_stories' => $relatedStories,
            'comments' => $comments,
            'comment_count' => $commentCount,
            'page_title' => $story['title'],
            'page_description' => $story['description']
        ]);
    }

    /**
     * Tìm kiếm truyện
     */
    public function search()
    {
        $query = $this->request->getGet('q');
        $page = $this->request->getGet('page') ?? 1;
        $limit = 24;
        $offset = ($page - 1) * $limit;

        if (empty($query)) {
            return redirect()->to('/');
        }

        $result = $this->storyModel->searchStories($query, $limit, $offset);
        $stories = $result['stories'];
        $total = $result['total'];

        return $this->renderView('story/search', [
            'stories' => $stories,
            'query' => $query,
            'pager' => [
                'current' => $page,
                'total' => ceil($total / $limit)
            ],
            'page_title' => 'Kết quả tìm kiếm: ' . $query,
            'page_description' => 'Kết quả tìm kiếm cho từ khóa: ' . $query
        ]);
    }

    /**
     * API gợi ý tìm kiếm
     */
    public function searchSuggestions()
    {
        $query = $this->request->getGet('q');

        if (empty($query) || strlen($query) < 2) {
            return $this->response->setJSON([]);
        }

        $suggestions = $this->storyModel->getSearchSuggestions($query);

        return $this->response->setJSON($suggestions);
    }

    /**
     * Danh sách truyện theo thể loại
     */
    public function category($slug)
    {
        $category = $this->categoryModel->where('slug', $slug)->first();

        if (!$category) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        $page = $this->request->getGet('page') ?? 1;
        $limit = 24;
        $offset = ($page - 1) * $limit;

        $result = $this->storyModel->getStoriesByCategory($slug, $limit, $offset);
        $stories = $result['stories'];
        $total = $result['total'];

        return $this->renderView('story/category', [
            'category' => $category,
            'stories' => $stories,
            'pager' => [
                'current' => $page,
                'total' => ceil($total / $limit)
            ],
            'page_title' => 'Thể loại: ' . $category['name'],
            'page_description' => 'Danh sách truyện thuộc thể loại ' . $category['name']
        ]);
    }

    /**
     * Truyện theo quốc gia
     */
    public function country($slug)
    {
        $country = $this->countryModel->where('slug', $slug)->first();

        if (!$country) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        $page = $this->request->getGet('page') ?? 1;
        $limit = 24;
        $offset = ($page - 1) * $limit;

        $result = $this->storyModel->getStoriesByCountry($slug, $limit, $offset);
        $stories = $result['stories'];
        $total = $result['total'];

        return $this->renderView('story/country', [
            'country' => $country,
            'stories' => $stories,
            'pager' => [
                'current' => $page,
                'total' => ceil($total / $limit)
            ],
            'page_title' => 'Quốc gia: ' . $country['name'],
            'page_description' => 'Danh sách truyện thuộc quốc gia ' . $country['name']
        ]);
    }

    /**
     * Truyện theo năm phát hành
     */
    public function byYear($year)
    {
        $page = $this->request->getGet('page') ?? 1;
        $limit = 24;
        $offset = ($page - 1) * $limit;

        $result = $this->storyModel->getStoriesByYear($year, $limit, $offset);
        $stories = $result['stories'];
        $total = $result['total'];

        return $this->renderView('story/year', [
            'year' => $year,
            'stories' => $stories,
            'pager' => [
                'current' => $page,
                'total' => ceil($total / $limit)
            ],
            'page_title' => 'Năm phát hành: ' . $year,
            'page_description' => 'Danh sách truyện phát hành năm ' . $year
        ]);
    }

    /**
     * Truyện theo tác giả
     */
    public function author($author)
    {
        $page = $this->request->getGet('page') ?? 1;
        $limit = 24;
        $offset = ($page - 1) * $limit;

        $result = $this->storyModel->getStoriesByAuthor($author, $limit, $offset);
        $stories = $result['stories'];
        $total = $result['total'];

        return $this->renderView('story/author', [
            'author' => $author,
            'stories' => $stories,
            'pager' => [
                'current' => $page,
                'total' => ceil($total / $limit)
            ],
            'page_title' => 'Tác giả: ' . $author,
            'page_description' => 'Danh sách truyện của tác giả ' . $author
        ]);
    }

    /**
     * Truyện hot
     */
    public function popular()
    {
        // Sử dụng thuật toán tính điểm hot trước
        $stories = $this->storyModel->getHotStories(24);

        return $this->renderView('story/popular', [
            'stories' => $stories,
            'page_title' => 'Truyện Hot',
            'page_description' => 'Danh sách truyện đang hot, được đọc nhiều nhất'
        ]);
    }

    /**
     * Truyện mới cập nhật
     */
    public function latest()
    {
        $stories = $this->storyModel->orderBy('updated_at', 'DESC')
            ->limit(24)
            ->find();

        return $this->renderView('story/latest', [
            'stories' => $stories,
            'page_title' => 'Truyện Mới Cập Nhật',
            'page_description' => 'Danh sách truyện mới được cập nhật'
        ]);
    }

    /**
     * Truyện đã hoàn thành
     */
    public function completed()
    {
        $stories = $this->storyModel->getCompletedStories(24);

        return $this->renderView('story/completed', [
            'stories' => $stories,
            'page_title' => 'Truyện Đã Hoàn Thành',
            'page_description' => 'Danh sách truyện đã hoàn thành, đầy đủ các chương'
        ]);
    }

    /**
     * Bảng xếp hạng truyện
     */
    public function rankings()
    {
        $rankings = $this->storyModel->getRankings();

        return $this->renderView('story/rankings', [
            'rankings' => $rankings,
            'page_title' => 'Bảng Xếp Hạng',
            'page_description' => 'Bảng xếp hạng truyện theo nhiều tiêu chí khác nhau'
        ]);
    }

    /**
     * Danh sách tất cả thể loại
     */
    public function categories()
    {
        $categories = $this->categoryModel->findAll();

        return $this->renderView('story/categories', [
            'categories' => $categories,
            'page_title' => 'Danh sách thể loại',
            'page_description' => 'Danh sách tất cả các thể loại truyện'
        ]);
    }

    /**
     * API đánh dấu truyện yêu thích
     */
    public function toggleBookmark()
    {
        // Kiểm tra người dùng đã đăng nhập chưa
        if (!$this->isLoggedIn()) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Bạn cần đăng nhập để sử dụng tính năng này',
                'redirect' => base_url('login')
            ]);
        }

        $storyId = $this->request->getPost('story_id');

        if (!$storyId) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Thiếu thông tin truyện'
            ]);
        }

        $userId = $this->currentUser['id'];

        // Kiểm tra bookmark đã tồn tại chưa
        $bookmarkModel = new \App\Models\BookmarkModel();
        $existingBookmark = $bookmarkModel->where('user_id', $userId)
            ->where('story_id', $storyId)
            ->first();

        if ($existingBookmark) {
            // Nếu đã tồn tại thì xóa
            $bookmarkModel->delete($existingBookmark['id']);

            // Giảm số lượt yêu thích trong bảng stories
            $this->db->query("UPDATE stories SET total_favorites = total_favorites - 1 WHERE id = $storyId AND total_favorites > 0");

            return $this->response->setJSON([
                'success' => true,
                'status' => 'removed',
                'message' => 'Đã xóa khỏi truyện yêu thích'
            ]);
        } else {
            // Nếu chưa tồn tại thì thêm mới
            $bookmarkModel->insert([
                'user_id' => $userId,
                'story_id' => $storyId
            ]);

            // Tăng số lượt yêu thích trong bảng stories
            $this->db->query("UPDATE stories SET total_favorites = total_favorites + 1 WHERE id = $storyId");

            return $this->response->setJSON([
                'success' => true,
                'status' => 'added',
                'message' => 'Đã thêm vào truyện yêu thích'
            ]);
        }
    }
}
