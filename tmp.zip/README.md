# Hệ Thống Quản Lý Truyện

Dự án này là một hệ thống quản lý và hiển thị truyện xây dựng trên CodeIgniter 4 và PostgreSQL, với giao diện người dùng giống với phimhottt.com.

## Yêu Cầu Hệ Thống

- PHP >= 7.4
- PostgreSQL >= 10
- Composer
- Apache hoặc Nginx
- PHP Extensions: intl, mbstring, json, xml, curl

## Cài Đặt

### 1. Clone Repository

```bash
git clone [đường dẫn repository]
cd [thư mục dự án]
```

### 2. Cài Đặt Các Dependency

```bash
composer install
```

### 3. Cấu Hình Cơ Sở Dữ Liệu

Sao chép file `.env.example` thành `.env` và cập nhật thông tin cơ sở dữ liệu:

```bash
cp env .env
```

Chỉnh sửa các thông số sau trong file `.env`:

```
database.default.hostname = localhost
database.default.database = [tên database]
database.default.username = [tên người dùng]
database.default.password = [mật khẩu]
database.default.DBDriver = Postgre
database.default.port = 5432
```

### 4. Tạo Cơ Sở Dữ Liệu

```bash
psql -U [tên người dùng] -c "CREATE DATABASE [tên database]"
```

### 5. Import Schema

```bash
psql -U [tên người dùng] -d [tên database] -f database/schema.sql
```

### 6. Khởi Động Máy Chủ Web

```bash
php spark serve
```

Sau đó, truy cập ứng dụng tại: http://localhost:8080

### 7. Cài Đặt Qua Trình Duyệt

Truy cập http://localhost:8080/install để chạy trình cài đặt trực quan, bao gồm các bước:
- Thiết lập cơ sở dữ liệu
- Tạo tài khoản admin
- Cấu hình trang web

## Cấu Trúc Dự Án

```
app/                    # Mã nguồn ứng dụng
├── Config/             # Các tệp cấu hình
├── Controllers/        # Các controller
│   └── Admin/          # Controller cho admin panel
├── Models/             # Các model
└── Views/              # Các file view
    ├── admin/          # Giao diện admin
    └── layouts/        # Layout chung
database/               # Schema và migration
public/                 # Tài nguyên công khai
└── assets/             # JS, CSS, hình ảnh
```

## Tính Năng Chính

- Quản lý truyện, chương, thể loại
- Quản lý bình luận
- Quản lý người dùng
- SEO tối ưu
- Thống kê truyện hot, bảng xếp hạng
- Tìm kiếm nâng cao
- Quản lý template
- Hỗ trợ đa ngôn ngữ

## Quản Trị

Truy cập trang quản trị tại: http://localhost:8080/admin

## Backup và Restore

Sử dụng các lệnh sau để backup và restore dữ liệu:

### Backup

```bash
pg_dump -U [tên người dùng] -F c [tên database] > backup_[ngày].dump
```

### Restore

```bash
pg_restore -U [tên người dùng] -d [tên database] backup_[ngày].dump
```

## Hỗ Trợ và Liên Hệ

Nếu có bất kỳ vấn đề hoặc câu hỏi, vui lòng tạo issue hoặc liên hệ qua [thông tin liên hệ].
