<?php
namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\StoryModel;
use App\Models\ChapterModel;
use App\Models\UserModel;
use App\Models\CommentModel;
use App\Models\LogModel;

class Reports extends BaseController
{
    protected $storyModel;
    protected $chapterModel;
    protected $userModel;
    protected $commentModel;
    protected $logModel;

    public function __construct()
    {
        $this->storyModel = new StoryModel();
        $this->chapterModel = new ChapterModel();
        $this->userModel = new UserModel();
        $this->commentModel = new CommentModel();
        $this->logModel = new LogModel();
    }

    /**
     * Hiển thị trang báo cáo chính
     */
    public function index()
    {
        // Kiểm tra quyền admin
        if (!$this->session->get('isLoggedIn') || $this->session->get('role') !== 'admin') {
            return redirect()->to(base_url('/login'));
        }

        // Lấy thống kê tổng quan
        $stats = [
            'total_stories' => $this->storyModel->countAllResults(),
            'total_chapters' => $this->chapterModel->countAllResults(),
            'total_users' => $this->userModel->countAllResults(),
            'total_comments' => $this->commentModel->countAllResults(),
            'active_users' => $this->userModel->where('status', 'active')->countAllResults(),
            'stories_per_country' => $this->getStoriesPerCountry(),
            'stories_per_category' => $this->getStoriesPerCategory(),
            'top_viewed_stories' => $this->getTopViewedStories(),
            'latest_comments' => $this->getLatestComments(),
            'latest_logs' => $this->getLatestLogs(),
        ];

        return $this->renderView('admin/reports/index.html', [
            'stats' => $stats,
            'current_page' => 'reports'
        ]);
    }

    /**
     * Xuất báo cáo dựa trên loại
     */
    public function export($type)
    {
        // Kiểm tra quyền admin
        if (!$this->session->get('isLoggedIn') || $this->session->get('role') !== 'admin') {
            return redirect()->to(base_url('/login'));
        }

        // Thiết lập header
        $this->response->setHeader('Content-Type', 'text/csv');
        $this->response->setHeader('Content-Disposition', 'attachment; filename="' . $type . '_report_' . date('Y-m-d') . '.csv"');

        // Stream output
        $output = fopen('php://output', 'w');

        // Xử lý theo từng loại báo cáo
        switch ($type) {
            case 'stories':
                $this->exportStories($output);
                break;

            case 'users':
                $this->exportUsers($output);
                break;

            case 'comments':
                $this->exportComments($output);
                break;

            case 'activities':
                $this->exportActivities($output);
                break;

            default:
                return redirect()->to(base_url('/admin/reports'))->with('error', 'Loại báo cáo không hợp lệ.');
        }

        // Đóng file handle
        fclose($output);
        exit;
    }

    /**
     * Xuất báo cáo truyện
     */
    private function exportStories($output)
    {
        // CSV Header
        fputcsv($output, ['ID', 'Tiêu đề', 'Tác giả', 'Lượt xem', 'Đánh giá', 'Quốc gia', 'Số chương', 'Trạng thái', 'Ngày tạo']);

        // Lấy dữ liệu
        $stories = $this->storyModel->select('stories.*, users.username as author_name, countries.name as country_name')
            ->join('users', 'users.id = stories.author_id', 'left')
            ->join('countries', 'countries.id = stories.country_id', 'left')
            ->findAll();

        $chapterCounts = [];
        $chapterResults = $this->chapterModel->select('story_id, COUNT(*) as chapter_count')
            ->groupBy('story_id')
            ->findAll();

        foreach ($chapterResults as $result) {
            $chapterCounts[$result['story_id']] = $result['chapter_count'];
        }

        // Ghi dữ liệu
        foreach ($stories as $story) {
            $status = $story['is_completed'] ? 'Hoàn thành' : 'Đang cập nhật';
            $chapterCount = $chapterCounts[$story['id']] ?? 0;

            fputcsv($output, [
                $story['id'],
                $story['title'],
                $story['author_name'],
                $story['views'],
                $story['rating'],
                $story['country_name'],
                $chapterCount,
                $status,
                $story['created_at']
            ]);
        }
    }

    /**
     * Xuất báo cáo người dùng
     */
    private function exportUsers($output)
    {
        // CSV Header
        fputcsv($output, ['ID', 'Tên người dùng', 'Email', 'Vai trò', 'Trạng thái', 'Đăng nhập cuối', 'Ngày đăng ký']);

        // Lấy dữ liệu
        $users = $this->userModel->findAll();

        // Ghi dữ liệu
        foreach ($users as $user) {
            fputcsv($output, [
                $user['id'],
                $user['username'],
                $user['email'],
                $user['role'],
                $user['status'],
                $user['last_login'],
                $user['created_at']
            ]);
        }
    }

    /**
     * Xuất báo cáo bình luận
     */
    private function exportComments($output)
    {
        // CSV Header
        fputcsv($output, ['ID', 'Người dùng', 'Truyện', 'Chương', 'Nội dung', 'Thời gian']);

        // Lấy dữ liệu
        $comments = $this->commentModel->select('comments.*, users.username, stories.title as story_title, chapters.title as chapter_title')
            ->join('users', 'users.id = comments.user_id', 'left')
            ->join('stories', 'stories.id = comments.story_id', 'left')
            ->join('chapters', 'chapters.id = comments.chapter_id', 'left')
            ->findAll();

        // Ghi dữ liệu
        foreach ($comments as $comment) {
            fputcsv($output, [
                $comment['id'],
                $comment['username'] ?? $comment['guest_name'] ?? 'Ẩn danh',
                $comment['story_title'],
                $comment['chapter_title'],
                $comment['content'],
                $comment['created_at']
            ]);
        }
    }

    /**
     * Xuất báo cáo hoạt động
     */
    private function exportActivities($output)
    {
        // CSV Header
        fputcsv($output, ['ID', 'Người dùng', 'Hành động', 'Chi tiết', 'Thời gian']);

        // Lấy dữ liệu
        $logs = $this->logModel->select('logs.*, users.username')
            ->join('users', 'users.id = logs.context->>"$.user_id"', 'left')
            ->orderBy('logs.created_at', 'DESC')
            ->findAll();

        // Ghi dữ liệu
        foreach ($logs as $log) {
            $context = json_decode($log['context'], true);
            $username = $log['username'] ?? ($context['username'] ?? 'Hệ thống');
            $details = json_encode($context, JSON_UNESCAPED_UNICODE);

            fputcsv($output, [
                $log['id'],
                $username,
                $log['message'],
                $details,
                $log['created_at']
            ]);
        }
    }

    /**
     * Lấy số lượng truyện theo quốc gia
     */
    private function getStoriesPerCountry()
    {
        return $this->storyModel->select('countries.name, COUNT(*) as count')
            ->join('countries', 'countries.id = stories.country_id')
            ->groupBy('countries.id')
            ->findAll();
    }

    /**
     * Lấy số lượng truyện theo thể loại
     */
    private function getStoriesPerCategory()
    {
        $db = \Config\Database::connect();
        return $db->table('story_categories')
            ->select('categories.name, COUNT(*) as count')
            ->join('categories', 'categories.id = story_categories.category_id')
            ->groupBy('categories.id')
            ->get()
            ->getResultArray();
    }

    /**
     * Lấy truyện có lượt xem cao nhất
     */
    private function getTopViewedStories($limit = 10)
    {
        return $this->storyModel->select('stories.*, users.username as author_name')
            ->join('users', 'users.id = stories.author_id', 'left')
            ->orderBy('views', 'DESC')
            ->limit($limit)
            ->findAll();
    }

    /**
     * Lấy bình luận mới nhất
     */
    private function getLatestComments($limit = 10)
    {
        return $this->commentModel->select('comments.*, users.username, stories.title as story_title')
            ->join('users', 'users.id = comments.user_id', 'left')
            ->join('stories', 'stories.id = comments.story_id', 'left')
            ->orderBy('comments.created_at', 'DESC')
            ->limit($limit)
            ->findAll();
    }

    /**
     * Lấy log mới nhất
     */
    private function getLatestLogs($limit = 10)
    {
        return $this->logModel->orderBy('created_at', 'DESC')
            ->limit($limit)
            ->findAll();
    }
}
