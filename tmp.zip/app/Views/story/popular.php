<?php $this->extend('layouts/main'); ?>

<?php $this->section('title') ?>
<?= $page_title ?>
<?php $this->endSection() ?>

<?php $this->section('meta_description') ?>
<?= $page_description ?>
<?php $this->endSection() ?>

<?php $this->section('content') ?>
<div class="container">
    <div class="row">
        <div class="col-12">
            <h1 class="h3 mb-4 py-2 border-bottom">
                <i class="fas fa-fire me-2"></i> Truyện Hot - Được Đọc Nhiều Nhất
            </h1>

            <div class="row row-cols-2 row-cols-md-3 row-cols-lg-4 row-cols-xl-6 g-4">
                <?php foreach ($stories as $story): ?>
                <div class="col">
                    <div class="card h-100 bg-dark">
                        <div class="position-relative">
                            <a href="<?= base_url('truyen/' . esc($story['slug'])) ?>">
                                <img src="<?= base_url(esc($story['cover_image'])) ?>" class="card-img-top" alt="<?= esc($story['title']) ?>" style="height: 250px; object-fit: cover;">
                            </a>
                            <?php if ($story['is_completed']): ?>
                            <span class="position-absolute top-0 end-0 badge bg-success m-2">Hoàn thành</span>
                            <?php endif; ?>
                            <span class="position-absolute top-0 start-0 badge bg-danger m-2">
                                <i class="fas fa-fire me-1"></i> HOT
                            </span>
                        </div>
                        <div class="card-body">
                            <h5 class="card-title">
                                <a href="<?= base_url('truyen/' . esc($story['slug'])) ?>" class="text-decoration-none text-light text-truncate d-block">
                                    <?= esc($story['title']) ?>
                                </a>
                            </h5>
                            <div class="d-flex justify-content-between align-items-center mt-2">
                                <div class="rating">
                                    <?php for ($i = 1; $i <= 5; $i++): ?>
                                        <?php if ($i <= round($story['rating'])): ?>
                                            <i class="fas fa-star text-warning"></i>
                                        <?php else: ?>
                                            <i class="far fa-star text-muted"></i>
                                        <?php endif; ?>
                                    <?php endfor; ?>
                                    <span class="ms-1">(<?= $story['rating'] ?>)</span>
                                </div>
                                <span class="badge bg-info">
                                    <i class="fas fa-eye me-1"></i> <?= number_format($story['views']) ?>
                                </span>
                            </div>
                            <p class="card-text mt-2 small text-truncate">
                                <?php
                                $categories = isset($story['categories']) ? $story['categories'] : [];
                                $categoryNames = array_map(function($cat) {
                                    return '<a href="' . base_url('the-loai/' . $cat['slug']) . '" class="text-decoration-none text-info">' . $cat['name'] . '</a>';
                                }, $categories);
                                echo implode(', ', array_slice($categoryNames, 0, 3));
                                ?>
                            </p>
                        </div>
                        <div class="card-footer text-muted small">
                            <div class="d-flex justify-content-between">
                                <span>
                                    <i class="fas fa-clock me-1"></i> <?= date('d/m/Y', strtotime($story['updated_at'])) ?>
                                </span>
                                <?php if (isset($story['latest_chapter'])): ?>
                                <span>
                                    <a href="<?= base_url('truyen/' . esc($story['slug']) . '/chuong-' . $story['latest_chapter']['chapter_number']) ?>" class="text-decoration-none text-info">
                                        <i class="fas fa-bookmark me-1"></i> <?= esc($story['latest_chapter']['chapter_number']) ?>
                                    </a>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>
<?php $this->endSection() ?>
