<?php $this->extend('layouts/main'); ?>

<?php $this->section('title') ?>
<?= $page_title ?>
<?php $this->endSection() ?>

<?php $this->section('meta_description') ?>
<?= $page_description ?>
<?php $this->endSection() ?>

<?php $this->section('content') ?>
<div class="container">
    <div class="row">
        <div class="col-12">
            <h1 class="h3 mb-4 py-2 border-bottom">
                <i class="fas fa-chart-line me-2"></i> Bảng Xếp Hạng Truyện
            </h1>

            <div class="card bg-dark mb-4">
                <div class="card-header">
                    <ul class="nav nav-tabs card-header-tabs" id="rankings-tabs" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="most-viewed-tab" data-bs-toggle="tab" data-bs-target="#most-viewed" type="button" role="tab" aria-controls="most-viewed" aria-selected="true">
                                <i class="fas fa-eye me-1"></i> Xem Nhiều
                            </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="daily-tab" data-bs-toggle="tab" data-bs-target="#daily" type="button" role="tab" aria-controls="daily" aria-selected="false">
                                <i class="fas fa-calendar-day me-1"></i> Theo Ngày
                            </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="weekly-tab" data-bs-toggle="tab" data-bs-target="#weekly" type="button" role="tab" aria-controls="weekly" aria-selected="false">
                                <i class="fas fa-calendar-week me-1"></i> Theo Tuần
                            </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="monthly-tab" data-bs-toggle="tab" data-bs-target="#monthly" type="button" role="tab" aria-controls="monthly" aria-selected="false">
                                <i class="fas fa-calendar-alt me-1"></i> Theo Tháng
                            </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="top-rated-tab" data-bs-toggle="tab" data-bs-target="#top-rated" type="button" role="tab" aria-controls="top-rated" aria-selected="false">
                                <i class="fas fa-star me-1"></i> Đánh Giá Cao
                            </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="most-favorited-tab" data-bs-toggle="tab" data-bs-target="#most-favorited" type="button" role="tab" aria-controls="most-favorited" aria-selected="false">
                                <i class="fas fa-heart me-1"></i> Yêu Thích
                            </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="completed-tab" data-bs-toggle="tab" data-bs-target="#completed" type="button" role="tab" aria-controls="completed" aria-selected="false">
                                <i class="fas fa-check-circle me-1"></i> Hoàn Thành
                            </button>
                        </li>
                    </ul>
                </div>
                <div class="card-body">
                    <div class="tab-content" id="rankingsTabContent">
                        <!-- Most Viewed Tab -->
                        <div class="tab-pane fade show active" id="most-viewed" role="tabpanel" aria-labelledby="most-viewed-tab">
                            <h5 class="text-center mb-4">Top Truyện Xem Nhiều</h5>
                            <div class="table-responsive">
                                <table class="table table-dark table-hover table-striped">
                                    <thead>
                                        <tr>
                                            <th width="5%">#</th>
                                            <th width="50%">Tên Truyện</th>
                                            <th width="15%">Đánh Giá</th>
                                            <th width="15%">Thể Loại</th>
                                            <th width="15%">Lượt Xem</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $rank = 1; ?>
                                        <?php foreach ($rankings['most_viewed'] as $story): ?>
                                        <tr>
                                            <td class="text-center"><?= $rank++ ?></td>
                                            <td>
                                                <a href="<?= base_url('truyen/' . esc($story['slug'])) ?>" class="d-flex align-items-center">
                                                    <img src="<?= base_url(esc($story['cover_image'])) ?>" alt="<?= esc($story['title']) ?>" class="me-2" width="40" height="60">
                                                    <span><?= esc($story['title']) ?></span>
                                                </a>
                                            </td>
                                            <td>
                                                <div class="rating">
                                                    <?php for ($i = 1; $i <= 5; $i++): ?>
                                                        <?php if ($i <= round($story['rating'])): ?>
                                                            <i class="fas fa-star text-warning"></i>
                                                        <?php else: ?>
                                                            <i class="far fa-star text-muted"></i>
                                                        <?php endif; ?>
                                                    <?php endfor; ?>
                                                    <span class="ms-1">(<?= $story['rating'] ?>)</span>
                                                </div>
                                            </td>
                                            <td>
                                                <?php
                                                $categories = isset($story['categories']) ? $story['categories'] : [];
                                                $categoryNames = array_map(function($cat) {
                                                    return $cat['name'];
                                                }, $categories);
                                                echo implode(', ', array_slice($categoryNames, 0, 2));
                                                ?>
                                            </td>
                                            <td><?= number_format($story['views']) ?></td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <!-- Daily Tab -->
                        <div class="tab-pane fade" id="daily" role="tabpanel" aria-labelledby="daily-tab">
                            <h5 class="text-center mb-4">Top Truyện Xem Nhiều Trong Ngày</h5>
                            <div class="table-responsive">
                                <table class="table table-dark table-hover table-striped">
                                    <thead>
                                        <tr>
                                            <th width="5%">#</th>
                                            <th width="50%">Tên Truyện</th>
                                            <th width="15%">Đánh Giá</th>
                                            <th width="15%">Thể Loại</th>
                                            <th width="15%">Lượt Xem Hôm Nay</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $rank = 1; ?>
                                        <?php foreach ($rankings['daily'] as $story): ?>
                                        <tr>
                                            <td class="text-center"><?= $rank++ ?></td>
                                            <td>
                                                <a href="<?= base_url('truyen/' . esc($story['slug'])) ?>" class="d-flex align-items-center">
                                                    <img src="<?= base_url(esc($story['cover_image'])) ?>" alt="<?= esc($story['title']) ?>" class="me-2" width="40" height="60">
                                                    <span><?= esc($story['title']) ?></span>
                                                </a>
                                            </td>
                                            <td>
                                                <div class="rating">
                                                    <?php for ($i = 1; $i <= 5; $i++): ?>
                                                        <?php if ($i <= round($story['rating'])): ?>
                                                            <i class="fas fa-star text-warning"></i>
                                                        <?php else: ?>
                                                            <i class="far fa-star text-muted"></i>
                                                        <?php endif; ?>
                                                    <?php endfor; ?>
                                                    <span class="ms-1">(<?= $story['rating'] ?>)</span>
                                                </div>
                                            </td>
                                            <td>
                                                <?php
                                                $categories = isset($story['categories']) ? $story['categories'] : [];
                                                $categoryNames = array_map(function($cat) {
                                                    return $cat['name'];
                                                }, $categories);
                                                echo implode(', ', array_slice($categoryNames, 0, 2));
                                                ?>
                                            </td>
                                            <td><?= number_format($story['views_day']) ?></td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <!-- Weekly Tab -->
                        <div class="tab-pane fade" id="weekly" role="tabpanel" aria-labelledby="weekly-tab">
                            <h5 class="text-center mb-4">Top Truyện Xem Nhiều Trong Tuần</h5>
                            <div class="table-responsive">
                                <table class="table table-dark table-hover table-striped">
                                    <thead>
                                        <tr>
                                            <th width="5%">#</th>
                                            <th width="50%">Tên Truyện</th>
                                            <th width="15%">Đánh Giá</th>
                                            <th width="15%">Thể Loại</th>
                                            <th width="15%">Lượt Xem Tuần Này</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $rank = 1; ?>
                                        <?php foreach ($rankings['weekly'] as $story): ?>
                                        <tr>
                                            <td class="text-center"><?= $rank++ ?></td>
                                            <td>
                                                <a href="<?= base_url('truyen/' . esc($story['slug'])) ?>" class="d-flex align-items-center">
                                                    <img src="<?= base_url(esc($story['cover_image'])) ?>" alt="<?= esc($story['title']) ?>" class="me-2" width="40" height="60">
                                                    <span><?= esc($story['title']) ?></span>
                                                </a>
                                            </td>
                                            <td>
                                                <div class="rating">
                                                    <?php for ($i = 1; $i <= 5; $i++): ?>
                                                        <?php if ($i <= round($story['rating'])): ?>
                                                            <i class="fas fa-star text-warning"></i>
                                                        <?php else: ?>
                                                            <i class="far fa-star text-muted"></i>
                                                        <?php endif; ?>
                                                    <?php endfor; ?>
                                                    <span class="ms-1">(<?= $story['rating'] ?>)</span>
                                                </div>
                                            </td>
                                            <td>
                                                <?php
                                                $categories = isset($story['categories']) ? $story['categories'] : [];
                                                $categoryNames = array_map(function($cat) {
                                                    return $cat['name'];
                                                }, $categories);
                                                echo implode(', ', array_slice($categoryNames, 0, 2));
                                                ?>
                                            </td>
                                            <td><?= number_format($story['views_week']) ?></td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <!-- Monthly Tab -->
                        <div class="tab-pane fade" id="monthly" role="tabpanel" aria-labelledby="monthly-tab">
                            <h5 class="text-center mb-4">Top Truyện Xem Nhiều Trong Tháng</h5>
                            <div class="table-responsive">
                                <table class="table table-dark table-hover table-striped">
                                    <thead>
                                        <tr>
                                            <th width="5%">#</th>
                                            <th width="50%">Tên Truyện</th>
                                            <th width="15%">Đánh Giá</th>
                                            <th width="15%">Thể Loại</th>
                                            <th width="15%">Lượt Xem Tháng Này</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $rank = 1; ?>
                                        <?php foreach ($rankings['monthly'] as $story): ?>
                                        <tr>
                                            <td class="text-center"><?= $rank++ ?></td>
                                            <td>
                                                <a href="<?= base_url('truyen/' . esc($story['slug'])) ?>" class="d-flex align-items-center">
                                                    <img src="<?= base_url(esc($story['cover_image'])) ?>" alt="<?= esc($story['title']) ?>" class="me-2" width="40" height="60">
                                                    <span><?= esc($story['title']) ?></span>
                                                </a>
                                            </td>
                                            <td>
                                                <div class="rating">
                                                    <?php for ($i = 1; $i <= 5; $i++): ?>
                                                        <?php if ($i <= round($story['rating'])): ?>
                                                            <i class="fas fa-star text-warning"></i>
                                                        <?php else: ?>
                                                            <i class="far fa-star text-muted"></i>
                                                        <?php endif; ?>
                                                    <?php endfor; ?>
                                                    <span class="ms-1">(<?= $story['rating'] ?>)</span>
                                                </div>
                                            </td>
                                            <td>
                                                <?php
                                                $categories = isset($story['categories']) ? $story['categories'] : [];
                                                $categoryNames = array_map(function($cat) {
                                                    return $cat['name'];
                                                }, $categories);
                                                echo implode(', ', array_slice($categoryNames, 0, 2));
                                                ?>
                                            </td>
                                            <td><?= number_format($story['views_month']) ?></td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <!-- Top Rated Tab -->
                        <div class="tab-pane fade" id="top-rated" role="tabpanel" aria-labelledby="top-rated-tab">
                            <h5 class="text-center mb-4">Top Truyện Đánh Giá Cao</h5>
                            <div class="table-responsive">
                                <table class="table table-dark table-hover table-striped">
                                    <thead>
                                        <tr>
                                            <th width="5%">#</th>
                                            <th width="50%">Tên Truyện</th>
                                            <th width="15%">Đánh Giá</th>
                                            <th width="15%">Thể Loại</th>
                                            <th width="15%">Lượt Đánh Giá</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $rank = 1; ?>
                                        <?php foreach ($rankings['top_rated'] as $story): ?>
                                        <tr>
                                            <td class="text-center"><?= $rank++ ?></td>
                                            <td>
                                                <a href="<?= base_url('truyen/' . esc($story['slug'])) ?>" class="d-flex align-items-center">
                                                    <img src="<?= base_url(esc($story['cover_image'])) ?>" alt="<?= esc($story['title']) ?>" class="me-2" width="40" height="60">
                                                    <span><?= esc($story['title']) ?></span>
                                                </a>
                                            </td>
                                            <td>
                                                <div class="rating">
                                                    <?php for ($i = 1; $i <= 5; $i++): ?>
                                                        <?php if ($i <= round($story['rating'])): ?>
                                                            <i class="fas fa-star text-warning"></i>
                                                        <?php else: ?>
                                                            <i class="far fa-star text-muted"></i>
                                                        <?php endif; ?>
                                                    <?php endfor; ?>
                                                    <span class="ms-1">(<?= $story['rating'] ?>)</span>
                                                </div>
                                            </td>
                                            <td>
                                                <?php
                                                $categories = isset($story['categories']) ? $story['categories'] : [];
                                                $categoryNames = array_map(function($cat) {
                                                    return $cat['name'];
                                                }, $categories);
                                                echo implode(', ', array_slice($categoryNames, 0, 2));
                                                ?>
                                            </td>
                                            <td><?= number_format($story['total_ratings']) ?></td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <!-- Most Favorited Tab -->
                        <div class="tab-pane fade" id="most-favorited" role="tabpanel" aria-labelledby="most-favorited-tab">
                            <h5 class="text-center mb-4">Top Truyện Được Yêu Thích</h5>
                            <div class="table-responsive">
                                <table class="table table-dark table-hover table-striped">
                                    <thead>
                                        <tr>
                                            <th width="5%">#</th>
                                            <th width="50%">Tên Truyện</th>
                                            <th width="15%">Đánh Giá</th>
                                            <th width="15%">Thể Loại</th>
                                            <th width="15%">Lượt Yêu Thích</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $rank = 1; ?>
                                        <?php foreach ($rankings['most_favorited'] as $story): ?>
                                        <tr>
                                            <td class="text-center"><?= $rank++ ?></td>
                                            <td>
                                                <a href="<?= base_url('truyen/' . esc($story['slug'])) ?>" class="d-flex align-items-center">
                                                    <img src="<?= base_url(esc($story['cover_image'])) ?>" alt="<?= esc($story['title']) ?>" class="me-2" width="40" height="60">
                                                    <span><?= esc($story['title']) ?></span>
                                                </a>
                                            </td>
                                            <td>
                                                <div class="rating">
                                                    <?php for ($i = 1; $i <= 5; $i++): ?>
                                                        <?php if ($i <= round($story['rating'])): ?>
                                                            <i class="fas fa-star text-warning"></i>
                                                        <?php else: ?>
                                                            <i class="far fa-star text-muted"></i>
                                                        <?php endif; ?>
                                                    <?php endfor; ?>
                                                    <span class="ms-1">(<?= $story['rating'] ?>)</span>
                                                </div>
                                            </td>
                                            <td>
                                                <?php
                                                $categories = isset($story['categories']) ? $story['categories'] : [];
                                                $categoryNames = array_map(function($cat) {
                                                    return $cat['name'];
                                                }, $categories);
                                                echo implode(', ', array_slice($categoryNames, 0, 2));
                                                ?>
                                            </td>
                                            <td><?= number_format($story['total_favorites']) ?></td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <!-- Completed Tab -->
                        <div class="tab-pane fade" id="completed" role="tabpanel" aria-labelledby="completed-tab">
                            <h5 class="text-center mb-4">Top Truyện Đã Hoàn Thành</h5>
                            <div class="table-responsive">
                                <table class="table table-dark table-hover table-striped">
                                    <thead>
                                        <tr>
                                            <th width="5%">#</th>
                                            <th width="50%">Tên Truyện</th>
                                            <th width="15%">Đánh Giá</th>
                                            <th width="15%">Thể Loại</th>
                                            <th width="15%">Lượt Xem</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $rank = 1; ?>
                                        <?php foreach ($rankings['completed'] as $story): ?>
                                        <tr>
                                            <td class="text-center"><?= $rank++ ?></td>
                                            <td>
                                                <a href="<?= base_url('truyen/' . esc($story['slug'])) ?>" class="d-flex align-items-center">
                                                    <img src="<?= base_url(esc($story['cover_image'])) ?>" alt="<?= esc($story['title']) ?>" class="me-2" width="40" height="60">
                                                    <span><?= esc($story['title']) ?></span>
                                                </a>
                                            </td>
                                            <td>
                                                <div class="rating">
                                                    <?php for ($i = 1; $i <= 5; $i++): ?>
                                                        <?php if ($i <= round($story['rating'])): ?>
                                                            <i class="fas fa-star text-warning"></i>
                                                        <?php else: ?>
                                                            <i class="far fa-star text-muted"></i>
                                                        <?php endif; ?>
                                                    <?php endfor; ?>
                                                    <span class="ms-1">(<?= $story['rating'] ?>)</span>
                                                </div>
                                            </td>
                                            <td>
                                                <?php
                                                $categories = isset($story['categories']) ? $story['categories'] : [];
                                                $categoryNames = array_map(function($cat) {
                                                    return $cat['name'];
                                                }, $categories);
                                                echo implode(', ', array_slice($categoryNames, 0, 2));
                                                ?>
                                            </td>
                                            <td><?= number_format($story['views']) ?></td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $this->endSection() ?>
