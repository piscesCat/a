<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\LogModel;
use App\Models\BackupModel;

class DatabaseMaintenance extends BaseController
{
    /**
     * Run the database cleanup procedure
     * Can be triggered manually by admin or via cronjob
     */
    public function cleanup()
    {
        // Only allow access from CLI or admin
        if (!is_cli() && !$this->requireAdmin()) {
            return $this->response->setStatusCode(403, 'Access Denied');
        }

        try {
            // Connect to the database
            $db = \Config\Database::connect();

            // Call the cleanup procedure
            $db->query('CALL cleanup_database()');

            // Log the successful cleanup
            $logModel = new LogModel();
            $logModel->info('Database cleanup executed successfully', [
                'triggered_by' => is_cli() ? 'cronjob' : ($this->currentUser['username'] ?? 'unknown'),
                'method' => is_cli() ? 'CLI' : 'web'
            ]);

            // If this is a web request, redirect with success message
            if (!is_cli()) {
                $this->session->setFlashdata('success', 'Dọn dẹp cơ sở dữ liệu thành công!');
                return redirect()->to(base_url('admin/backups'));
            }

            // If CLI, just print success message
            if (is_cli()) {
                CLI::write('Database cleanup completed successfully.', 'green');
                return 0;
            }

            // Default response for other methods
            return $this->response->setJSON([
                'success' => true,
                'message' => 'Database cleanup executed successfully'
            ]);
        } catch (\Exception $e) {
            // Log error
            $logModel = new LogModel();
            $logModel->error('Database cleanup failed', [
                'error' => $e->getMessage(),
                'triggered_by' => is_cli() ? 'cronjob' : ($this->currentUser['username'] ?? 'unknown'),
                'method' => is_cli() ? 'CLI' : 'web'
            ]);

            // Handle different response types
            if (is_cli()) {
                CLI::error('Database cleanup failed: ' . $e->getMessage());
                return 1;
            } else if (!$this->request->isAJAX()) {
                $this->session->setFlashdata('error', 'Dọn dẹp cơ sở dữ liệu thất bại: ' . $e->getMessage());
                return redirect()->to(base_url('admin/backups'));
            } else {
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'Database cleanup failed: ' . $e->getMessage()
                ]);
            }
        }
    }

    /**
     * Reset view statistics for stories
     * - Daily: Reset views_day
     * - Weekly: Reset views_week
     * - Monthly: Reset views_month
     */
    public function resetStats($period = 'daily')
    {
        // Only allow access from CLI or admin
        if (!is_cli() && !$this->requireAdmin()) {
            return $this->response->setStatusCode(403, 'Access Denied');
        }

        try {
            // Load the StoryModel
            $storyModel = new \App\Models\StoryModel();

            // Reset the appropriate statistics
            switch ($period) {
                case 'daily':
                    $storyModel->resetDailyViews();
                    break;
                case 'weekly':
                    $storyModel->resetWeeklyViews();
                    break;
                case 'monthly':
                    $storyModel->resetMonthlyViews();
                    break;
                default:
                    throw new \Exception('Invalid period specified. Use daily, weekly, or monthly.');
            }

            // Log the reset
            $logModel = new LogModel();
            $logModel->info('View statistics reset', [
                'period' => $period,
                'triggered_by' => is_cli() ? 'cronjob' : ($this->currentUser['username'] ?? 'unknown'),
                'method' => is_cli() ? 'CLI' : 'web'
            ]);

            // Handle response based on request type
            if (is_cli()) {
                CLI::write($period . ' view statistics reset successfully.', 'green');
                return 0;
            } else if (!$this->request->isAJAX()) {
                $this->session->setFlashdata('success', 'Đã reset thống kê lượt xem ' . $this->getPeriodName($period));
                return redirect()->to(base_url('admin/dashboard'));
            } else {
                return $this->response->setJSON([
                    'success' => true,
                    'message' => 'View statistics reset successfully'
                ]);
            }
        } catch (\Exception $e) {
            // Log error
            $logModel = new LogModel();
            $logModel->error('View statistics reset failed', [
                'error' => $e->getMessage(),
                'period' => $period,
                'triggered_by' => is_cli() ? 'cronjob' : ($this->currentUser['username'] ?? 'unknown')
            ]);

            // Handle different response types
            if (is_cli()) {
                CLI::error('View statistics reset failed: ' . $e->getMessage());
                return 1;
            } else if (!$this->request->isAJAX()) {
                $this->session->setFlashdata('error', 'Reset thống kê thất bại: ' . $e->getMessage());
                return redirect()->to(base_url('admin/dashboard'));
            } else {
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'View statistics reset failed: ' . $e->getMessage()
                ]);
            }
        }
    }

    /**
     * Update recommended stories based on algorithm
     */
    public function updateRecommendedStories()
    {
        // Only allow access from CLI or admin
        if (!is_cli() && !$this->requireAdmin()) {
            return $this->response->setStatusCode(403, 'Access Denied');
        }

        try {
            // Load the StoryModel
            $storyModel = new \App\Models\StoryModel();

            // Get the number of recommended stories from settings
            $settingsModel = new \App\Models\SettingsModel();
            $maxRecommended = (int)($settingsModel->getSetting('max_recommended_stories') ?? 20);

            // Update the recommended stories
            $updated = $storyModel->updateRecommendedStories($maxRecommended);

            if (!$updated) {
                throw new \Exception('Failed to update recommended stories.');
            }

            // Log the update
            $logModel = new LogModel();
            $logModel->info('Recommended stories updated', [
                'count' => $maxRecommended,
                'triggered_by' => is_cli() ? 'cronjob' : ($this->currentUser['username'] ?? 'unknown'),
                'method' => is_cli() ? 'CLI' : 'web'
            ]);

            // Handle response based on request type
            if (is_cli()) {
                CLI::write('Recommended stories updated successfully.', 'green');
                return 0;
            } else if (!$this->request->isAJAX()) {
                $this->session->setFlashdata('success', 'Đã cập nhật danh sách truyện đề xuất');
                return redirect()->to(base_url('admin/dashboard'));
            } else {
                return $this->response->setJSON([
                    'success' => true,
                    'message' => 'Recommended stories updated successfully'
                ]);
            }
        } catch (\Exception $e) {
            // Log error
            $logModel = new LogModel();
            $logModel->error('Recommended stories update failed', [
                'error' => $e->getMessage(),
                'triggered_by' => is_cli() ? 'cronjob' : ($this->currentUser['username'] ?? 'unknown')
            ]);

            // Handle different response types
            if (is_cli()) {
                CLI::error('Recommended stories update failed: ' . $e->getMessage());
                return 1;
            } else if (!$this->request->isAJAX()) {
                $this->session->setFlashdata('error', 'Cập nhật truyện đề xuất thất bại: ' . $e->getMessage());
                return redirect()->to(base_url('admin/dashboard'));
            } else {
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'Recommended stories update failed: ' . $e->getMessage()
                ]);
            }
        }
    }

    /**
     * Helper method to get the Vietnamese name for a period
     */
    private function getPeriodName($period)
    {
        switch ($period) {
            case 'daily':
                return 'theo ngày';
            case 'weekly':
                return 'theo tuần';
            case 'monthly':
                return 'theo tháng';
            default:
                return $period;
        }
    }
}
