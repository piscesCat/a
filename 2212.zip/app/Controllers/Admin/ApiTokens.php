<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\TokenModel;
use App\Models\UserModel;
use Firebase\JWT\JWT;

class ApiTokens extends BaseController
{
    protected $tokenModel;
    protected $userModel;

    public function __construct()
    {
        $this->tokenModel = new TokenModel();
        $this->userModel = new UserModel();
    }

    /**
     * Display API tokens management page
     */
    public function index()
    {
        // Require admin role
        $check = $this->requireAdmin();
        if ($check !== true) {
            return $check;
        }

        // Get all tokens with user information
        $tokens = $this->tokenModel->getTokensWithUsers();

        // Get users for dropdown
        $users = $this->userModel->findAll();

        $data = [
            'title' => 'Quản lý API Tokens',
            'tokens' => $tokens,
            'users' => $users,
            'current_user' => $this->currentUser
        ];

        return $this->renderView('admin/api_tokens/index.html', $data);
    }

    /**
     * Create a new API token
     */
    public function create()
    {
        // Require admin role
        $check = $this->requireAdmin();
        if ($check !== true) {
            return $check;
        }

        // Validate request
        $userId = $this->request->getPost('user_id');
        $expiryDays = $this->request->getPost('expiry_days');

        // Validate user exists
        $user = $this->userModel->find($userId);
        if (!$user) {
            return redirect()->back()->with('error', 'Người dùng không tồn tại.');
        }

        // Validate user has high enough permissions (role 1 or higher)
        if ($user['role'] < 1) {
            return redirect()->back()->with('error', 'Người dùng không có quyền truy cập API.');
        }

        // Generate token using JWT
        $expiryDays = intval($expiryDays) ?: 30; // Default to 30 days
        $expiresAt = time() + ($expiryDays * 24 * 60 * 60);

        $payload = [
            'user_id' => $userId,
            'username' => $user['username'],
            'email' => $user['email'],
            'role' => $user['role'],
            'iat' => time(),
            'exp' => $expiresAt
        ];

        // Get JWT secret key from config or .env
        $key = $this->getJwtSecretKey();

        // Generate token
        $token = JWT::encode($payload, $key, 'HS256');

        // Store token in database
        $this->tokenModel->insert([
            'user_id' => $userId,
            'token' => $token,
            'expires_at' => date('Y-m-d H:i:s', $expiresAt),
            'created_at' => date('Y-m-d H:i:s')
        ]);

        // Log the token creation
        $this->logModel->info('API Token created', [
            'user_id' => $this->currentUser['id'],
            'token_for_user_id' => $userId,
            'token_expires' => date('Y-m-d H:i:s', $expiresAt),
            'ip_address' => $this->request->getIPAddress()
        ]);

        return redirect()->to('/admin/api-tokens')->with('success', 'API Token đã được tạo thành công.');
    }

    /**
     * Get JWT secret key from config or .env
     */
    private function getJwtSecretKey()
    {
        // Try to get from config
        $key = getenv('JWT_SECRET_KEY');

        // If not set, generate a new one and save it
        if (!$key) {
            // Generate a secure random key
            $key = bin2hex(random_bytes(32));

            // Try to save it to .env file
            $envPath = ROOTPATH . '.env';
            if (file_exists($envPath) && is_writable($envPath)) {
                $envContent = file_get_contents($envPath);

                // Check if JWT_SECRET_KEY already exists
                if (strpos($envContent, 'JWT_SECRET_KEY') !== false) {
                    // Replace the existing value
                    $envContent = preg_replace('/JWT_SECRET_KEY\\s*=.*/', "JWT_SECRET_KEY = \"$key\"", $envContent);
                } else {
                    // Add new key
                    $envContent .= "\n# JWT Configuration\nJWT_SECRET_KEY = \"$key\"\n";
                }

                file_put_contents($envPath, $envContent);
            }

            // Set the environment variable for the current request
            putenv("JWT_SECRET_KEY=$key");
        }

        return $key;
    }
}
