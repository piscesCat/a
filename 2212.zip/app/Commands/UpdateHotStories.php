<?php

namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use App\Models\StoryModel;
use App\Models\LogModel;

class UpdateHotStories extends BaseCommand
{
    /**
     * The Command's Group
     *
     * @var string
     */
    protected $group = 'App';

    /**
     * The Command's Name
     *
     * @var string
     */
    protected $name = 'stories:update-hot';

    /**
     * The Command's Description
     *
     * @var string
     */
    protected $description = 'Cập nhật trạng thái HOT cho các truyện dựa trên lượt xem và tương tác';

    /**
     * The Command's Usage
     *
     * @var string
     */
    protected $usage = 'stories:update-hot [options]';

    /**
     * The Command's Arguments
     *
     * @var array
     */
    protected $arguments = [];

    /**
     * The Command's Options
     *
     * @var array
     */
    protected $options = [
        '--min-views' => 'Số lượt xem tối thiểu trong ngày để đánh dấu là hot (mặc định: 100)',
        '--growth-rate' => 'Tỷ lệ tăng trưởng tối thiểu so với ngày trước (mặc định: 30%)',
        '--min-ratings' => 'Số lượng đánh giá mới tối thiểu trong 24h (mặc định: 10)',
        '--cooldown' => 'Số ngày tự động loại bỏ trạng thái hot (mặc định: 3)'
    ];

    /**
     * Actually execute a command.
     *
     * @param array $params
     */
    public function run(array $params)
    {
        CLI::write('Đang cập nhật trạng thái HOT cho truyện...', 'yellow');

        // Lấy các tham số từ command line options
        $minDailyViews = $params['min-views'] ?? 100;
        $growthRate = $params['growth-rate'] ?? 30;
        $minNewRatings = $params['min-ratings'] ?? 10;
        $cooldownDays = $params['cooldown'] ?? 3;

        try {
            $storyModel = new StoryModel();
            $result = $storyModel->updateHotStories(
                $minDailyViews,
                $growthRate,
                $minNewRatings,
                $cooldownDays
            );

            if ($result) {
                CLI::write('Cập nhật trạng thái HOT cho truyện thành công!', 'green');
                return 0;
            } else {
                CLI::error('Cập nhật trạng thái HOT cho truyện thất bại!');
                return 1;
            }
        } catch (\Exception $e) {
            // Ghi log lỗi
            $logModel = new LogModel();
            $logModel->error('Cập nhật trạng thái HOT cho truyện thất bại', [
                'error' => $e->getMessage(),
                'triggered_by' => 'cronjob',
                'method' => 'CLI'
            ]);

            CLI::error('Cập nhật trạng thái HOT cho truyện thất bại: ' . $e->getMessage());
            return 1;
        }
    }
}
