<?php

namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use App\Models\StoryModel;
use App\Models\LogModel;

class SuggestFeaturedStories extends BaseCommand
{
    /**
     * The Command's Group
     *
     * @var string
     */
    protected $group = 'App';

    /**
     * The Command's Name
     *
     * @var string
     */
    protected $name = 'stories:suggest-featured';

    /**
     * The Command's Description
     *
     * @var string
     */
    protected $description = 'Đề xuất truyện nên được đánh dấu là nổi bật (featured) dựa trên nhiều yếu tố';

    /**
     * The Command's Usage
     *
     * @var string
     */
    protected $usage = 'stories:suggest-featured [options]';

    /**
     * The Command's Arguments
     *
     * @var array
     */
    protected $arguments = [];

    /**
     * The Command's Options
     *
     * @var array
     */
    protected $options = [
        '--limit' => 'Số lượng truyện đề xuất tối đa (mặc định: 10)',
        '--min-rating' => 'Đánh giá tối thiểu (mặc định: 4.0)',
        '--min-views' => 'Lượt xem tối thiểu (mặc định: 500)',
        '--include-current' => 'Bao gồm cả truyện đã featured (mặc định: không)',
    ];

    /**
     * Actually execute a command.
     *
     * @param array $params
     */
    public function run(array $params)
    {
        CLI::write('Đang đề xuất truyện nổi bật...', 'yellow');

        // Lấy các tham số từ command line options
        $limit = $params['limit'] ?? 10;
        $options = [
            'min_rating' => $params['min-rating'] ?? 4.0,
            'min_views' => $params['min-views'] ?? 500,
            'exclude_current_featured' => !isset($params['include-current']),
        ];

        try {
            $storyModel = new StoryModel();
            $suggestions = $storyModel->suggestFeaturedStories($limit, $options);

            if (empty($suggestions)) {
                CLI::error('Không có đề xuất nào được tìm thấy!');
                return 1;
            }

            // Hiển thị kết quả
            CLI::write('Đề xuất ' . count($suggestions) . ' truyện nổi bật:', 'green');
            CLI::newLine();

            $table = [];
            foreach ($suggestions as $index => $suggestion) {
                $table[] = [
                    ($index + 1),
                    $suggestion['title'],
                    $suggestion['score'] . '%',
                    implode('; ', $suggestion['reasons'])
                ];
            }

            CLI::table($table, ['#', 'Tên truyện', 'Điểm', 'Lý do đề xuất']);

            // Lưu báo cáo đề xuất vào file
            $this->saveReport($suggestions);

            return 0;
        } catch (\Exception $e) {
            // Ghi log lỗi
            $logModel = new LogModel();
            $logModel->error('Đề xuất truyện nổi bật thất bại', [
                'error' => $e->getMessage(),
                'triggered_by' => 'cronjob',
                'method' => 'CLI'
            ]);

            CLI::error('Đề xuất truyện nổi bật thất bại: ' . $e->getMessage());
            return 1;
        }
    }

    /**
     * Lưu báo cáo đề xuất vào file trong thư mục writable/reports
     *
     * @param array $suggestions Danh sách truyện được đề xuất
     * @return bool Trả về true nếu lưu thành công
     */
    protected function saveReport(array $suggestions)
    {
        $reportDir = WRITEPATH . 'reports';

        // Tạo thư mục nếu chưa tồn tại
        if (!is_dir($reportDir)) {
            mkdir($reportDir, 0755, true);
        }

        $timestamp = date('Y-m-d_H-i-s');
        $filename = $reportDir . '/featured_suggestions_' . $timestamp . '.json';

        // Định dạng dữ liệu báo cáo
        $reportData = [
            'generated_at' => date('Y-m-d H:i:s'),
            'count' => count($suggestions),
            'suggestions' => $suggestions
        ];

        // Lưu file JSON
        $result = file_put_contents($filename, json_encode($reportData, JSON_PRETTY_PRINT));

        if ($result !== false) {
            CLI::write('Báo cáo đề xuất đã được lưu tại: ' . $filename, 'green');
            return true;
        } else {
            CLI::error('Không thể lưu báo cáo đề xuất!');
            return false;
        }
    }
}
