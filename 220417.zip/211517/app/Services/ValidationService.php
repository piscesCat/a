<?php

namespace App\Services;

use CodeIgniter\Validation\Validation;
use Config\Services;

/**
 * ValidationService - Xử lý validation dữ liệu thống nhất trong toàn bộ ứng dụng
 */
class ValidationService
{
    /**
     * CodeIgniter validation instance
     * @var Validation
     */
    protected $validation;

    /**
     * ErrorService để xử lý lỗi
     * @var ErrorService
     */
    protected $errorService;

    /**
     * Request instance
     */
    protected $request;

    /**
     * Session instance
     */
    protected $session;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->validation = Services::validation();
        $this->errorService = new ErrorService();
        $this->request = Services::request();
        $this->session = Services::session();
    }

    /**
     * Xác thực dữ liệu đầu vào
     *
     * @param array $data Dữ liệu cần xác thực
     * @param array $rules Quy tắc xác thực
     * @param array $messages Thông báo tùy chỉnh cho lỗi xác thực
     * @param bool $isApi Có phải là API request không
     * @return mixed True nếu xác thực thành công, phản hồi nếu thất bại
     */
    public function validate($data, $rules, $messages = [], $isApi = false)
    {
        // Đặt quy tắc xác thực
        $this->validation->setRules($rules, $messages);

        // Thực hiện xác thực
        if ($this->validation->run($data)) {
            return true;
        }

        // Lấy tất cả lỗi xác thực
        $errors = $this->validation->getErrors();

        // First error for flash message
        $firstError = reset($errors);

        // Ghi log lỗi xác thực
        $context = [
            'validation' => $errors,
            'request_data' => array_diff_key($data, array_flip(['password', 'confirm_password', 'current_password', 'token', 'api_key']))
        ];

        // Xử lý dựa trên loại request
        if ($isApi || $this->request->isAJAX()) {
            return $this->errorService->handleError(
                'Dữ liệu không hợp lệ: ' . $firstError,
                'warning',
                $context,
                true,
                422 // Unprocessable Entity
            );
        } else {
            // Lưu errors vào session để hiển thị trong form
            $this->session->setFlashdata('errors', $errors);

            // Lưu dữ liệu đã nhập vào old() để giữ giá trị trong form
            $this->session->setFlashdata('_ci_validation_old_input', $data);

            return $this->errorService->handleError(
                'Dữ liệu không hợp lệ: ' . $firstError,
                'warning',
                $context
            );
        }
    }

    /**
     * Lấy dữ liệu đã xác thực
     *
     * @param array $data Dữ liệu đầu vào
     * @param array $rules Quy tắc xác thực
     * @param array $messages Thông báo tùy chỉnh cho lỗi xác thực
     * @param bool $isApi Có phải là API request không
     * @return mixed Dữ liệu đã xác thực hoặc phản hồi nếu thất bại
     */
    public function getValidatedData($data, $rules, $messages = [], $isApi = false)
    {
        // Xác thực dữ liệu
        $validationResult = $this->validate($data, $rules, $messages, $isApi);

        // Nếu xác thực thất bại, trả về kết quả (response)
        if ($validationResult !== true) {
            return $validationResult;
        }

        // Lọc ra chỉ những trường đã được xác thực
        $validatedData = [];
        foreach ($rules as $field => $rule) {
            if (isset($data[$field])) {
                $validatedData[$field] = $data[$field];
            }
        }

        return $validatedData;
    }

    /**
     * Tạo quy tắc xác thực cho tài nguyên cụ thể
     *
     * @param string $resource Tên tài nguyên (story, chapter, user, etc.)
     * @param string $action Hành động (create, update)
     * @return array Quy tắc xác thực
     */
    public function getRules($resource, $action = 'create')
    {
        $rules = [];
        $messages = [];

        switch ($resource) {
            case 'story':
                if ($action === 'create') {
                    $rules = [
                        'title' => 'required|min_length[3]|max_length[255]',
                        'slug' => 'required|alpha_dash|min_length[3]|max_length[255]|is_unique[stories.slug]',
                        'description' => 'required|min_length[10]',
                        'author_id' => 'required|is_natural_no_zero|exists[users.id]',
                        'status' => 'required|in_list[published,draft,completed]',
                        'categories' => 'required',
                        'categories.*' => 'is_natural_no_zero|exists[categories.id]',
                    ];

                    $messages = [
                        'title' => [
                            'required' => 'Tiêu đề truyện không được để trống',
                            'min_length' => 'Tiêu đề truyện phải có ít nhất {param} ký tự',
                            'max_length' => 'Tiêu đề truyện không được vượt quá {param} ký tự',
                        ],
                        'slug' => [
                            'required' => 'Slug không được để trống',
                            'alpha_dash' => 'Slug chỉ được chứa chữ cái, số và dấu gạch ngang',
                            'min_length' => 'Slug phải có ít nhất {param} ký tự',
                            'max_length' => 'Slug không được vượt quá {param} ký tự',
                            'is_unique' => 'Slug đã tồn tại, vui lòng chọn slug khác',
                        ],
                        'description' => [
                            'required' => 'Mô tả truyện không được để trống',
                            'min_length' => 'Mô tả truyện phải có ít nhất {param} ký tự',
                        ],
                        'author_id' => [
                            'required' => 'Tác giả không được để trống',
                            'is_natural_no_zero' => 'ID tác giả không hợp lệ',
                            'exists' => 'Tác giả không tồn tại',
                        ],
                        'status' => [
                            'required' => 'Trạng thái truyện không được để trống',
                            'in_list' => 'Trạng thái truyện không hợp lệ',
                        ],
                        'categories' => [
                            'required' => 'Thể loại không được để trống',
                        ],
                        'categories.*' => [
                            'is_natural_no_zero' => 'ID thể loại không hợp lệ',
                            'exists' => 'Thể loại không tồn tại',
                        ],
                    ];
                } elseif ($action === 'update') {
                    $rules = [
                        'title' => 'required|min_length[3]|max_length[255]',
                        'slug' => 'required|alpha_dash|min_length[3]|max_length[255]|is_unique[stories.slug,id,{id}]',
                        'description' => 'required|min_length[10]',
                        'author_id' => 'required|is_natural_no_zero|exists[users.id]',
                        'status' => 'required|in_list[published,draft,completed]',
                        'categories' => 'required',
                        'categories.*' => 'is_natural_no_zero|exists[categories.id]',
                    ];

                    $messages = [
                        'title' => [
                            'required' => 'Tiêu đề truyện không được để trống',
                            'min_length' => 'Tiêu đề truyện phải có ít nhất {param} ký tự',
                            'max_length' => 'Tiêu đề truyện không được vượt quá {param} ký tự',
                        ],
                        'slug' => [
                            'required' => 'Slug không được để trống',
                            'alpha_dash' => 'Slug chỉ được chứa chữ cái, số và dấu gạch ngang',
                            'min_length' => 'Slug phải có ít nhất {param} ký tự',
                            'max_length' => 'Slug không được vượt quá {param} ký tự',
                            'is_unique' => 'Slug đã tồn tại, vui lòng chọn slug khác',
                        ],
                        'description' => [
                            'required' => 'Mô tả truyện không được để trống',
                            'min_length' => 'Mô tả truyện phải có ít nhất {param} ký tự',
                        ],
                        'author_id' => [
                            'required' => 'Tác giả không được để trống',
                            'is_natural_no_zero' => 'ID tác giả không hợp lệ',
                            'exists' => 'Tác giả không tồn tại',
                        ],
                        'status' => [
                            'required' => 'Trạng thái truyện không được để trống',
                            'in_list' => 'Trạng thái truyện không hợp lệ',
                        ],
                        'categories' => [
                            'required' => 'Thể loại không được để trống',
                        ],
                        'categories.*' => [
                            'is_natural_no_zero' => 'ID thể loại không hợp lệ',
                            'exists' => 'Thể loại không tồn tại',
                        ],
                    ];
                }
                break;

            case 'chapter':
                if ($action === 'create') {
                    $rules = [
                        'story_id' => 'required|is_natural_no_zero|exists[stories.id]',
                        'title' => 'required|min_length[3]|max_length[255]',
                        'content' => 'required|min_length[10]',
                        'status' => 'required|in_list[published,draft]',
                        'chapter_number' => 'required|is_natural_no_zero',
                    ];

                    $messages = [
                        'story_id' => [
                            'required' => 'Truyện không được để trống',
                            'is_natural_no_zero' => 'ID truyện không hợp lệ',
                            'exists' => 'Truyện không tồn tại',
                        ],
                        'title' => [
                            'required' => 'Tiêu đề chương không được để trống',
                            'min_length' => 'Tiêu đề chương phải có ít nhất {param} ký tự',
                            'max_length' => 'Tiêu đề chương không được vượt quá {param} ký tự',
                        ],
                        'content' => [
                            'required' => 'Nội dung chương không được để trống',
                            'min_length' => 'Nội dung chương phải có ít nhất {param} ký tự',
                        ],
                        'status' => [
                            'required' => 'Trạng thái chương không được để trống',
                            'in_list' => 'Trạng thái chương không hợp lệ',
                        ],
                        'chapter_number' => [
                            'required' => 'Số chương không được để trống',
                            'is_natural_no_zero' => 'Số chương phải là số nguyên dương',
                        ],
                    ];
                } elseif ($action === 'update') {
                    $rules = [
                        'story_id' => 'required|is_natural_no_zero|exists[stories.id]',
                        'title' => 'required|min_length[3]|max_length[255]',
                        'content' => 'required|min_length[10]',
                        'status' => 'required|in_list[published,draft]',
                        'chapter_number' => 'required|is_natural_no_zero',
                    ];

                    $messages = [
                        'story_id' => [
                            'required' => 'Truyện không được để trống',
                            'is_natural_no_zero' => 'ID truyện không hợp lệ',
                            'exists' => 'Truyện không tồn tại',
                        ],
                        'title' => [
                            'required' => 'Tiêu đề chương không được để trống',
                            'min_length' => 'Tiêu đề chương phải có ít nhất {param} ký tự',
                            'max_length' => 'Tiêu đề chương không được vượt quá {param} ký tự',
                        ],
                        'content' => [
                            'required' => 'Nội dung chương không được để trống',
                            'min_length' => 'Nội dung chương phải có ít nhất {param} ký tự',
                        ],
                        'status' => [
                            'required' => 'Trạng thái chương không được để trống',
                            'in_list' => 'Trạng thái chương không hợp lệ',
                        ],
                        'chapter_number' => [
                            'required' => 'Số chương không được để trống',
                            'is_natural_no_zero' => 'Số chương phải là số nguyên dương',
                        ],
                    ];
                }
                break;

            case 'user':
                if ($action === 'create') {
                    $rules = [
                        'username' => 'required|min_length[3]|max_length[50]|alpha_numeric_space|is_unique[users.username]',
                        'email' => 'required|valid_email|is_unique[users.email]',
                        'password' => 'required|min_length[8]|max_length[255]',
                        'confirm_password' => 'required|matches[password]',
                        'role' => 'required|in_list[0,1,2,3]',
                    ];

                    $messages = [
                        'username' => [
                            'required' => 'Tên đăng nhập không được để trống',
                            'min_length' => 'Tên đăng nhập phải có ít nhất {param} ký tự',
                            'max_length' => 'Tên đăng nhập không được vượt quá {param} ký tự',
                            'alpha_numeric_space' => 'Tên đăng nhập chỉ được chứa chữ cái, số và khoảng trắng',
                            'is_unique' => 'Tên đăng nhập đã tồn tại, vui lòng chọn tên khác',
                        ],
                        'email' => [
                            'required' => 'Email không được để trống',
                            'valid_email' => 'Email không hợp lệ',
                            'is_unique' => 'Email đã tồn tại, vui lòng chọn email khác',
                        ],
                        'password' => [
                            'required' => 'Mật khẩu không được để trống',
                            'min_length' => 'Mật khẩu phải có ít nhất {param} ký tự',
                            'max_length' => 'Mật khẩu không được vượt quá {param} ký tự',
                        ],
                        'confirm_password' => [
                            'required' => 'Xác nhận mật khẩu không được để trống',
                            'matches' => 'Xác nhận mật khẩu không khớp với mật khẩu',
                        ],
                        'role' => [
                            'required' => 'Vai trò không được để trống',
                            'in_list' => 'Vai trò không hợp lệ',
                        ],
                    ];
                } elseif ($action === 'update') {
                    // Trong trường hợp update, password là tùy chọn
                    $rules = [
                        'username' => 'required|min_length[3]|max_length[50]|alpha_numeric_space|is_unique[users.username,id,{id}]',
                        'email' => 'required|valid_email|is_unique[users.email,id,{id}]',
                        'password' => 'permit_empty|min_length[8]|max_length[255]',
                        'confirm_password' => 'permit_empty|matches[password]',
                        'role' => 'required|in_list[0,1,2,3]',
                    ];

                    $messages = [
                        'username' => [
                            'required' => 'Tên đăng nhập không được để trống',
                            'min_length' => 'Tên đăng nhập phải có ít nhất {param} ký tự',
                            'max_length' => 'Tên đăng nhập không được vượt quá {param} ký tự',
                            'alpha_numeric_space' => 'Tên đăng nhập chỉ được chứa chữ cái, số và khoảng trắng',
                            'is_unique' => 'Tên đăng nhập đã tồn tại, vui lòng chọn tên khác',
                        ],
                        'email' => [
                            'required' => 'Email không được để trống',
                            'valid_email' => 'Email không hợp lệ',
                            'is_unique' => 'Email đã tồn tại, vui lòng chọn email khác',
                        ],
                        'password' => [
                            'min_length' => 'Mật khẩu phải có ít nhất {param} ký tự',
                            'max_length' => 'Mật khẩu không được vượt quá {param} ký tự',
                        ],
                        'confirm_password' => [
                            'matches' => 'Xác nhận mật khẩu không khớp với mật khẩu',
                        ],
                        'role' => [
                            'required' => 'Vai trò không được để trống',
                            'in_list' => 'Vai trò không hợp lệ',
                        ],
                    ];
                }
                break;

            // Thêm quy tắc cho các tài nguyên khác ở đây

            default:
                // Quy tắc mặc định hoặc trả về rỗng
                break;
        }

        return ['rules' => $rules, 'messages' => $messages];
    }
}
