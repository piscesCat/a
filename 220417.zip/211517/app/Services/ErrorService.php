<?php

namespace App\Services;

use CodeIgniter\HTTP\ResponseInterface;
use Psr\Log\LoggerInterface;
use App\Models\LogModel;

/**
 * ErrorService - Xử lý lỗi thống nhất trong toàn bộ ứng dụng
 */
class ErrorService
{
    /**
     * Logger instance
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * Log model for database logging
     * @var LogModel
     */
    protected $logModel;

    /**
     * Request instance
     */
    protected $request;

    /**
     * ResponseInterface
     */
    protected $response;

    /**
     * Current user information
     */
    protected $currentUser;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->logger = \Config\Services::logger();
        $this->request = \Config\Services::request();
        $this->response = \Config\Services::response();
        $this->session = \Config\Services::session();

        // Kiểm tra xem hệ thống đã được cài đặt chưa
        $isInstalled = file_exists(ROOTPATH . 'installed.txt');

        if ($isInstalled) {
            $this->logModel = new LogModel();
            $this->currentUser = $this->session->get('user');
        }
    }

    /**
     * Xử lý lỗi và trả về phản hồi phù hợp
     *
     * @param \Exception|\Error $exception Lỗi cần xử lý
     * @param string $level Mức độ lỗi (error, warning, info, debug)
     * @param array $context Thông tin bổ sung
     * @param bool $isApi Có phải là API request không
     * @param int $statusCode HTTP status code (mặc định: 500)
     * @return mixed Phản hồi (redirect, JSON hoặc view)
     */
    public function handleException($exception, $level = 'error', $context = [], $isApi = false, $statusCode = 500)
    {
        // Lấy thông tin lỗi
        $message = $exception->getMessage();
        $trace = $exception->getTraceAsString();
        $file = $exception->getFile();
        $line = $exception->getLine();

        // Bổ sung thông tin vào context
        $context = array_merge($context, [
            'file' => $file,
            'line' => $line,
            'trace' => $trace,
            'ip' => $this->request->getIPAddress(),
            'uri' => (string) $this->request->getUri(),
            'user_agent' => $this->request->getUserAgent()->getAgentString(),
            'user_id' => $this->currentUser['id'] ?? null,
            'username' => $this->currentUser['username'] ?? 'guest',
            'method' => $this->request->getMethod(),
            'is_ajax' => $this->request->isAJAX(),
        ]);

        // Log lỗi
        $this->logError($message, $level, $context);

        // Xử lý dựa trên loại request
        if ($isApi || $this->request->isAJAX()) {
            return $this->jsonResponse($message, false, $context, $statusCode);
        } else {
            // Lưu thông báo lỗi vào flash data
            $this->session->setFlashdata('error', $this->sanitizeErrorMessage($message));

            // Chuyển hướng về trang trước hoặc trang chủ
            $previousUrl = $this->request->getServer('HTTP_REFERER');
            if (!empty($previousUrl)) {
                return redirect()->to($previousUrl);
            } else {
                return redirect()->to(base_url());
            }
        }
    }

    /**
     * Xử lý lỗi thông thường (không phải exception)
     *
     * @param string $message Thông báo lỗi
     * @param string $level Mức độ lỗi (error, warning, info, debug)
     * @param array $context Thông tin bổ sung
     * @param bool $isApi Có phải là API request không
     * @param int $statusCode HTTP status code (mặc định: 400)
     * @return mixed Phản hồi (redirect, JSON hoặc view)
     */
    public function handleError($message, $level = 'error', $context = [], $isApi = false, $statusCode = 400)
    {
        // Bổ sung thông tin vào context
        $context = array_merge($context, [
            'ip' => $this->request->getIPAddress(),
            'uri' => (string) $this->request->getUri(),
            'user_agent' => $this->request->getUserAgent()->getAgentString(),
            'user_id' => $this->currentUser['id'] ?? null,
            'username' => $this->currentUser['username'] ?? 'guest',
            'method' => $this->request->getMethod(),
            'is_ajax' => $this->request->isAJAX(),
        ]);

        // Log lỗi
        $this->logError($message, $level, $context);

        // Xử lý dựa trên loại request
        if ($isApi || $this->request->isAJAX()) {
            return $this->jsonResponse($message, false, $context, $statusCode);
        } else {
            // Lưu thông báo lỗi vào flash data
            $this->session->setFlashdata('error', $this->sanitizeErrorMessage($message));

            // Chuyển hướng về trang trước hoặc trang chủ
            $previousUrl = $this->request->getServer('HTTP_REFERER');
            if (!empty($previousUrl)) {
                return redirect()->to($previousUrl);
            } else {
                return redirect()->to(base_url());
            }
        }
    }

    /**
     * Xử lý thành công
     *
     * @param string $message Thông báo thành công
     * @param array $data Dữ liệu trả về (cho API)
     * @param bool $isApi Có phải là API request không
     * @return mixed Phản hồi (redirect hoặc JSON)
     */
    public function handleSuccess($message, $data = [], $isApi = false)
    {
        // Xử lý dựa trên loại request
        if ($isApi || $this->request->isAJAX()) {
            return $this->jsonResponse($message, true, $data);
        } else {
            // Lưu thông báo thành công vào flash data
            $this->session->setFlashdata('success', $message);

            // Chuyển hướng về trang trước hoặc trang chủ
            $previousUrl = $this->request->getServer('HTTP_REFERER');
            if (!empty($previousUrl)) {
                return redirect()->to($previousUrl);
            } else {
                return redirect()->to(base_url());
            }
        }
    }

    /**
     * Ghi log lỗi
     *
     * @param string $message Thông báo lỗi
     * @param string $level Mức độ lỗi
     * @param array $context Thông tin bổ sung
     */
    protected function logError($message, $level = 'error', $context = [])
    {
        // Log vào file log
        $this->logger->log($level, $message, $context);

        // Log vào database nếu có LogModel
        if (isset($this->logModel)) {
            switch ($level) {
                case 'error':
                    $this->logModel->error($message, $context);
                    break;
                case 'warning':
                    $this->logModel->warning($message, $context);
                    break;
                case 'info':
                    $this->logModel->info($message, $context);
                    break;
                case 'debug':
                    $this->logModel->debug($message, $context);
                    break;
                default:
                    $this->logModel->info($message, $context);
            }
        }
    }

    /**
     * Tạo phản hồi JSON
     *
     * @param string $message Thông báo
     * @param bool $success Trạng thái thành công
     * @param array $data Dữ liệu bổ sung
     * @param int $statusCode HTTP status code
     * @return ResponseInterface
     */
    protected function jsonResponse($message, $success = true, $data = [], $statusCode = 200)
    {
        $response = [
            'success' => $success,
            'message' => $this->sanitizeErrorMessage($message),
        ];

        // Nếu có dữ liệu, thêm vào phản hồi
        if (!empty($data)) {
            if ($success) {
                $response['data'] = $data;
            } else {
                // Nếu là lỗi, chỉ đưa các thông tin cần thiết vào errors
                $errors = [];
                if (isset($data['validation'])) {
                    $errors['validation'] = $data['validation'];
                }
                if (isset($data['code'])) {
                    $response['code'] = $data['code'];
                }
                if (!empty($errors)) {
                    $response['errors'] = $errors;
                }
            }
        }

        return $this->response->setJSON($response)->setStatusCode($statusCode);
    }

    /**
     * Làm sạch thông báo lỗi để hiển thị cho người dùng
     *
     * @param string $message Thông báo lỗi gốc
     * @return string Thông báo lỗi đã làm sạch
     */
    protected function sanitizeErrorMessage($message)
    {
        // Kiểm tra môi trường
        if (ENVIRONMENT !== 'development') {
            // Trong production, ẩn các thông báo lỗi chi tiết
            if (strpos($message, 'SQL') !== false ||
                strpos($message, 'database') !== false ||
                strpos($message, 'DB') !== false ||
                strpos($message, 'syntax') !== false ||
                strpos($message, 'file') !== false) {
                return 'Đã xảy ra lỗi hệ thống. Vui lòng thử lại sau hoặc liên hệ quản trị viên.';
            }
        }

        // Loại bỏ các thông tin nhạy cảm trong thông báo
        $message = preg_replace('/PASSWORD=[^\s]+/i', 'PASSWORD=*****', $message);
        $message = preg_replace('/password=[^\s&]+/i', 'password=*****', $message);
        $message = preg_replace('/secret=[^\s&]+/i', 'secret=*****', $message);
        $message = preg_replace('/key=[^\s&]+/i', 'key=*****', $message);

        return $message;
    }

    /**
     * Tạo và trả về trang lỗi 404
     *
     * @return mixed
     */
    public function show404()
    {
        // Log lỗi 404
        $this->logError('Page not found: ' . uri_string(), 'warning', [
            'ip' => $this->request->getIPAddress(),
            'uri' => (string) $this->request->getUri(),
            'user_agent' => $this->request->getUserAgent()->getAgentString(),
            'user_id' => $this->currentUser['id'] ?? null,
            'method' => $this->request->getMethod(),
        ]);

        // Nếu là API request, trả về JSON
        if ($this->request->isAJAX() ||
            strpos(uri_string(), 'api/') === 0 ||
            $this->request->getHeaderLine('Accept') === 'application/json') {
            return $this->jsonResponse('Trang không tồn tại', false, [], 404);
        }

        // Hiển thị trang 404
        return view('errors/html/error_404', ['heading' => 'Trang không tồn tại', 'message' => 'Trang bạn đang tìm kiếm không tồn tại hoặc đã bị di chuyển.']);
    }

    /**
     * Tạo và trả về trang lỗi 403
     *
     * @param string $message
     * @return mixed
     */
    public function show403($message = 'Bạn không có quyền truy cập trang này')
    {
        // Log lỗi 403
        $this->logError('Access forbidden: ' . uri_string(), 'warning', [
            'ip' => $this->request->getIPAddress(),
            'uri' => (string) $this->request->getUri(),
            'user_agent' => $this->request->getUserAgent()->getAgentString(),
            'user_id' => $this->currentUser['id'] ?? null,
            'method' => $this->request->getMethod(),
        ]);

        // Nếu là API request, trả về JSON
        if ($this->request->isAJAX() ||
            strpos(uri_string(), 'api/') === 0 ||
            $this->request->getHeaderLine('Accept') === 'application/json') {
            return $this->jsonResponse($message, false, [], 403);
        }

        // Lưu thông báo lỗi vào flash data
        $this->session->setFlashdata('error', $message);

        // Chuyển hướng về trang trước hoặc trang chủ
        $previousUrl = $this->request->getServer('HTTP_REFERER');
        if (!empty($previousUrl)) {
            return redirect()->to($previousUrl);
        } else {
            return redirect()->to(base_url());
        }
    }
}
