<?php

namespace App\Models;

use CodeIgniter\Model;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;

class TokenModel extends Model
{
    protected $table = 'tokens';
    protected $primaryKey = 'id';
    protected $allowedFields = ['user_id', 'token', 'expires_at', 'created_at'];

    protected $returnType = 'array';

    /**
     * Tạo token mới cho người dùng
     *
     * @param int $userId ID người dùng
     * @return string Token được tạo
     */
    public function createToken($userId)
    {
        // Tạo token ngẫu nhiên
        $token = bin2hex(random_bytes(32));

        // Thời gian hết hạn (30 ngày)
        $expiresAt = date('Y-m-d H:i:s', strtotime('+30 days'));

        // Lưu vào database
        $data = [
            'user_id' => $userId,
            'token' => $token,
            'expires_at' => $expiresAt,
            'created_at' => date('Y-m-d H:i:s')
        ];

        $this->insert($data);

        return $token;
    }

    /**
     * Tạo token mới với thời gian hết hạn tùy chỉnh
     *
     * @param int $userId ID người dùng
     * @param int $expiryDays Số ngày token có hiệu lực
     * @return string Token được tạo
     */
    public function createTokenWithExpiry($userId, $expiryDays = 30)
    {
        // Tạo token ngẫu nhiên
        $token = bin2hex(random_bytes(32));

        // Thời gian hết hạn tùy chỉnh
        $expiresAt = date('Y-m-d H:i:s', strtotime("+{$expiryDays} days"));

        // Lưu vào database
        $data = [
            'user_id' => $userId,
            'token' => $token,
            'expires_at' => $expiresAt,
            'created_at' => date('Y-m-d H:i:s')
        ];

        $this->insert($data);

        return $token;
    }

    /**
     * Tạo JWT token dựa trên thông tin user
     *
     * @param array $user Thông tin người dùng
     * @param int $expiryDays Số ngày token có hiệu lực
     * @return string JWT token
     */
    public function createJwtToken($user, $expiryDays = 30)
    {
        $key = $this->getJwtSecretKey();
        $time = time();
        $expire = $time + (86400 * $expiryDays); // 86400 = 1 day

        $payload = [
            'iss' => 'story_app',               // Issuer
            'aud' => 'story_app_api_users',     // Audience
            'iat' => $time,                     // Issued at time
            'nbf' => $time,                     // Not before time
            'exp' => $expire,                   // Expiration time
            'sub' => $user['id'],               // Subject (user ID)
            'uid' => $user['id'],               // User ID
            'uname' => $user['username'],       // Username
            'role' => $user['role'],            // User role
            'jti' => bin2hex(random_bytes(16))  // JWT ID - unique for each token
        ];

        $jwt = JWT::encode($payload, $key, 'HS256');

        // Save token reference to database for revocation capability
        $data = [
            'user_id' => $user['id'],
            'token' => hash('sha256', $jwt), // Save hash of JWT for security
            'expires_at' => date('Y-m-d H:i:s', $expire),
            'created_at' => date('Y-m-d H:i:s')
        ];

        $this->insert($data);

        return $jwt;
    }

    /**
     * Xác thực JWT token
     *
     * @param string $jwt JWT token to verify
     * @return array|null User data if valid, null if invalid
     */
    public function verifyJwtToken($jwt)
    {
        $key = $this->getJwtSecretKey();

        try {
            // Decode JWT
            $decoded = JWT::decode($jwt, new Key($key, 'HS256'));

            // Check if token exists in database and not revoked
            $hashedToken = hash('sha256', $jwt);
            $tokenExists = $this->where('token', $hashedToken)
                               ->where('expires_at >', date('Y-m-d H:i:s'))
                               ->first();

            if (!$tokenExists) {
                return null; // Token revoked or expired
            }

            // Get user data
            $userModel = new UserModel();
            $user = $userModel->find($decoded->uid);

            if (!$user) {
                return null;
            }

            return $user;
        } catch (\Exception $e) {
            // Token is invalid
            log_message('error', 'JWT validation error: ' . $e->getMessage());
            return null;
        }
    }

    /**
     * Lấy thông tin người dùng từ token
     *
     * @param string $token Token chuỗi
     * @return array|null Thông tin người dùng hoặc null nếu không tìm thấy
     */
    public function getUserFromToken($token)
    {
        // Tìm token trong database
        $tokenData = $this->where('token', $token)
                         ->where('expires_at >', date('Y-m-d H:i:s'))
                         ->first();

        if (!$tokenData) {
            return null;
        }

        // Lấy thông tin người dùng
        $userModel = new UserModel();
        $user = $userModel->find($tokenData['user_id']);

        if (!$user) {
            return null;
        }

        return $user;
    }

    /**
     * Xóa token
     *
     * @param string $token Token cần xóa
     * @return bool Kết quả xóa
     */
    public function deleteToken($token)
    {
        return $this->where('token', $token)->delete();
    }

    /**
     * Xóa tất cả token của người dùng
     *
     * @param int $userId ID người dùng
     * @return bool Kết quả xóa
     */
    public function deleteUserTokens($userId)
    {
        return $this->where('user_id', $userId)->delete();
    }

    /**
     * Xóa token hết hạn
     *
     * @return bool Kết quả xóa
     */
    public function deleteExpiredTokens()
    {
        return $this->where('expires_at <', date('Y-m-d H:i:s'))->delete();
    }

    /**
     * Get all tokens with user information
     */
    public function getTokensWithUsers()
    {
        $db = \Config\Database::connect();
        $tokens = $db->table('tokens')
                    ->select('tokens.*, users.username, users.email, users.role')
                    ->join('users', 'users.id = tokens.user_id')
                    ->orderBy('tokens.created_at', 'DESC')
                    ->get()
                    ->getResultArray();

        // Format tokens for display
        foreach ($tokens as &$token) {
            // Format dates for display
            $token['created_at_formatted'] = date('d/m/Y H:i', strtotime($token['created_at']));
            $token['expires_at_formatted'] = date('d/m/Y H:i', strtotime($token['expires_at']));

            // Role text
            switch($token['role']) {
                case 3:
                    $token['role_text'] = 'Người sáng lập';
                    $token['role_color'] = 'danger';
                    break;
                case 2:
                    $token['role_text'] = 'Admin';
                    $token['role_color'] = 'warning';
                    break;
                case 1:
                    $token['role_text'] = 'Cộng tác viên';
                    $token['role_color'] = 'success';
                    break;
                default:
                    $token['role_text'] = 'Thành viên';
                    $token['role_color'] = 'secondary';
            }

            // Display only first 10 characters of token for security
            $token['token_preview'] = substr($token['token'], 0, 10) . '...';

            // Check if token is expired
            $token['is_expired'] = strtotime($token['expires_at']) < time();
        }

        return $tokens;
    }

    /**
     * Get tokens for a specific user
     */
    public function getTokensByUserId($userId)
    {
        return $this->where('user_id', $userId)
                    ->orderBy('created_at', 'DESC')
                    ->findAll();
    }

    /**
     * Verify if a token is valid
     */
    public function verifyToken($token)
    {
        $tokenData = $this->where('token', $token)
                          ->where('expires_at >', date('Y-m-d H:i:s'))
                          ->first();

        return $tokenData ?: false;
    }

    /**
     * Get JWT secret key from environment
     *
     * @return string JWT secret key
     * @throws \RuntimeException If JWT secret key is not set in production
     */
    private function getJwtSecretKey()
    {
        // In production, throw an exception if the key is not set
        if (ENVIRONMENT === 'production' && empty($_ENV['JWT_SECRET_KEY'])) {
            throw new \RuntimeException('JWT_SECRET_KEY is not set in production environment');
        }

        // Get the key from environment or use default only for non-production
        $key = $_ENV['JWT_SECRET_KEY'] ?? null;

        // If key is not set, generate a warning and use a fallback only in development
        if (empty($key)) {
            log_message('warning', 'JWT_SECRET_KEY is not set. Using default key is HIGHLY DISCOURAGED.');
            return 'development-jwt-key-' . md5(__FILE__); // Generate a somewhat unique key
        }

        return $key;
    }
}
