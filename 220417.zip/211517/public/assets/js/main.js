// Chức năng chuyển đổi Theme
document.addEventListener('DOMContentLoaded', function() {
    // Kiểm tra theme từ localStorage
    const currentTheme = localStorage.getItem('theme');
    if (currentTheme) {
        document.documentElement.setAttribute('data-theme', currentTheme);
    }

    // Xử lý sự kiện click vào nút chuyển đổi
    const themeToggle = document.getElementById('theme-toggle');
    if (themeToggle) {
        themeToggle.addEventListener('click', function() {
            // Lấy theme hiện tại
            const currentTheme = document.documentElement.getAttribute('data-theme');

            // Chuyển đổi theme
            let targetTheme = 'dark';
            if (currentTheme !== 'light') {
                targetTheme = 'light';
            }

            // Áp dụng theme mới
            document.documentElement.setAttribute('data-theme', targetTheme);

            // Lưu theme vào localStorage
            localStorage.setItem('theme', targetTheme);
        });
    }
});

// Gợi ý tìm kiếm
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('search-input');
    const suggestionsContainer = document.getElementById('search-suggestions');

    if (!searchInput || !suggestionsContainer) return;

    let debounceTimer;

    searchInput.addEventListener('input', function() {
        clearTimeout(debounceTimer);

        const query = this.value.trim();

        if (query.length < 2) {
            suggestionsContainer.style.display = 'none';
            return;
        }

        debounceTimer = setTimeout(function() {
            fetch(`${baseUrl}/search/suggestions?q=${encodeURIComponent(query)}`)
                .then(response => response.json())
                .then(data => {
                    if (data.suggestions && data.suggestions.length > 0) {
                        suggestionsContainer.innerHTML = '';

                        data.suggestions.forEach(suggestion => {
                            const item = document.createElement('div');
                            item.className = 'suggestion-item';

                            const link = document.createElement('a');
                            link.href = `${baseUrl}/truyen/${suggestion.slug}`;
                            link.textContent = suggestion.title;

                            item.appendChild(link);
                            suggestionsContainer.appendChild(item);
                        });

                        suggestionsContainer.style.display = 'block';
                    } else {
                        suggestionsContainer.style.display = 'none';
                    }
                })
                .catch(error => {
                    console.error('Lỗi khi tải gợi ý:', error);
                    suggestionsContainer.style.display = 'none';
                });
        }, 300);
    });

    // Ẩn gợi ý khi click bên ngoài
    document.addEventListener('click', function(event) {
        if (!searchInput.contains(event.target) && !suggestionsContainer.contains(event.target)) {
            suggestionsContainer.style.display = 'none';
        }
    });

    // Hiển thị gợi ý khi input được focus
    searchInput.addEventListener('focus', function() {
        if (this.value.trim().length >= 2) {
            suggestionsContainer.style.display = 'block';
        }
    });
});

// Thông báo Toast
function showToast(message, type = 'info') {
    // Tạo container cho toast nếu chưa tồn tại
    let toastContainer = document.getElementById('toast-container');
    if (!toastContainer) {
        toastContainer = document.createElement('div');
        toastContainer.id = 'toast-container';
        toastContainer.className = 'toast-container position-fixed bottom-0 end-0 p-3';
        document.body.appendChild(toastContainer);
    }

    // Tạo ID duy nhất cho toast
    const toastId = 'toast-' + Date.now();

    // Xác định màu nền dựa trên loại thông báo
    let bgColor = 'bg-info';
    if (type === 'success') bgColor = 'bg-success';
    if (type === 'error') bgColor = 'bg-danger';
    if (type === 'warning') bgColor = 'bg-warning';

    // Tạo HTML cho toast
    const toastHtml = `
        <div id="${toastId}" class="toast align-items-center ${bgColor} text-white border-0" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="d-flex">
                <div class="toast-body">
                    ${message}
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
        </div>
    `;

    // Thêm toast vào container
    toastContainer.insertAdjacentHTML('beforeend', toastHtml);

    // Khởi tạo và hiển thị toast
    const toastElement = document.getElementById(toastId);
    const toast = new bootstrap.Toast(toastElement, { autohide: true, delay: 3000 });
    toast.show();

    // Xóa toast sau khi nó bị ẩn
    toastElement.addEventListener('hidden.bs.toast', function() {
        toastElement.remove();
    });
}

/**
 * Hiển thị cảnh báo khi localStorage gần đầy
 * @param {string} currentSize Kích thước hiện tại (MB)
 */
window.showStorageWarning = function(currentSize) {
    // Tạo thông báo modal
    const modal = document.createElement('div');
    modal.className = 'storage-warning-modal';
    modal.style.position = 'fixed';
    modal.style.top = '0';
    modal.style.left = '0';
    modal.style.width = '100%';
    modal.style.height = '100%';
    modal.style.backgroundColor = 'rgba(0,0,0,0.7)';
    modal.style.zIndex = '9999';
    modal.style.display = 'flex';
    modal.style.alignItems = 'center';
    modal.style.justifyContent = 'center';

    // Nội dung modal
    const content = document.createElement('div');
    content.style.backgroundColor = '#fff';
    content.style.borderRadius = '8px';
    content.style.padding = '20px';
    content.style.maxWidth = '500px';
    content.style.width = '80%';
    content.style.color = '#333';

    // Tiêu đề
    const title = document.createElement('h3');
    title.textContent = 'Cảnh báo: Bộ nhớ gần đầy';
    title.style.margin = '0 0 15px 0';
    title.style.color = '#e74c3c';

    // Nội dung
    const message = document.createElement('p');
    message.innerHTML = `Bộ nhớ lưu trữ bookmark hiện tại: <b>${currentSize}MB</b>.<br>
                        Nếu tiếp tục thêm nhiều bookmark, dữ liệu có thể sẽ bị mất.<br>
                        Vui lòng chọn một trong các tùy chọn sau:`;
    message.style.lineHeight = '1.6';

    // Tạo container cho các nút
    const buttonContainer = document.createElement('div');
    buttonContainer.style.marginTop = '20px';
    buttonContainer.style.display = 'flex';
    buttonContainer.style.justifyContent = 'space-between';
    buttonContainer.style.flexWrap = 'wrap';
    buttonContainer.style.gap = '10px';

    // Nút xóa bookmark cũ
    const deleteButton = document.createElement('button');
    deleteButton.textContent = 'Xóa bookmark cũ';
    deleteButton.style.padding = '10px 15px';
    deleteButton.style.backgroundColor = '#e74c3c';
    deleteButton.style.color = 'white';
    deleteButton.style.border = 'none';
    deleteButton.style.borderRadius = '4px';
    deleteButton.style.cursor = 'pointer';
    deleteButton.onclick = function() {
        ClientBookmark.enforceStorageLimits(true);
        modal.remove();
        showToast('Đã xóa các bookmark cũ', 'success');
    };

    // Nút xuất bookmark
    const exportButton = document.createElement('button');
    exportButton.textContent = 'Xuất bookmark ra file';
    exportButton.style.padding = '10px 15px';
    exportButton.style.backgroundColor = '#3498db';
    exportButton.style.color = 'white';
    exportButton.style.border = 'none';
    exportButton.style.borderRadius = '4px';
    exportButton.style.cursor = 'pointer';
    exportButton.onclick = function() {
        ClientBookmark.exportBookmarks();
        modal.remove();
    };

    // Nút đóng
    const closeButton = document.createElement('button');
    closeButton.textContent = 'Đóng';
    closeButton.style.padding = '10px 15px';
    closeButton.style.backgroundColor = '#7f8c8d';
    closeButton.style.color = 'white';
    closeButton.style.border = 'none';
    closeButton.style.borderRadius = '4px';
    closeButton.style.cursor = 'pointer';
    closeButton.onclick = function() {
        modal.remove();
    };

    // Thêm các phần tử vào modal
    buttonContainer.appendChild(deleteButton);
    buttonContainer.appendChild(exportButton);
    buttonContainer.appendChild(closeButton);

    content.appendChild(title);
    content.appendChild(message);
    content.appendChild(buttonContainer);
    modal.appendChild(content);

    // Thêm vào body
    document.body.appendChild(modal);
};

// Alias for compatibility with client-bookmark.js
window.showNotification = showToast;

// Xử lý gửi bình luận
document.addEventListener('DOMContentLoaded', function() {
    const storyCommentForm = document.getElementById('story-comment-form');
    const chapterCommentForm = document.getElementById('chapter-comment-form');

    if (storyCommentForm) {
        storyCommentForm.addEventListener('submit', function(e) {
            e.preventDefault();
            submitComment(this, 'story');
        });
    }

    if (chapterCommentForm) {
        chapterCommentForm.addEventListener('submit', function(e) {
            e.preventDefault();
            submitComment(this, 'chapter');
        });
    }

    // Các nút xóa bình luận
    document.querySelectorAll('.delete-comment').forEach(button => {
        button.addEventListener('click', function() {
            const commentId = this.getAttribute('data-id');
            if (confirm('Bạn có chắc chắn muốn xóa bình luận này?')) {
                deleteComment(commentId);
            }
        });
    });

    // Nút tải thêm bình luận
    const loadMoreBtn = document.getElementById('load-more-comments');
    if (loadMoreBtn) {
        loadMoreBtn.addEventListener('click', function() {
            const storyId = this.getAttribute('data-story-id');
            const chapterId = this.getAttribute('data-chapter-id');
            const offset = parseInt(this.getAttribute('data-offset'), 10);

            loadMoreComments(storyId, chapterId, offset);
        });
    }
});

// Xử lý tính lượt xem theo thời gian dừng lại ở trang
document.addEventListener('DOMContentLoaded', function() {
    // Kiểm tra xem đang ở trang chương hay trang truyện
    const chapterViewElement = document.getElementById('chapter-view-container');
    const storyViewElement = document.getElementById('story-view-container');

    // Biến theo dõi thời gian
    let viewTimer = null;
    let viewStartTime = null;
    let viewSent = false;

    // Hàm gửi lượt xem cho chương
    function sendChapterView(chapterId, storyId, duration) {
        if (viewSent) return; // Đảm bảo chỉ gửi một lần

        fetch(`${baseUrl}/api/chapter/view`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Requested-With': 'XMLHttpRequest',
                'X-CSRF-TOKEN': csrfToken
            },
            body: `chapterId=${chapterId}&storyId=${storyId}&viewDuration=${duration}&csrf_token_name=${csrfToken}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                console.log('Đã tính lượt xem cho chương');
            }
            viewSent = true;
        })
        .catch(error => {
            console.error('Lỗi khi gửi lượt xem:', error);
        });
    }

    // Hàm gửi lượt xem cho truyện
    function sendStoryView(storyId, duration) {
        if (viewSent) return; // Đảm bảo chỉ gửi một lần

        fetch(`${baseUrl}/api/story/view`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Requested-With': 'XMLHttpRequest',
                'X-CSRF-TOKEN': csrfToken
            },
            body: `storyId=${storyId}&viewDuration=${duration}&csrf_token_name=${csrfToken}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                console.log('Đã tính lượt xem cho truyện');
            }
            viewSent = true;
        })
        .catch(error => {
            console.error('Lỗi khi gửi lượt xem:', error);
        });
    }

    // Nếu đang ở trang chương
    if (chapterViewElement) {
        const chapterId = chapterViewElement.getAttribute('data-chapter-id');
        const storyId = chapterViewElement.getAttribute('data-story-id');

        if (chapterId && storyId) {
            // Bắt đầu tính thời gian
            viewStartTime = Date.now();

            // Sau 5 giây, gửi request để tăng lượt xem
            viewTimer = setTimeout(() => {
                const duration = Math.floor((Date.now() - viewStartTime) / 1000);
                sendChapterView(chapterId, storyId, duration);
            }, 5000);

            // Thêm sự kiện để đảm bảo vẫn tính lượt xem khi người dùng rời trang
            window.addEventListener('beforeunload', function() {
                if (!viewSent && viewStartTime) {
                    const duration = Math.floor((Date.now() - viewStartTime) / 1000);
                    if (duration >= 5) {
                        sendChapterView(chapterId, storyId, duration);
                    }
                }
            });
        }
    }

    // Nếu đang ở trang truyện
    else if (storyViewElement) {
        const storyId = storyViewElement.getAttribute('data-story-id');

        if (storyId) {
            // Bắt đầu tính thời gian
            viewStartTime = Date.now();

            // Sau 5 giây, gửi request để tăng lượt xem
            viewTimer = setTimeout(() => {
                const duration = Math.floor((Date.now() - viewStartTime) / 1000);
                sendStoryView(storyId, duration);
            }, 5000);

            // Thêm sự kiện để đảm bảo vẫn tính lượt xem khi người dùng rời trang
            window.addEventListener('beforeunload', function() {
                if (!viewSent && viewStartTime) {
                    const duration = Math.floor((Date.now() - viewStartTime) / 1000);
                    if (duration >= 5) {
                        sendStoryView(storyId, duration);
                    }
                }
            });
        }
    }
});
