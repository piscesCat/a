<?php

namespace Config;

use CodeIgniter\Cache\CacheInterface;
use CodeIgniter\Config\BaseConfig;

class Cache extends BaseConfig
{
    /**
     * Phương thức lưu trữ cache mặc định
     * Các tùy chọn: file, redis, memcached
     *
     * @var string
     */
    public $handler = 'file';

    /**
     * Biến dự phòng khi phương thức chính không khả dụng
     *
     * @var string
     */
    public $backupHandler = 'dummy';

    /**
     * Thời gian cache mặc định
     *
     * @var integer
     */
    public $ttl = 60;

    /**
     * Thư mục lưu trữ file cache
     *
     * @var string
     */
    public $file = [
        'storePath' => WRITEPATH . 'cache/',
        'dirLevel'  => 1,
    ];

    /**
     * Cấu hình cho Redis
     *
     * @var array
     */
    public $redis = [
        'host'     => '127.0.0.1',
        'password' => null,
        'port'     => 6379,
        'timeout'  => 0,
        'database' => 0,
    ];

    /**
     * Cấu hình cho Memcached
     *
     * @var array
     */
    public $memcached = [
        'host'   => '127.0.0.1',
        'port'   => 11211,
        'weight' => 1,
        'raw'    => false,
    ];

    /**
     * Sử dụng cấu hình từ biến môi trường nếu có
     */
    public function __construct()
    {
        parent::__construct();

        // Cấu hình handler
        $this->handler = $_ENV['CACHE_DRIVER'] ?? $this->handler;

        // Nếu Redis được cấu hình trong biến môi trường, sử dụng nó
        if (isset($_ENV['REDIS_HOST'])) {
            $this->redis['host'] = $_ENV['REDIS_HOST'];
            $this->redis['port'] = $_ENV['REDIS_PORT'] ?? 6379;
            $this->redis['password'] = $_ENV['REDIS_PASSWORD'] ?? null;
            $this->redis['database'] = $_ENV['REDIS_DB'] ?? 0;

            // Kiểm tra xem Redis có khả dụng không
            if ($this->handler === 'redis' && $this->isRedisAvailable()) {
                $this->handler = 'redis';
            } else if ($this->handler === 'redis') {
                // Nếu Redis không khả dụng nhưng được chọn, quay lại file
                $this->handler = 'file';
            }
        }

        // Nếu Memcached được cấu hình trong biến môi trường, sử dụng nó
        if (isset($_ENV['MEMCACHED_HOST'])) {
            $this->memcached['host'] = $_ENV['MEMCACHED_HOST'];
            $this->memcached['port'] = $_ENV['MEMCACHED_PORT'] ?? 11211;
        }

        // Cấu hình TTL từ biến môi trường
        if (isset($_ENV['CACHE_TTL'])) {
            $this->ttl = (int)$_ENV['CACHE_TTL'];
        }
    }

    /**
     * Kiểm tra xem Redis có khả dụng không
     *
     * @return bool
     */
    private function isRedisAvailable(): bool
    {
        if (!extension_loaded('redis')) {
            return false;
        }

        try {
            $redis = new \Redis();
            $connected = $redis->connect(
                $this->redis['host'],
                $this->redis['port'],
                $this->redis['timeout']
            );

            if (!$connected) {
                return false;
            }

            if ($this->redis['password'] !== null) {
                $redis->auth($this->redis['password']);
            }

            $redis->select($this->redis['database']);
            $redis->ping();
            $redis->close();

            return true;
        } catch (\Exception $e) {
            log_message('error', 'Redis connection failed: ' . $e->getMessage());
            return false;
        }
    }
}
