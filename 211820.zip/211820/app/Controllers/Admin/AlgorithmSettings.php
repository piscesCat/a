<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\SettingsModel;
use App\Models\LogModel;

class AlgorithmSettings extends BaseController
{
    protected $settingsModel;
    protected $logModel;

    public function __construct()
    {
        $this->settingsModel = new SettingsModel();
        $this->logModel = new LogModel();
    }

    /**
     * Hiển thị trang cài đặt thuật toán
     */
    public function index()
    {
        $data = [
            'title' => 'Cài đặt thuật toán',
            'settings' => $this->getAllAlgorithmSettings()
        ];

        // Lấy danh sách thuật toán
        return view('admin/algorithm/index.html', $data);
    }

    /**
     * Cập nhật các cài đặt thuật toán
     */
    public function save()
    {
        if (!$this->request->isAJAX()) {
            return redirect()->to('/admin/algorithm');
        }

        $settingsData = $this->request->getPost('settings');
        $changedCount = 0;

        if (!empty($settingsData) && is_array($settingsData)) {
            foreach ($settingsData as $key => $value) {
                // Đảm bảo key hợp lệ (chỉ cập nhật các cài đặt thuật toán)
                if (strpos($key, 'algorithm_') === 0) {
                    $this->settingsModel->updateSetting($key, $value);
                    $changedCount++;
                }
            }

            // Ghi log
            $this->logModel->info('Cập nhật cài đặt thuật toán', [
                'user_id' => session()->get('user_id'),
                'changed_count' => $changedCount,
                'settings' => array_keys($settingsData)
            ]);

            return $this->response->setJSON([
                'success' => true,
                'message' => "Đã cập nhật $changedCount cài đặt thuật toán"
            ]);
        }

        return $this->response->setJSON([
            'success' => false,
            'message' => 'Không có dữ liệu cài đặt được gửi'
        ]);
    }

    /**
     * Thực thi một thuật toán ngay lập tức
     */
    public function execute()
    {
        if (!$this->request->isAJAX()) {
            return redirect()->to('/admin/algorithm');
        }

        $algorithm = $this->request->getPost('algorithm');
        $results = null;
        $success = false;
        $message = '';

        // Kiểm tra thuật toán đã chọn và thực thi
        switch ($algorithm) {
            case 'update_hot':
                // Thực thi thuật toán HOT
                $storyModel = new \App\Models\StoryModel();
                $minDailyViews = (int)$this->settingsModel->getSetting('algorithm_hot_min_daily_views', 100);
                $growthRate = (float)$this->settingsModel->getSetting('algorithm_hot_growth_rate', 30);
                $minNewRatings = (int)$this->settingsModel->getSetting('algorithm_hot_min_new_ratings', 10);
                $cooldownDays = (int)$this->settingsModel->getSetting('algorithm_hot_cooldown_days', 3);

                $result = $storyModel->updateHotStories($minDailyViews, $growthRate, $minNewRatings, $cooldownDays);
                $success = (bool)$result;
                $message = $success ? 'Đã cập nhật trạng thái HOT cho truyện thành công' : 'Cập nhật trạng thái HOT thất bại';
                break;

            case 'suggest_featured':
                // Thực thi thuật toán đề xuất truyện nổi bật
                $storyModel = new \App\Models\StoryModel();
                $limit = (int)$this->settingsModel->getSetting('algorithm_featured_limit', 10);
                $minRating = (float)$this->settingsModel->getSetting('algorithm_featured_min_rating', 4.0);
                $minViews = (int)$this->settingsModel->getSetting('algorithm_featured_min_views', 500);

                $options = [
                    'min_rating' => $minRating,
                    'min_views' => $minViews,
                    'new_story_days' => (int)$this->settingsModel->getSetting('algorithm_featured_new_story_days', 30),
                    'view_weight' => (float)$this->settingsModel->getSetting('algorithm_featured_view_weight', 0.3),
                    'rating_weight' => (float)$this->settingsModel->getSetting('algorithm_featured_rating_weight', 0.4),
                    'comment_weight' => (float)$this->settingsModel->getSetting('algorithm_featured_comment_weight', 0.2),
                    'recency_weight' => (float)$this->settingsModel->getSetting('algorithm_featured_recency_weight', 0.1),
                    'min_categories_diversity' => (int)$this->settingsModel->getSetting('algorithm_featured_min_categories_diversity', 5)
                ];

                $results = $storyModel->suggestFeaturedStories($limit, $options);
                $success = !empty($results);
                $message = $success ? 'Đã đề xuất ' . count($results) . ' truyện nổi bật' : 'Không tìm thấy truyện để đề xuất';
                break;

            case 'update_recommended':
                // Thực thi thuật toán cập nhật truyện đề xuất
                $storyModel = new \App\Models\StoryModel();
                $limit = (int)$this->settingsModel->getSetting('algorithm_recommended_limit', 20);
                $minRating = (float)$this->settingsModel->getSetting('algorithm_recommended_min_rating', 3.5);

                $options = [
                    'min_rating' => $minRating,
                    'min_rating_count' => (int)$this->settingsModel->getSetting('algorithm_recommended_min_rating_count', 5),
                    'recent_days' => (int)$this->settingsModel->getSetting('algorithm_recommended_recent_days', 30),
                    'max_per_category' => (int)$this->settingsModel->getSetting('algorithm_recommended_max_per_category', 3),
                    'refresh_rate' => (int)$this->settingsModel->getSetting('algorithm_recommended_refresh_rate', 50)
                ];

                $result = $storyModel->updateRecommendedStories($limit, $options);
                $success = (bool)$result;
                $message = $success ? 'Đã cập nhật truyện đề xuất thành công' : 'Cập nhật truyện đề xuất thất bại';
                break;

            case 'update_story_status':
                // Thực thi thuật toán cập nhật trạng thái truyện
                $storyModel = new \App\Models\StoryModel();

                $options = [
                    'min_chapters_for_publish' => (int)$this->settingsModel->getSetting('algorithm_status_min_chapters', 3),
                    'inactive_days_for_complete' => (int)$this->settingsModel->getSetting('algorithm_status_inactive_days', 90),
                    'require_admin_approval' => (bool)$this->settingsModel->getSetting('algorithm_status_require_approval', true)
                ];

                $result = $storyModel->updateStoryStatus($options);
                $success = true; // Hàm luôn trả về một mảng thống kê
                $results = $result;
                $message = 'Đã cập nhật trạng thái ' . $result['total_updated'] . ' truyện';
                break;

            case 'reset_views':
                // Reset lượt xem theo kỳ (ngày/tuần/tháng)
                $storyModel = new \App\Models\StoryModel();
                $period = $this->request->getPost('period');

                switch ($period) {
                    case 'daily':
                        $result = $storyModel->resetDailyViews();
                        $message = 'Đã reset lượt xem theo ngày';
                        break;
                    case 'weekly':
                        $result = $storyModel->resetWeeklyViews();
                        $message = 'Đã reset lượt xem theo tuần';
                        break;
                    case 'monthly':
                        $result = $storyModel->resetMonthlyViews();
                        $message = 'Đã reset lượt xem theo tháng';
                        break;
                    default:
                        $result = false;
                        $message = 'Không xác định được kỳ reset lượt xem';
                }

                $success = (bool)$result;
                break;

            default:
                $message = 'Thuật toán không hợp lệ';
                $success = false;
        }

        // Ghi log
        $this->logModel->info('Thực thi thủ công thuật toán: ' . $algorithm, [
            'user_id' => session()->get('user_id'),
            'success' => $success,
            'algorithm' => $algorithm,
            'results' => $results
        ]);

        return $this->response->setJSON([
            'success' => $success,
            'message' => $message,
            'results' => $results
        ]);
    }

    /**
     * Lấy tất cả cài đặt liên quan đến thuật toán
     */
    private function getAllAlgorithmSettings()
    {
        // Cài đặt mặc định nếu chưa có
        $defaults = [
            // Thuật toán HOT
            'algorithm_hot_min_daily_views' => 100,
            'algorithm_hot_growth_rate' => 30,
            'algorithm_hot_min_new_ratings' => 10,
            'algorithm_hot_cooldown_days' => 3,

            // Thuật toán FEATURED
            'algorithm_featured_limit' => 10,
            'algorithm_featured_min_rating' => 4.0,
            'algorithm_featured_min_views' => 500,
            'algorithm_featured_new_story_days' => 30,
            'algorithm_featured_view_weight' => 0.3,
            'algorithm_featured_rating_weight' => 0.4,
            'algorithm_featured_comment_weight' => 0.2,
            'algorithm_featured_recency_weight' => 0.1,
            'algorithm_featured_min_categories_diversity' => 5,
            'algorithm_featured_exclude_current' => true,

            // Thuật toán RECOMMENDED
            'algorithm_recommended_limit' => 20,
            'algorithm_recommended_min_rating' => 3.5,
            'algorithm_recommended_min_rating_count' => 5,
            'algorithm_recommended_recent_days' => 30,
            'algorithm_recommended_max_per_category' => 3,
            'algorithm_recommended_refresh_rate' => 50,

            // Thuật toán STATUS
            'algorithm_status_min_chapters' => 3,
            'algorithm_status_inactive_days' => 90,
            'algorithm_status_require_approval' => true,

            // Cấu hình cronjob
            'algorithm_cron_daily_time' => '00:05',
            'algorithm_cron_weekly_day' => 1,
            'algorithm_cron_monthly_day' => 1,
            'algorithm_websocket_enabled' => false
        ];

        // Lấy các cài đặt hiện tại
        $settings = [];
        foreach ($defaults as $key => $defaultValue) {
            $settings[$key] = $this->settingsModel->getSetting($key, $defaultValue);
        }

        return $settings;
    }
}
