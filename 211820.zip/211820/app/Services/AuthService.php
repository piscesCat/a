<?php

namespace App\Services;

use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

class AuthService
{
    protected $tokenModel;
    protected $userModel;
    protected $session;
    protected $request;
    protected $response;

    public function __construct()
    {
        $this->tokenModel = new \App\Models\TokenModel();
        $this->userModel = new \App\Models\UserModel();
        $this->session = session();
        $this->request = service('request');
        $this->response = service('response');
    }

    /**
     * Kiểm tra người dùng đã đăng nhập chưa
     *
     * @return bool
     */
    public function isLoggedIn()
    {
        return (bool)$this->session->get('isLoggedIn');
    }

    /**
     * Kiểm tra người dùng có phải admin không (role >= 2)
     *
     * @return bool
     */
    public function isAdmin()
    {
        if (!$this->isLoggedIn()) {
            return false;
        }

        $user = $this->session->get('user');
        return isset($user['role']) && $user['role'] >= 2;
    }

    /**
     * Kiểm tra người dùng có phải người sáng lập không (role = 3)
     *
     * @return bool
     */
    public function isFounder()
    {
        if (!$this->isLoggedIn()) {
            return false;
        }

        $user = $this->session->get('user');
        return isset($user['role']) && $user['role'] == 3;
    }

    /**
     * Kiểm tra người dùng có phải cộng tác viên không (role >= 1)
     *
     * @return bool
     */
    public function isContributor()
    {
        if (!$this->isLoggedIn()) {
            return false;
        }

        $user = $this->session->get('user');
        return isset($user['role']) && $user['role'] >= 1;
    }

    /**
     * Kiểm tra quyền truy cập
     *
     * @param array|null $user Thông tin người dùng
     * @param int $requiredRole Vai trò tối thiểu được yêu cầu
     * @return bool True nếu người dùng có quyền
     */
    public function hasPermission($user, $requiredRole)
    {
        if (!$user) {
            return false;
        }

        return $user['role'] >= $requiredRole;
    }

    /**
     * Kiểm tra quyền API và trả về JSON response phù hợp nếu không có quyền
     *
     * @param RequestInterface $request Request object
     * @param int $requiredRole Role tối thiểu cần có (0: user, 1: contributor, 2: admin, 3: founder)
     * @return array|ResponseInterface Thông tin user nếu có quyền, Response JSON nếu không
     */
    public function checkApiPermission(RequestInterface $request = null, int $requiredRole = 0)
    {
        $request = $request ?? $this->request;
        $user = $this->verifyApiToken($request);

        if (!$user) {
            return $this->response->setStatusCode(401)->setJSON([
                'success' => false,
                'message' => 'Không có quyền truy cập'
            ]);
        }

        if ($requiredRole > 0 && $user['role'] < $requiredRole) {
            return $this->response->setStatusCode(403)->setJSON([
                'success' => false,
                'message' => 'Bạn không có quyền thực hiện chức năng này'
            ]);
        }

        return $user;
    }

    /**
     * Kiểm tra xác thực qua session
     *
     * @return array|null User info hoặc null nếu không có session
     */
    public function checkSessionAuth()
    {
        $user = $this->session->get('user');
        if (!$user) {
            return null;
        }

        // Kiểm tra xem người dùng còn tồn tại và active không
        $currentUser = $this->userModel->find($user['id']);
        if (!$currentUser || $currentUser['status'] !== 'active') {
            $this->session->remove('user');
            return null;
        }

        return $user;
    }

    /**
     * Kiểm tra xác thực qua API token
     *
     * @param string $authHeader Chuỗi Authorization header
     * @return array|null User info hoặc null nếu token không hợp lệ
     */
    public function checkTokenAuth($authHeader)
    {
        if (empty($authHeader) || !preg_match('/Bearer\\s+(.*)$/i', $authHeader, $matches)) {
            return null;
        }

        $token = $matches[1];
        $user = $this->tokenModel->getUserFromToken($token);

        // Kiểm tra xem người dùng còn tồn tại và active không
        if ($user && $user['status'] === 'active') {
            return $user;
        }

        return null;
    }

    /**
     * Đăng nhập người dùng và lưu session
     *
     * @param string $username Username hoặc email
     * @param string $password Mật khẩu
     * @return array Mảng với kết quả đăng nhập
     */
    public function login($username, $password)
    {
        // Kiểm tra đầu vào
        if (empty($username) || empty($password)) {
            return [
                'success' => false,
                'message' => 'Vui lòng nhập tên đăng nhập và mật khẩu'
            ];
        }

        // Tìm người dùng theo username hoặc email
        $user = $this->userModel->where('username', $username)
                              ->orWhere('email', $username)
                              ->first();

        // Kiểm tra người dùng tồn tại
        if (!$user) {
            return [
                'success' => false,
                'message' => 'Tên đăng nhập hoặc mật khẩu không đúng'
            ];
        }

        // Kiểm tra trạng thái người dùng
        if ($user['status'] !== 'active') {
            return [
                'success' => false,
                'message' => 'Tài khoản của bạn đã bị khóa hoặc chưa kích hoạt'
            ];
        }

        // Kiểm tra mật khẩu
        if (!password_verify($password, $user['password'])) {
            return [
                'success' => false,
                'message' => 'Tên đăng nhập hoặc mật khẩu không đúng'
            ];
        }

        // Loại bỏ mật khẩu trước khi lưu vào session
        unset($user['password']);

        // Lưu thông tin người dùng vào session
        $this->session->set('user', $user);
        $this->session->set('isLoggedIn', true);

        // Lưu log đăng nhập
        $logModel = new \App\Models\LogModel();
        $logModel->info('Đăng nhập thành công', [
            'user_id' => $user['id'],
            'ip' => $_SERVER['REMOTE_ADDR'] ?? '',
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? ''
        ]);

        return [
            'success' => true,
            'message' => 'Đăng nhập thành công',
            'user' => $user
        ];
    }

    /**
     * Đăng xuất người dùng
     *
     * @return array Mảng với kết quả đăng xuất
     */
    public function logout()
    {
        $user = $this->session->get('user');

        if ($user) {
            // Lưu log đăng xuất
            $logModel = new \App\Models\LogModel();
            $logModel->info('Đăng xuất', [
                'user_id' => $user['id']
            ]);
        }

        $this->session->remove('user');
        $this->session->remove('isLoggedIn');

        return [
            'success' => true,
            'message' => 'Đăng xuất thành công'
        ];
    }

    /**
     * Tạo API token cho người dùng
     *
     * @param int $userId ID người dùng
     * @param string $name Tên token
     * @param int $expireDays Số ngày token có hiệu lực (0 = không hết hạn)
     * @return array Mảng với thông tin token
     */
    public function createApiToken($userId, $name, $expireDays = 30)
    {
        $token = bin2hex(random_bytes(32)); // Generate a secure random token

        $data = [
            'user_id' => $userId,
            'token' => $token,
            'name' => $name,
            'created_at' => date('Y-m-d H:i:s'),
            'last_used_at' => null
        ];

        if ($expireDays > 0) {
            $data['expires_at'] = date('Y-m-d H:i:s', strtotime("+$expireDays days"));
        }

        $tokenId = $this->tokenModel->insert($data);

        if ($tokenId) {
            return [
                'success' => true,
                'token' => $token,
                'token_id' => $tokenId,
                'expires_at' => $data['expires_at'] ?? null
            ];
        }

        return [
            'success' => false,
            'message' => 'Không thể tạo token'
        ];
    }

    /**
     * Xác thực token API
     *
     * @param RequestInterface $request
     * @return array|null Thông tin người dùng nếu token hợp lệ, null nếu không
     */
    public function verifyApiToken(RequestInterface $request = null)
    {
        $request = $request ?? $this->request;
        $authHeader = $request->getHeaderLine('Authorization');

        if (empty($authHeader) || !preg_match('/Bearer\\s+(.*)$/i', $authHeader, $matches)) {
            return null;
        }

        $token = $matches[1];
        $tokenModel = new \App\Models\TokenModel();

        return $tokenModel->getUserFromToken($token);
    }
}
