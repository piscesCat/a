<?php
namespace App\Models;

use CodeIgniter\Model;

class MediaModel extends Model
{
    protected $table = 'media';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'file_name', 'file_path', 'file_type', 'file_size', 'user_id', 'uploaded_at'
    ];
    protected $returnType = 'array';
    protected $useTimestamps = false;

    /**
     * Get all media files with pagination
     */
    public function getMedia($limit = 20, $offset = 0, $user_id = null, $type = null)
    {
        $query = $this->select('media.*, users.username')
                      ->join('users', 'users.id = media.user_id', 'left');

        if ($user_id !== null) {
            $query->where('media.user_id', $user_id);
        }

        if ($type !== null) {
            $query->where('media.file_type', $type);
        }

        return $query->orderBy('media.uploaded_at', 'DESC')
                     ->limit($limit, $offset)
                     ->find();
    }

    /**
     * Count media files
     */
    public function countMedia($user_id = null, $type = null)
    {
        $query = $this;

        if ($user_id !== null) {
            $query = $query->where('user_id', $user_id);
        }

        if ($type !== null) {
            $query = $query->where('file_type', $type);
        }

        return $query->countAllResults();
    }

    /**
     * Get media by type
     */
    public function getByType($type, $limit = 20, $offset = 0)
    {
        return $this->where('file_type', $type)
                    ->orderBy('uploaded_at', 'DESC')
                    ->limit($limit, $offset)
                    ->find();
    }

    /**
     * Save a media file
     */
    public function saveMedia($file, $user_id)
    {
        if (!$file->isValid() || $file->hasMoved()) {
            return false;
        }

        // Get file info
        $clientName = $file->getClientName();
        $tempPath = $file->getTempName();
        $mimeType = $file->getClientMimeType();
        $size = $file->getSize();
        $extension = $file->getClientExtension();

        // Validate file type more thoroughly
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/svg+xml'];
        $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'];

        // Check MIME type from fileinfo
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $detectedType = finfo_file($finfo, $tempPath);
        finfo_close($finfo);

        // Verify both MIME type and extension
        if (!in_array($mimeType, $allowedTypes) || !in_array(strtolower($extension), $allowedExtensions)) {
            log_message('error', 'Invalid file type: {mime}, extension: {ext}', [
                'mime' => $mimeType,
                'ext' => $extension
            ]);
            return false;
        }

        // Additional check - detected type should match with allowed types
        if (!in_array($detectedType, $allowedTypes)) {
            log_message('error', 'File type mismatch: Reported {mime}, Detected {detected}', [
                'mime' => $mimeType,
                'detected' => $detectedType
            ]);
            return false;
        }

        // Generate a unique filename
        $newName = $file->getRandomName();

        // Define upload directory
        $uploadPath = 'uploads/media';

        // Ensure upload directory exists
        if (!is_dir(ROOTPATH . 'public/' . $uploadPath)) {
            mkdir(ROOTPATH . 'public/' . $uploadPath, 0777, true);
        }

        // Move the file
        $file->move(ROOTPATH . 'public/' . $uploadPath, $newName);
        $fullPath = ROOTPATH . 'public/' . $uploadPath . '/' . $newName;

        // Resize image if it's a standard image (not SVG)
        if ($detectedType !== 'image/svg+xml' && function_exists('imagecreatefromjpeg')) {
            $this->resizeImage($fullPath, $detectedType, 1200); // Max width 1200px
        }

        // Insert into database
        $data = [
            'file_name' => $clientName,
            'file_path' => $uploadPath . '/' . $newName,
            'file_type' => $detectedType, // Use detected type for better security
            'file_size' => filesize($fullPath), // Get actual file size after potential resizing
            'user_id' => $user_id,
            'uploaded_at' => date('Y-m-d H:i:s')
        ];

        return $this->insert($data);
    }

    /**
     * Resize an image to improve performance
     */
    protected function resizeImage($filePath, $mimeType, $maxWidth = 1200)
    {
        // Get current dimensions
        list($width, $height) = getimagesize($filePath);

        // Only resize if width is greater than maxWidth
        if ($width <= $maxWidth) {
            return true;
        }

        // Calculate new dimensions
        $newWidth = $maxWidth;
        $newHeight = ($height / $width) * $newWidth;

        // Create image resource based on type
        $sourceImage = null;
        switch ($mimeType) {
            case 'image/jpeg':
                $sourceImage = imagecreatefromjpeg($filePath);
                break;
            case 'image/png':
                $sourceImage = imagecreatefrompng($filePath);
                break;
            case 'image/gif':
                $sourceImage = imagecreatefromgif($filePath);
                break;
            case 'image/webp':
                if (function_exists('imagecreatefromwebp')) {
                    $sourceImage = imagecreatefromwebp($filePath);
                }
                break;
            default:
                return false;
        }

        if (!$sourceImage) {
            return false;
        }

        // Create new image
        $newImage = imagecreatetruecolor($newWidth, $newHeight);

        // Handle transparency for PNG and GIF
        if ($mimeType === 'image/png' || $mimeType === 'image/gif') {
            imagealphablending($newImage, false);
            imagesavealpha($newImage, true);
            $transparent = imagecolorallocatealpha($newImage, 255, 255, 255, 127);
            imagefilledrectangle($newImage, 0, 0, $newWidth, $newHeight, $transparent);
        }

        // Resize the image
        imagecopyresampled($newImage, $sourceImage, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);

        // Save the image
        switch ($mimeType) {
            case 'image/jpeg':
                imagejpeg($newImage, $filePath, 85); // 85% quality
                break;
            case 'image/png':
                imagepng($newImage, $filePath, 8); // Compression level 8 (0-9)
                break;
            case 'image/gif':
                imagegif($newImage, $filePath);
                break;
            case 'image/webp':
                if (function_exists('imagewebp')) {
                    imagewebp($newImage, $filePath, 85);
                }
                break;
        }

        // Free up memory
        imagedestroy($sourceImage);
        imagedestroy($newImage);

        return true;
    }

    /**
     * Delete a media file
     */
    public function deleteMedia($id)
    {
        $media = $this->find($id);

        if (!$media) {
            return false;
        }

        // Delete the physical file
        $filePath = ROOTPATH . 'public/' . $media['file_path'];

        if (file_exists($filePath)) {
            unlink($filePath);
        }

        // Delete the database record
        return $this->delete($id);
    }
}
