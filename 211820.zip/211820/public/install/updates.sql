-- Script cập nhật phân biệt Bookmark và Truyện yêu thích
-- Đồng thời loại bỏ các trường không cần thiết

-- Bước 1: Xóa trigger và function liên quan đến search_vector
DROP TRIGGER IF EXISTS stories_vector_update ON stories;
DROP FUNCTION IF EXISTS stories_vector_update();

-- Bước 2: Xóa các trường search_vector và hot_marked_at vì không còn sử dụng
ALTER TABLE stories DROP COLUMN IF EXISTS search_vector;
ALTER TABLE stories DROP COLUMN IF EXISTS hot_marked_at;

-- Bước 3: Cập nhật thông tin settings về bookmark và favorites
INSERT INTO settings (id, value, description)
VALUES
    ('max_client_favorites', '50', 'Số lượng truyện yêu thích tối đa cho mỗi người dùng'),
    ('max_client_bookmarks', '50', 'Số lượng bookmark tối đa cho mỗi người dùng')
ON CONFLICT (id) DO UPDATE SET
    value = EXCLUDED.value,
    description = EXCLUDED.description;

-- Ghi nhận việc cập nhật database
INSERT INTO system_changes (change_type, description, sql_query, created_at)
VALUES ('structure', 'Xóa các trường không cần thiết', 'Xóa search_vector, hot_marked_at từ bảng stories và cập nhật tìm kiếm', CURRENT_TIMESTAMP);
