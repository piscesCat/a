<?php

namespace App\Controllers\Api;

use App\Controllers\BaseController;
use App\Models\TokenModel;
use App\Models\UserModel;
use Firebase\JWT\JWT;

class ApiTokens extends BaseController
{
    protected $tokenModel;
    protected $userModel;

    public function __construct()
    {
        $this->tokenModel = new TokenModel();
        $this->userModel = new UserModel();
    }

    /**
     * Create a new API token (requires authentication)
     */
    public function createToken()
    {
        // Check if user is authenticated
        $userId = $this->request->getPost('user_id');
        $username = $this->request->getPost('username');
        $password = $this->request->getPost('password');

        if (!$userId && (!$username || !$password)) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Missing authentication credentials'
            ])->setStatusCode(401);
        }

        // Verify credentials if username/password provided
        if ($username && $password) {
            $user = $this->userModel->where('username', $username)->first();

            if (!$user || !password_verify($password, $user['password'])) {
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'Invalid credentials'
                ])->setStatusCode(401);
            }

            $userId = $user['id'];
        } else {
            // Verify userId exists
            $user = $this->userModel->find($userId);
            if (!$user) {
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'User not found'
                ])->setStatusCode(401);
            }
        }

        // Check if user has sufficient permissions (role 1 or higher)
        if ($user['role'] < 1) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Insufficient permissions'
            ])->setStatusCode(403);
        }

        // Generate token
        $expiryDays = $this->request->getPost('expiry_days') ?? 30;
        $expiresAt = time() + (intval($expiryDays) * 24 * 60 * 60);

        $payload = [
            'user_id' => $user['id'],
            'username' => $user['username'],
            'email' => $user['email'],
            'role' => $user['role'],
            'iat' => time(),
            'exp' => $expiresAt
        ];

        // Get JWT secret key
        $key = $this->getJwtSecretKey();

        // Generate token
        $token = JWT::encode($payload, $key, 'HS256');

        // Store token in database
        $this->tokenModel->insert([
            'user_id' => $user['id'],
            'token' => $token,
            'expires_at' => date('Y-m-d H:i:s', $expiresAt),
            'created_at' => date('Y-m-d H:i:s')
        ]);

        // Log the token creation
        $this->logModel->info('API Token created via API', [
            'user_id' => $user['id'],
            'ip_address' => $this->request->getIPAddress()
        ]);

        return $this->response->setJSON([
            'success' => true,
            'data' => [
                'token' => $token,
                'expires_at' => date('Y-m-d H:i:s', $expiresAt),
                'user' => [
                    'id' => $user['id'],
                    'username' => $user['username'],
                    'role' => $user['role']
                ]
            ]
        ]);
    }

    /**
     * Get all tokens for authenticated user
     */
    public function getTokens()
    {
        // Get user from the authenticated request
        $user = $this->getAuthenticatedUser();

        if (!$user) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Authentication required'
            ])->setStatusCode(401);
        }

        // Get tokens for this user
        $tokens = $this->tokenModel->getTokensByUserId($user['id']);

        // Format tokens (don't include the full token for security)
        $formattedTokens = [];
        foreach ($tokens as $token) {
            $formattedTokens[] = [
                'id' => $token['id'],
                'token_preview' => substr($token['token'], 0, 10) . '...',
                'created_at' => $token['created_at'],
                'expires_at' => $token['expires_at'],
                'is_expired' => strtotime($token['expires_at']) < time()
            ];
        }

        return $this->response->setJSON([
            'success' => true,
            'data' => [
                'tokens' => $formattedTokens
            ]
        ]);
    }

    /**
     * Revoke (delete) a token
     */
    public function revokeToken($id)
    {
        // Get user from the authenticated request
        $user = $this->getAuthenticatedUser();

        if (!$user) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Authentication required'
            ])->setStatusCode(401);
        }

        // Get the token
        $token = $this->tokenModel->find($id);

        if (!$token) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Token not found'
            ])->setStatusCode(404);
        }

        // Check if the token belongs to the user or if the user is an admin
        if ($token['user_id'] != $user['id'] && $user['role'] < 2) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'You do not have permission to revoke this token'
            ])->setStatusCode(403);
        }

        // Delete the token
        $this->tokenModel->delete($id);

        // Log the token revocation
        $this->logModel->info('API Token revoked via API', [
            'user_id' => $user['id'],
            'token_for_user_id' => $token['user_id'],
            'token_id' => $id,
            'ip_address' => $this->request->getIPAddress()
        ]);

        return $this->response->setJSON([
            'success' => true,
            'message' => 'Token revoked successfully'
        ]);
    }

    /**
     * Get authenticated user from JWT token in Authorization header
     */
    protected function getAuthenticatedUser()
    {
        $authHeader = $this->request->getServer('HTTP_AUTHORIZATION');

        if (!$authHeader || !preg_match('/Bearer\s+(.*)$/i', $authHeader, $matches)) {
            return null;
        }

        $token = $matches[1];

        // Verify token in database
        $tokenData = $this->tokenModel->verifyToken($token);

        if (!$tokenData) {
            return null;
        }

        // Get user
        $user = $this->userModel->find($tokenData['user_id']);

        return $user;
    }

    /**
     * Get JWT secret key from config or .env
     */
    private function getJwtSecretKey()
    {
        // Try to get from config
        $key = getenv('JWT_SECRET_KEY');

        // If not set, generate a new one and save it
        if (!$key) {
            // Generate a secure random key
            $key = bin2hex(random_bytes(32));

            // Try to save it to .env file
            $envPath = ROOTPATH . '.env';
            if (file_exists($envPath) && is_writable($envPath)) {
                $envContent = file_get_contents($envPath);

                // Check if JWT_SECRET_KEY already exists
                if (strpos($envContent, 'JWT_SECRET_KEY') !== false) {
                    // Replace the existing value
                    $envContent = preg_replace('/JWT_SECRET_KEY\s*=.*/', "JWT_SECRET_KEY = \"$key\"", $envContent);
                } else {
                    // Add new key
                    $envContent .= "\n# JWT Configuration\nJWT_SECRET_KEY = \"$key\"\n";
                }

                file_put_contents($envPath, $envContent);
            }

            // Set the environment variable for the current request
            putenv("JWT_SECRET_KEY=$key");
        }

        return $key;
    }
}
