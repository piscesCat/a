<?php
namespace App\Models;

use CodeIgniter\Model;

class CountryModel extends Model
{
    protected $table = 'countries';
    protected $primaryKey = 'id';
    protected $returnType = 'array';
    protected $allowedFields = [
        'name', 'slug', 'description', 'flag_image',
        'code', 'region', 'status'
    ];

    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    /**
     * Lấy tất cả quốc gia kèm số lượng truyện
     */
    public function getCountriesWithCount()
    {
        $db = \Config\Database::connect();
        $builder = $db->table('countries')
                      ->select('countries.*, COUNT(stories.id) as story_count')
                      ->join('stories', 'stories.country_id = countries.id', 'left')
                      ->groupBy('countries.id')
                      ->orderBy('countries.name', 'ASC');

        return $builder->get()->getResultArray();
    }

    /**
     * Lấy quốc gia theo slug
     */
    public function getCountryBySlug($slug)
    {
        return $this->where('slug', $slug)->first();
    }

    /**
     * Lấy quốc gia theo mã
     */
    public function getCountryByCode($code)
    {
        return $this->where('code', $code)->first();
    }

    /**
     * Lấy quốc gia phổ biến (nhiều truyện nhất)
     */
    public function getPopularCountries($limit = 10)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('countries')
                      ->select('countries.*, COUNT(stories.id) as story_count')
                      ->join('stories', 'stories.country_id = countries.id')
                      ->where('countries.status', 'active')
                      ->groupBy('countries.id')
                      ->orderBy('story_count', 'DESC')
                      ->limit($limit);

        return $builder->get()->getResultArray();
    }

    /**
     * Lấy tất cả quốc gia đang hoạt động
     */
    public function getActiveCountries()
    {
        return $this->where('status', 'active')
                   ->orderBy('name', 'ASC')
                   ->findAll();
    }

    /**
     * Lấy danh sách quốc gia theo khu vực
     */
    public function getCountriesByRegion()
    {
        $countries = $this->where('status', 'active')
                        ->orderBy('region', 'ASC')
                        ->orderBy('name', 'ASC')
                        ->findAll();

        $result = [];

        foreach ($countries as $country) {
            $region = $country['region'] ?? 'Other';
            if (!isset($result[$region])) {
                $result[$region] = [];
            }
            $result[$region][] = $country;
        }

        return $result;
    }

    /**
     * Lấy danh sách quốc gia có truyện trong hệ thống
     * Phương thức mới: Chỉ hiển thị quốc gia từ truyện có sẵn
     */
    public function getCountriesFromStories()
    {
        $db = \Config\Database::connect();
        $builder = $db->table('countries')
                      ->select('countries.*')
                      ->join('stories', 'stories.country_id = countries.id')
                      ->where('countries.status', 'active')
                      ->groupBy('countries.id')
                      ->orderBy('countries.name', 'ASC');

        return $builder->get()->getResultArray();
    }

    /**
     * Phương thức mới: Lấy danh sách quốc gia có sẵn từ thư viện JS
     * Dùng cho hiển thị dropdown chọn quốc gia
     */
    public function getCountriesFromLibrary()
    {
        // Danh sách được tải từ thư viện JS
        // Chỉ để sử dụng, không có trong admin panel
        return [
            'VN' => ['name' => 'Việt Nam', 'region' => 'Asia'],
            'CN' => ['name' => 'Trung Quốc', 'region' => 'Asia'],
            'JP' => ['name' => 'Nhật Bản', 'region' => 'Asia'],
            'KR' => ['name' => 'Hàn Quốc', 'region' => 'Asia'],
            'US' => ['name' => 'Mỹ', 'region' => 'North America'],
            'GB' => ['name' => 'Anh', 'region' => 'Europe'],
            'FR' => ['name' => 'Pháp', 'region' => 'Europe'],
            'DE' => ['name' => 'Đức', 'region' => 'Europe'],
            'IT' => ['name' => 'Ý', 'region' => 'Europe'],
            'ES' => ['name' => 'Tây Ban Nha', 'region' => 'Europe'],
            'TH' => ['name' => 'Thái Lan', 'region' => 'Asia'],
            'HK' => ['name' => 'Hồng Kông', 'region' => 'Asia'],
            'TW' => ['name' => 'Đài Loan', 'region' => 'Asia'],
            'IN' => ['name' => 'Ấn Độ', 'region' => 'Asia'],
            'RU' => ['name' => 'Nga', 'region' => 'Europe'],
            'CA' => ['name' => 'Canada', 'region' => 'North America'],
            'AU' => ['name' => 'Úc', 'region' => 'Oceania'],
            'BR' => ['name' => 'Brazil', 'region' => 'South America'],
            'OTHER' => ['name' => 'Khác', 'region' => 'Other']
        ];
    }
}
