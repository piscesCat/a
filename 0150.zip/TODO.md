# Danh sách công việc cần làm tiếp theo

Dựa trên yêu cầu từ file `log.txt`, danh sách các công việc cần thực hiện:

## Đã hoàn thành
- [x] Xoá bỏ hoàn toàn chức năng tạo quốc gia trong admin panel và hiển thị danh sách quốc gia bằng thư viện js, sau đó truy vấn để hiển thị danh sách quốc gia ở header của những truyện có sẵn
- [x] Thêm bookmark ở chương
- [x] API token sẽ lấy ở Admin Panel thay vì sử dụng api với user pass
- [x] Truyện hot thay đổi thành truyện đề xuất kèm thuật toán thông minh
- [x] Sửa layout admin thành admin/layouts/admin.html
- [x] Cập nhật template theo sự thay đổi trên
- [x] Bảo mật không cho phép thao tác vượt quyền hạn
- [x] Phân biệt rõ ràng tác giả với người đăng (tài khoản đã đăng truyện) trong code đang bị nhầm lẫn
- [x] Chức năng bookmark cho bất kỳ người truy cập nào không cần đăng nhập vì mã nguồn không cho phép users đăng ky, đăng nhập
- [x] Sử dụng JWT làm token
- [x] Thêm chức năng tạo thành viên dưới phân quyền thấp hơn người sáng lập (tài khoản đầu tiên được tạo lúc install) với 3 phân quyền: Người sáng lập, Admin, Cộng tác viên
- [x] Áp dụng hiển thị và sử dụng chức năng cho từng phân quyền theo màu sắc trên web (ví dụ comments)
- [x] Bổ sung post ảnh lên imgur qua api và trong mã nguồn
- [x] Bổ sung bảng editor cho phần viết truyện có tuỳ chọn post ảnh mô tả nội dung
- [x] Tách biệt hoàn toàn giao diện template của Views/admin và bên ngoài không cho twig code extents các file template khác ngoài Views/admin

## Cần thực hiện tiếp theo
- [ ] Mở rộng áp dụng phân quyền vào các controller còn lại
- [ ] Sửa template bao gồm css, jss, views là sửa hẳn nội dung file không bao gồm template của admin panel
- [ ] Kiểm thử và tối ưu hóa các tính năng mới
- [ ] Thêm unit tests cho các chức năng quan trọng

## Chi tiết công việc

### 1. Mở rộng phân quyền cho các controller còn lại
- Áp dụng kiểm tra quyền vào tất cả controllers
- Điều chỉnh hiển thị các nút chức năng theo quyền của người dùng
- Đảm bảo tất cả các endpoint đều có kiểm tra quyền phù hợp

### 2. Cải thiện giao diện người dùng
- Tiếp tục áp dụng phân biệt màu sắc theo vai trò vào các phần khác của website
- Cập nhật CSS/JS cho phù hợp với chức năng mới
- Đảm bảo trải nghiệm người dùng nhất quán
- Tối ưu hóa responsive design

### 3. Kiểm thử và tối ưu hóa
- Kiểm tra hiệu suất của các tính năng mới
- Kiểm tra bảo mật của hệ thống phân quyền
- Kiểm tra đồng bộ bookmark trên các thiết bị và trình duyệt khác nhau
- Kiểm tra việc upload ảnh qua Imgur API

### 4. Tài liệu và hướng dẫn
- Cập nhật tài liệu API với các endpoints mới
- Viết hướng dẫn sử dụng các tính năng mới
- Chuẩn bị tài liệu triển khai cho môi trường sản phẩm

## Đã hoàn thành nhưng cần kiểm tra lại
- API Authentication với JWT - Đã triển khai, cần kiểm tra thêm với các trường hợp đặc biệt
- Phân quyền và bảo mật - Đã triển khai logic cơ bản, cần mở rộng vào tất cả controllers
- Guest Bookmark - Đã triển khai, cần kiểm tra trải nghiệm người dùng trên nhiều trình duyệt
- TinyMCE Editor và Imgur Integration - Đã triển khai, cần kiểm tra với các loại nội dung phức tạp

## Lưu ý
- Cập nhật file TODO.md sau mỗi lần có tiến độ để theo dõi công việc
- Ưu tiên các vấn đề bảo mật và kiểm thử
- Kiểm tra kỹ lưỡng quyền truy cập vào các tài nguyên nhạy cảm
- Đảm bảo hiệu suất tốt khi số lượng dữ liệu tăng lên
