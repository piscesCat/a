/**
 * Lưu/xóa bookmark (hoạt động với cả user đăng nhập và không đăng nhập)
 */
public function toggleBookmark()
{
    // Lấy story_id từ request
    $storyId = $this->request->getPost('story_id');
    if (!$storyId) {
        return $this->response->setJSON([
            'status' => 'error',
            'message' => 'ID truyện không hợp lệ'
        ]);
    }

    // Kiểm tra truyện có tồn tại không
    $story = $this->storyModel->find($storyId);
    if (!$story) {
        return $this->response->setJSON([
            'status' => 'error',
            'message' => 'Truyện không tồn tại'
        ]);
    }

    // Xử lý bookmark dựa vào trạng thái đăng nhập
    if (session()->get('isLoggedIn')) {
        // Người dùng đã đăng nhập
        $userId = session()->get('user')['id'];
        return $this->toggleUserBookmark($userId, $storyId);
    } else {
        // Người dùng không đăng nhập, sử dụng cookie
        return $this->toggleCookieBookmark($storyId, $story['title']);
    }
}

/**
 * Xử lý bookmark cho người dùng đã đăng nhập
 */
private function toggleUserBookmark($userId, $storyId)
{
    $db = \Config\Database::connect();
    $builder = $db->table('bookmarks');

    // Kiểm tra bookmark đã tồn tại chưa
    $existing = $builder->where('user_id', $userId)
                        ->where('story_id', $storyId)
                        ->get()
                        ->getRow();

    if ($existing) {
        // Đã có bookmark, xóa đi
        $builder->where('user_id', $userId)
                ->where('story_id', $storyId)
                ->delete();

        return $this->response->setJSON([
            'status' => 'success',
            'action' => 'removed',
            'message' => 'Đã xóa truyện khỏi danh sách theo dõi'
        ]);
    } else {
        // Chưa có bookmark, thêm mới
        $builder->insert([
            'user_id' => $userId,
            'story_id' => $storyId,
            'created_at' => date('Y-m-d H:i:s')
        ]);

        return $this->response->setJSON([
            'status' => 'success',
            'action' => 'added',
            'message' => 'Đã thêm truyện vào danh sách theo dõi'
        ]);
    }
}

/**
 * Xử lý bookmark cho người dùng không đăng nhập (dùng cookie)
 */
private function toggleCookieBookmark($storyId, $storyTitle)
{
    // Cookie sẽ có tên "bookmarks" và chứa danh sách ID truyện được bookmark
    $bookmarks = $this->request->getCookie('bookmarks');
    $bookmarkData = $bookmarks ? json_decode($bookmarks, true) : [];

    // Kiểm tra xem truyện đã được bookmark chưa
    $index = array_search($storyId, array_column($bookmarkData, 'id'));

    if ($index !== false) {
        // Đã có bookmark, xóa đi
        array_splice($bookmarkData, $index, 1);
        $action = 'removed';
        $message = 'Đã xóa truyện khỏi danh sách theo dõi';
    } else {
        // Chưa có bookmark, thêm mới
        // Giới hạn số lượng bookmark trong cookie là 50
        if (count($bookmarkData) >= 50) {
            array_shift($bookmarkData); // Xóa bookmark cũ nhất
        }

        $bookmarkData[] = [
            'id' => $storyId,
            'title' => $storyTitle,
            'date' => date('Y-m-d H:i:s')
        ];

        $action = 'added';
        $message = 'Đã thêm truyện vào danh sách theo dõi';
    }

    // Lưu lại vào cookie, có thời hạn 90 ngày
    $this->response->setCookie(
        'bookmarks',
        json_encode($bookmarkData),
        time() + 60 * 60 * 24 * 90, // 90 ngày
        '/',
        '',
        false,
        true // httpOnly
    );

    return $this->response->setJSON([
        'status' => 'success',
        'action' => $action,
        'message' => $message
    ]);
}

/**
 * Hiển thị danh sách bookmark của người dùng hiện tại
 */
public function bookmarks()
{
    if (session()->get('isLoggedIn')) {
        // Người dùng đã đăng nhập, lấy bookmarks từ database
        $userId = session()->get('user')['id'];
        $bookmarks = $this->getUserBookmarks($userId);

        return view('story/bookmarks.html', [
            'bookmarks' => $bookmarks,
            'title' => 'Truyện đang theo dõi',
            'type' => 'user'
        ]);
    } else {
        // Người dùng không đăng nhập, lấy bookmarks từ cookie
        $bookmarks = $this->getCookieBookmarks();

        return view('story/bookmarks.html', [
            'bookmarks' => $bookmarks,
            'title' => 'Truyện đang theo dõi',
            'type' => 'guest'
        ]);
    }
}

/**
 * Lấy danh sách bookmark của người dùng đã đăng nhập
 */
private function getUserBookmarks($userId)
{
    $db = \Config\Database::connect();
    $builder = $db->table('bookmarks');

    return $builder->select('stories.*, bookmarks.created_at as bookmarked_at')
                   ->join('stories', 'stories.id = bookmarks.story_id')
                   ->where('bookmarks.user_id', $userId)
                   ->orderBy('bookmarks.created_at', 'DESC')
                   ->get()
                   ->getResultArray();
}

/**
 * Lấy danh sách bookmark từ cookie cho người dùng không đăng nhập
 */
private function getCookieBookmarks()
{
    $bookmarks = $this->request->getCookie('bookmarks');
    if (!$bookmarks) {
        return [];
    }

    $bookmarkData = json_decode($bookmarks, true);
    if (!$bookmarkData) {
        return [];
    }

    // Lấy thông tin chi tiết của các truyện
    $storyIds = array_column($bookmarkData, 'id');
    if (empty($storyIds)) {
        return [];
    }

    $stories = $this->storyModel->whereIn('id', $storyIds)->findAll();

    // Sắp xếp theo thứ tự trong cookie
    $result = [];
    foreach ($bookmarkData as $bookmark) {
        foreach ($stories as $story) {
            if ($story['id'] == $bookmark['id']) {
                $story['bookmarked_at'] = $bookmark['date'];
                $result[] = $story;
                break;
            }
        }
    }

    return $result;
}

// Đã xóa phương thức recommended(), latest(), và completed() vì đã có trong Novel.php
