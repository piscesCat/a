<?php

namespace App\Libraries;

class ImgurClient
{
    protected $clientId;
    protected $clientSecret;

    public function __construct()
    {
        // Lấy client ID từ cấu hình hoặc biến môi trường
        $this->clientId = getenv('IMGUR_CLIENT_ID') ?: '';
        $this->clientSecret = getenv('IMGUR_CLIENT_SECRET') ?: '';
    }

    /**
     * Upload ảnh lên Imgur
     *
     * @param string $imageData Dữ liệu ảnh (base64 hoặc binary)
     * @param bool $isBase64 Cờ xác định imageData đã là base64 hay chưa
     * @return array Kết quả từ Imgur API
     */
    public function uploadImage($imageData, $isBase64 = false)
    {
        // Kiểm tra client ID
        if (empty($this->clientId)) {
            return [
                'success' => false,
                'error' => 'Không tìm thấy Imgur Client ID. Vui lòng cấu hình trong .env',
                'status' => 400
            ];
        }

        // Chuyển đổi dữ liệu thành base64 nếu cần
        $base64Image = $isBase64 ? $imageData : base64_encode($imageData);

        // Thiết lập cURL request
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://api.imgur.com/3/image');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Client-ID ' . $this->clientId
        ]);
        curl_setopt($ch, CURLOPT_POSTFIELDS, [
            'image' => $base64Image
        ]);

        // Thực hiện request
        $response = curl_exec($ch);
        $error = curl_error($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        // Kiểm tra lỗi cURL
        if ($error) {
            return [
                'success' => false,
                'error' => 'cURL Error: ' . $error,
                'status' => 500
            ];
        }

        // Parse response JSON
        $result = json_decode($response, true);

        // Kiểm tra và trả về kết quả
        if (isset($result['success']) && $result['success']) {
            return [
                'success' => true,
                'data' => [
                    'link' => $result['data']['link'],
                    'deletehash' => $result['data']['deletehash'] ?? '',
                    'id' => $result['data']['id'] ?? '',
                    'type' => $result['data']['type'] ?? ''
                ],
                'status' => $httpCode
            ];
        }

        // Trả về lỗi
        return [
            'success' => false,
            'error' => $result['data']['error'] ?? 'Không thể upload ảnh lên Imgur',
            'status' => $httpCode
        ];
    }

    /**
     * Upload ảnh từ URL
     *
     * @param string $imageUrl URL của ảnh cần upload
     * @return array Kết quả từ Imgur API
     */
    public function uploadImageFromUrl($imageUrl)
    {
        // Kiểm tra client ID
        if (empty($this->clientId)) {
            return [
                'success' => false,
                'error' => 'Không tìm thấy Imgur Client ID. Vui lòng cấu hình trong .env',
                'status' => 400
            ];
        }

        // Thiết lập cURL request
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://api.imgur.com/3/image');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Client-ID ' . $this->clientId
        ]);
        curl_setopt($ch, CURLOPT_POSTFIELDS, [
            'image' => $imageUrl,
            'type' => 'url'
        ]);

        // Thực hiện request
        $response = curl_exec($ch);
        $error = curl_error($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        // Kiểm tra lỗi cURL
        if ($error) {
            return [
                'success' => false,
                'error' => 'cURL Error: ' . $error,
                'status' => 500
            ];
        }

        // Parse response JSON
        $result = json_decode($response, true);

        // Kiểm tra và trả về kết quả
        if (isset($result['success']) && $result['success']) {
            return [
                'success' => true,
                'data' => [
                    'link' => $result['data']['link'],
                    'deletehash' => $result['data']['deletehash'] ?? '',
                    'id' => $result['data']['id'] ?? '',
                    'type' => $result['data']['type'] ?? ''
                ],
                'status' => $httpCode
            ];
        }

        // Trả về lỗi
        return [
            'success' => false,
            'error' => $result['data']['error'] ?? 'Không thể upload ảnh lên Imgur',
            'status' => $httpCode
        ];
    }

    /**
     * Xóa ảnh từ Imgur
     *
     * @param string $deleteHash Delete hash của ảnh cần xóa
     * @return array Kết quả từ Imgur API
     */
    public function deleteImage($deleteHash)
    {
        // Kiểm tra client ID
        if (empty($this->clientId)) {
            return [
                'success' => false,
                'error' => 'Không tìm thấy Imgur Client ID. Vui lòng cấu hình trong .env',
                'status' => 400
            ];
        }

        // Thiết lập cURL request
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://api.imgur.com/3/image/' . $deleteHash);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'DELETE');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Client-ID ' . $this->clientId
        ]);

        // Thực hiện request
        $response = curl_exec($ch);
        $error = curl_error($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        // Kiểm tra lỗi cURL
        if ($error) {
            return [
                'success' => false,
                'error' => 'cURL Error: ' . $error,
                'status' => 500
            ];
        }

        // Parse response JSON
        $result = json_decode($response, true);

        // Kiểm tra và trả về kết quả
        if (isset($result['success']) && $result['success']) {
            return [
                'success' => true,
                'status' => $httpCode
            ];
        }

        // Trả về lỗi
        return [
            'success' => false,
            'error' => $result['data']['error'] ?? 'Không thể xóa ảnh từ Imgur',
            'status' => $httpCode
        ];
    }
}
