<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

class ApiAuthFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        $tokenModel = new \App\Models\TokenModel();
        $authHeader = $request->getServer('HTTP_AUTHORIZATION');

        if (!$authHeader || !preg_match('/Bearer\\s+(.*)$/i', $authHeader, $matches)) {
            return service('response')->setJSON([
                'error' => 'Unauthorized'
            ])->setStatusCode(401);
        }

        $token = $matches[1];

        // Verify token
        if (!$tokenModel->verifyToken($token)) {
            return service('response')->setJSON([
                'error' => 'Invalid or expired token'
            ])->setStatusCode(401);
        }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // No action needed
    }
}
