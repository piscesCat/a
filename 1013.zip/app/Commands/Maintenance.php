<?php

namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;

class Maintenance extends BaseCommand
{
    /**
     * The Command's Group
     *
     * @var string
     */
    protected $group = 'App';

    /**
     * The Command's Name
     *
     * @var string
     */
    protected $name = 'maintenance';

    /**
     * The Command's Description
     *
     * @var string
     */
    protected $description = 'Run maintenance tasks like database cleanup, statistics reset, etc.';

    /**
     * The Command's Usage
     *
     * @var string
     */
    protected $usage = 'maintenance [task] [options]';

    /**
     * The Command's Arguments
     *
     * @var array
     */
    protected $arguments = [
        'task' => 'The maintenance task to run (cleanup, reset-daily, reset-weekly, reset-monthly, update-recommended)',
    ];

    /**
     * The Command's Options
     *
     * @var array
     */
    protected $options = [];

    /**
     * Actually execute a command.
     *
     * @param array $params
     */
    public function run(array $params)
    {
        $task = array_shift($params);

        if (empty($task)) {
            CLI::error('Task name is required. Available tasks: cleanup, reset-daily, reset-weekly, reset-monthly, update-recommended');
            return;
        }

        switch ($task) {
            case 'cleanup':
                $this->runCleanup();
                break;
            case 'reset-daily':
                $this->resetStats('daily');
                break;
            case 'reset-weekly':
                $this->resetStats('weekly');
                break;
            case 'reset-monthly':
                $this->resetStats('monthly');
                break;
            case 'update-recommended':
                $this->updateRecommended();
                break;
            default:
                CLI::error('Unknown task: ' . $task);
                CLI::write('Available tasks: cleanup, reset-daily, reset-weekly, reset-monthly, update-recommended');
                break;
        }
    }

    /**
     * Run database cleanup tasks
     */
    private function runCleanup()
    {
        CLI::write('Running database cleanup...', 'yellow');

        $maintenance = new \App\Controllers\Admin\DatabaseMaintenance();
        $result = $maintenance->cleanup();

        if ($result === 0) {
            CLI::write('Database cleanup completed successfully!', 'green');
        } else {
            CLI::error('Database cleanup failed!');
        }
    }

    /**
     * Reset statistics for stories
     */
    private function resetStats($period)
    {
        CLI::write('Resetting ' . $period . ' statistics...', 'yellow');

        $maintenance = new \App\Controllers\Admin\DatabaseMaintenance();
        $result = $maintenance->resetStats($period);

        if ($result === 0) {
            CLI::write($period . ' statistics reset successfully!', 'green');
        } else {
            CLI::error($period . ' statistics reset failed!');
        }
    }

    /**
     * Update recommended stories
     */
    private function updateRecommended()
    {
        CLI::write('Updating recommended stories...', 'yellow');

        $maintenance = new \App\Controllers\Admin\DatabaseMaintenance();
        $result = $maintenance->updateRecommendedStories();

        if ($result === 0) {
            CLI::write('Recommended stories updated successfully!', 'green');
        } else {
            CLI::error('Recommended stories update failed!');
        }
    }
}
