<div class="alert alert-info">
    <i class="fas fa-info-circle"></i> Chào mừng bạn đến với quá trình cài đặt hệ thống. Trước khi tiếp tục, hãy đảm bảo rằng máy chủ của bạn đáp ứng tất cả các yêu cầu sau.
</div>

<h4 class="mb-3">Kiểm tra phiên bản và extension PHP</h4>
<div class="table-responsive mb-4">
    <table class="table table-bordered">
        <thead class="table-light">
            <tr>
                <th>Tên</th>
                <th>Yêu cầu</th>
                <th>Hiện tại</th>
                <th>Trạng thái</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($requirements as $requirement): ?>
            <tr>
                <td><?= $requirement['name'] ?></td>
                <td><?= $requirement['required'] ?></td>
                <td><?= $requirement['current'] ?></td>
                <td>
                    <?php if ($requirement['status']): ?>
                        <span class="badge bg-success"><i class="fas fa-check"></i> OK</span>
                    <?php else: ?>
                        <span class="badge bg-danger"><i class="fas fa-times"></i> Không đạt</span>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<h4 class="mb-3">Kiểm tra quyền truy cập thư mục</h4>
<div class="table-responsive mb-4">
    <table class="table table-bordered">
        <thead class="table-light">
            <tr>
                <th>Thư mục/Tệp</th>
                <th>Yêu cầu</th>
                <th>Hiện tại</th>
                <th>Trạng thái</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($permissions as $permission): ?>
            <tr>
                <td><?= $permission['name'] ?></td>
                <td><?= $permission['required'] ?></td>
                <td><?= $permission['current'] ?></td>
                <td>
                    <?php if ($permission['status']): ?>
                        <span class="badge bg-success"><i class="fas fa-check"></i> OK</span>
                    <?php else: ?>
                        <span class="badge bg-danger"><i class="fas fa-times"></i> Không đạt</span>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<div class="mb-4">
    <?php
    $canProceed = true;
    foreach ($requirements as $requirement) {
        if (!$requirement['status']) {
            $canProceed = false;
            break;
        }
    }

    foreach ($permissions as $permission) {
        if (!$permission['status']) {
            $canProceed = false;
            break;
        }
    }
    ?>

    <?php if (!$canProceed): ?>
    <div class="alert alert-warning">
        <i class="fas fa-exclamation-triangle"></i> Vui lòng đảm bảo máy chủ của bạn đáp ứng tất cả các yêu cầu trước khi tiếp tục.
    </div>
    <?php endif; ?>
</div>

<form method="post" action="">
    <input type="hidden" name="step" value="1">

    <div class="d-flex justify-content-between">
        <button type="button" class="btn btn-secondary" onclick="window.location.reload();">
            <i class="fas fa-sync-alt"></i> Kiểm tra lại
        </button>

        <button type="submit" name="proceed" class="btn btn-primary" <?= $canProceed ? '' : 'disabled' ?>>
            Tiếp tục <i class="fas fa-arrow-right"></i>
        </button>
    </div>
</form>
