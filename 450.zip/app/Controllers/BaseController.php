// app/Controllers/BaseController.php
namespace App\Controllers;

use CodeIgniter\Controller;
use CodeIgniter\HTTP\CLIRequest;
use CodeIgniter\HTTP\IncomingRequest;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use Config\Services;
use Psr\Log\LoggerInterface;
use App\Models\SettingsModel;
use App\Models\UserModel;
use App\Models\CategoryModel;
use App\Models\LogModel;

/**
 * Class BaseController
 *
 * BaseController cung cấp nơi thuận tiện để tải các thành phần
 * và thực hiện các chức năng mà tất cả các controller của bạn cần.
 */
abstract class BaseController extends Controller
{
    /**
     * Thể hiện của đối tượng Request chính.
     *
     * @var CLIRequest|IncomingRequest
     */
    protected $request;

    /**
     * Một mảng các helpers được tải tự động khi
     * lớp được khởi tạo. Các helpers này sẽ khả dụng
     * cho tất cả các controller khác kế thừa BaseController.
     *
     * @var array
     */
    protected $helpers = ['url', 'form', 'text', 'date', 'cookie', 'security'];

    /**
     * Thể hiện của Session
     */
    protected $session;

    /**
     * Các Model
     */
    protected $userModel;
    protected $settingsModel;
    protected $logModel;

    /**
     * Người dùng hiện tại đang đăng nhập
     */
    protected $currentUser;

    /**
     * Thể hiện của Database
     */
    protected $db;

    /**
     * Hệ thống đã được cài đặt chưa
     */
    protected $isInstalled = false;

    /**
     * Dữ liệu view
     */
    protected $viewData = [];

    /**
     * Bộ nhớ đệm cài đặt
     */
    protected static $settingsCache = null;

    /**
     * Hàm khởi tạo.
     */
    public function initController(RequestInterface $request, ResponseInterface $response, LoggerInterface $logger)
    {
        // Không chỉnh sửa dòng này
        parent::initController($request, $response, $logger);

        // Preload any models, libraries, etc, here.
        $this->twig = new \Config\Twig();
        $this->db = \Config\Database::connect();
        $this->session = \Config\Services::session();

        // Load Models
        $this->settingsModel = new \App\Models\SettingsModel();

        // Lấy thiết lập từ cơ sở dữ liệu
        $settings = $this->settingsModel->getSettings();

        // Load thiết lập vào Twig
        foreach ($settings as $key => $value) {
            $this->twig->addGlobal($key, $value);
        }

        // Thêm thông tin phiên làm việc
        $this->twig->addGlobal('session', $this->session);

        // Thêm thông tin người dùng hiện tại
        $this->twig->addGlobal('current_user', $this->session->get('user'));

        // Thêm biến môi trường URL
        $this->twig->addGlobal('base_url', base_url());
        $this->twig->addGlobal('site_url', site_url());
        $this->twig->addGlobal('current_url', current_url());

        // Thêm danh sách quốc gia có truyện
        $storyModel = new \App\Models\StoryModel();
        $countries = $storyModel->getCountries();
        $this->twig->addGlobal('available_countries', $countries);

        // Khởi tạo cơ sở dữ liệu
        $this->db = \Config\Database::connect();

        // Khởi tạo session
        $this->session = Services::session();

        // Kiểm tra xem hệ thống đã được cài đặt chưa
        $this->isInstalled = file_exists(ROOTPATH . 'installed.txt');

        // Kiểm tra CSRF cho các yêu cầu POST
        $this->validateCSRF();

        // Khởi tạo các model
        $this->initModels();

        // Lấy thông tin người dùng hiện tại từ session
        $this->loadCurrentUser();

        // Chia sẻ dữ liệu chung với tất cả các view
        $this->shareCommonData();
    }

    /**
     * Khởi tạo các model
     */
    protected function initModels()
    {
        if ($this->isInstalled) {
            $this->userModel = new UserModel();
            $this->settingsModel = new SettingsModel();
            $this->logModel = new LogModel();
        }
    }

    /**
     * Xác thực token CSRF cho các yêu cầu POST, PUT, DELETE
     */
    protected function validateCSRF()
    {
        // Bỏ qua cho quá trình cài đặt hoặc cho các yêu cầu GET
        if (!$this->isInstalled || $this->request->getMethod() === 'get') {
            return;
        }

        // Kiểm tra token CSRF
        if (!$this->request->isAJAX() && ($this->request->getMethod() === 'post' || $this->request->getMethod() === 'put' || $this->request->getMethod() === 'delete')) {
            if (!csrf_verify($this->request)) {
                // Ghi log về nỗ lực tấn công CSRF
                if (isset($this->logModel)) {
                    $this->logModel->error('CSRF validation failed', [
                        'ip' => $this->request->getIPAddress(),
                        'uri' => $this->request->getUri(),
                        'user_agent' => $this->request->getUserAgent()
                    ]);
                }

                // Chuyển hướng với thông báo lỗi
                $this->session->setFlashdata('error', 'Xác thực bảo mật thất bại. Vui lòng thử lại.');

                // Nếu là yêu cầu AJAX, trả về JSON
                if ($this->request->isAJAX()) {
                    $response = Services::response();
                    return $response->setJSON([
                        'success' => false,
                        'message' => 'CSRF validation failed'
                    ])->setStatusCode(403);
                }

                // Ngược lại, chuyển hướng
                return redirect()->back();
            }
        }
    }

    /**
     * Tải thông tin người dùng hiện tại từ session
     */
    protected function loadCurrentUser()
    {
        if ($this->isInstalled && $this->session->has('user_id')) {
            $userId = (int) $this->session->get('user_id');

            if ($userId > 0) {
                $this->currentUser = $this->userModel->find($userId);

                // Nếu không tìm thấy người dùng hoặc không hoạt động, đăng xuất họ
                if (empty($this->currentUser) || $this->currentUser['status'] !== 'active') {
                    $this->session->remove(['user_id', 'username', 'role']);
                    $this->currentUser = null;

                    // Tạo lại ID phiên cho bảo mật
                    $this->session->regenerate(true);
                }
            }
        }
    }

    /**
     * Chia sẻ dữ liệu chung với tất cả các view
     */
    protected function shareCommonData()
    {
        // Dữ liệu chung cho tất cả các view
        if ($this->isInstalled) {
            try {
                // Tải danh mục (với bộ nhớ đệm)
                $categoryModel = new CategoryModel();
                $categories = cache('categories') ?? $categoryModel->findAll();

                if (empty(cache('categories'))) {
                    cache()->save('categories', $categories, 300); // Lưu trong bộ nhớ đệm 5 phút
                }

                // Tải danh sách quốc gia
                $storyModel = new \App\Models\StoryModel();
                $countries = cache('countries') ?? $storyModel->getCountriesWithCount();

                if (empty(cache('countries'))) {
                    cache()->save('countries', $countries, 300); // Lưu trong bộ nhớ đệm 5 phút
                }

                // Lấy cài đặt trang web
                $settings = $this->getSettings();

                // Chuẩn bị thông báo flash
                $flashMessages = [];

                if ($this->session->getFlashdata('success')) {
                    $flashMessages['success'] = $this->session->getFlashdata('success');
                }

                if ($this->session->getFlashdata('error')) {
                    $flashMessages['error'] = $this->session->getFlashdata('error');
                }

                if ($this->session->getFlashdata('warning')) {
                    $flashMessages['warning'] = $this->session->getFlashdata('warning');
                }

                if ($this->session->getFlashdata('info')) {
                    $flashMessages['info'] = $this->session->getFlashdata('info');
                }

                // Bao gồm thông báo chuyển đổi bookmark nếu có
                $bookmarkMessage = $this->session->getFlashdata('bookmark_message');

                // Chia sẻ dữ liệu với các view
                $this->viewData = [
                    'current_user' => $this->currentUser,
                    'categories' => $categories,
                    'countries' => $countries,
                    'settings' => $settings,
                    'current_url' => current_url(),
                    'is_installed' => $this->isInstalled,
                    'flash_messages' => $flashMessages,
                    'bookmark_message' => $bookmarkMessage
                ];
            } catch (\Exception $e) {
                log_message('error', 'Error loading common data: ' . $e->getMessage());

                // Tập dữ liệu tối thiểu cho các trường hợp lỗi
                $this->viewData = [
                    'current_url' => current_url(),
                    'is_installed' => $this->isInstalled
                ];
            }
        } else {
            // Dữ liệu cơ bản cho quá trình cài đặt
            $this->viewData = [
                'current_url' => current_url(),
                'is_installed' => $this->isInstalled
            ];
        }
    }

    /**
     * Lấy cài đặt từ cơ sở dữ liệu với bộ nhớ đệm
     */
    protected function getSettings()
    {
        // Trả về cài đặt đã lưu trong bộ nhớ đệm nếu có
        if (self::$settingsCache !== null) {
            return self::$settingsCache;
        }

        // Kiểm tra bộ nhớ đệm
        $cachedSettings = cache('site_settings');
        if ($cachedSettings !== null) {
            self::$settingsCache = $cachedSettings;
            return $cachedSettings;
        }

        // Cài đặt mặc định để dự phòng
        $defaultSettings = [
            'site_name' => 'Web Truyện Hay',
            'site_description' => 'Trang web truyện hay, cập nhật thông tin truyện mới nhất',
            'story_title_template' => '[title] - [year] | [country]',
            'story_description_template' => 'Truyện [title] [year] - [country] thuộc thể loại [categories]. Truyện do [author] đánh giá.',
            'chapter_title_template' => 'Chương [number]: [title] - [story_title]',
            'chapter_description_template' => 'Đọc chương [number]: [title] của truyện [story_title]',
            'default_meta_title' => 'Đọc truyện online - Web truyện hay',
            'default_meta_description' => 'Đọc truyện online, truyện chữ, truyện full, truyện hay, truyện hot, truyện mới cập nhật',
            'default_meta_keywords' => 'đọc truyện, truyện online, truyện hay, truyện chữ, truyện full'
        ];

        if (!$this->isInstalled) {
            return $defaultSettings;
        }

        try {
            // Sử dụng SettingsModel để lấy cài đặt
            $settings = $this->settingsModel->getAllSettings();

            if (empty($settings)) {
                return $defaultSettings;
            }

            // Kết hợp cài đặt mặc định với cài đặt từ DB để đảm bảo tất cả các khóa tồn tại
            $settings = array_merge($defaultSettings, $settings);

            // Lưu cài đặt vào bộ nhớ đệm
            cache()->save('site_settings', $settings, 3600); // Lưu trong bộ nhớ đệm 1 giờ
            self::$settingsCache = $settings;

            return $settings;
        } catch (\Exception $e) {
            log_message('error', 'Error loading settings: ' . $e->getMessage());
            return $defaultSettings;
        }
    }

    /**
     * Xóa bộ nhớ đệm cài đặt
     */
    protected function clearSettingsCache()
    {
        self::$settingsCache = null;
        cache()->delete('site_settings');
        cache()->delete('categories');
        cache()->delete('countries');
    }

    /**
     * Hiển thị view với dữ liệu chung và bộ nhớ đệm tối ưu
     */
    protected function renderView(string $view, array $data = [])
    {
        // Kết hợp dữ liệu chung với dữ liệu view
        $mergedData = array_merge($this->viewData, $data);

        // Kiểm tra xem đây có phải là yêu cầu AJAX không
        $isAjaxRequest = $this->request->isAJAX();

        // Đối với yêu cầu AJAX, chỉ trả về nội dung view mà không có layout
        if ($isAjaxRequest) {
            // Nếu đây là yêu cầu AJAX và view bao gồm layout,
            // chúng ta cần đặt cờ để ngăn chặn việc hiển thị layout
            $mergedData['ajax_request'] = true;

            // Hiển thị view
            return view($view, $mergedData);
        }

        // Đối với yêu cầu thông thường, hiển thị với layout như bình thường
        return view($view, $mergedData);
    }

    /**
     * Kiểm tra xem người dùng đã đăng nhập chưa
     */
    protected function isLoggedIn()
    {
        return !empty($this->currentUser);
    }

    /**
     * Kiểm tra xem người dùng có phải là admin (role 2) hoặc founder (role 3) không
     */
    protected function isAdmin()
    {
        if (empty($this->currentUser)) {
            return false;
        }

        return $this->currentUser['role'] >= 2; // Admin (2) hoặc Founder (3)
    }

    /**
     * Kiểm tra xem người dùng có phải là founder (role 3) không
     */
    protected function isFounder()
    {
        if (empty($this->currentUser)) {
            return false;
        }

        return $this->currentUser['role'] == 3; // Founder (3)
    }

    /**
     * Kiểm tra xem người dùng có ít nhất là contributor (role 1) không
     */
    protected function isContributor()
    {
        if (empty($this->currentUser)) {
            return false;
        }

        return $this->currentUser['role'] >= 1; // Contributor (1), Admin (2), hoặc Founder (3)
    }

    /**
     * Kiểm tra xem người dùng có vai trò bằng hoặc cao hơn vai trò yêu cầu không
     *
     * @param int $requiredRole Vai trò tối thiểu yêu cầu (1=Contributor, 2=Admin, 3=Founder)
     * @return bool True nếu người dùng có vai trò yêu cầu hoặc cao hơn
     */
    protected function hasRole($requiredRole)
    {
        if (empty($this->currentUser)) {
            return false;
        }

        return $this->currentUser['role'] >= $requiredRole;
    }

    /**
     * Chuyển hướng đến trang đăng nhập nếu chưa đăng nhập
     */
    protected function requireLogin()
    {
        if (!$this->isLoggedIn()) {
            // Ghi log về nỗ lực truy cập trái phép
            if (isset($this->logModel)) {
                $this->logModel->warning('Unauthorized access attempt', [
                    'ip' => $this->request->getIPAddress(),
                    'uri' => $this->request->getUri(),
                    'user_agent' => $this->request->getUserAgent()
                ]);
            }

            $this->session->setFlashdata('error', 'Vui lòng đăng nhập để tiếp tục.');
            return redirect()->to(base_url('login?redirect=' . current_url()));
        }

        return true;
    }

    /**
     * Chuyển hướng đến trang chủ nếu không phải admin hoặc founder
     */
    protected function requireAdmin()
    {
        // Kiểm tra đăng nhập trước
        $loginCheck = $this->requireLogin();
        if ($loginCheck !== true) {
            return $loginCheck;
        }

        if (!$this->isAdmin()) {
            // Ghi log về nỗ lực truy cập admin trái phép
            if (isset($this->logModel)) {
                $this->logModel->warning('Unauthorized admin access attempt', [
                    'user_id' => $this->currentUser['id'] ?? null,
                    'username' => $this->currentUser['username'] ?? 'unknown',
                    'ip' => $this->request->getIPAddress(),
                    'uri' => $this->request->getUri()
                ]);
            }

            $this->session->setFlashdata('error', 'Bạn không có quyền truy cập trang này.');
            return redirect()->to(base_url());
        }

        return true;
    }

    /**
     * Chuyển hướng đến trang chủ nếu không phải founder
     */
    protected function requireFounder()
    {
        // Kiểm tra đăng nhập trước
        $loginCheck = $this->requireLogin();
        if ($loginCheck !== true) {
            return $loginCheck;
        }

        if (!$this->isFounder()) {
            // Ghi log về nỗ lực truy cập founder trái phép
            if (isset($this->logModel)) {
                $this->logModel->warning('Unauthorized founder access attempt', [
                    'user_id' => $this->currentUser['id'] ?? null,
                    'username' => $this->currentUser['username'] ?? 'unknown',
                    'ip' => $this->request->getIPAddress(),
                    'uri' => $this->request->getUri()
                ]);
            }

            $this->session->setFlashdata('error', 'Bạn không có quyền Người sáng lập để truy cập trang này.');
            return redirect()->to(base_url());
        }

        return true;
    }

    /**
     * Yêu cầu cấp độ vai trò tối thiểu để truy cập tài nguyên
     *
     * @param int $requiredRole Vai trò tối thiểu yêu cầu (1=Contributor, 2=Admin, 3=Founder)
     * @return bool|redirect True nếu được phép, phản hồi chuyển hướng nếu không
     */
    protected function requireRole($requiredRole)
    {
        // Kiểm tra đăng nhập trước
        $loginCheck = $this->requireLogin();
        if ($loginCheck !== true) {
            return $loginCheck;
        }

        if (!$this->hasRole($requiredRole)) {
            // Ghi log về nỗ lực truy cập vai trò trái phép
            if (isset($this->logModel)) {
                $this->logModel->warning('Unauthorized role access attempt', [
                    'user_id' => $this->currentUser['id'] ?? null,
                    'username' => $this->currentUser['username'] ?? 'unknown',
                    'required_role' => $requiredRole,
                    'user_role' => $this->currentUser['role'] ?? 'unknown',
                    'ip' => $this->request->getIPAddress(),
                    'uri' => $this->request->getUri()
                ]);
            }

            $this->session->setFlashdata('error', 'Bạn không có đủ quyền để truy cập trang này.');
            return redirect()->to(base_url());
        }

        return true;
    }

    /**
     * Chuyển hướng đến trang cài đặt nếu chưa cài đặt
     */
    protected function requireInstalled()
    {
        if (!$this->isInstalled) {
            return redirect()->to(base_url('install'));
        }

        return true;
    }

    /**
     * Bảo vệ khỏi chế độ bảo trì
     */
    protected function checkMaintenanceMode()
    {
        if (!$this->isInstalled) {
            return true;
        }

        $settings = $this->getSettings();

        // Kiểm tra xem chế độ bảo trì có bật và người dùng không phải admin
        if (isset($settings['maintenance_mode']) && $settings['maintenance_mode'] === 'on' && !$this->isAdmin()) {
            return view('maintenance');
        }

        return true;
    }

    /**
     * Định dạng ngày thành dạng đọc được
     */
    protected function formatDate($date, $format = 'd/m/Y H:i')
    {
        if (empty($date)) {
            return '';
        }

        return date($format, strtotime($date));
    }

    /**
     * Tính thời gian trôi qua từ một ngày
     */
    protected function timeAgo($datetime, $full = false)
    {
        $now = new \DateTime;
        $ago = new \DateTime($datetime);
        $diff = $now->diff($ago);

        $diff->w = floor($diff->d / 7);
        $diff->d -= $diff->w * 7;

        $string = [
            'y' => 'năm',
            'm' => 'tháng',
            'w' => 'tuần',
            'd' => 'ngày',
            'h' => 'giờ',
            'i' => 'phút',
            's' => 'giây',
        ];

        foreach ($string as $k => &$v) {
            if ($diff->$k) {
                $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? '' : '');
            } else {
                unset($string[$k]);
            }
        }

        if (!$full) $string = array_slice($string, 0, 1);
        return $string ? implode(', ', $string) . ' trước' : 'vừa xong';
    }

    /**
     * Kiểm tra xem người dùng hiện tại có sở hữu tài nguyên không
     *
     * @param string $model Model để sử dụng (ví dụ: 'StoryModel')
     * @param int $resourceId ID của tài nguyên cần kiểm tra
     * @param string $ownerColumn Cột chỉ ra quyền sở hữu (mặc định: 'uploader_id')
     * @return bool True nếu người dùng sở hữu tài nguyên, ngược lại false
     */
    protected function isResourceOwner($model, $resourceId, $ownerColumn = 'uploader_id')
    {
        if (empty($this->currentUser)) {
            return false;
        }

        // Founder và admin luôn có quyền truy cập tất cả tài nguyên
        if ($this->currentUser['role'] >= 2) {
            return true;
        }

        // Tạo thể hiện model nếu nó không tồn tại
        $modelClass = "\\App\\Models\\{$model}";
        $modelInstance = new $modelClass();

        // Tìm tài nguyên
        $resource = $modelInstance->find($resourceId);
        if (!$resource) {
            return false;
        }

        // Kiểm tra xem người dùng hiện tại có phải là chủ sở hữu không
        return isset($resource[$ownerColumn]) && $resource[$ownerColumn] == $this->currentUser['id'];
    }

    /**
     * Kiểm tra quyền sở hữu tài nguyên và chuyển hướng nếu không phải chủ sở hữu
     *
     * @param string $model Model để sử dụng (ví dụ: 'StoryModel')
     * @param int $resourceId ID của tài nguyên cần kiểm tra
     * @param string $ownerColumn Cột chỉ ra quyền sở hữu (mặc định: 'uploader_id')
     * @return bool|redirect True nếu được phép, phản hồi chuyển hướng nếu không
     */
    protected function requireResourceOwnership($model, $resourceId, $ownerColumn = 'uploader_id')
    {
        // Kiểm tra đăng nhập
        $loginCheck = $this->requireLogin();
        if ($loginCheck !== true) {
            return $loginCheck;
        }

        // Không bypass tự động cho admin, chỉ kiểm tra quyền sở hữu
        if (!$this->isResourceOwner($model, $resourceId, $ownerColumn)) {
            // Log the unauthorized access attempt
            if (isset($this->logModel)) {
                $this->logModel->warning('Unauthorized resource access attempt', [
                    'user_id' => $this->currentUser['id'] ?? null,
                    'username' => $this->currentUser['username'] ?? 'unknown',
                    'model' => $model,
                    'resource_id' => $resourceId,
                    'ip' => $this->request->getIPAddress(),
                    'uri' => $this->request->getUri()
                ]);
            }

            // Nếu là admin/founder, cho phép truy cập nhưng vẫn ghi log
            if ($this->currentUser['role'] >= 2) {
                if (isset($this->logModel)) {
                    $this->logModel->info('Admin/Founder accessing resource', [
                        'user_id' => $this->currentUser['id'],
                        'username' => $this->currentUser['username'],
                        'model' => $model,
                        'resource_id' => $resourceId
                    ]);
                }
                return true;
            }

            // If this is an AJAX request, return JSON
            if ($this->request->isAJAX()) {
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'Bạn không có quyền truy cập tài nguyên này'
                ])->setStatusCode(403);
            }

            // Otherwise, redirect with error message
            $this->session->setFlashdata('error', 'Bạn không có quyền truy cập tài nguyên này');
            return redirect()->back();
        }

        return true;
    }
}
