<?php

namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use App\Models\StoryModel;
use App\Models\LogModel;

class UpdateRecommendedStories extends BaseCommand
{
    /**
     * The Command's Group
     *
     * @var string
     */
    protected $group = 'App';

    /**
     * The Command's Name
     *
     * @var string
     */
    protected $name = 'stories:update-recommended';

    /**
     * The Command's Description
     *
     * @var string
     */
    protected $description = 'Cập nhật danh sách truyện được đề xuất dựa trên hành vi đọc, đánh giá và xu hướng';

    /**
     * The Command's Usage
     *
     * @var string
     */
    protected $usage = 'stories:update-recommended [options]';

    /**
     * The Command's Arguments
     *
     * @var array
     */
    protected $arguments = [];

    /**
     * The Command's Options
     *
     * @var array
     */
    protected $options = [
        '--limit' => 'Số lượng truyện đề xuất tối đa (mặc định: 20)',
        '--min-rating' => 'Đánh giá tối thiểu (mặc định: 3.5)',
        '--recent-days' => 'Số ngày gần đây để ưu tiên (mặc định: 30)',
        '--refresh-rate' => 'Tỷ lệ % cập nhật (50% = đổi 50% danh sách mỗi lần chạy)'
    ];

    /**
     * Actually execute a command.
     *
     * @param array $params
     */
    public function run(array $params)
    {
        CLI::write('Đang cập nhật danh sách truyện được đề xuất...', 'yellow');

        // Lấy các tham số từ command line options
        $limit = $params['limit'] ?? 20;
        $options = [
            'min_rating' => $params['min-rating'] ?? 3.5,
            'recent_days' => $params['recent-days'] ?? 30,
            'refresh_rate' => $params['refresh-rate'] ?? 50
        ];

        try {
            $storyModel = new StoryModel();
            $result = $storyModel->updateRecommendedStories($limit, $options);

            if ($result) {
                // Lấy danh sách truyện đã được cập nhật
                $recommendedStories = $storyModel->where('is_recommended', true)
                                                ->orderBy('rating', 'DESC')
                                                ->find();

                CLI::write('Cập nhật thành công ' . count($recommendedStories) . ' truyện được đề xuất!', 'green');
                CLI::newLine();

                // Hiển thị danh sách truyện đã cập nhật
                $table = [];
                foreach ($recommendedStories as $index => $story) {
                    $table[] = [
                        ($index + 1),
                        $story['title'],
                        number_format($story['rating'], 1) . '/5',
                        $story['views_month'] . ' lượt xem tháng này'
                    ];

                    // Hiển thị tối đa 10 truyện
                    if ($index >= 9) {
                        break;
                    }
                }

                if (!empty($table)) {
                    CLI::write('Top 10 truyện được đề xuất:', 'green');
                    CLI::table($table, ['#', 'Tên truyện', 'Đánh giá', 'Lượt xem tháng']);
                }

                return 0;
            } else {
                CLI::error('Cập nhật danh sách truyện được đề xuất thất bại!');
                return 1;
            }
        } catch (\Exception $e) {
            // Ghi log lỗi
            $logModel = new LogModel();
            $logModel->error('Cập nhật danh sách truyện được đề xuất thất bại', [
                'error' => $e->getMessage(),
                'triggered_by' => 'cronjob',
                'method' => 'CLI'
            ]);

            CLI::error('Cập nhật danh sách truyện được đề xuất thất bại: ' . $e->getMessage());
            return 1;
        }
    }
}
