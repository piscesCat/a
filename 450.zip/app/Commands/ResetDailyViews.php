<?php

namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use App\Models\StoryModel;
use App\Models\LogModel;

class ResetDailyViews extends BaseCommand
{
    /**
     * The Command's Group
     *
     * @var string
     */
    protected $group = 'App';

    /**
     * The Command's Name
     *
     * @var string
     */
    protected $name = 'stats:reset-daily';

    /**
     * The Command's Description
     *
     * @var string
     */
    protected $description = 'Reset lượt xem theo ngày của tất cả truyện';

    /**
     * The Command's Usage
     *
     * @var string
     */
    protected $usage = 'stats:reset-daily';

    /**
     * The Command's Arguments
     *
     * @var array
     */
    protected $arguments = [];

    /**
     * The Command's Options
     *
     * @var array
     */
    protected $options = [];

    /**
     * Actually execute a command.
     *
     * @param array $params
     */
    public function run(array $params)
    {
        CLI::write('Đang reset lượt xem hàng ngày...', 'yellow');

        try {
            $storyModel = new StoryModel();
            $result = $storyModel->resetDailyViews();

            // Ghi log hoạt động
            $logModel = new LogModel();
            $logModel->info('Reset lượt xem theo ngày', [
                'triggered_by' => 'cronjob',
                'method' => 'CLI'
            ]);

            CLI::write('Reset lượt xem hàng ngày thành công!', 'green');
            return 0;
        } catch (\Exception $e) {
            // Ghi log lỗi
            $logModel = new LogModel();
            $logModel->error('Reset lượt xem theo ngày thất bại', [
                'error' => $e->getMessage(),
                'triggered_by' => 'cronjob',
                'method' => 'CLI'
            ]);

            CLI::error('Reset lượt xem hàng ngày thất bại: ' . $e->getMessage());
            return 1;
        }
    }
}
