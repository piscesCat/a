<?php

namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use App\Models\StoryModel;
use App\Models\LogModel;

class ResetMonthlyViews extends BaseCommand
{
    /**
     * The Command's Group
     *
     * @var string
     */
    protected $group = 'App';

    /**
     * The Command's Name
     *
     * @var string
     */
    protected $name = 'stats:reset-monthly';

    /**
     * The Command's Description
     *
     * @var string
     */
    protected $description = 'Reset lượt xem theo tháng của tất cả truyện';

    /**
     * The Command's Usage
     *
     * @var string
     */
    protected $usage = 'stats:reset-monthly';

    /**
     * The Command's Arguments
     *
     * @var array
     */
    protected $arguments = [];

    /**
     * The Command's Options
     *
     * @var array
     */
    protected $options = [];

    /**
     * Actually execute a command.
     *
     * @param array $params
     */
    public function run(array $params)
    {
        CLI::write('Đang reset lượt xem hàng tháng...', 'yellow');

        try {
            $storyModel = new StoryModel();
            $result = $storyModel->resetMonthlyViews();

            // Ghi log hoạt động
            $logModel = new LogModel();
            $logModel->info('Reset lượt xem theo tháng', [
                'triggered_by' => 'cronjob',
                'method' => 'CLI'
            ]);

            CLI::write('Reset lượt xem hàng tháng thành công!', 'green');
            return 0;
        } catch (\Exception $e) {
            // Ghi log lỗi
            $logModel = new LogModel();
            $logModel->error('Reset lượt xem theo tháng thất bại', [
                'error' => $e->getMessage(),
                'triggered_by' => 'cronjob',
                'method' => 'CLI'
            ]);

            CLI::error('Reset lượt xem hàng tháng thất bại: ' . $e->getMessage());
            return 1;
        }
    }
}
