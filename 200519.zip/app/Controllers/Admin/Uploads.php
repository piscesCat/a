<?php
namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\SettingsModel;
use App\Models\LogModel;
use App\Libraries\ImgurClient;

class Uploads extends BaseController
{
    protected $logModel;
    protected $settingsModel;
    protected $imgurClient;

    public function __construct()
    {
        $this->logModel = new LogModel();
        $this->settingsModel = new SettingsModel();
        $this->imgurClient = new ImgurClient();
    }

    /**
     * Show upload manager page
     */
    public function index()
    {
        // Require admin role
        $check = $this->requireAdmin();
        if ($check !== true) {
            return $check;
        }

        // Get upload settings
        $settings = [
            'imgur_client_id' => $this->settingsModel->getSetting('imgur_client_id', ''),
            'imgur_enabled' => $this->settingsModel->getSetting('imgur_enabled', 'off'),
            'max_upload_size' => $this->settingsModel->getSetting('max_upload_size', '5'),
            'allowed_file_types' => $this->settingsModel->getSetting('allowed_file_types', 'jpg,jpeg,png,gif'),
        ];

        return $this->renderView('admin/uploads/index.html', [
            'title' => 'Quản lý uploads',
            'settings' => $settings
        ]);
    }

    /**
     * Update upload settings
     */
    public function saveSettings()
    {
        // Require admin role
        $check = $this->requireAdmin();
        if ($check !== true) {
            return $check;
        }

        // Check if the user is a Founder
        if (!$this->isFounder()) {
            return redirect()->to('/admin/uploads')
                ->with('error', 'Chỉ người sáng lập mới có quyền thay đổi cài đặt upload');
        }

        // Update settings
        $this->settingsModel->updateSetting('imgur_client_id', $this->request->getPost('imgur_client_id'));
        $this->settingsModel->updateSetting('imgur_enabled', $this->request->getPost('imgur_enabled', 'off'));
        $this->settingsModel->updateSetting('max_upload_size', $this->request->getPost('max_upload_size', '5'));
        $this->settingsModel->updateSetting('allowed_file_types', $this->request->getPost('allowed_file_types', 'jpg,jpeg,png,gif'));

        // Log the action
        $this->logModel->info('Cập nhật cài đặt upload', [
            'user_id' => $this->currentUser['id'],
            'ip' => $this->request->getIPAddress()
        ]);

        return redirect()->to('/admin/uploads')
            ->with('success', 'Cài đặt upload đã được cập nhật');
    }

    /**
     * Handle image upload from editor
     */
    public function uploadImage()
    {
        // Require contributor role at minimum
        $check = $this->requireRole(1); // 1 = Contributor
        if ($check !== true) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Không có quyền upload'
            ]);
        }

        // Get the image file
        $file = $this->request->getFile('image');
        if (!$file || !$file->isValid()) {
            // Kiểm tra nếu có URL được cung cấp (cho upload từ URL)
            $url = $this->request->getPost('url');
            if (!empty($url) && filter_var($url, FILTER_VALIDATE_URL)) {
                // Upload từ URL (chỉ hỗ trợ Imgur)
                $uploadType = $this->request->getPost('upload_type') ?? 'imgur';
                if ($uploadType === 'imgur') {
                    // Kiểm tra nếu Client ID đã được cấu hình
                    $imgurClientId = $this->settingsModel->getSetting('imgur_client_id', '');
                    if (empty($imgurClientId)) {
                        return $this->response->setJSON([
                            'success' => false,
                            'message' => 'Imgur Client ID chưa được cấu hình.'
                        ]);
                    }

                    // Upload từ URL lên Imgur
                    $result = $this->imgurClient->uploadImageFromUrl($url);

                    if ($result['success']) {
                        // Log the upload
                        $this->logModel->info('Upload hình ảnh từ URL lên Imgur thành công', [
                            'user_id' => $this->currentUser['id'],
                            'url' => $url,
                            'imgur_url' => $result['data']['link']
                        ]);

                        return $this->response->setJSON([
                            'success' => true,
                            'data' => [
                                'url' => $result['data']['link'],
                                'delete_hash' => $result['data']['deletehash'] ?? '',
                                'message' => 'Upload từ URL lên Imgur thành công'
                            ]
                        ]);
                    } else {
                        return $this->response->setJSON([
                            'success' => false,
                            'message' => $result['error'] ?? 'Không thể upload ảnh lên Imgur'
                        ]);
                    }
                }
            }

            return $this->response->setJSON([
                'success' => false,
                'message' => 'Không có file hình ảnh hợp lệ hoặc URL không hợp lệ'
            ]);
        }

        // Validate file type
        $mimeType = $file->getMimeType();
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];

        if (!in_array($mimeType, $allowedTypes)) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Loại file không được hỗ trợ. Chỉ chấp nhận: JPG, PNG, GIF, WEBP'
            ]);
        }

        // Validate file size (max 5MB by default)
        $maxSize = (int)$this->settingsModel->getSetting('max_upload_size', '5') * 1024 * 1024;
        if ($file->getSize() > $maxSize) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Kích thước file quá lớn. Tối đa ' . ($maxSize / 1024 / 1024) . 'MB'
            ]);
        }

        // Check which upload type was selected
        $uploadType = $this->request->getPost('upload_type') ?? 'local';

        if ($uploadType === 'imgur') {
            // Kiểm tra nếu Client ID đã được cấu hình
            $imgurClientId = $this->settingsModel->getSetting('imgur_client_id', '');
            if (empty($imgurClientId)) {
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'Imgur Client ID chưa được cấu hình. Vui lòng sử dụng upload local.'
                ]);
            }

            // Read file data
            $fileData = file_get_contents($file->getTempName());

            // Upload to Imgur using ImgurClient
            $result = $this->imgurClient->uploadImage($fileData);

            if ($result['success']) {
                // Log the upload
                $this->logModel->info('Upload hình ảnh lên Imgur thành công', [
                    'user_id' => $this->currentUser['id'],
                    'file_name' => $file->getName(),
                    'file_size' => $file->getSize(),
                    'imgur_url' => $result['data']['link']
                ]);

                return $this->response->setJSON([
                    'success' => true,
                    'data' => [
                        'url' => $result['data']['link'],
                        'delete_hash' => $result['data']['deletehash'] ?? '',
                        'name' => $file->getName(),
                        'message' => 'Upload lên Imgur thành công'
                    ]
                ]);
            } else {
                // Fallback to local upload if Imgur fails
                return $this->uploadToLocal($file);
            }
        } else {
            // Upload to local server
            return $this->uploadToLocal($file);
        }
    }

    /**
     * Upload image to Imgur
     *
     * @param object $file The uploaded file
     * @return string|false The Imgur URL or false if failed
     */
    protected function uploadToImgur($file)
    {
        $clientId = $this->settingsModel->getSetting('imgur_client_id', '');

        if (empty($clientId)) {
            return false;
        }

        // Initialize cURL
        $curl = curl_init();

        // Set cURL options
        curl_setopt_array($curl, [
            CURLOPT_URL => 'https://api.imgur.com/3/image',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => [
                'image' => base64_encode(file_get_contents($file->getTempName()))
            ],
            CURLOPT_HTTPHEADER => [
                'Authorization: Client-ID ' . $clientId
            ],
        ]);

        // Execute cURL request
        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
            log_message('error', 'Imgur API Error: ' . $err);
            return false;
        }

        $data = json_decode($response, true);

        if (isset($data['data']['link'])) {
            return $data['data']['link'];
        }

        if (isset($data['data']['error'])) {
            log_message('error', 'Imgur API Error: ' . $data['data']['error']);
        }

        return false;
    }

    /**
     * Upload image to local server
     *
     * @param object $file The uploaded file
     * @return JSON response
     */
    protected function uploadToLocal($file)
    {
        // Validate file size
        $maxSize = (int)$this->settingsModel->getSetting('max_upload_size', '5') * 1024 * 1024; // Convert MB to bytes
        if ($file->getSize() > $maxSize) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Kích thước file quá lớn. Tối đa ' . ($maxSize / 1024 / 1024) . 'MB'
            ]);
        }

        // Validate file type
        $allowedTypes = explode(',', $this->settingsModel->getSetting('allowed_file_types', 'jpg,jpeg,png,gif'));
        $fileExt = $file->getClientExtension();

        if (!in_array(strtolower($fileExt), $allowedTypes)) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Loại file không được hỗ trợ. Chỉ chấp nhận: ' . implode(', ', $allowedTypes)
            ]);
        }

        // Generate a new filename
        $newName = $file->getRandomName();

        // Move the file to the uploads directory
        if ($file->move(FCPATH . 'uploads/images', $newName)) {
            // Generate the URL for the uploaded file
            $uploadUrl = base_url('uploads/images/' . $newName);

            // Log the upload
            $this->logModel->info('Upload hình ảnh thành công', [
                'user_id' => $this->currentUser['id'],
                'file_name' => $newName,
                'file_size' => $file->getSize(),
                'url' => $uploadUrl
            ]);

            return $this->response->setJSON([
                'success' => true,
                'data' => [
                    'url' => $uploadUrl,
                    'name' => $newName,
                    'message' => 'Upload thành công'
                ]
            ]);
        } else {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Không thể upload file. Lỗi: ' . $file->getErrorString()
            ]);
        }
    }

    /**
     * Display all uploaded files
     */
    public function listFiles()
    {
        // Require admin role
        $check = $this->requireAdmin();
        if ($check !== true) {
            return $check;
        }

        $files = [];
        $uploadsDir = FCPATH . 'uploads/images';

        if (is_dir($uploadsDir)) {
            $fileList = scandir($uploadsDir);

            foreach ($fileList as $file) {
                if ($file != '.' && $file != '..' && !is_dir($uploadsDir . '/' . $file)) {
                    $fileInfo = [
                        'name' => $file,
                        'url' => base_url('uploads/images/' . $file),
                        'size' => filesize($uploadsDir . '/' . $file),
                        'date' => date('Y-m-d H:i:s', filemtime($uploadsDir . '/' . $file))
                    ];

                    $files[] = $fileInfo;
                }
            }
        }

        // Sort files by date (newest first)
        usort($files, function($a, $b) {
            return strtotime($b['date']) - strtotime($a['date']);
        });

        return $this->renderView('admin/uploads/list.html', [
            'title' => 'Danh sách uploads',
            'files' => $files
        ]);
    }

    /**
     * Delete an uploaded file
     */
    public function deleteFile()
    {
        // Require admin role
        $check = $this->requireAdmin();
        if ($check !== true) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Không có quyền xóa'
            ]);
        }

        $filename = $this->request->getPost('filename');

        if (empty($filename)) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Tên file không hợp lệ'
            ]);
        }

        // Security check to prevent directory traversal
        $filename = basename($filename);
        $filePath = FCPATH . 'uploads/images/' . $filename;

        if (file_exists($filePath) && is_file($filePath)) {
            if (unlink($filePath)) {
                // Log the deletion
                $this->logModel->info('Xóa file upload', [
                    'user_id' => $this->currentUser['id'],
                    'file_name' => $filename,
                    'ip' => $this->request->getIPAddress()
                ]);

                return $this->response->setJSON([
                    'success' => true,
                    'message' => 'File đã được xóa'
                ]);
            } else {
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'Không thể xóa file'
                ]);
            }
        } else {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'File không tồn tại'
            ]);
        }
    }
}
