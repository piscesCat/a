/**
 * Hệ thống Bookmark
 *
 * Module này xử lý các bookmarks, sử dụng localStorage cho lưu trữ client-side.
 * Các thông tin được tối ưu để tiết kiệm dung lượng lưu trữ.
 */
const ClientBookmark = {
    // Cài đặt mặc định
    config: {
        maxItems: 50,                      // Số lượng bookmark tối đa
        maxStorageMB: 2,                   // Dung lượng tối đa (MB)
        cleanupInterval: 7 * 24 * 60 * 60, // Thời gian tự động dọn dẹp (7 ngày)
        storageKey: 'bookmarks',           // Key để lưu trong localStorage
        lastCleanupKey: 'bookmark_cleanup' // Key lưu thời gian dọn dẹp gần nhất
    },

    /**
     * Khởi tạo hệ thống bookmark
     */
    init: function() {
        // Kiểm tra nếu localStorage khả dụng
        if (!this.isLocalStorageAvailable()) {
            console.warn('localStorage không khả dụng. Bookmarks sẽ không được lưu.');
            return;
        }

        // Khởi tạo localStorage nếu cần
        if (!localStorage.getItem(this.config.storageKey)) {
            localStorage.setItem(this.config.storageKey, JSON.stringify({}));
        }

        // Tối ưu dữ liệu hiện tại để giảm dung lượng
        this.optimizeStorage();

        // Dọn dẹp bookmark cũ nếu cần
        this.performCleanupIfNeeded();
    },

    /**
     * Thêm hoặc chuyển đổi trạng thái bookmark
     *
     * @param {number} storyId - ID của truyện cần đánh dấu
     * @param {object} storyData - Dữ liệu bổ sung của truyện (tiêu đề, v.v.)
     * @param {number|null} chapterId - ID chương (nếu có)
     * @returns {object} Trạng thái của thao tác
     */
    toggle: function(storyId, storyData, chapterId = null) {
        let bookmarks = this.getAll();
        let action = '';
        let message = '';

        if (bookmarks[storyId]) {
            // Xóa bookmark nếu đã tồn tại
            delete bookmarks[storyId];
            action = 'removed';
            message = 'Đã xóa khỏi danh sách bookmark';
        } else {
            // Thêm bookmark mới với dữ liệu tối ưu
            bookmarks[storyId] = this.createOptimizedBookmark(storyId, storyData, chapterId);
            action = 'added';
            message = 'Đã thêm vào danh sách bookmark';

            // Kiểm tra giới hạn lưu trữ sau khi thêm
            this.enforceStorageLimits();
        }

        // Lưu vào localStorage
        this.saveAll(bookmarks);

        return {
            action: action,
            message: message
        };
    },

    /**
     * Tạo bookmark với dữ liệu tối ưu để tiết kiệm dung lượng
     *
     * @param {number} storyId - ID truyện
     * @param {object} storyData - Dữ liệu truyện
     * @param {number|null} chapterId - ID chương
     * @returns {object} Bookmark đã được tối ưu
     */
    createOptimizedBookmark: function(storyId, storyData, chapterId) {
        // Chỉ lưu các thông tin cần thiết: ID, slug và timestamp
        // Các thông tin khác sẽ được truy vấn từ database khi cần
        const bookmark = {
            i: parseInt(storyId),                   // ID (i thay vì id)
            s: (storyData.slug || '').substr(0, 50),    // Lưu slug để truy vấn
            c: chapterId ? parseInt(chapterId) : null,  // Chapter ID
            d: Math.floor(Date.now() / 1000)            // Date (Unix timestamp thay vì ISO string)
        };

        return bookmark;
    },

    /**
     * Cập nhật thông tin chương cho một truyện đã đánh dấu
     *
     * @param {number} storyId - ID truyện
     * @param {number} chapterId - ID chương
     * @returns {boolean} Trạng thái thành công
     */
    updateChapter: function(storyId, chapterId) {
        let bookmarks = this.getAll();

        if (!bookmarks[storyId]) {
            // Nếu truyện chưa được đánh dấu, thêm với thông tin tối thiểu
            bookmarks[storyId] = {
                i: parseInt(storyId),
                c: parseInt(chapterId),
                d: Math.floor(Date.now() / 1000)
            };
            this.saveAll(bookmarks);
            this.enforceStorageLimits();
            return true;
        }

        // Cập nhật ID chương và thời gian
        bookmarks[storyId].c = parseInt(chapterId);
        bookmarks[storyId].d = Math.floor(Date.now() / 1000);

        // Lưu vào localStorage
        this.saveAll(bookmarks);
        return true;
    },

    /**
     * Kiểm tra nếu một truyện đã được đánh dấu
     *
     * @param {number} storyId - ID truyện cần kiểm tra
     * @returns {boolean} True nếu đã đánh dấu
     */
    isBookmarked: function(storyId) {
        const bookmarks = this.getAll();
        return !!bookmarks[storyId];
    },

    /**
     * Lấy một bookmark cụ thể
     *
     * @param {number} storyId - ID truyện
     * @returns {object|null} Dữ liệu bookmark hoặc null
     */
    get: function(storyId) {
        const bookmarks = this.getAll();
        const bookmark = bookmarks[storyId];

        if (!bookmark) return null;

        // Chuyển đổi từ định dạng tối ưu sang định dạng đầy đủ
        return {
            id: bookmark.i || parseInt(storyId),
            slug: bookmark.s || '',
            chapter_id: bookmark.c || null,
            time: bookmark.d ? new Date(bookmark.d * 1000).toISOString() : new Date().toISOString()
        };
    },

    /**
     * Lấy tất cả bookmarks dưới dạng đối tượng
     *
     * @returns {object} Tất cả bookmark
     */
    getAll: function() {
        const data = localStorage.getItem(this.config.storageKey);
        return data ? JSON.parse(data) : {};
    },

    /**
     * Lấy tất cả bookmarks dưới dạng mảng (để hiển thị)
     *
     * @returns {array} Mảng các đối tượng bookmark
     */
    getAllAsArray: function() {
        const bookmarks = this.getAll();
        const result = [];

        for (const id in bookmarks) {
            if (bookmarks.hasOwnProperty(id)) {
                const bookmark = bookmarks[id];
                // Chuyển từ định dạng tối ưu sang định dạng đầy đủ
                // Chỉ trả về thông tin cần thiết, các thông tin khác sẽ được truy vấn từ server
                result.push({
                    id: bookmark.i || parseInt(id),
                    slug: bookmark.s || '',
                    chapter_id: bookmark.c || null,
                    time: bookmark.d ? new Date(bookmark.d * 1000).toISOString() : new Date().toISOString()
                });
            }
        }

        // Sắp xếp theo thời gian gần nhất trước
        return result.sort((a, b) => {
            return new Date(b.time) - new Date(a.time);
        });
    },

    /**
     * Lưu tất cả bookmark vào localStorage
     *
     * @param {object} bookmarks - Đối tượng bookmarks
     */
    saveAll: function(bookmarks) {
        try {
            localStorage.setItem(this.config.storageKey, JSON.stringify(bookmarks));
        } catch (e) {
            console.error('Lỗi khi lưu bookmark:', e);
            // Nếu lỗi do vượt quá dung lượng, giảm số lượng bookmark
            if (e.name === 'QuotaExceededError' || e.name === 'NS_ERROR_DOM_QUOTA_REACHED') {
                this.enforceStorageLimits(true);
            }
        }
    },

    /**
     * Xóa tất cả bookmark
     */
    clearAll: function() {
        localStorage.setItem(this.config.storageKey, JSON.stringify({}));
    },

    /**
     * Xuất bookmarks ra file JSON
     */
    exportBookmarks: function() {
        const bookmarks = this.getAllAsArray(); // Lấy dạng đầy đủ để export
        const dataStr = JSON.stringify(bookmarks, null, 2);
        const dataUri = 'data:application/json;charset=utf-8,' + encodeURIComponent(dataStr);

        const exportFileDefaultName = 'bookmarks-' + new Date().toISOString().slice(0, 10) + '.json';

        const linkElement = document.createElement('a');
        linkElement.setAttribute('href', dataUri);
        linkElement.setAttribute('download', exportFileDefaultName);
        linkElement.click();
    },

    /**
     * Nhập bookmarks từ file JSON
     *
     * @param {File} file - File JSON cần nhập
     * @returns {Promise} Promise với kết quả
     */
    importBookmarks: function(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();

            reader.onload = (e) => {
                try {
                    const importedData = JSON.parse(e.target.result);

                    if (!Array.isArray(importedData) && typeof importedData !== 'object') {
                        throw new Error('Định dạng dữ liệu không hợp lệ');
                    }

                    const currentBookmarks = this.getAll();
                    let count = 0;

                    // Xử lý cả hai định dạng có thể có: mảng hoặc đối tượng
                    if (Array.isArray(importedData)) {
                        importedData.forEach(item => {
                            const storyId = item.id || item.i;
                            if (storyId) {
                                currentBookmarks[storyId] = this.createOptimizedBookmark(
                                    storyId,
                                    {
                                        slug: item.slug || item.s || ''
                                    },
                                    item.chapter_id || item.c || null
                                );
                                count++;
                            }
                        });
                    } else {
                        // Xử lý định dạng đối tượng
                        for (const key in importedData) {
                            if (importedData.hasOwnProperty(key)) {
                                const item = importedData[key];
                                const storyId = parseInt(key);
                                currentBookmarks[storyId] = this.createOptimizedBookmark(
                                    storyId,
                                    {
                                        slug: item.slug || item.s || ''
                                    },
                                    item.chapter_id || item.c || null
                                );
                                count++;
                            }
                        }
                    }

                    this.saveAll(currentBookmarks);
                    this.enforceStorageLimits(); // Đảm bảo không vượt quá giới hạn

                    resolve({
                        success: true,
                        count: count
                    });
                } catch (error) {
                    reject({
                        success: false,
                        error: 'Lỗi khi nhập dữ liệu: ' + error.message
                    });
                }
            };

            reader.onerror = () => {
                reject({
                    success: false,
                    error: 'Không thể đọc tệp dữ liệu'
                });
            };

            reader.readAsText(file);
        });
    },

    /**
     * Thực hiện việc dọn dẹp bookmark cũ nếu cần thiết
     */
    performCleanupIfNeeded: function() {
        const lastCleanup = localStorage.getItem(this.config.lastCleanupKey);
        const now = Math.floor(Date.now() / 1000);

        // Nếu chưa có thời gian dọn dẹp gần nhất hoặc đã quá hạn dọn dẹp
        if (!lastCleanup || (now - parseInt(lastCleanup)) > this.config.cleanupInterval) {
            this.optimizeStorage();
            this.enforceStorageLimits();
            localStorage.setItem(this.config.lastCleanupKey, now.toString());
        }
    },

    /**
     * Tối ưu dữ liệu lưu trữ để giảm dung lượng
     */
    optimizeStorage: function() {
        const bookmarks = this.getAll();
        const optimizedBookmarks = {};

        // Chuyển đổi tất cả bookmark sang định dạng tối ưu
        for (const storyId in bookmarks) {
            if (bookmarks.hasOwnProperty(storyId)) {
                const bookmark = bookmarks[storyId];

                // Nếu đã ở định dạng tối ưu (có trường i), giữ nguyên
                if (bookmark.i !== undefined) {
                    optimizedBookmarks[storyId] = bookmark;
                    continue;
                }

                // Nếu đang ở định dạng cũ, chuyển đổi sang định dạng tối ưu
                optimizedBookmarks[storyId] = this.createOptimizedBookmark(
                    parseInt(storyId),
                    {
                        slug: bookmark.slug || ''
                    },
                    bookmark.chapter_id || null
                );

                // Giữ lại thời gian gốc nếu có
                if (bookmark.time) {
                    try {
                        optimizedBookmarks[storyId].d = Math.floor(new Date(bookmark.time).getTime() / 1000);
                    } catch (e) {
                        // Nếu lỗi, sử dụng thời gian hiện tại
                        optimizedBookmarks[storyId].d = Math.floor(Date.now() / 1000);
                    }
                }
            }
        }

        // Lưu trạng thái đã tối ưu
        this.saveAll(optimizedBookmarks);
    },

    /**
     * Thực thi các giới hạn lưu trữ để không vượt quá dung lượng cho phép
     *
     * @param {boolean} forceReduce - Có bắt buộc giảm dung lượng không
     */
    enforceStorageLimits: function(forceReduce = false) {
        const bookmarks = this.getAll();
        const bookmarkCount = Object.keys(bookmarks).length;

        // Kiểm tra giới hạn số lượng
        if (bookmarkCount > this.config.maxItems || forceReduce) {
            const bookmarksArray = [];

            // Chuyển sang mảng để sắp xếp
            for (const id in bookmarks) {
                if (bookmarks.hasOwnProperty(id)) {
                    const item = bookmarks[id];
                    bookmarksArray.push({
                        id: id,
                        data: item,
                        time: item.d || 0
                    });
                }
            }

            // Sắp xếp theo thời gian, mới nhất trước
            bookmarksArray.sort((a, b) => b.time - a.time);

            // Giữ lại chỉ số lượng tối đa
            const keepCount = forceReduce ? Math.floor(this.config.maxItems * 0.7) : this.config.maxItems;
            const keptBookmarks = {};

            bookmarksArray.slice(0, keepCount).forEach(item => {
                keptBookmarks[item.id] = item.data;
            });

            // Lưu lại danh sách đã giảm
            this.saveAll(keptBookmarks);
        }

        // Kiểm tra dung lượng nếu có thể
        this.checkStorageSize();
    },

    /**
     * Kiểm tra kích thước lưu trữ và giảm nếu cần
     */
    checkStorageSize: function() {
        try {
            // Ước tính kích thước localStorage
            let totalSize = 0;
            for (let i = 0; i < localStorage.length; i++) {
                const key = localStorage.key(i);
                const value = localStorage.getItem(key);
                totalSize += (key.length + value.length) * 2; // Ký tự UTF-16 = 2 byte
            }

            const sizeMB = totalSize / (1024 * 1024);

            // Nếu gần đạt giới hạn, hiển thị thông báo thay vì tự động xóa
            if (sizeMB > this.config.maxStorageMB * 0.9) {
                // Hiển thị thông báo và lựa chọn cho người dùng
                if (window.showStorageWarning) {
                    window.showStorageWarning(sizeMB.toFixed(2));
                } else if (confirm(`Bộ nhớ lưu trữ bookmark gần đầy (${sizeMB.toFixed(2)}MB/${this.config.maxStorageMB}MB). Bạn có muốn xóa các bookmark cũ không?`)) {
                    this.enforceStorageLimits(true);
                }
            }
        } catch (e) {
            console.error('Lỗi khi kiểm tra kích thước lưu trữ:', e);
        }
    },

    /**
     * Kiểm tra liệu localStorage có khả dụng không
     *
     * @returns {boolean} True nếu localStorage khả dụng
     */
    isLocalStorageAvailable: function() {
        try {
            const test = 'test';
            localStorage.setItem(test, test);
            localStorage.removeItem(test);
            return true;
        } catch (e) {
            return false;
        }
    }
};

// Khởi tạo hệ thống bookmark khi trang tải xong
document.addEventListener('DOMContentLoaded', function() {
    ClientBookmark.init();

    // Thêm event listeners cho các nút bookmark nếu tồn tại
    const bookmarkButtons = document.querySelectorAll('.bookmark-button, .js-bookmark-btn');

    bookmarkButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();

            const storyId = parseInt(this.dataset.storyId);
            const chapterId = this.dataset.chapterId ? parseInt(this.dataset.chapterId) : null;
            const storyTitle = this.dataset.storyTitle || '';
            const storySlug = this.dataset.storySlug || '';
            const coverImage = this.dataset.coverImage || '';
            const authorName = this.dataset.authorName || '';

            const result = ClientBookmark.toggle(storyId, {
                title: storyTitle,
                slug: storySlug,
                cover_image: coverImage,
                author_name: authorName
            }, chapterId);

            // Cập nhật giao diện dựa trên kết quả
            if (result.action === 'added') {
                this.classList.add('active');
                this.title = 'Đã lưu vào tủ truyện';
                if (this.querySelector('.bookmark-text')) {
                    this.querySelector('.bookmark-text').textContent = 'Đã lưu';
                }
            } else {
                this.classList.remove('active');
                this.title = 'Lưu vào tủ truyện';
                if (this.querySelector('.bookmark-text')) {
                    this.querySelector('.bookmark-text').textContent = 'Lưu truyện';
                }
            }

            // Hiển thị thông báo nếu có
            if (window.showNotification) {
                window.showNotification(result.message);
            }
        });
    });

    // Khởi tạo trạng thái các nút bookmark
    bookmarkButtons.forEach(button => {
        const storyId = parseInt(button.dataset.storyId);
        if (ClientBookmark.isBookmarked(storyId)) {
            button.classList.add('active');
            button.title = 'Đã lưu vào tủ truyện';
            if (button.querySelector('.bookmark-text')) {
                button.querySelector('.bookmark-text').textContent = 'Đã lưu';
            }
        }
    });
});
