<?php include 'templates/header.php'; ?>

<div class="container mt-4">
    <div class="card">
        <div class="card-header bg-primary text-white">
            <h2>Hướng dẫn cài đặt Cronjob</h2>
        </div>
        <div class="card-body">
            <p class="lead">
                Hệ thống sử dụng nhiều tác vụ tự động được chạy theo lịch để cập nhật dữ liệu và đảm bảo trang web hoạt động hiệu quả.
                Dưới đây là hướng dẫn cài đặt các cronjob cần thiết.
            </p>

            <h3 class="mt-4">Danh sách các Cronjob cần thiết</h3>

            <div class="card mb-3">
                <div class="card-header">
                    1. Cập nhật truyện Hot (UpdateHotStories)
                </div>
                <div class="card-body">
                    <p>Cập nhật danh sách truyện hot dựa vào các tiêu chí như lượt xem, đánh giá, bình luận mới.</p>
                    <pre class="bg-light p-2"><code>0 */3 * * * php /đường/dẫn/đến/index.php commands:update-hot-stories</code></pre>
                </div>
            </div>

            <div class="card mb-3">
                <div class="card-header">
                    2. Cập nhật truyện Đề xuất (UpdateRecommendedStories)
                </div>
                <div class="card-body">
                    <p>Cập nhật danh sách truyện được đề xuất dựa trên thuật toán thông minh.</p>
                    <pre class="bg-light p-2"><code>0 */6 * * * php /đường/dẫn/đến/index.php commands:update-recommended-stories</code></pre>
                </div>
            </div>

            <div class="card mb-3">
                <div class="card-header">
                    3. Cập nhật trạng thái truyện (UpdateStoryStatus)
                </div>
                <div class="card-body">
                    <p>Cập nhật trạng thái hoàn thành/đang tiến hành của truyện dựa vào thời gian cập nhật.</p>
                    <pre class="bg-light p-2"><code>0 0 * * * php /đường/dẫn/đến/index.php commands:update-story-status</code></pre>
                </div>
            </div>

            <div class="card mb-3">
                <div class="card-header">
                    4. Đề xuất truyện nổi bật (SuggestFeaturedStories)
                </div>
                <div class="card-body">
                    <p>Tạo danh sách đề xuất truyện nổi bật cho admin.</p>
                    <pre class="bg-light p-2"><code>0 0 * * 1 php /đường/dẫn/đến/index.php commands:suggest-featured-stories</code></pre>
                </div>
            </div>

            <div class="card mb-3">
                <div class="card-header">
                    5. Reset lượt xem (ResetViews)
                </div>
                <div class="card-body">
                    <p>Reset lượt xem theo ngày, tuần, tháng.</p>
                    <pre class="bg-light p-2"><code>0 0 * * * php /đường/dẫn/đến/index.php commands:reset-daily-views
0 0 * * 0 php /đường/dẫn/đến/index.php commands:reset-weekly-views
0 0 1 * * php /đường/dẫn/đến/index.php commands:reset-monthly-views</code></pre>
                </div>
            </div>

            <div class="card mb-3">
                <div class="card-header">
                    6. Bảo trì hệ thống (Maintenance)
                </div>
                <div class="card-body">
                    <p>Thực hiện các tác vụ bảo trì hệ thống như dọn dẹp file tạm, tối ưu database.</p>
                    <pre class="bg-light p-2"><code>0 3 * * 0 php /đường/dẫn/đến/index.php commands:maintenance</code></pre>
                </div>
            </div>

            <h3 class="mt-4">Cài đặt Cronjob</h3>

            <div class="card mb-3">
                <div class="card-header">
                    Trên Linux/Unix
                </div>
                <div class="card-body">
                    <ol>
                        <li>Đăng nhập vào server qua SSH</li>
                        <li>Mở crontab để chỉnh sửa:
                            <pre class="bg-light p-2 mt-2"><code>crontab -e</code></pre>
                        </li>
                        <li>Thêm các dòng cronjob ở trên, thay thế <code>/đường/dẫn/đến</code> bằng đường dẫn thực tế tới thư mục root của trang web.</li>
                        <li>Lưu và thoát.</li>
                    </ol>
                </div>
            </div>

            <div class="card mb-3">
                <div class="card-header">
                    Trên Shared Hosting
                </div>
                <div class="card-body">
                    <ol>
                        <li>Đăng nhập vào Control Panel (cPanel, Plesk, DirectAdmin...)</li>
                        <li>Tìm phần quản lý Cronjob/Scheduled Tasks</li>
                        <li>Thêm các cronjob theo hướng dẫn trên giao diện, sử dụng các lệnh đã cung cấp.</li>
                    </ol>
                </div>
            </div>

            <div class="card mb-3">
                <div class="card-header">
                    Trên Windows Server
                </div>
                <div class="card-body">
                    <ol>
                        <li>Sử dụng Task Scheduler để tạo các tác vụ định kỳ</li>
                        <li>Cho mỗi tác vụ, sử dụng lệnh tương ứng:
                            <pre class="bg-light p-2 mt-2"><code>C:\path\to\php.exe C:\path\to\index.php commands:tên-lệnh</code></pre>
                        </li>
                    </ol>
                </div>
            </div>

            <div class="card mb-3">
                <div class="card-header bg-info text-white">
                    Sử dụng Master Cronjob (Đề xuất)
                </div>
                <div class="card-body">
                    <p>Để đơn giản hóa việc quản lý, bạn có thể sử dụng master cronjob để tự động chạy tất cả các tác vụ cần thiết:</p>
                    <pre class="bg-light p-2"><code>* * * * * php /đường/dẫn/đến/index.php commands:master-cron</code></pre>
                    <p>MasterCron sẽ tự động quản lý việc chạy các tác vụ con theo lịch phù hợp, giảm thiểu số lượng cronjob cần cài đặt.</p>
                </div>
            </div>
        </div>
        <div class="card-footer">
            <a href="index.php" class="btn btn-secondary">Quay lại</a>
        </div>
    </div>
</div>

<?php include 'templates/footer.php'; ?>
