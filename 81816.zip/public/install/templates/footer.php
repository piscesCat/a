</div>
                </div>

                <div class="text-center text-muted mb-4">
                    <small>&copy; <?= date('Y') ?> Web Truyện - Phát triển bởi Web Truyện Team</small>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>
</html>
