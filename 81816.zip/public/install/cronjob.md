# Hướng dẫn cài đặt Cronjob

Hệ thống sử dụng nhiều tác vụ tự động được chạy theo lịch để cập nhật dữ liệu và đảm bảo trang web hoạt động hiệu quả. Dưới đây là hướng dẫn cài đặt các cronjob cần thiết.

## Danh sách các Cronjob cần thiết

### 1. Cập nhật truyện Hot (UpdateHotStories)
Cập nhật danh sách truyện hot dựa vào các tiêu chí như lượt xem, đánh giá, bình luận mới.
```
0 */3 * * * php /đường/dẫn/đến/index.php commands:update-hot-stories
```

### 2. Cập nhật truyện Đề xuất (UpdateRecommendedStories)
Cập nhật danh sách truyện được đề xuất dựa trên thuật toán thông minh.
```
0 */6 * * * php /đường/dẫn/đến/index.php commands:update-recommended-stories
```

### 3. Cập nhật trạng thái truyện (UpdateStoryStatus)
Cập nhật trạng thái hoàn thành/đang tiến hành của truyện dựa vào thời gian cập nhật.
```
0 0 * * * php /đường/dẫn/đến/index.php commands:update-story-status
```

### 4. Đề xuất truyện nổi bật (SuggestFeaturedStories)
Tạo danh sách đề xuất truyện nổi bật cho admin.
```
0 0 * * 1 php /đường/dẫn/đến/index.php commands:suggest-featured-stories
```

### 5. Reset lượt xem (ResetViews)
Reset lượt xem theo ngày, tuần, tháng.
```
0 0 * * * php /đường/dẫn/đến/index.php commands:reset-daily-views
0 0 * * 0 php /đường/dẫn/đến/index.php commands:reset-weekly-views
0 0 1 * * php /đường/dẫn/đến/index.php commands:reset-monthly-views
```

### 6. Bảo trì hệ thống (Maintenance)
Thực hiện các tác vụ bảo trì hệ thống như dọn dẹp file tạm, tối ưu database.
```
0 3 * * 0 php /đường/dẫn/đến/index.php commands:maintenance
```

## Cài đặt Cronjob

### Trên Linux/Unix

1. Đăng nhập vào server qua SSH
2. Mở crontab để chỉnh sửa:
   ```
   crontab -e
   ```
3. Thêm các dòng cronjob ở trên, thay thế `/đường/dẫn/đến` bằng đường dẫn thực tế tới thư mục root của trang web.
4. Lưu và thoát.

### Trên Shared Hosting

1. Đăng nhập vào Control Panel (cPanel, Plesk, DirectAdmin...)
2. Tìm phần quản lý Cronjob/Scheduled Tasks
3. Thêm các cronjob theo hướng dẫn trên giao diện, sử dụng các lệnh đã cung cấp.

### Trên Windows Server

1. Sử dụng Task Scheduler để tạo các tác vụ định kỳ
2. Cho mỗi tác vụ, sử dụng lệnh tương ứng:
   ```
   C:\path\to\php.exe C:\path\to\index.php commands:tên-lệnh
   ```

## Sử dụng Master Cronjob

Để đơn giản hóa việc quản lý, bạn có thể sử dụng master cronjob để tự động chạy tất cả các tác vụ cần thiết:

```
* * * * * php /đường/dẫn/đến/index.php commands:master-cron
```

MasterCron sẽ tự động quản lý việc chạy các tác vụ con theo lịch phù hợp, giảm thiểu số lượng cronjob cần cài đặt.
