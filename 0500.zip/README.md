# Web Truyện CI4 với PostgreSQL

Hệ thống quản lý truyện xây dựng trên CodeIgniter 4 và PostgreSQL, sử dụng Twig làm template engine.

## Yêu cầu hệ thống

- PHP >= 7.4 hoặc PHP 8.x
- Composer
- PostgreSQL >= 12.0
- PHP extensions: curl, fileinfo, gd, intl, json, mbstring, pgsql, xml

## Cài đặt

1. Clone repository về máy:

```bash
git clone <repository-url> web-truyen
cd web-truyen
```

2. Cài đặt các dependencies bằng Composer:

```bash
composer install
```

3. Tạo file `.env` từ file `.env.example`:

```bash
cp .env.example .env
```

4. Cấu hình kết nối database trong file `.env`:

```ini
database.default.hostname = localhost
database.default.database = web_truyen
database.default.username = postgres
database.default.password = your_password
database.default.DBDriver = Postgre
database.default.port = 5432
```

5. Tạo database và nhập schema:

```bash
# Tạo database (sử dụng PostgreSQL)
psql -U postgres -c "CREATE DATABASE web_truyen;"

# Import schema từ file database/schema.sql
psql -U postgres -d web_truyen -f database/schema.sql
```

### Sử dụng Docker cho PostgreSQL (tùy chọn)

Nếu bạn không có sẵn PostgreSQL trên máy, bạn có thể sử dụng Docker:

```bash
# Chạy PostgreSQL container
docker run --name postgres -e POSTGRES_PASSWORD=postgres -e POSTGRES_USER=postgres -p 5432:5432 -d postgres:13

# Tạo database
docker exec -it postgres psql -U postgres -c "CREATE DATABASE web_truyen;"

# Import schema
docker exec -i postgres psql -U postgres -d web_truyen < database/schema.sql
```

Sau đó, cấu hình `.env` với thông tin kết nối Docker:

```ini
database.default.hostname = localhost
database.default.database = web_truyen
database.default.username = postgres
database.default.password = postgres
database.default.DBDriver = Postgre
database.default.port = 5432
```

6. Đặt quyền truy cập cho thư mục writable:

```bash
chmod -R 777 writable/
```

7. Khởi động server development:

```bash
php spark serve
```

Sau khi khởi động, truy cập hệ thống qua URL: `http://localhost:8080/install` để tiến hành cài đặt.

## Cấu trúc hệ thống

- **app/Config**: Chứa các file cấu hình
  - **Routes.php**: Định nghĩa các routes của hệ thống
  - **Database.php**: Cấu hình kết nối database

- **app/Controllers**: Chứa các controller
  - **Admin/**: Controller cho phần quản trị
  - **BaseController.php**: Controller cơ sở

- **app/Models**: Chứa các model tương tác với database

- **app/Views**: Chứa các file giao diện (sử dụng Twig)
  - **admin/**: Giao diện phần quản trị
  - **layouts/**: Layout chung
  - **story/**: Giao diện hiển thị truyện
  - **chapter/**: Giao diện hiển thị chương

- **public**: Thư mục public, chứa assets (css, js, images)

- **database**: Chứa file schema.sql để khởi tạo database

## Tính năng chính

1. **Người dùng**:
   - Đọc truyện theo thể loại, quốc gia, năm phát hành
   - Tìm kiếm truyện
   - Xem bảng xếp hạng truyện
   - Đánh dấu truyện yêu thích (bookmark)
   - Bình luận truyện (không cần đăng nhập)

2. **Quản trị viên**:
   - Quản lý truyện, chương, thể loại, quốc gia
   - Quản lý bình luận
   - Quản lý người dùng
   - Cài đặt hệ thống
   - Xem báo cáo và logs
   - Quản lý uploads
   - Tùy chỉnh giao diện qua template và CSS

## Hướng dẫn sử dụng PostgreSQL với CI4

CodeIgniter 4 hỗ trợ PostgreSQL thông qua database driver Postgre. Để sử dụng PostgreSQL hiệu quả trong CI4, bạn cần:

1. **Cài đặt PHP extension**: Đảm bảo PHP extension `pgsql` đã được cài đặt:
   ```bash
   sudo apt-get install php-pgsql  # Ubuntu/Debian
   ```

2. **Cấu hình kết nối** trong `/app/Config/Database.php` hoặc trong file `.env`:
   ```php
   public $default = [
       'DSN'      => '',
       'hostname' => 'localhost',
       'username' => 'postgres',
       'password' => 'your_password',
       'database' => 'web_truyen',
       'DBDriver' => 'Postgre',
       'DBPrefix' => '',
       'pConnect' => false,
       'DBDebug'  => (ENVIRONMENT !== 'production'),
       'charset'  => 'utf8',
       'DBCollat' => 'utf8_general_ci',
       'swapPre'  => '',
       'encrypt'  => false,
       'compress' => false,
       'strictOn' => false,
       'failover' => [],
       'port'     => 5432,
   ];
   ```

3. **Sử dụng Query Builder** trong model:
   ```php
   $builder = $this->db->table('stories');
   $query = $builder->select('stories.*, authors.name as author_name')
               ->join('authors', 'authors.id = stories.author_id')
               ->where('stories.status', 'active')
               ->get();
   return $query->getResultArray();
   ```

4. **Làm việc với JSON** trong PostgreSQL:
   ```php
   // Truy vấn dữ liệu JSON
   $builder->where("settings->'theme'", '"dark"');

   // Cập nhật dữ liệu JSON
   $builder->set("settings", "jsonb_set(settings, '{theme}', '\"light\"')", false);
   ```

5. **Tận dụng Full-Text Search** của PostgreSQL:
   ```php
   // Tìm kiếm văn bản đầy đủ
   $builder->select('*')
           ->where("to_tsvector('english', title || ' ' || description) @@ to_tsquery('english', ?)", [$searchTerm]);
   ```

## Customization

Hệ thống cho phép tùy chỉnh giao diện thông qua các thiết lập trong trang quản trị:

1. **Templates**: Tùy chỉnh mã HTML của các thành phần
2. **Styles**: Tùy chỉnh CSS và JavaScript
3. **SEO Settings**: Tùy chỉnh meta tags, title templates

## Thuật toán phân loại truyện "Hot"

Hệ thống sử dụng một thuật toán tổng hợp để xác định các truyện "hot", bao gồm:
- Lượt xem gần đây (trong 7 ngày qua)
- Số lượng bình luận
- Lượt thích/bookmark
- Xếp hạng trung bình
- Thời gian cập nhật

Formula tính điểm "hot":
```
hot_score = (views_last_7_days * 0.5) + (comments_count * 2) + (bookmarks_count * 3) + (avg_rating * 10) + recency_bonus
```

Trong đó `recency_bonus` được tính dựa trên thời gian cập nhật gần nhất.

## Ghi chú

- Sử dụng PostgreSQL thay vì MySQL giúp tận dụng các tính năng mạnh mẽ như JSON type, Full-text search...
- Hệ thống sử dụng Twig template engine để tách biệt logic và giao diện
- Cache được sử dụng để tối ưu hiệu suất cho các truy vấn phổ biến
- Admin có thể bình luận trực tiếp trong truyện với tên màu đỏ để phân biệt

## Hỗ trợ & Liên hệ

Vui lòng tạo issue trên GitHub repository nếu bạn gặp vấn đề hoặc có câu hỏi.
