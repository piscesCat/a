<?php

namespace App\Models;

use CodeIgniter\Model;

class TokenModel extends Model
{
    protected $table = 'tokens';
    protected $primaryKey = 'id';
    protected $allowedFields = ['user_id', 'token', 'expires_at', 'created_at'];

    /**
     * Tạo token mới cho người dùng
     */
    public function createToken($userId)
    {
        // Tạo token ngẫu nhiên
        $token = bin2hex(random_bytes(32));

        // Thời gian hết hạn (30 ngày)
        $expiresAt = date('Y-m-d H:i:s', strtotime('+30 days'));

        // Lưu vào database
        $data = [
            'user_id' => $userId,
            'token' => $token,
            'expires_at' => $expiresAt,
            'created_at' => date('Y-m-d H:i:s')
        ];

        $this->insert($data);

        return $token;
    }

    /**
     * Lấy thông tin người dùng từ token
     */
    public function getUserFromToken($token)
    {
        // Tìm token trong database
        $tokenData = $this->where('token', $token)
                         ->where('expires_at >', date('Y-m-d H:i:s'))
                         ->first();

        if (!$tokenData) {
            return null;
        }

        // Lấy thông tin người dùng
        $userModel = new UserModel();
        $user = $userModel->find($tokenData['user_id']);

        if (!$user) {
            return null;
        }

        return $user;
    }

    /**
     * Xóa token
     */
    public function deleteToken($token)
    {
        return $this->where('token', $token)->delete();
    }

    /**
     * Xóa tất cả token của người dùng
     */
    public function deleteUserTokens($userId)
    {
        return $this->where('user_id', $userId)->delete();
    }

    /**
     * Xóa token hết hạn
     */
    public function deleteExpiredTokens()
    {
        return $this->where('expires_at <', date('Y-m-d H:i:s'))->delete();
    }
}
