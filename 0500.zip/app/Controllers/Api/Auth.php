<?php

namespace App\Controllers\Api;

use App\Controllers\BaseController;
use App\Models\UserModel;
use App\Models\TokenModel;

class Auth extends BaseController
{
    protected $userModel;
    protected $tokenModel;

    public function __construct()
    {
        $this->userModel = new UserModel();
        $this->tokenModel = new TokenModel();
    }

    /**
     * API đăng nhập
     */
    public function login()
    {
        // Validate input
        $rules = [
            'username' => 'required',
            'password' => 'required'
        ];

        if (!$this->validate($rules)) {
            return $this->response->setStatusCode(400)->setJSON([
                'success' => false,
                'message' => 'Dữ liệu đăng nhập không hợp lệ',
                'errors' => $this->validator->getErrors()
            ]);
        }

        $data = $this->request->getJSON(true);
        $username = $data['username'];
        $password = $data['password'];

        // Tìm người dùng theo username
        $user = $this->userModel->where('username', $username)->first();

        if (!$user) {
            return $this->response->setStatusCode(401)->setJSON([
                'success' => false,
                'message' => 'Tên đăng nhập hoặc mật khẩu không đúng'
            ]);
        }

        // Kiểm tra trạng thái tài khoản
        if ($user['status'] != 'active') {
            return $this->response->setStatusCode(401)->setJSON([
                'success' => false,
                'message' => 'Tài khoản đã bị khóa'
            ]);
        }

        // Kiểm tra mật khẩu
        if (!password_verify($password, $user['password'])) {
            return $this->response->setStatusCode(401)->setJSON([
                'success' => false,
                'message' => 'Tên đăng nhập hoặc mật khẩu không đúng'
            ]);
        }

        // Tạo token mới
        $token = $this->tokenModel->createToken($user['id']);

        // Trả về thông tin người dùng và token
        return $this->response->setJSON([
            'success' => true,
            'message' => 'Đăng nhập thành công',
            'data' => [
                'user' => [
                    'id' => $user['id'],
                    'username' => $user['username'],
                    'email' => $user['email'],
                    'display_name' => $user['display_name'],
                    'role' => $user['role'],
                    'avatar' => $user['avatar'],
                    'created_at' => $user['created_at']
                ],
                'token' => $token,
                'token_type' => 'Bearer',
                'expires_in' => 30 * 24 * 60 * 60 // 30 days in seconds
            ]
        ]);
    }
}
