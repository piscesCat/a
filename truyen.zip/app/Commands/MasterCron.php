<?php

namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use App\Models\LogModel;

/**
 * Lớp MasterCron thực hiện tất cả các tác vụ cron trong một lần chạy duy nhất
 * Đảm bảo các tác vụ được thực thi theo thứ tự hợp lý và ghi log đầy đủ
 */
class MasterCron extends BaseCommand
{
    /**
     * The Command's Group
     *
     * @var string
     */
    protected $group = 'App';

    /**
     * The Command's Name
     *
     * @var string
     */
    protected $name = 'cron:master';

    /**
     * The Command's Description
     *
     * @var string
     */
    protected $description = 'Thực hiện tất cả các tác vụ cron định kỳ trong một lần chạy duy nhất';

    /**
     * The Command's Usage
     *
     * @var string
     */
    protected $usage = 'cron:master [options]';

    /**
     * The Command's Arguments
     *
     * @var array
     */
    protected $arguments = [];

    /**
     * The Command's Options
     *
     * @var array
     */
    protected $options = [
        '--daily'   => 'Chỉ thực hiện các tác vụ hàng ngày',
        '--weekly'  => 'Chỉ thực hiện các tác vụ hàng tuần',
        '--monthly' => 'Chỉ thực hiện các tác vụ hàng tháng',
        '--cleanup' => 'Chỉ thực hiện dọn dẹp hệ thống',
        '--schedule' => 'Thực hiện các tác vụ dựa trên ngày hiện tại (daily/weekly/monthly tự động)'
    ];

    /**
     * Thực thi command
     *
     * @param array $params
     * @return int Mã trạng thái trả về
     */
    public function run(array $params)
    {
        CLI::write('=== BẮT ĐẦU TÁC VỤ MASTER CRON ===', 'blue');
        CLI::write('Thời gian bắt đầu: ' . date('Y-m-d H:i:s'), 'yellow');

        $startTime = microtime(true);
        $logModel = new LogModel();
        $taskResults = [];
        $errorOccurred = false;

        // Ghi log bắt đầu
        $logModel->info('Bắt đầu Master Cron', [
            'triggered_by' => 'cronjob',
            'method' => 'CLI',
            'date' => date('Y-m-d'),
            'options' => $params
        ]);

        try {
            // Xác định tác vụ nào cần chạy
            $runDaily = isset($params['daily']) || isset($params['schedule']) || (empty($params) || count($params) === 0);
            $runWeekly = isset($params['weekly']) || isset($params['schedule']) || (empty($params) || count($params) === 0);
            $runMonthly = isset($params['monthly']) || isset($params['schedule']) || (empty($params) || count($params) === 0);
            $runCleanup = isset($params['cleanup']) || (empty($params) || count($params) === 0);

            // Nếu dùng schedule, tự động kiểm tra ngày để chạy các tác vụ phù hợp
            if (isset($params['schedule'])) {
                $dayOfWeek = date('N'); // 1 (Thứ 2) đến 7 (Chủ nhật)
                $dayOfMonth = date('j'); // 1-31

                // Nếu là thứ 2, chạy tác vụ tuần
                $runWeekly = ($dayOfWeek == 1);

                // Nếu là ngày đầu tháng, chạy tác vụ tháng
                $runMonthly = ($dayOfMonth == 1);
            }

            // 1. Tác vụ hàng ngày
            if ($runDaily) {
                CLI::write('Đang thực hiện các tác vụ hàng ngày...', 'green');

                // 1.1. Reset lượt xem hàng ngày
                CLI::write('  Đang reset lượt xem hàng ngày...', 'cyan');
                try {
                    $storyModel = new \App\Models\StoryModel();
                    $result = $storyModel->resetDailyViews();
                    $taskResults['reset_daily'] = [
                        'success' => (bool)$result,
                        'message' => 'Reset lượt xem hàng ngày ' . ((bool)$result ? 'thành công' : 'thất bại')
                    ];
                    CLI::write('  Reset lượt xem hàng ngày ' . ((bool)$result ? 'thành công' : 'thất bại'), 'green');
                } catch (\Exception $e) {
                    $taskResults['reset_daily'] = [
                        'success' => false,
                        'message' => 'Lỗi: ' . $e->getMessage()
                    ];
                    $errorOccurred = true;
                    CLI::write('  Lỗi: ' . $e->getMessage(), 'red');
                }

                // 1.2. Cập nhật trạng thái HOT cho truyện
                CLI::write('  Đang cập nhật trạng thái HOT cho truyện...', 'cyan');
                try {
                    $storyModel = new \App\Models\StoryModel();
                    $result = $storyModel->updateHotStories();
                    $taskResults['update_hot'] = [
                        'success' => (bool)$result,
                        'message' => 'Cập nhật trạng thái HOT ' . ((bool)$result ? 'thành công' : 'thất bại')
                    ];
                    CLI::write('  Cập nhật trạng thái HOT ' . ((bool)$result ? 'thành công' : 'thất bại'), 'green');
                } catch (\Exception $e) {
                    $taskResults['update_hot'] = [
                        'success' => false,
                        'message' => 'Lỗi: ' . $e->getMessage()
                    ];
                    $errorOccurred = true;
                    CLI::write('  Lỗi: ' . $e->getMessage(), 'red');
                }

                // 1.3. Cập nhật trạng thái truyện
                CLI::write('  Đang cập nhật trạng thái truyện...', 'cyan');
                try {
                    $storyModel = new \App\Models\StoryModel();
                    $result = $storyModel->updateStoryStatus();
                    $taskResults['update_story_status'] = [
                        'success' => true,
                        'message' => 'Cập nhật trạng thái truyện thành công'
                    ];
                    CLI::write('  Cập nhật trạng thái truyện thành công', 'green');
                } catch (\Exception $e) {
                    $taskResults['update_story_status'] = [
                        'success' => false,
                        'message' => 'Lỗi: ' . $e->getMessage()
                    ];
                    $errorOccurred = true;
                    CLI::write('  Lỗi: ' . $e->getMessage(), 'red');
                }
            }

            // 2. Tác vụ hàng tuần
            if ($runWeekly) {
                CLI::write('Đang thực hiện các tác vụ hàng tuần...', 'green');

                // 2.1. Reset lượt xem hàng tuần
                CLI::write('  Đang reset lượt xem hàng tuần...', 'cyan');
                try {
                    $storyModel = new \App\Models\StoryModel();
                    $result = $storyModel->resetWeeklyViews();
                    $taskResults['reset_weekly'] = [
                        'success' => (bool)$result,
                        'message' => 'Reset lượt xem hàng tuần ' . ((bool)$result ? 'thành công' : 'thất bại')
                    ];
                    CLI::write('  Reset lượt xem hàng tuần ' . ((bool)$result ? 'thành công' : 'thất bại'), 'green');
                } catch (\Exception $e) {
                    $taskResults['reset_weekly'] = [
                        'success' => false,
                        'message' => 'Lỗi: ' . $e->getMessage()
                    ];
                    $errorOccurred = true;
                    CLI::write('  Lỗi: ' . $e->getMessage(), 'red');
                }

                // 2.2. Đề xuất truyện nổi bật
                CLI::write('  Đang đề xuất truyện nổi bật...', 'cyan');
                try {
                    $storyModel = new \App\Models\StoryModel();
                    $result = $storyModel->suggestFeaturedStories();
                    $taskResults['suggest_featured'] = [
                        'success' => !empty($result),
                        'message' => 'Đề xuất truyện nổi bật ' . (!empty($result) ? 'thành công' : 'thất bại')
                    ];
                    CLI::write('  Đề xuất truyện nổi bật ' . (!empty($result) ? 'thành công' : 'thất bại'), 'green');
                } catch (\Exception $e) {
                    $taskResults['suggest_featured'] = [
                        'success' => false,
                        'message' => 'Lỗi: ' . $e->getMessage()
                    ];
                    $errorOccurred = true;
                    CLI::write('  Lỗi: ' . $e->getMessage(), 'red');
                }
            }

            // 3. Tác vụ hàng tháng
            if ($runMonthly) {
                CLI::write('Đang thực hiện các tác vụ hàng tháng...', 'green');

                // 3.1. Reset lượt xem hàng tháng
                CLI::write('  Đang reset lượt xem hàng tháng...', 'cyan');
                try {
                    $storyModel = new \App\Models\StoryModel();
                    $result = $storyModel->resetMonthlyViews();
                    $taskResults['reset_monthly'] = [
                        'success' => (bool)$result,
                        'message' => 'Reset lượt xem hàng tháng ' . ((bool)$result ? 'thành công' : 'thất bại')
                    ];
                    CLI::write('  Reset lượt xem hàng tháng ' . ((bool)$result ? 'thành công' : 'thất bại'), 'green');
                } catch (\Exception $e) {
                    $taskResults['reset_monthly'] = [
                        'success' => false,
                        'message' => 'Lỗi: ' . $e->getMessage()
                    ];
                    $errorOccurred = true;
                    CLI::write('  Lỗi: ' . $e->getMessage(), 'red');
                }

                // 3.2. Cập nhật truyện được đề xuất
                CLI::write('  Đang cập nhật truyện được đề xuất...', 'cyan');
                try {
                    $storyModel = new \App\Models\StoryModel();
                    $result = $storyModel->updateRecommendedStories();
                    $taskResults['update_recommended'] = [
                        'success' => (bool)$result,
                        'message' => 'Cập nhật truyện được đề xuất ' . ((bool)$result ? 'thành công' : 'thất bại')
                    ];
                    CLI::write('  Cập nhật truyện được đề xuất ' . ((bool)$result ? 'thành công' : 'thất bại'), 'green');
                } catch (\Exception $e) {
                    $taskResults['update_recommended'] = [
                        'success' => false,
                        'message' => 'Lỗi: ' . $e->getMessage()
                    ];
                    $errorOccurred = true;
                    CLI::write('  Lỗi: ' . $e->getMessage(), 'red');
                }
            }

            // 4. Dọn dẹp hệ thống
            if ($runCleanup) {
                CLI::write('Đang dọn dẹp hệ thống...', 'green');

                // 4.1. Dọn dẹp cơ sở dữ liệu
                $db = db_connect();
                try {
                    // Sử dụng stored procedure đã định nghĩa trong cơ sở dữ liệu
                    $db->query('CALL cleanup_database()');
                    $taskResults['database_cleanup'] = [
                        'success' => true,
                        'message' => 'Dọn dẹp cơ sở dữ liệu thành công'
                    ];
                } catch (\Exception $e) {
                    $taskResults['database_cleanup'] = [
                        'success' => false,
                        'message' => 'Lỗi khi dọn dẹp cơ sở dữ liệu: ' . $e->getMessage()
                    ];
                    $errorOccurred = true;
                }

                // 4.2. Xóa tokens hết hạn
                $tokenModel = new \App\Models\TokenModel();
                $tokenModel->deleteExpiredTokens();
                $taskResults['token_cleanup'] = [
                    'success' => true,
                    'message' => 'Xóa tokens hết hạn thành công'
                ];
            }

            // Tính thời gian thực thi
            $executionTime = round(microtime(true) - $startTime, 2);

            // Ghi log kết thúc
            $logModel->info('Hoàn thành Master Cron', [
                'execution_time' => $executionTime . 's',
                'results' => $taskResults,
                'date' => date('Y-m-d')
            ]);

            CLI::write('=== KẾT THÚC TÁC VỤ MASTER CRON ===', 'blue');
            CLI::write('Thời gian kết thúc: ' . date('Y-m-d H:i:s'), 'yellow');
            CLI::write('Tổng thời gian thực thi: ' . $executionTime . ' giây', 'green');

            $this->displaySummary($taskResults);

            return $errorOccurred ? 1 : 0;
        } catch (\Exception $e) {
            // Xử lý lỗi và ghi log
            $logModel->error('Lỗi trong Master Cron', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
                'date' => date('Y-m-d')
            ]);

            CLI::error('Đã xảy ra lỗi: ' . $e->getMessage());
            return 1;
        }
    }

    /**
     * Hiển thị tóm tắt kết quả các tác vụ
     *
     * @param array $results Kết quả từ các tác vụ
     */
    private function displaySummary($results)
    {
        CLI::write("\nTÓM TẮT KẾT QUẢ:", 'white');
        CLI::write('---------------------------------', 'white');

        $successCount = 0;
        $failCount = 0;

        foreach ($results as $task => $result) {
            $status = $result['success'] ? 'THÀNH CÔNG' : 'THẤT BẠI';
            $color = $result['success'] ? 'green' : 'red';

            if ($result['success']) {
                $successCount++;
            } else {
                $failCount++;
            }

            $taskName = str_pad(ucwords(str_replace('_', ' ', $task)), 25, ' ');
            CLI::write("$taskName : ", 'white', false);
            CLI::write($status, $color);
        }

        CLI::write('---------------------------------', 'white');
        CLI::write("Tổng số: " . count($results) . " | Thành công: $successCount | Thất bại: $failCount", 'yellow');
    }
}
