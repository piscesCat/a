<div class="alert alert-info">
    <i class="fas fa-info-circle"></i> Cấu hình máy chủ web để hoàn tất quá trình cài đặt. Hệ thống phát hiện bạn đang sử dụng <strong><?= ucfirst($server_type) ?></strong>.
</div>

<?php if ($server_type === 'apache'): ?>
    <div class="alert alert-success">
        <i class="fas fa-check-circle"></i> Hệ thống đã tự động cấu hình <strong>.htaccess</strong> cho máy chủ Apache của bạn. Không cần thêm cấu hình nào khác.
    </div>
<?php else: ?>
    <div class="mb-4">
        <p>Để hoàn tất cài đặt và đảm bảo hệ thống hoạt động chính xác, bạn cần cấu hình máy chủ web của mình. Vui lòng tuân theo các hướng dẫn bên dưới:</p>
    </div>

    <?php if ($server_type === 'nginx'): ?>
        <h5 class="mb-3">Cấu hình Nginx</h5>
        <p>Vui lòng thêm cấu hình sau vào file cấu hình Nginx của bạn:</p>

        <div class="mb-3">
            <pre class="bg-light p-3 rounded"><code id="nginx-config"><?= htmlspecialchars($server_configs['config']) ?></code></pre>
            <button class="btn btn-sm btn-primary copy-btn" data-clipboard-target="#nginx-config">
                <i class="fas fa-copy"></i> Sao chép cấu hình
            </button>
        </div>

        <div class="alert alert-warning">
            <i class="fas fa-exclamation-triangle"></i> Nhớ thay thế <code>your-domain.com</code> và <code>/path/to/your/project</code> bằng giá trị thực tế của bạn và khởi động lại Nginx sau khi cập nhật file cấu hình.
        </div>

    <?php elseif ($server_type === 'openlitespeed'): ?>
        <h5 class="mb-3">Cấu hình OpenLiteSpeed</h5>
        <p>Đối với OpenLiteSpeed, bạn cần tạo file .htaccess trong thư mục public/ với nội dung sau:</p>

        <div class="mb-3">
            <pre class="bg-light p-3 rounded"><code id="openlitespeed-config"><?= htmlspecialchars($server_configs['config']) ?></code></pre>
            <button class="btn btn-sm btn-primary copy-btn" data-clipboard-target="#openlitespeed-config">
                <i class="fas fa-copy"></i> Sao chép cấu hình
            </button>
        </div>

        <div class="alert alert-warning">
            <i class="fas fa-exclamation-triangle"></i> Đảm bảo bật tính năng rewrite và hỗ trợ .htaccess trong cấu hình Virtual Host của OpenLiteSpeed.
        </div>

    <?php else: ?>
        <h5 class="mb-3">Cấu hình cho máy chủ web không xác định</h5>
        <p>Hệ thống không thể phát hiện chính xác loại máy chủ web của bạn. Dưới đây là các cấu hình cho các máy chủ web phổ biến:</p>

        <ul class="nav nav-tabs" id="serverTabs" role="tablist">
            <li class="nav-item" role="presentation">
                <a class="nav-link active" id="apache-tab" data-bs-toggle="tab" href="#apache" role="tab">Apache</a>
            </li>
            <li class="nav-item" role="presentation">
                <a class="nav-link" id="nginx-tab" data-bs-toggle="tab" href="#nginx" role="tab">Nginx</a>
            </li>
            <li class="nav-item" role="presentation">
                <a class="nav-link" id="openlitespeed-tab" data-bs-toggle="tab" href="#openlitespeed" role="tab">OpenLiteSpeed</a>
            </li>
        </ul>

        <div class="tab-content p-3 border border-top-0 rounded-bottom mb-4" id="serverTabsContent">
            <div class="tab-pane fade show active" id="apache" role="tabpanel">
                <h6>File .htaccess trong thư mục gốc:</h6>
                <pre class="bg-light p-2 rounded"><code id="apache-root-config"><?= htmlspecialchars($server_configs['root']) ?></code></pre>
                <button class="btn btn-sm btn-primary copy-btn mb-3" data-clipboard-target="#apache-root-config">
                    <i class="fas fa-copy"></i> Sao chép
                </button>

                <h6>File .htaccess trong thư mục public/:</h6>
                <pre class="bg-light p-2 rounded"><code id="apache-public-config"><?= htmlspecialchars($server_configs['public']) ?></code></pre>
                <button class="btn btn-sm btn-primary copy-btn" data-clipboard-target="#apache-public-config">
                    <i class="fas fa-copy"></i> Sao chép
                </button>
            </div>

            <div class="tab-pane fade" id="nginx" role="tabpanel">
                <pre class="bg-light p-2 rounded"><code id="nginx-tab-config"><?= htmlspecialchars($server_configs['nginx']) ?></code></pre>
                <button class="btn btn-sm btn-primary copy-btn" data-clipboard-target="#nginx-tab-config">
                    <i class="fas fa-copy"></i> Sao chép
                </button>
            </div>

            <div class="tab-pane fade" id="openlitespeed" role="tabpanel">
                <pre class="bg-light p-2 rounded"><code id="ols-tab-config"><?= htmlspecialchars($server_configs['openlitespeed']) ?></code></pre>
                <button class="btn btn-sm btn-primary copy-btn" data-clipboard-target="#ols-tab-config">
                    <i class="fas fa-copy"></i> Sao chép
                </button>
            </div>

            <div class="tab-pane fade" id="iis" role="tabpanel">
                <pre class="bg-light p-2 rounded"><code id="iis-tab-config"><?= htmlspecialchars($server_configs['iis']) ?></code></pre>
                <button class="btn btn-sm btn-primary copy-btn" data-clipboard-target="#iis-tab-config">
                    <i class="fas fa-copy"></i> Sao chép
                </button>
            </div>
        </div>
    <?php endif; ?>
<?php endif; ?>

<form method="post" action="<?= BASE_URL ?>">
    <input type="hidden" name="step" value="3.5">
    <input type="hidden" name="confirm_server_config" value="1">

    <div class="d-flex justify-content-between mt-4">
        <a href="<?= BASE_URL ?>admin" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Quay lại
        </a>

        <button type="submit" class="btn btn-primary">
            Tiếp tục <i class="fas fa-arrow-right"></i>
        </button>
    </div>
</form>

<script src="https://cdn.jsdelivr.net/npm/clipboard@2.0.8/dist/clipboard.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        new ClipboardJS('.copy-btn').on('success', function(e) {
            e.trigger.innerHTML = '<i class="fas fa-check"></i> Đã sao chép';
            setTimeout(function() {
                e.trigger.innerHTML = '<i class="fas fa-copy"></i> Sao chép cấu hình';
            }, 2000);
        });
    });
</script>
