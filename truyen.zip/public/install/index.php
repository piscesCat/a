<?php
/**
 * Web Truyện - Installer
 * File cài đặt độc lập giúp khởi tạo hệ thống một cách dễ dàng
 */

// Định nghĩa các đường dẫn quan trọng
define('INSTALLER_VERSION', '1.0');
define('ROOTPATH', realpath(dirname(dirname(__FILE__)) . '/../') . '/');
define('APPPATH', ROOTPATH . 'app/');
define('VIEWPATH', APPPATH . 'Views/');
define('WRITEPATH', ROOTPATH . 'writable/');
define('INSTALL_PATH', __DIR__ . '/');

// Khởi tạo session
session_start();

// Thiết lập header và error reporting
header('Content-Type: text/html; charset=UTF-8');
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Định nghĩa các URL và route
$scriptName = $_SERVER['SCRIPT_NAME'];
$scriptDir = dirname($scriptName);

// Xây dựng BASE_URL dựa trên thông tin request hiện tại
$base_url = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == "on") ? "https" : "http");
$base_url .= "://" . $_SERVER['HTTP_HOST'];
$base_url .= rtrim($scriptDir, '/') . '/';
define('BASE_URL', $base_url);

// Xác định route hiện tại
$requestUri = $_SERVER['REQUEST_URI'] ?? '';
$scriptDirPattern = str_replace('/', '\/', $scriptDir);
$pattern = '/^' . $scriptDirPattern . '\/([^?]*)(\?.*)?$/';

if (preg_match($pattern, $requestUri, $matches)) {
    $route = $matches[1] ?: 'index';
} else if ($requestUri == $scriptDir || $requestUri == $scriptDir . '/') {
    $route = 'index';
} else {
    // Xử lý trường hợp chạy trực tiếp file index.php
    $route = 'index';
}

// Loại bỏ phần install/ nếu có trong route
$route = str_replace('install/', '', $route);
$route = trim($route, '/');

// Kiểm tra xem hệ thống đã được cài đặt chưa
function isInstalled() {
    return file_exists(ROOTPATH . 'installed.txt');
}

// Kiểm tra yêu cầu hệ thống
function checkRequirements() {
    return [
        [
            'name' => 'PHP Version',
            'required' => '7.4 or higher',
            'current' => PHP_VERSION,
            'status' => version_compare(PHP_VERSION, '7.4.0', '>=')
        ],
        [
            'name' => 'PDO PostgreSQL Extension',
            'required' => 'Enabled',
            'current' => extension_loaded('pdo_pgsql') ? 'Enabled' : 'Disabled',
            'status' => extension_loaded('pdo_pgsql')
        ],
        [
            'name' => 'Fileinfo Extension',
            'required' => 'Enabled',
            'current' => extension_loaded('fileinfo') ? 'Enabled' : 'Disabled',
            'status' => extension_loaded('fileinfo')
        ],
        [
            'name' => 'CURL Extension',
            'required' => 'Enabled',
            'current' => extension_loaded('curl') ? 'Enabled' : 'Disabled',
            'status' => extension_loaded('curl')
        ],
        [
            'name' => 'GD Extension',
            'required' => 'Enabled',
            'current' => extension_loaded('gd') ? 'Enabled' : 'Disabled',
            'status' => extension_loaded('gd')
        ],
        [
            'name' => 'JSON Extension',
            'required' => 'Enabled',
            'current' => extension_loaded('json') ? 'Enabled' : 'Disabled',
            'status' => extension_loaded('json')
        ]
    ];
}

// Kiểm tra quyền thư mục
function checkPermissions() {
    return [
        [
            'name' => 'writable/cache/',
            'required' => 'Writable',
            'current' => is_writable(WRITEPATH . 'cache') ? 'Writable' : 'Not Writable',
            'status' => is_writable(WRITEPATH . 'cache')
        ],
        [
            'name' => 'writable/logs/',
            'required' => 'Writable',
            'current' => is_writable(WRITEPATH . 'logs') ? 'Writable' : 'Not Writable',
            'status' => is_writable(WRITEPATH . 'logs')
        ],
        [
            'name' => 'writable/uploads/',
            'required' => 'Writable',
            'current' => is_writable(WRITEPATH . 'uploads') ? 'Writable' : 'Not Writable',
            'status' => is_writable(WRITEPATH . 'uploads')
        ],
        [
            'name' => 'public/install/',
            'required' => 'Writable',
            'current' => is_writable(INSTALL_PATH) ? 'Writable' : 'Not Writable',
            'status' => is_writable(INSTALL_PATH)
        ],
        [
            'name' => 'public/',
            'required' => 'Writable',
            'current' => is_writable(ROOTPATH . 'public') ? 'Writable' : 'Not Writable',
            'status' => is_writable(ROOTPATH . 'public')
        ]
    ];
}

// Lưu cấu hình database
function saveDatabaseConfig($hostname, $database, $username, $password, $port) {
    $configPath = APPPATH . 'Config/Database.php';
    $config = file_get_contents($configPath);

    // Replace database settings in config file
    $config = preg_replace("/'hostname' => '.*?'/", "'hostname' => '$hostname'", $config);
    $config = preg_replace("/'database' => '.*?'/", "'database' => '$database'", $config);
    $config = preg_replace("/'username' => '.*?'/", "'username' => '$username'", $config);
    $config = preg_replace("/'password' => '.*?'/", "'password' => '$password'", $config);
    $config = preg_replace("/'port' => .*?,/", "'port' => $port,", $config);

    // Save updated config file
    file_put_contents($configPath, $config);

    // Create a flag file to indicate database is configured
    file_put_contents(ROOTPATH . 'database_configured.txt', date('Y-m-d H:i:s'));
}

// Tạo file .env từ cấu hình người dùng đã nhập
function createEnvFile($appName, $appUrl, $appKey, $imgurClientId, $imgurClientSecret, $dbHostname, $dbPort, $dbName, $dbUsername, $dbPassword) {
    $envContent = "# Tệp cấu hình môi trường (Environment Configuration)
# Được tạo tự động bởi quá trình cài đặt

# Thông tin ứng dụng
APP_NAME=\"$appName\"
APP_ENV=production
APP_KEY=$appKey
APP_DEBUG=false
APP_URL=$appUrl

# Cấu hình Cơ sở dữ liệu
DB_CONNECTION=pgsql
DB_HOST=$dbHostname
DB_PORT=$dbPort
DB_DATABASE=$dbName
DB_USERNAME=$dbUsername
DB_PASSWORD=$dbPassword

# Cấu hình API Imgur
IMGUR_CLIENT_ID=$imgurClientId
IMGUR_CLIENT_SECRET=$imgurClientSecret

# Thời gian JWT Token hết hạn (phút)
JWT_EXPIRE=60

# Các thiết lập khác
DEFAULT_LOCALE=vi
TIMEZONE=Asia/Ho_Chi_Minh
LOG_LEVEL=error
CACHE_DRIVER=file
SESSION_DRIVER=file
COOKIE_SECURE=false

# Cấu hình uploads
UPLOADS_PATH=writable/uploads
UPLOADS_MAX_SIZE=5M
UPLOADS_ALLOWED_TYPES=jpg,jpeg,png,gif,webp

# Cấu hình SEO
SEO_TITLE_MAX_LENGTH=70
SEO_DESCRIPTION_MAX_LENGTH=160
SEO_DEFAULT_IMAGE=/assets/images/default-share.jpg
";

    // Lưu file .env vào thư mục gốc
    file_put_contents(ROOTPATH . '.env', $envContent);

    // Tạo file .env.example nếu chưa có
    if (!file_exists(ROOTPATH . '.env.example')) {
        file_put_contents(ROOTPATH . '.env.example', $envContent);
    }

    return true;
}

// Import database schema
function importDatabaseSchema() {
    try {
        // Kết nối đến database
        $configPath = APPPATH . 'Config/Database.php';
        if (!file_exists($configPath)) {
            throw new Exception('Database configuration file not found.');
        }

        // Parse database config file để lấy thông tin kết nối
        $config = file_get_contents($configPath);
        preg_match("/'hostname' => '(.*?)'/", $config, $hostname);
        preg_match("/'database' => '(.*?)'/", $config, $database);
        preg_match("/'username' => '(.*?)'/", $config, $username);
        preg_match("/'password' => '(.*?)'/", $config, $password);
        preg_match("/'port' => (.*?),/", $config, $port);

        if (empty($hostname[1]) || empty($database[1]) || empty($username[1])) {
            throw new Exception('Database configuration is incomplete.');
        }

        // Kết nối database
        $dsn = "pgsql:host={$hostname[1]};port={$port[1]};dbname={$database[1]}";
        $pdo = new PDO($dsn, $username[1], $password[1]);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Kiểm tra xem database đã có bảng nào chưa
        $stmt = $pdo->query("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = 'public'");
        $tableCount = $stmt->fetchColumn();
        $databaseEmpty = ($tableCount == 0);

        // Xử lý trường hợp database không trống theo tùy chọn người dùng
        $dbHandleExisting = $_SESSION['input']['db_handle_existing'] ?? 'update';

        if (!$databaseEmpty) {
            if ($dbHandleExisting == 'recreate') {
                // Xóa toàn bộ bảng nếu người dùng chọn tạo lại
                $pdo->exec("DROP SCHEMA public CASCADE; CREATE SCHEMA public; GRANT ALL ON SCHEMA public TO PUBLIC;");
                $databaseEmpty = true;

                // Cần kết nối lại vì schema đã bị xóa
                $pdo = new PDO($dsn, $username[1], $password[1]);
                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                // Log để debug
                error_log('Database schema dropped and recreated.');
            } else {
                // Kiểm tra xem table settings đã tồn tại chưa (nếu đã tồn tại, đây có thể là cài đặt cũ)
                $stmt = $pdo->query("SELECT to_regclass('public.settings')");
                $settingsExists = $stmt->fetchColumn() !== null;

                if ($settingsExists) {
                    // Kiểm tra xem đã có dữ liệu trong bảng settings
                    $stmt = $pdo->query("SELECT COUNT(*) FROM settings");
                    $settingsCount = $stmt->fetchColumn();

                    if ($settingsCount > 0) {
                        // Lưu lại giá trị cài đặt hiện tại để khôi phục sau khi cập nhật schema
                        $stmt = $pdo->query("SELECT id, value FROM settings");
                        $currentSettings = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
                        error_log('Saved ' . count($currentSettings) . ' settings for restoration.');
                    }
                }

                error_log('Using update mode for existing database.');
            }
        }

        // Đọc file SQL cấu trúc
        $schema = file_get_contents(INSTALL_PATH . 'unified_schema.sql');
        if (empty($schema)) {
            throw new Exception('Schema file is empty or could not be read.');
        }

        // Thực thi SQL cấu trúc database
        $pdo->exec($schema);
        error_log('Schema SQL executed successfully.');

        // Đọc và thực thi file dữ liệu mặc định
        $default_data = file_get_contents(INSTALL_PATH . 'default_data.sql');
        if (empty($default_data)) {
            throw new Exception('Default data file is empty or could not be read.');
        }

        $pdo->exec($default_data);
        error_log('Default data SQL executed successfully.');

        // Nếu có các cài đặt cũ, khôi phục lại các cài đặt có thể tương thích
        if (isset($currentSettings) && !empty($currentSettings)) {
            foreach ($currentSettings as $id => $value) {
                try {
                    // Chỉ cập nhật các cài đặt đã tồn tại, không thêm mới
                    $pdo->exec("UPDATE settings SET value = '$value' WHERE id = '$id' AND id NOT IN ('installed_at', 'site_version', 'database_version')");
                } catch (Exception $e) {
                    error_log('Error restoring setting ' . $id . ': ' . $e->getMessage());
                    // Bỏ qua lỗi khi khôi phục cài đặt
                    continue;
                }
            }
            error_log('Restored compatible settings from previous installation.');
        }

        // Ghi log về việc cài đặt
        try {
            $action = $databaseEmpty ? 'Cài đặt mới' : ($dbHandleExisting == 'recreate' ? 'Xóa và tạo lại' : 'Cập nhật cấu trúc');
            $pdo->exec("INSERT INTO system_changes (change_type, description, sql_query, created_at)
                       VALUES ('install', '{$action} từ installer', 'Thực hiện từ quá trình cài đặt', CURRENT_TIMESTAMP)");
            error_log('Installation logged to system_changes table.');
        } catch (Exception $e) {
            // Bỏ qua lỗi nếu không thể ghi log
            error_log('Error logging to system_changes: ' . $e->getMessage());
        }

        return true;
    } catch (PDOException $e) {
        error_log('Database error in importDatabaseSchema: ' . $e->getMessage());
        $_SESSION['error'] = 'Database import error: ' . $e->getMessage();
        return false;
    } catch (Exception $e) {
        error_log('General error in importDatabaseSchema: ' . $e->getMessage());
        $_SESSION['error'] = 'Error: ' . $e->getMessage();
        return false;
    }
}

// Tạo tài khoản admin
function createAdminUser($username, $email, $password) {
    try {
        // Kết nối đến database
        $configPath = APPPATH . 'Config/Database.php';
        $config = file_get_contents($configPath);
        preg_match("/'hostname' => '(.*?)'/", $config, $hostname_db);
        preg_match("/'database' => '(.*?)'/", $config, $database_db);
        preg_match("/'username' => '(.*?)'/", $config, $username_db);
        preg_match("/'password' => '(.*?)'/", $config, $password_db);
        preg_match("/'port' => (.*?),/", $config, $port_db);

        // Kết nối database
        $dsn = "pgsql:host={$hostname_db[1]};port={$port_db[1]};dbname={$database_db[1]}";
        $pdo = new PDO($dsn, $username_db[1], $password_db[1]);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Hash mật khẩu
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Kiểm tra xem người dùng sáng lập đã tồn tại chưa
        $stmt = $pdo->prepare("SELECT * FROM users WHERE role = 3");
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            // Cập nhật người dùng sáng lập nếu đã tồn tại
            $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ?, password = ? WHERE role = 3");
            $stmt->execute([$username, $email, $hashed_password]);
        } else {
            // Tạo người dùng sáng lập mới
            $stmt = $pdo->prepare("INSERT INTO users (username, email, password, role, status, created_at, updated_at) VALUES (?, ?, ?, 3, 'active', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)");
            $stmt->execute([$username, $email, $hashed_password]);
        }

        return true;
    } catch (PDOException $e) {
        $_SESSION['error'] = 'Database error: ' . $e->getMessage();
        return false;
    } catch (Exception $e) {
        $_SESSION['error'] = 'Error: ' . $e->getMessage();
        return false;
    }
}

// Lưu cài đặt trang web
function saveSiteSettings($siteName, $siteDescription) {
    try {
        // Kết nối đến database
        $configPath = APPPATH . 'Config/Database.php';
        $config = file_get_contents($configPath);
        preg_match("/'hostname' => '(.*?)'/", $config, $hostname);
        preg_match("/'database' => '(.*?)'/", $config, $database);
        preg_match("/'username' => '(.*?)'/", $config, $username_db);
        preg_match("/'password' => '(.*?)'/", $config, $password_db);
        preg_match("/'port' => (.*?),/", $config, $port);

        // Kết nối database
        $dsn = "pgsql:host={$hostname[1]};port={$port[1]};dbname={$database[1]}";
        $pdo = new PDO($dsn, $username_db[1], $password_db[1]);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Lưu settings
        $settings = [
            'site_name' => $siteName,
            'site_description' => $siteDescription,
            'installed_at' => date('Y-m-d H:i:s')
        ];

        foreach ($settings as $name => $value) {
            // Check if setting exists
            $stmt = $pdo->prepare("SELECT id FROM settings WHERE name = ?");
            $stmt->execute([$name]);

            if ($stmt->rowCount() > 0) {
                // Update existing setting
                $stmt = $pdo->prepare("UPDATE settings SET value = ? WHERE name = ?");
                $stmt->execute([$value, $name]);
            } else {
                // Insert new setting
                $stmt = $pdo->prepare("INSERT INTO settings (name, value) VALUES (?, ?)");
                $stmt->execute([$name, $value]);
            }
        }

        return true;
    } catch (PDOException $e) {
        $_SESSION['error'] = 'Database error: ' . $e->getMessage();
        return false;
    } catch (Exception $e) {
        $_SESSION['error'] = 'Error: ' . $e->getMessage();
        return false;
    }
}

// Hoàn thành cài đặt
function completeInstallation($siteName = null, $siteDescription = null) {
    // Tạo flag file để đánh dấu cài đặt hoàn tất
    file_put_contents(ROOTPATH . 'installed.txt', date('Y-m-d H:i:s'));

    // Xóa file chỉ báo cấu hình database nếu tồn tại
    if (file_exists(ROOTPATH . 'database_configured.txt')) {
        @unlink(ROOTPATH . 'database_configured.txt');
    }

    // Cập nhật file .env nếu có thông tin trang web
    if ($siteName && file_exists(ROOTPATH . '.env')) {
        $envContent = file_get_contents(ROOTPATH . '.env');

        // Cập nhật tên ứng dụng
        $envContent = preg_replace('/APP_NAME=\".*?\"/', 'APP_NAME="' . addslashes($siteName) . '"', $envContent);

        // Đặt lại chế độ debug thành false cho môi trường sản xuất
        $envContent = preg_replace('/APP_DEBUG=.*/', 'APP_DEBUG=false', $envContent);

        // Lưu file .env đã cập nhật
        file_put_contents(ROOTPATH . '.env', $envContent);
    }

    // Phát hiện kiểu máy chủ web và áp dụng cấu hình nếu có thể
    $serverType = detectWebServer();

    // Nếu là Apache, tự động áp dụng cấu hình
    if ($serverType === 'apache') {
        applyApacheConfig();
    }

    // Lưu thông tin kiểu máy chủ web vào session để hiển thị ở trang hoàn tất
    $_SESSION['server_type'] = $serverType;
    $_SESSION['server_configs'] = getServerConfig($serverType);

    return true;
}

// Xóa file cài đặt
function removeInstallationFiles() {
    // Danh sách file cần xóa (chỉ xóa các file trong thư mục public/install)
    $filesToRemove = [
        ROOTPATH . 'public/install.php',
        ROOTPATH . 'public/install/index.php',
        ROOTPATH . 'public/install/templates/index.php',
        ROOTPATH . 'public/install/templates/database.php',
        ROOTPATH . 'public/install/templates/admin.php',
        ROOTPATH . 'public/install/templates/complete.php',
        ROOTPATH . 'public/install/templates/header.php',
        ROOTPATH . 'public/install/templates/footer.php',
        ROOTPATH . 'public/install/setup.sql',
        ROOTPATH . 'public/install/.htaccess'
    ];

    // Xóa các file
    foreach ($filesToRemove as $file) {
        if (file_exists($file)) {
            @unlink($file);
        }
    }

    // Xóa thư mục
    @rmdir(ROOTPATH . 'public/install/templates');
    @rmdir(ROOTPATH . 'public/install');

    return true;
}

// Tự động phát hiện loại máy chủ web
function detectWebServer() {
    $server_software = $_SERVER['SERVER_SOFTWARE'] ?? '';

    if (stripos($server_software, 'apache') !== false) {
        return 'apache';
    } elseif (stripos($server_software, 'nginx') !== false) {
        return 'nginx';
    } elseif (stripos($server_software, 'litespeed') !== false) {
        return 'openlitespeed';
    } else {
        // Không thể xác định chính xác
        return 'unknown';
    }
}

// Lấy nội dung cấu hình máy chủ dựa trên loại
function getServerConfig($type) {
    $configPath = INSTALL_PATH . 'server_configs/';

    switch ($type) {
        case 'apache':
            return [
                'config' => file_get_contents($configPath . 'apache.txt')
            ];
        case 'nginx':
            return [
                'config' => file_get_contents($configPath . 'nginx.txt')
            ];
        case 'openlitespeed':
            return [
                'config' => file_get_contents($configPath . 'openlitespeed.txt')
            ];
        default:
            return [
                'apache' => file_get_contents($configPath . 'apache.txt'),
                'nginx' => file_get_contents($configPath . 'nginx.txt'),
                'openlitespeed' => file_get_contents($configPath . 'openlitespeed.txt')
            ];
    }
}

// Áp dụng cấu hình Apache nếu máy chủ là Apache
function applyApacheConfig() {
    $serverConfig = getServerConfig('apache');

    // Viết file .htaccess vào thư mục public
    if (is_writable(ROOTPATH . 'public')) {
        file_put_contents(ROOTPATH . 'public/.htaccess', $serverConfig['config']);
    }

    return true;
}

// Chuyển hướng tới URL
function redirect($route) {
    // Đảm bảo rằng URL redirect tương thích với cấu trúc BASE_URL
    $url = BASE_URL;

    // Nếu không phải trang chính, thêm route vào URL
    if ($route !== 'index' && $route !== '') {
        $url .= $route;
    }

    header('Location: ' . $url);
    exit;
}

// Hiển thị template
function view($template, $data = []) {
    extract($data);

    // Template header
    include INSTALL_PATH . 'templates/header.php';

    // Nội dung chính
    include INSTALL_PATH . 'templates/' . $template . '.php';

    // Template footer
    include INSTALL_PATH . 'templates/footer.php';
}

// Tạo thư mục templates nếu chưa có
if (!is_dir(INSTALL_PATH . 'templates')) {
    mkdir(INSTALL_PATH . 'templates', 0755, true);
}

// Route handling
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['step'])) {
        $step = $_POST['step'];

        if ($step == '1' && isset($_POST['proceed'])) {
            // Redirect to database configuration step
            redirect('database');
        }
        else if ($step == '2' && isset($_POST['db_hostname'])) {
            // Process database configuration
            $hostname = $_POST['db_hostname'];
            $database = $_POST['db_name'];
            $username = $_POST['db_username'];
            $password = $_POST['db_password'];
            $port = $_POST['db_port'];

            // Thông tin cho file .env
            $appName = $_POST['app_name'] ?? 'WebTruyen';
            $appUrl = $_POST['app_url'] ?? rtrim(BASE_URL, '/');
            $appKey = $_POST['app_key'] ?? bin2hex(random_bytes(16));
            $imgurClientId = $_POST['imgur_client_id'] ?? '';
            $imgurClientSecret = $_POST['imgur_client_secret'] ?? '';
            $dbHandleExisting = $_POST['db_handle_existing'] ?? 'update';

            // Lưu input vào session để phục vụ trường hợp reload form
            $_SESSION['input'] = $_POST;

            // Lưu cấu hình database
            saveDatabaseConfig($hostname, $database, $username, $password, $port);

            // Tạo file .env
            createEnvFile($appName, $appUrl, $appKey, $imgurClientId, $imgurClientSecret, $hostname, $port, $database, $username, $password);

            // Import database schema
            if (importDatabaseSchema()) {
                // Update settings for Imgur in database
                try {
                    $dsn = "pgsql:host={$hostname};port={$port};dbname={$database}";
                    $pdo = new PDO($dsn, $username, $password);
                    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                    // Insert Imgur settings
                    $stmt = $pdo->prepare("INSERT INTO settings (name, value) VALUES (?, ?) ON CONFLICT (name) DO UPDATE SET value = EXCLUDED.value");
                    $stmt->execute(['imgur_client_id', $imgurClientId]);
                    $stmt->execute(['imgur_enabled', !empty($imgurClientId) ? 'on' : 'off']);
                } catch (Exception $e) {
                    // Log error but continue
                    error_log('Error setting Imgur values: ' . $e->getMessage());
                }

                redirect('admin');
            } else {
                redirect('database');
            }
        }
        else if ($step == '3' && isset($_POST['username'])) {
            // Process admin account setup
            $username = $_POST['username'];
            $email = $_POST['email'];
            $password = $_POST['password'];
            $siteName = $_POST['site_name'];
            $siteDescription = $_POST['site_description'] ?? '';

            if (createAdminUser($username, $email, $password) &&
                saveSiteSettings($siteName, $siteDescription)) {

                // Phát hiện loại máy chủ web
                $serverType = detectWebServer();

                // Nếu là Apache, tự động áp dụng cấu hình và chuyển đến trang hoàn tất
                if ($serverType === 'apache') {
                    completeInstallation($siteName, $siteDescription);
                    $_SESSION['success'] = 'Cài đặt hệ thống thành công!';
                    redirect('complete');
                } else {
                    // Nếu không phải Apache, hiển thị trang cấu hình máy chủ web
                    $_SESSION['admin_data'] = [
                        'username' => $username,
                        'email' => $email,
                        'site_name' => $siteName,
                        'site_description' => $siteDescription
                    ];
                    redirect('server-config');
                }
            } else {
                redirect('admin');
            }
        }
        else if ($step == '3.5' && isset($_POST['confirm_server_config'])) {
            // Hoàn tất cài đặt sau khi xem cấu hình máy chủ web
            $adminData = $_SESSION['admin_data'] ?? [];
            $siteName = $adminData['site_name'] ?? '';
            $siteDescription = $adminData['site_description'] ?? '';

            completeInstallation($siteName, $siteDescription);
            $_SESSION['success'] = 'Cài đặt hệ thống thành công!';
            redirect('complete');
        }
    }
} else {
    // GET request handling
    switch ($route) {
        case 'database':
            // Check requirements first
            $requirements = checkRequirements();
            $permissions = checkPermissions();
            $canProceed = true;

            foreach ($requirements as $requirement) {
                if (!$requirement['status']) {
                    $canProceed = false;
                    break;
                }
            }

            foreach ($permissions as $permission) {
                if (!$permission['status']) {
                    $canProceed = false;
                    break;
                }
            }

            if (!$canProceed) {
                $_SESSION['error'] = 'Kiểm tra lại các yêu cầu hệ thống.';
                redirect('');
            }

            view('database', [
                'title' => 'Cài đặt hệ thống - Cấu hình Cơ sở dữ liệu',
                'step' => 2
            ]);
            break;

        case 'admin':
            // Check if database is configured
            if (!file_exists(ROOTPATH . 'database_configured.txt')) {
                $_SESSION['error'] = 'Bạn phải cấu hình cơ sở dữ liệu trước.';
                redirect('database');
            }

            view('admin', [
                'title' => 'Cài đặt hệ thống - Tạo tài khoản quản trị',
                'step' => 3
            ]);
            break;

        case 'complete':
            // Check if installation is complete
            if (!$_SESSION['success'] && !isInstalled()) {
                redirect('');
            }

            // Lấy thông tin server type từ session
            $serverType = $_SESSION['server_type'] ?? 'unknown';
            $serverConfigs = $_SESSION['server_configs'] ?? [];

            view('complete', [
                'title' => 'Cài đặt hoàn tất',
                'step' => 4,
                'server_type' => $serverType,
                'server_configs' => $serverConfigs
            ]);
            break;

        case 'server-config':
            // Trang hiển thị cấu hình máy chủ web cho người dùng
            if (!file_exists(ROOTPATH . 'database_configured.txt') && !isInstalled()) {
                $_SESSION['error'] = 'Bạn phải cấu hình cơ sở dữ liệu trước.';
                redirect('database');
            }

            // Phát hiện kiểu máy chủ web
            $serverType = detectWebServer();
            $serverConfigs = getServerConfig($serverType);

            view('server_config', [
                'title' => 'Cấu hình máy chủ web',
                'step' => 3.5,
                'server_type' => $serverType,
                'server_configs' => $serverConfigs
            ]);
            break;

        case 'cleanup':
            // Xóa file cài đặt khi đã hoàn thành
            if ($_SERVER['REQUEST_METHOD'] === 'POST' && isInstalled()) {
                removeInstallationFiles();
                echo json_encode(['success' => true, 'message' => 'Installation files have been removed']);
                exit;
            }
            break;

        default:
            // Check if already installed
            if (isInstalled()) {
                // Redirect to home page
                $homeUrl = rtrim(preg_replace('/\/install.*$/', '', BASE_URL), '/') . '/';
                header('Location: ' . $homeUrl);
                exit;
            }

            // Default: system requirements check
            view('index', [
                'title' => 'Cài đặt hệ thống',
                'step' => 1,
                'requirements' => checkRequirements(),
                'permissions' => checkPermissions()
            ]);
            break;
    }
}
