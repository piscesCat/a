<?php
// public/index.php
define('FCPATH', __DIR__ . DIRECTORY_SEPARATOR);
chdir(FCPATH);

// Check if the system is already installed
if (!file_exists(realpath(dirname(__FILE__) . '/../') . '/installed.txt')) {
    // Xác định đường dẫn đến thư mục install
    $installPath = 'install/';

    // Nếu cần, có thể xây dựng URL đầy đủ
    $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://';
    $host = $_SERVER['HTTP_HOST'];
    $scriptPath = dirname($_SERVER['SCRIPT_NAME']);
    $installUrl = $protocol . $host . rtrim($scriptPath, '/') . '/' . $installPath;

    header('Location: ' . $installUrl);
    exit;
}

require FCPATH . '../vendor/autoload.php';

$app = require FCPATH . '../app/Config/Boot/production.php';
$kernel = $app->getKernel();
$kernel->boot();

$app->run();
