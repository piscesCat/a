<?php

namespace App\Libraries;

use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;
use App\Models\LogModel;

/**
 * WebSocketServer
 *
 * Cung cấp một giải pháp WebSocket để thay thế cronjob
 * Hỗ trợ thực hiện các tác vụ định kỳ mà không cần phụ thuộc vào cron của hệ thống
 *
 * Cách sử dụng:
 * 1. Khởi động server: php spark websocket:start
 * 2. Gửi lệnh từ client: {"command": "run_cron", "type": "daily"}
 */
class WebSocketServer implements MessageComponentInterface
{
    protected $clients;
    protected $adminClients;
    protected $logModel;
    protected $lastRunTime;
    protected $scheduledTasks;

    public function __construct()
    {
        $this->clients = new \SplObjectStorage;
        $this->adminClients = new \SplObjectStorage;
        $this->logModel = new LogModel();
        $this->lastRunTime = [
            'daily' => null,
            'weekly' => null,
            'monthly' => null,
            'cleanup' => null
        ];

        // Thiết lập các tác vụ định kỳ
        $this->scheduledTasks = [
            'daily' => [
                'interval' => 86400, // 24 giờ
                'time' => '00:05', // Thời gian chạy: 00:05
                'lastRun' => null
            ],
            'weekly' => [
                'interval' => 604800, // 7 ngày
                'dayOfWeek' => 1, // Thứ 2
                'time' => '01:00', // Thời gian chạy: 01:00
                'lastRun' => null
            ],
            'monthly' => [
                'interval' => 2592000, // 30 ngày (gần đúng)
                'dayOfMonth' => 1, // Ngày 1 hàng tháng
                'time' => '02:00', // Thời gian chạy: 02:00
                'lastRun' => null
            ],
            'cleanup' => [
                'interval' => 604800, // 7 ngày
                'dayOfWeek' => 7, // Chủ nhật
                'time' => '03:00', // Thời gian chạy: 03:00
                'lastRun' => null
            ]
        ];

        // Khởi động theo dõi thời gian cho các tác vụ
        $this->startScheduler();

        $this->logModel->info('WebSocket Server khởi động', [
            'time' => date('Y-m-d H:i:s')
        ]);
    }

    /**
     * Xử lý khi có kết nối mới
     */
    public function onOpen(ConnectionInterface $conn)
    {
        $this->clients->attach($conn);

        $this->logModel->info('Kết nối mới', [
            'connection_id' => $conn->resourceId,
            'client_count' => count($this->clients)
        ]);

        // Gửi thông báo chào mừng
        $conn->send(json_encode([
            'type' => 'welcome',
            'message' => 'Chào mừng đến với WebSocket Server',
            'connection_id' => $conn->resourceId,
            'time' => date('Y-m-d H:i:s')
        ]));
    }

    /**
     * Xử lý khi nhận được tin nhắn
     */
    public function onMessage(ConnectionInterface $from, $msg)
    {
        try {
            $data = json_decode($msg, true);

            if (!$data || !isset($data['command'])) {
                $from->send(json_encode([
                    'type' => 'error',
                    'message' => 'Định dạng tin nhắn không hợp lệ'
                ]));
                return;
            }

            switch ($data['command']) {
                case 'auth':
                    $this->handleAuth($from, $data);
                    break;

                case 'run_cron':
                    $this->handleRunCron($from, $data);
                    break;

                case 'get_status':
                    $this->handleGetStatus($from);
                    break;

                default:
                    $from->send(json_encode([
                        'type' => 'error',
                        'message' => 'Lệnh không được hỗ trợ: ' . $data['command']
                    ]));
            }
        } catch (\Exception $e) {
            $this->logModel->error('Lỗi khi xử lý tin nhắn', [
                'error' => $e->getMessage(),
                'connection_id' => $from->resourceId
            ]);

            $from->send(json_encode([
                'type' => 'error',
                'message' => 'Đã xảy ra lỗi: ' . $e->getMessage()
            ]));
        }
    }

    /**
     * Xử lý khi kết nối đóng
     */
    public function onClose(ConnectionInterface $conn)
    {
        $this->clients->detach($conn);

        if ($this->adminClients->contains($conn)) {
            $this->adminClients->detach($conn);
        }

        $this->logModel->info('Kết nối đóng', [
            'connection_id' => $conn->resourceId,
            'client_count' => count($this->clients)
        ]);
    }

    /**
     * Xử lý khi có lỗi
     */
    public function onError(ConnectionInterface $conn, \Exception $e)
    {
        $this->logModel->error('Lỗi WebSocket', [
            'connection_id' => $conn->resourceId,
            'error' => $e->getMessage()
        ]);

        $conn->close();
    }

    /**
     * Xử lý yêu cầu xác thực admin
     */
    protected function handleAuth(ConnectionInterface $conn, $data)
    {
        if (!isset($data['token'])) {
            $conn->send(json_encode([
                'type' => 'error',
                'message' => 'Thiếu token xác thực'
            ]));
            return;
        }

        // Kiểm tra token xác thực
        $tokenModel = new \App\Models\TokenModel();
        $tokenData = $tokenModel->verifyToken($data['token']);

        if ($tokenData) {
            $userModel = new \App\Models\UserModel();
            $user = $userModel->find($tokenData['user_id']);

            if ($user && $user['role'] >= 2) { // Chỉ cho phép admin
                $this->adminClients->attach($conn);

                $conn->send(json_encode([
                    'type' => 'auth_success',
                    'message' => 'Xác thực thành công, bạn có quyền admin',
                    'user' => [
                        'id' => $user['id'],
                        'username' => $user['username'],
                        'role' => $user['role']
                    ]
                ]));

                $this->logModel->info('Xác thực admin thành công', [
                    'connection_id' => $conn->resourceId,
                    'user_id' => $user['id']
                ]);
            } else {
                $conn->send(json_encode([
                    'type' => 'auth_failed',
                    'message' => 'Bạn không có quyền admin'
                ]));
            }
        } else {
            $conn->send(json_encode([
                'type' => 'auth_failed',
                'message' => 'Token không hợp lệ hoặc đã hết hạn'
            ]));
        }
    }

    /**
     * Xử lý yêu cầu chạy cronjob
     */
    protected function handleRunCron(ConnectionInterface $from, $data)
    {
        // Kiểm tra quyền admin
        if (!$this->adminClients->contains($from)) {
            $from->send(json_encode([
                'type' => 'error',
                'message' => 'Bạn không có quyền thực hiện tác vụ này'
            ]));
            return;
        }

        $type = $data['type'] ?? 'daily';

        // Chạy tác vụ theo loại
        $result = $this->executeCronTask($type);

        // Gửi kết quả về cho client
        $from->send(json_encode([
            'type' => 'cron_result',
            'task_type' => $type,
            'success' => $result['success'],
            'message' => $result['message'],
            'details' => $result['details'] ?? null
        ]));

        // Gửi thông báo cho tất cả các admin khác
        foreach ($this->adminClients as $client) {
            if ($client !== $from) {
                $client->send(json_encode([
                    'type' => 'notification',
                    'message' => "Tác vụ $type vừa được thực thi bởi admin khác",
                    'time' => date('Y-m-d H:i:s')
                ]));
            }
        }
    }

    /**
     * Xử lý yêu cầu lấy trạng thái
     */
    protected function handleGetStatus(ConnectionInterface $from)
    {
        // Kiểm tra quyền admin
        if (!$this->adminClients->contains($from)) {
            $from->send(json_encode([
                'type' => 'error',
                'message' => 'Bạn không có quyền thực hiện tác vụ này'
            ]));
            return;
        }

        // Lấy thời gian chạy gần nhất cho mỗi loại tác vụ
        $taskStatus = [];
        foreach ($this->scheduledTasks as $type => $config) {
            $taskStatus[$type] = [
                'last_run' => $config['lastRun'] ? date('Y-m-d H:i:s', $config['lastRun']) : 'Chưa chạy',
                'next_run' => $this->calculateNextRunTime($type),
                'config' => $config
            ];
        }

        // Gửi thông tin trạng thái
        $from->send(json_encode([
            'type' => 'status',
            'server_time' => date('Y-m-d H:i:s'),
            'uptime' => $this->getServerUptime(),
            'client_count' => count($this->clients),
            'admin_count' => count($this->adminClients),
            'tasks' => $taskStatus
        ]));
    }

    /**
     * Thực thi tác vụ cron theo loại
     */
    protected function executeCronTask($type)
    {
        try {
            $startTime = microtime(true);
            $command = '';

            switch ($type) {
                case 'daily':
                    $command = 'php spark cron:master --daily';
                    break;

                case 'weekly':
                    $command = 'php spark cron:master --weekly';
                    break;

                case 'monthly':
                    $command = 'php spark cron:master --monthly';
                    break;

                case 'cleanup':
                    $command = 'php spark cron:master --cleanup';
                    break;

                case 'all':
                    $command = 'php spark cron:master';
                    break;

                default:
                    return [
                        'success' => false,
                        'message' => 'Loại tác vụ không hợp lệ: ' . $type
                    ];
            }

            // Thực thi lệnh
            $output = [];
            $returnCode = 0;
            exec($command . ' 2>&1', $output, $returnCode);

            // Ghi nhận thời gian chạy
            $this->lastRunTime[$type] = time();
            if (isset($this->scheduledTasks[$type])) {
                $this->scheduledTasks[$type]['lastRun'] = time();
            }

            $executionTime = round(microtime(true) - $startTime, 2);

            // Ghi log
            $this->logModel->info("Tác vụ '$type' đã được thực thi qua WebSocket", [
                'execution_time' => $executionTime . 's',
                'return_code' => $returnCode,
                'command' => $command
            ]);

            return [
                'success' => ($returnCode === 0),
                'message' => ($returnCode === 0) ? "Tác vụ '$type' thực thi thành công" : "Tác vụ '$type' thất bại",
                'details' => [
                    'execution_time' => $executionTime,
                    'output' => $output
                ]
            ];
        } catch (\Exception $e) {
            $this->logModel->error("Lỗi khi thực thi tác vụ '$type'", [
                'error' => $e->getMessage()
            ]);

            return [
                'success' => false,
                'message' => "Lỗi khi thực thi tác vụ '$type': " . $e->getMessage()
            ];
        }
    }

    /**
     * Khởi động bộ lập lịch để tự động chạy các tác vụ định kỳ
     */
    protected function startScheduler()
    {
        // Thiết lập một timer để kiểm tra các tác vụ định kỳ mỗi phút
        $loop = \React\EventLoop\Factory::create();

        $loop->addPeriodicTimer(60, function() {
            $this->checkScheduledTasks();
        });

        // Timer để kiểm tra sức khỏe hệ thống
        $loop->addPeriodicTimer(300, function() {
            $this->checkSystemHealth();
        });
    }

    /**
     * Kiểm tra và thực thi các tác vụ theo lịch trình
     */
    protected function checkScheduledTasks()
    {
        $now = time();
        $today = date('Y-m-d');
        $currentTime = date('H:i');
        $dayOfWeek = date('N'); // 1 (Thứ 2) đến 7 (Chủ nhật)
        $dayOfMonth = date('j'); // 1-31

        foreach ($this->scheduledTasks as $type => $config) {
            // Kiểm tra thời gian chạy gần nhất
            if ($config['lastRun'] !== null && ($now - $config['lastRun']) < 3600) {
                // Nếu đã chạy trong 1 giờ gần đây, bỏ qua
                continue;
            }

            $shouldRun = false;

            // Kiểm tra theo loại tác vụ
            switch ($type) {
                case 'daily':
                    // Kiểm tra thời gian (HH:MM)
                    if ($currentTime === $config['time']) {
                        $shouldRun = true;
                    }
                    break;

                case 'weekly':
                    // Kiểm tra ngày trong tuần và thời gian
                    if ($dayOfWeek == $config['dayOfWeek'] && $currentTime === $config['time']) {
                        $shouldRun = true;
                    }
                    break;

                case 'monthly':
                    // Kiểm tra ngày trong tháng và thời gian
                    if ($dayOfMonth == $config['dayOfMonth'] && $currentTime === $config['time']) {
                        $shouldRun = true;
                    }
                    break;

                case 'cleanup':
                    // Kiểm tra ngày trong tuần và thời gian
                    if ($dayOfWeek == $config['dayOfWeek'] && $currentTime === $config['time']) {
                        $shouldRun = true;
                    }
                    break;
            }

            // Nếu đến thời điểm chạy, thực thi tác vụ
            if ($shouldRun) {
                $result = $this->executeCronTask($type);

                // Thông báo cho tất cả admin
                $this->broadcastToAdmins([
                    'type' => 'task_executed',
                    'task' => $type,
                    'time' => date('Y-m-d H:i:s'),
                    'result' => $result
                ]);
            }
        }
    }

    /**
     * Kiểm tra sức khỏe hệ thống và thông báo nếu có vấn đề
     */
    protected function checkSystemHealth()
    {
        // Kiểm tra bộ nhớ
        $memoryUsage = memory_get_usage(true);
        $memoryLimit = $this->getMemoryLimit();

        if ($memoryUsage > 0.9 * $memoryLimit) {
            $this->logModel->warning('Cảnh báo: Sử dụng bộ nhớ cao', [
                'memory_usage' => $this->formatBytes($memoryUsage),
                'memory_limit' => $this->formatBytes($memoryLimit),
                'percentage' => round(($memoryUsage / $memoryLimit) * 100, 2) . '%'
            ]);

            $this->broadcastToAdmins([
                'type' => 'warning',
                'message' => 'Cảnh báo: Sử dụng bộ nhớ cao (' . $this->formatBytes($memoryUsage) . ')',
                'time' => date('Y-m-d H:i:s')
            ]);
        }
    }

    /**
     * Gửi thông điệp đến tất cả admin
     */
    protected function broadcastToAdmins($message)
    {
        $jsonMessage = json_encode($message);

        foreach ($this->adminClients as $client) {
            $client->send($jsonMessage);
        }
    }

    /**
     * Tính toán thời gian chạy tiếp theo của một tác vụ
     */
    protected function calculateNextRunTime($type)
    {
        if (!isset($this->scheduledTasks[$type])) {
            return 'N/A';
        }

        $config = $this->scheduledTasks[$type];
        $now = time();

        // Tạo ngày/giờ cơ sở
        $baseTime = strtotime(date('Y-m-d') . ' ' . $config['time']);

        switch ($type) {
            case 'daily':
                // Nếu thời gian hiện tại đã qua thời gian chạy hôm nay, thì chạy vào ngày mai
                if ($now > $baseTime) {
                    $nextRun = strtotime('+1 day', $baseTime);
                } else {
                    $nextRun = $baseTime;
                }
                break;

            case 'weekly':
                $currentDayOfWeek = date('N');
                $daysUntilTarget = ($config['dayOfWeek'] - $currentDayOfWeek + 7) % 7;

                if ($daysUntilTarget === 0 && $now > $baseTime) {
                    // Nếu đúng ngày nhưng đã qua giờ, đợi đến tuần sau
                    $daysUntilTarget = 7;
                }

                $nextRun = strtotime("+$daysUntilTarget days", $baseTime);
                break;

            case 'monthly':
                $currentDay = date('j');
                $currentMonth = date('n');
                $currentYear = date('Y');

                // Tính ngày chạy tiếp theo
                if ($currentDay < $config['dayOfMonth']) {
                    // Nếu chưa đến ngày chạy trong tháng này
                    $nextRun = mktime(
                        intval(substr($config['time'], 0, 2)),
                        intval(substr($config['time'], 3, 2)),
                        0,
                        $currentMonth,
                        $config['dayOfMonth'],
                        $currentYear
                    );
                } else if ($currentDay > $config['dayOfMonth'] || ($currentDay == $config['dayOfMonth'] && $now > $baseTime)) {
                    // Nếu đã qua ngày chạy trong tháng này hoặc đúng ngày nhưng đã qua giờ
                    $nextMonth = $currentMonth + 1;
                    $nextYear = $currentYear;

                    if ($nextMonth > 12) {
                        $nextMonth = 1;
                        $nextYear++;
                    }

                    $nextRun = mktime(
                        intval(substr($config['time'], 0, 2)),
                        intval(substr($config['time'], 3, 2)),
                        0,
                        $nextMonth,
                        $config['dayOfMonth'],
                        $nextYear
                    );
                } else {
                    // Đúng ngày và chưa qua giờ
                    $nextRun = $baseTime;
                }
                break;

            case 'cleanup':
                // Tương tự như weekly
                $currentDayOfWeek = date('N');
                $daysUntilTarget = ($config['dayOfWeek'] - $currentDayOfWeek + 7) % 7;

                if ($daysUntilTarget === 0 && $now > $baseTime) {
                    $daysUntilTarget = 7;
                }

                $nextRun = strtotime("+$daysUntilTarget days", $baseTime);
                break;

            default:
                return 'N/A';
        }

        return date('Y-m-d H:i:s', $nextRun);
    }

    /**
     * Lấy giới hạn bộ nhớ của PHP
     */
    protected function getMemoryLimit()
    {
        $memoryLimit = ini_get('memory_limit');

        if (preg_match('/^(\d+)(.)$/', $memoryLimit, $matches)) {
            if ($matches[2] == 'M') {
                return $matches[1] * 1024 * 1024;
            } else if ($matches[2] == 'K') {
                return $matches[1] * 1024;
            } else if ($matches[2] == 'G') {
                return $matches[1] * 1024 * 1024 * 1024;
            }
        }

        return $memoryLimit;
    }

    /**
     * Định dạng bytes thành đơn vị đọc được
     */
    protected function formatBytes($bytes, $precision = 2)
    {
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];

        $bytes = max($bytes, 0);
        $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
        $pow = min($pow, count($units) - 1);

        $bytes /= pow(1024, $pow);

        return round($bytes, $precision) . ' ' . $units[$pow];
    }

    /**
     * Lấy thời gian hoạt động của server
     */
    protected function getServerUptime()
    {
        $uptime = '';

        if (function_exists('shell_exec')) {
            $uptime = @shell_exec('uptime -p');
            if (!$uptime) {
                $uptime = 'Không thể xác định';
            }
        } else {
            $uptime = 'Không thể xác định (shell_exec không khả dụng)';
        }

        return $uptime;
    }
}
