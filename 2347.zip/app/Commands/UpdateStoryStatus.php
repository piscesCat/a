<?php

namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use App\Models\StoryModel;
use App\Models\LogModel;

class UpdateStoryStatus extends BaseCommand
{
    /**
     * The Command's Group
     *
     * @var string
     */
    protected $group = 'App';

    /**
     * The Command's Name
     *
     * @var string
     */
    protected $name = 'stories:update-status';

    /**
     * The Command's Description
     *
     * @var string
     */
    protected $description = 'Cập nhật trạng thái truyện (draft, published, completed) dựa trên tình trạng và hoạt động';

    /**
     * The Command's Usage
     *
     * @var string
     */
    protected $usage = 'stories:update-status [options]';

    /**
     * The Command's Arguments
     *
     * @var array
     */
    protected $arguments = [];

    /**
     * The Command's Options
     *
     * @var array
     */
    protected $options = [
        '--min-chapters' => 'Số lượng chương tối thiểu để được publish (mặc định: 3)',
        '--inactive-days' => 'Số ngày không hoạt động để đánh dấu là completed (mặc định: 90)',
        '--auto-update' => 'Tự động cập nhật mà không cần phê duyệt (mặc định: không)',
    ];

    /**
     * Actually execute a command.
     *
     * @param array $params
     */
    public function run(array $params)
    {
        CLI::write('Đang cập nhật trạng thái truyện...', 'yellow');

        // Lấy các tham số từ command line options
        $options = [
            'min_chapters_for_publish' => $params['min-chapters'] ?? 3,
            'inactive_days_for_complete' => $params['inactive-days'] ?? 90,
            'require_admin_approval' => !isset($params['auto-update']),
        ];

        try {
            $storyModel = new StoryModel();
            $result = $storyModel->updateStoryStatus($options);

            // Hiển thị thống kê
            CLI::write('Kết quả cập nhật trạng thái truyện:', 'green');
            CLI::write('- Truyện chuyển từ nháp sang xuất bản: ' . $result['draft_to_published']);
            CLI::write('- Truyện được đánh dấu là đã hoàn thành: ' . $result['marked_completed']);
            CLI::write('- Tổng số truyện được cập nhật: ' . $result['total_updated']);
            CLI::write('- Số đề xuất cần phê duyệt: ' . count($result['pending_admin_review']));

            // Lưu báo cáo đề xuất nếu có
            if (!empty($result['pending_admin_review'])) {
                $this->saveReport($result['pending_admin_review']);

                CLI::newLine();
                CLI::write('Danh sách đề xuất cần phê duyệt:', 'yellow');

                $table = [];
                foreach ($result['pending_admin_review'] as $index => $proposal) {
                    $table[] = [
                        ($index + 1),
                        $proposal['title'],
                        $proposal['current_status'],
                        $proposal['suggested_status'],
                        $proposal['reason']
                    ];
                }

                CLI::table($table, ['#', 'Tên truyện', 'Trạng thái hiện tại', 'Trạng thái đề xuất', 'Lý do']);
            }

            return 0;
        } catch (\Exception $e) {
            // Ghi log lỗi
            $logModel = new LogModel();
            $logModel->error('Cập nhật trạng thái truyện thất bại', [
                'error' => $e->getMessage(),
                'triggered_by' => 'cronjob',
                'method' => 'CLI'
            ]);

            CLI::error('Cập nhật trạng thái truyện thất bại: ' . $e->getMessage());
            return 1;
        }
    }

    /**
     * Lưu báo cáo đề xuất cần phê duyệt vào file
     *
     * @param array $proposals Danh sách đề xuất cần phê duyệt
     * @return bool Trả về true nếu lưu thành công
     */
    protected function saveReport(array $proposals)
    {
        $reportDir = WRITEPATH . 'reports';

        // Tạo thư mục nếu chưa tồn tại
        if (!is_dir($reportDir)) {
            mkdir($reportDir, 0755, true);
        }

        $timestamp = date('Y-m-d_H-i-s');
        $filename = $reportDir . '/status_proposals_' . $timestamp . '.json';

        // Định dạng dữ liệu báo cáo
        $reportData = [
            'generated_at' => date('Y-m-d H:i:s'),
            'count' => count($proposals),
            'proposals' => $proposals
        ];

        // Lưu file JSON
        $result = file_put_contents($filename, json_encode($reportData, JSON_PRETTY_PRINT));

        if ($result !== false) {
            CLI::write('Báo cáo đề xuất đã được lưu tại: ' . $filename, 'green');
            return true;
        } else {
            CLI::error('Không thể lưu báo cáo đề xuất!');
            return false;
        }
    }
}
