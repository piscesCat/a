<?php
namespace App\Controllers;

use App\Models\StoryModel;
use App\Models\CategoryModel;
use App\Models\ChapterModel;

class Home extends BaseController
{
    public function index()
    {
        // Lấy thể hiện của StoryModel
        $storyModel = new StoryModel();

        // Lấy truyện nổi bật
        $featuredStories = $storyModel->getFeaturedStories(6);

        // Lấy truyện mới cập nhật
        $latestUpdatedStories = $storyModel->getRecentlyUpdated(12);

        // Lấy truyện được đề xuất
        $recommendedStories = $storyModel->getRecommended(5);

        // Lấy truyện đã hoàn thành
        $completedStories = $storyModel->getCompleted(6);

        // Lấy tác giả hàng đầu
        $userModel = new \App\Models\UserModel();
        $db = \Config\Database::connect();
        $query = $db->table('users')
                    ->select('users.id, users.username, users.avatar, COUNT(stories.id) as story_count')
                    ->join('stories', 'stories.author_id = users.id')
                    ->where('stories.status', 'published')
                    ->groupBy('users.id')
                    ->orderBy('story_count', 'DESC')
                    ->limit(5)
                    ->get();
        $topAuthors = $query->getResultArray();

        // Lấy danh mục với số lượng truyện
        $categoryModel = new CategoryModel();
        $categories = $categoryModel->getCategoriesWithCount();

        // Lấy các chương mới nhất
        $chapterModel = new ChapterModel();
        $latestChapters = $chapterModel->getLatestChapters(15);

        // Hiển thị view với dữ liệu
        return $this->renderView('home.html', [
            'featured_stories' => $featuredStories,
            'latest_updated_stories' => $latestUpdatedStories,
            'recommended_stories' => $recommendedStories,
            'completed_stories' => $completedStories,
            'top_authors' => $topAuthors,
            'categories' => $categories,
            'latest_chapters' => $latestChapters
        ]);
    }

    /**
     * Lấy danh sách quốc gia từ trường country trong bảng story
     */
    public function getCountries()
    {
        $storyModel = new \App\Models\StoryModel();
        $countries = $storyModel->getCountries();

        return $this->response->setJSON([
            'status' => 'success',
            'data' => $countries
        ]);
    }
}
