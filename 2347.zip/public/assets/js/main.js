// Chức năng chuyển đổi Theme
document.addEventListener('DOMContentLoaded', function() {
    // Kiểm tra theme từ localStorage
    const currentTheme = localStorage.getItem('theme');
    if (currentTheme) {
        document.documentElement.setAttribute('data-theme', currentTheme);
    }

    // Xử lý sự kiện click vào nút chuyển đổi
    const themeToggle = document.getElementById('theme-toggle');
    if (themeToggle) {
        themeToggle.addEventListener('click', function() {
            // Lấy theme hiện tại
            const currentTheme = document.documentElement.getAttribute('data-theme');

            // Chuyển đổi theme
            let targetTheme = 'dark';
            if (currentTheme !== 'light') {
                targetTheme = 'light';
            }

            // Áp dụng theme mới
            document.documentElement.setAttribute('data-theme', targetTheme);

            // Lưu theme vào localStorage
            localStorage.setItem('theme', targetTheme);
        });
    }
});

// Gợi ý tìm kiếm
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('search-input');
    const suggestionsContainer = document.getElementById('search-suggestions');

    if (!searchInput || !suggestionsContainer) return;

    let debounceTimer;

    searchInput.addEventListener('input', function() {
        clearTimeout(debounceTimer);

        const query = this.value.trim();

        if (query.length < 2) {
            suggestionsContainer.style.display = 'none';
            return;
        }

        debounceTimer = setTimeout(function() {
            fetch(`${baseUrl}/search/suggestions?q=${encodeURIComponent(query)}`)
                .then(response => response.json())
                .then(data => {
                    if (data.suggestions && data.suggestions.length > 0) {
                        suggestionsContainer.innerHTML = '';

                        data.suggestions.forEach(suggestion => {
                            const item = document.createElement('div');
                            item.className = 'suggestion-item';

                            const link = document.createElement('a');
                            link.href = `${baseUrl}/truyen/${suggestion.slug}`;
                            link.textContent = suggestion.title;

                            item.appendChild(link);
                            suggestionsContainer.appendChild(item);
                        });

                        suggestionsContainer.style.display = 'block';
                    } else {
                        suggestionsContainer.style.display = 'none';
                    }
                })
                .catch(error => {
                    console.error('Lỗi khi tải gợi ý:', error);
                    suggestionsContainer.style.display = 'none';
                });
        }, 300);
    });

    // Ẩn gợi ý khi click bên ngoài
    document.addEventListener('click', function(event) {
        if (!searchInput.contains(event.target) && !suggestionsContainer.contains(event.target)) {
            suggestionsContainer.style.display = 'none';
        }
    });

    // Hiển thị gợi ý khi input được focus
    searchInput.addEventListener('focus', function() {
        if (this.value.trim().length >= 2) {
            suggestionsContainer.style.display = 'block';
        }
    });
});

// Chuyển đổi trạng thái Bookmark
function toggleBookmark(storyId, button) {
    if (!userId) {
        window.location.href = `${baseUrl}/dang-nhap`;
        return;
    }

    fetch(`${baseUrl}/bookmarks/toggle`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-Requested-With': 'XMLHttpRequest'
        },
        body: `story_id=${storyId}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            if (data.status === 'added') {
                button.classList.remove('btn-outline-danger');
                button.classList.add('btn-danger');
                button.querySelector('i').classList.remove('far');
                button.querySelector('i').classList.add('fas');
            } else {
                button.classList.remove('btn-danger');
                button.classList.add('btn-outline-danger');
                button.querySelector('i').classList.remove('fas');
                button.querySelector('i').classList.add('far');
            }

            // Hiển thị thông báo thành công
            showToast(data.message, 'success');
        } else {
            // Hiển thị thông báo lỗi
            showToast(data.message, 'error');

            if (data.redirect) {
                setTimeout(() => {
                    window.location.href = data.redirect;
                }, 1000);
            }
        }
    })
    .catch(error => {
        console.error('Lỗi khi chuyển đổi bookmark:', error);
        showToast('Đã xảy ra lỗi khi thực hiện.', 'error');
    });
}

// Thông báo Toast
function showToast(message, type = 'info') {
    // Tạo container cho toast nếu chưa tồn tại
    let toastContainer = document.getElementById('toast-container');
    if (!toastContainer) {
        toastContainer = document.createElement('div');
        toastContainer.id = 'toast-container';
        toastContainer.className = 'toast-container position-fixed bottom-0 end-0 p-3';
        document.body.appendChild(toastContainer);
    }

    // Tạo ID duy nhất cho toast
    const toastId = 'toast-' + Date.now();

    // Xác định màu nền dựa trên loại thông báo
    let bgColor = 'bg-info';
    if (type === 'success') bgColor = 'bg-success';
    if (type === 'error') bgColor = 'bg-danger';
    if (type === 'warning') bgColor = 'bg-warning';

    // Tạo HTML cho toast
    const toastHtml = `
        <div id="${toastId}" class="toast align-items-center ${bgColor} text-white border-0" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="d-flex">
                <div class="toast-body">
                    ${message}
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
        </div>
    `;

    // Thêm toast vào container
    toastContainer.insertAdjacentHTML('beforeend', toastHtml);

    // Khởi tạo và hiển thị toast
    const toastElement = document.getElementById(toastId);
    const toast = new bootstrap.Toast(toastElement, { autohide: true, delay: 3000 });
    toast.show();

    // Xóa toast sau khi nó bị ẩn
    toastElement.addEventListener('hidden.bs.toast', function() {
        toastElement.remove();
    });
}

// Xử lý gửi bình luận
document.addEventListener('DOMContentLoaded', function() {
    const storyCommentForm = document.getElementById('story-comment-form');
    const chapterCommentForm = document.getElementById('chapter-comment-form');

    if (storyCommentForm) {
        storyCommentForm.addEventListener('submit', function(e) {
            e.preventDefault();
            submitComment(this, 'story');
        });
    }

    if (chapterCommentForm) {
        chapterCommentForm.addEventListener('submit', function(e) {
            e.preventDefault();
            submitComment(this, 'chapter');
        });
    }

    // Các nút xóa bình luận
    document.querySelectorAll('.delete-comment').forEach(button => {
        button.addEventListener('click', function() {
            const commentId = this.getAttribute('data-id');
            if (confirm('Bạn có chắc chắn muốn xóa bình luận này?')) {
                deleteComment(commentId);
            }
        });
    });

    // Nút tải thêm bình luận
    const loadMoreBtn = document.getElementById('load-more-comments');
    if (loadMoreBtn) {
        loadMoreBtn.addEventListener('click', function() {
            const storyId = this.getAttribute('data-story-id');
            const chapterId = this.getAttribute('data-chapter-id');
            const offset = parseInt(this.getAttribute('data-offset'), 10);

            loadMoreComments(storyId, chapterId, offset);
        });
    }
});

function submitComment(form, type) {
    const formData = new FormData(form);
    const submitBtn = form.querySelector('button[type="submit"]');
    const originalBtnText = submitBtn.innerHTML;

    // Vô hiệu hóa nút và hiển thị trạng thái đang tải
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Đang gửi...';

    // Gửi yêu cầu
    fetch(`${baseUrl}/comments/${type}`, {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        // Đặt lại trạng thái nút
        submitBtn.disabled = false;
        submitBtn.innerHTML = originalBtnText;

        if (data.status === 'success') {
            // Xóa dữ liệu trong form
            form.reset();

            // Hiển thị thông báo thành công
            showToast(data.message, 'success');

            // Chuyển hướng nếu cần
            if (data.redirect) {
                setTimeout(() => {
                    window.location.href = data.redirect;
                }, 1000);
            }
        } else {
            // Hiển thị thông báo lỗi
            showToast(data.message, 'error');
        }
    })
    .catch(error => {
        // Đặt lại trạng thái nút
        submitBtn.disabled = false;
        submitBtn.innerHTML = originalBtnText;

        // Hiển thị thông báo lỗi
        console.error('Lỗi khi gửi bình luận:', error);
        showToast('Đã xảy ra lỗi khi gửi bình luận.', 'error');
    });
}

function deleteComment(commentId) {
    fetch(`${baseUrl}/comments/delete`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-Requested-With': 'XMLHttpRequest'
        },
        body: `comment_id=${commentId}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            // Xóa bình luận khỏi DOM
            const commentElement = document.getElementById(`comment-${commentId}`);
            if (commentElement) {
                commentElement.remove();
            }

            // Hiển thị thông báo thành công
            showToast(data.message, 'success');
        } else {
            // Hiển thị thông báo lỗi
            showToast(data.message, 'error');
        }
    })
    .catch(error => {
        console.error('Lỗi khi xóa bình luận:', error);
        showToast('Đã xảy ra lỗi khi xóa bình luận.', 'error');
    });
}

function loadMoreComments(storyId, chapterId, offset) {
    const loadMoreBtn = document.getElementById('load-more-comments');
    const commentsContainer = document.getElementById('comments-container');

    if (!loadMoreBtn || !commentsContainer) return;

    // Hiển thị trạng thái đang tải
    loadMoreBtn.disabled = true;
    loadMoreBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Đang tải...';

    // Xây dựng các tham số truy vấn
    let params = `story_id=${storyId}&offset=${offset}`;
    if (chapterId) {
        params += `&chapter_id=${chapterId}`;
    }

    // Tải thêm bình luận
    fetch(`${baseUrl}/comments/load-more?${params}`)
        .then(response => response.json())
        .then(data => {
            // Đặt lại trạng thái nút
            loadMoreBtn.disabled = false;
            loadMoreBtn.innerHTML = 'Xem thêm bình luận';

            if (data.status === 'success') {
                // Thêm bình luận mới vào cuối
                commentsContainer.insertAdjacentHTML('beforeend', data.html);

                // Cập nhật offset
                loadMoreBtn.setAttribute('data-offset', offset + 10);

                // Ẩn nút nếu không còn bình luận
                if (!data.hasMore) {
                    loadMoreBtn.style.display = 'none';
                }

                // Thêm sự kiện lắng nghe cho các nút xóa mới
                document.querySelectorAll('.delete-comment').forEach(button => {
                    button.addEventListener('click', function() {
                        const commentId = this.getAttribute('data-id');
                        if (confirm('Bạn có chắc chắn muốn xóa bình luận này?')) {
                            deleteComment(commentId);
                        }
                    });
                });
            } else {
                // Hiển thị thông báo lỗi
                showToast('Không thể tải thêm bình luận.', 'error');
            }
        })
        .catch(error => {
            // Đặt lại trạng thái nút
            loadMoreBtn.disabled = false;
            loadMoreBtn.innerHTML = 'Xem thêm bình luận';

            // Hiển thị thông báo lỗi
            console.error('Lỗi khi tải thêm bình luận:', error);
            showToast('Đã xảy ra lỗi khi tải bình luận.', 'error');
        });
}
