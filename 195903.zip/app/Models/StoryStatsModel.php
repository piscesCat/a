<?php

namespace App\Models;

use CodeIgniter\Model;

/**
 * StoryStatsModel
 *
 * Model để lưu trữ và quản lý lịch sử thống kê lượt xem của truyện
 * Giúp theo dõi lượt xem theo ngày, tuần, tháng và cung cấp dữ liệu cho các thuật toán
 */
class StoryStatsModel extends Model
{
    protected $table = 'story_stats';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';

    protected $allowedFields = [
        'story_id', 'date', 'views', 'views_daily', 'views_weekly', 'views_monthly',
        'ratings_count', 'ratings_avg', 'favorites_count'
    ];

    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    /**
     * Lưu thống kê lượt xem hàng ngày cho truyện
     *
     * @param string $date Ngày cần lưu thống kê (Y-m-d)
     * @return bool Kết quả lưu
     */
    public function saveStatsForDate($date = null)
    {
        if ($date === null) {
            $date = date('Y-m-d');
        }

        $db = \Config\Database::connect();
        $storyModel = new StoryModel();

        // Lấy danh sách story_id và thống kê hiện tại
        $stories = $storyModel->select('id, views, views_day, views_week, views_month, rating, total_ratings, total_favorites')
                            ->where('status', 'published')
                            ->findAll();

        $batchData = [];
        foreach ($stories as $story) {
            // Kiểm tra nếu đã có bản ghi cho ngày này
            $existing = $this->where('story_id', $story['id'])
                           ->where('date', $date)
                           ->first();

            if ($existing) {
                // Cập nhật bản ghi hiện có
                $this->update($existing['id'], [
                    'views' => $story['views'],
                    'views_daily' => $story['views_day'],
                    'views_weekly' => $story['views_week'],
                    'views_monthly' => $story['views_month'],
                    'ratings_avg' => $story['rating'],
                    'ratings_count' => $story['total_ratings'],
                    'favorites_count' => $story['total_favorites'],
                    'updated_at' => date('Y-m-d H:i:s')
                ]);
            } else {
                // Thêm bản ghi mới
                $batchData[] = [
                    'story_id' => $story['id'],
                    'date' => $date,
                    'views' => $story['views'],
                    'views_daily' => $story['views_day'],
                    'views_weekly' => $story['views_week'],
                    'views_monthly' => $story['views_month'],
                    'ratings_avg' => $story['rating'],
                    'ratings_count' => $story['total_ratings'],
                    'favorites_count' => $story['total_favorites'],
                    'created_at' => date('Y-m-d H:i:s'),
                    'updated_at' => date('Y-m-d H:i:s')
                ];
            }
        }

        // Thêm hàng loạt các bản ghi mới
        if (!empty($batchData)) {
            $this->insertBatch($batchData);
        }

        return true;
    }

    /**
     * Lấy thống kê lượt xem trong khoảng thời gian
     *
     * @param int $storyId ID của truyện
     * @param string $startDate Ngày bắt đầu (Y-m-d)
     * @param string $endDate Ngày kết thúc (Y-m-d)
     * @return array Danh sách thống kê
     */
    public function getStatsInDateRange($storyId, $startDate, $endDate)
    {
        return $this->where('story_id', $storyId)
                   ->where('date >=', $startDate)
                   ->where('date <=', $endDate)
                   ->orderBy('date', 'ASC')
                   ->findAll();
    }

    /**
     * Lấy thống kê lượt xem của ngày trước đó
     *
     * @param int $storyId ID của truyện
     * @param string $date Ngày tham chiếu
     * @return array|null Thống kê của ngày trước đó
     */
    public function getPreviousDayStats($storyId, $date = null)
    {
        if ($date === null) {
            $date = date('Y-m-d');
        }

        $previousDate = date('Y-m-d', strtotime('-1 day', strtotime($date)));

        return $this->where('story_id', $storyId)
                   ->where('date', $previousDate)
                   ->first();
    }

    /**
     * Xóa thống kê cũ (giữ lại N ngày gần nhất)
     *
     * @param int $keepDays Số ngày dữ liệu cần giữ lại
     * @return bool Kết quả xóa
     */
    public function deleteOldStats($keepDays = 90)
    {
        $cutoffDate = date('Y-m-d', strtotime("-$keepDays days"));

        return $this->where('date <', $cutoffDate)->delete();
    }

    /**
     * Lấy thống kê tăng trưởng theo ngày
     *
     * @param int $storyId ID của truyện
     * @param int $days Số ngày muốn xem thống kê
     * @return array Thống kê tăng trưởng
     */
    public function getGrowthStats($storyId, $days = 7)
    {
        $endDate = date('Y-m-d');
        $startDate = date('Y-m-d', strtotime("-$days days"));

        $stats = $this->where('story_id', $storyId)
                     ->where('date >=', $startDate)
                     ->where('date <=', $endDate)
                     ->orderBy('date', 'ASC')
                     ->findAll();

        // Tính toán tỷ lệ tăng trưởng giữa các ngày
        $growthStats = [];
        $previousViews = null;

        foreach ($stats as $index => $stat) {
            $currentViews = $stat['views_daily'];
            $growthRate = null;

            if ($previousViews !== null && $previousViews > 0) {
                $growthRate = (($currentViews - $previousViews) / $previousViews) * 100;
            }

            $growthStats[] = [
                'date' => $stat['date'],
                'views' => $currentViews,
                'growth_rate' => $growthRate,
                'complete_data' => $stat
            ];

            $previousViews = $currentViews;
        }

        return $growthStats;
    }

    /**
     * Lấy ngày reset cuối cùng
     *
     * @param string $resetType Loại reset (daily, weekly, monthly)
     * @return string|null Ngày reset cuối cùng (Y-m-d)
     */
    public function getLastResetDate($resetType)
    {
        $settingsModel = new SettingsModel();
        return $settingsModel->getSetting('last_reset_' . $resetType, null);
    }

    /**
     * Cập nhật ngày reset cuối cùng
     *
     * @param string $resetType Loại reset (daily, weekly, monthly)
     * @param string $date Ngày reset (Y-m-d)
     * @return bool Kết quả cập nhật
     */
    public function updateLastResetDate($resetType, $date = null)
    {
        if ($date === null) {
            $date = date('Y-m-d');
        }

        $settingsModel = new SettingsModel();
        return $settingsModel->updateSetting('last_reset_' . $resetType, $date);
    }
}
