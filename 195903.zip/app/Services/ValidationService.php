<?php

namespace App\Services;

use CodeIgniter\HTTP\ResponseInterface;
use Config\Services;

class ValidationService
{
    protected $validation;
    protected $response;
    protected $errorService;

    public function __construct()
    {
        $this->validation = Services::validation();
        $this->response = Services::response();
        $this->errorService = new ErrorService();
    }

    /**
     * Xác thực dữ liệu với các quy tắc được cung cấp
     *
     * @param array $data Dữ liệu cần xác thực
     * @param array $rules Quy tắc xác thực
     * @param array $messages Thông báo tùy chỉnh (tùy chọn)
     * @return bool|array TRUE nếu hợp lệ, mảng lỗi nếu không hợp lệ
     */
    public function validate(array $data, array $rules, array $messages = [])
    {
        $this->validation->reset();
        $this->validation->setRules($rules, $messages);

        if ($this->validation->run($data)) {
            return true;
        }

        return $this->validation->getErrors();
    }

    /**
     * Xác thực dữ liệu API với các quy tắc được cung cấp và trả về JSON nếu có lỗi
     *
     * @param array $data Dữ liệu cần xác thực
     * @param array $rules Quy tắc xác thực
     * @param array $messages Thông báo tùy chỉnh (tùy chọn)
     * @return bool|ResponseInterface TRUE nếu hợp lệ, Response JSON nếu không hợp lệ
     */
    public function validateApi(array $data, array $rules, array $messages = [])
    {
        $result = $this->validate($data, $rules, $messages);

        if ($result === true) {
            return true;
        }

        // Trả về phản hồi JSON với lỗi
        return $this->response->setStatusCode(422)->setJSON([
            'success' => false,
            'message' => 'Dữ liệu không hợp lệ',
            'errors' => $result
        ]);
    }

    /**
     * Lọc dữ liệu đầu vào dựa trên danh sách các trường cho phép
     *
     * @param array $data Dữ liệu đầu vào
     * @param array $allowedFields Danh sách trường cho phép
     * @return array Dữ liệu đã lọc
     */
    public function filterData(array $data, array $allowedFields)
    {
        $filteredData = [];

        foreach ($allowedFields as $field) {
            if (isset($data[$field])) {
                $filteredData[$field] = $data[$field];
            }
        }

        return $filteredData;
    }

    /**
     * Làm sạch dữ liệu đầu vào khỏi các mã độc tiềm ẩn
     *
     * @param mixed $data Dữ liệu cần làm sạch (string, array, object)
     * @param bool $encodeHTML Có mã hóa HTML hay không
     * @return mixed Dữ liệu đã làm sạch
     */
    public function sanitize($data, $encodeHTML = true)
    {
        if (is_array($data)) {
            $sanitized = [];
            foreach ($data as $key => $value) {
                $sanitized[$key] = $this->sanitize($value, $encodeHTML);
            }
            return $sanitized;
        } elseif (is_object($data)) {
            $vars = get_object_vars($data);
            foreach ($vars as $key => $value) {
                $data->$key = $this->sanitize($value, $encodeHTML);
            }
            return $data;
        } elseif (is_string($data)) {
            // Loại bỏ các ký tự không mong muốn
            $data = trim($data);

            // Loại bỏ các thẻ script và các thuộc tính nguy hiểm
            $data = preg_replace('/<script\b[^>]*>(.*?)<\/script>/is', '', $data);
            $data = preg_replace('/on\w+\s*=\s*(?:"[^"]*"|\'[^\']*\')/i', '', $data);

            // Mã hóa HTML nếu cần
            if ($encodeHTML) {
                $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
            }

            return $data;
        }

        return $data;
    }

    /**
     * Tạo bộ quy tắc Validation cho một model cụ thể
     *
     * @param string $model Tên model (ví dụ: 'UserModel')
     * @param string $scenario Tình huống xác thực (create, update, login, etc.)
     * @return array Bộ quy tắc Validation
     */
    public function getRules(string $model, string $scenario = 'default')
    {
        $rules = [];
        $messages = [];

        switch ($model) {
            case 'UserModel':
                switch ($scenario) {
                    case 'create':
                        $rules = [
                            'username' => 'required|alpha_numeric_space|min_length[3]|max_length[30]|is_unique[users.username]',
                            'email' => 'required|valid_email|is_unique[users.email]',
                            'password' => 'required|min_length[8]',
                            'password_confirm' => 'required|matches[password]',
                            'role' => 'required|in_list[0,1,2,3]',
                        ];
                        $messages = [
                            'username' => [
                                'required' => 'Tên người dùng không được để trống',
                                'alpha_numeric_space' => 'Tên người dùng chỉ được chứa chữ cái, số và khoảng trắng',
                                'min_length' => 'Tên người dùng phải có ít nhất 3 ký tự',
                                'max_length' => 'Tên người dùng không được vượt quá 30 ký tự',
                                'is_unique' => 'Tên người dùng đã tồn tại'
                            ],
                            'email' => [
                                'required' => 'Email không được để trống',
                                'valid_email' => 'Vui lòng nhập email hợp lệ',
                                'is_unique' => 'Email đã được sử dụng'
                            ],
                            'password' => [
                                'required' => 'Mật khẩu không được để trống',
                                'min_length' => 'Mật khẩu phải có ít nhất 8 ký tự'
                            ],
                            'password_confirm' => [
                                'required' => 'Vui lòng xác nhận mật khẩu',
                                'matches' => 'Xác nhận mật khẩu không khớp'
                            ],
                            'role' => [
                                'required' => 'Vai trò không được để trống',
                                'in_list' => 'Vai trò không hợp lệ'
                            ]
                        ];
                        break;
                    case 'update':
                        $rules = [
                            'username' => 'required|alpha_numeric_space|min_length[3]|max_length[30]',
                            'email' => 'required|valid_email',
                            'role' => 'required|in_list[0,1,2,3]',
                        ];
                        $messages = [
                            'username' => [
                                'required' => 'Tên người dùng không được để trống',
                                'alpha_numeric_space' => 'Tên người dùng chỉ được chứa chữ cái, số và khoảng trắng',
                                'min_length' => 'Tên người dùng phải có ít nhất 3 ký tự',
                                'max_length' => 'Tên người dùng không được vượt quá 30 ký tự'
                            ],
                            'email' => [
                                'required' => 'Email không được để trống',
                                'valid_email' => 'Vui lòng nhập email hợp lệ'
                            ],
                            'role' => [
                                'required' => 'Vai trò không được để trống',
                                'in_list' => 'Vai trò không hợp lệ'
                            ]
                        ];
                        break;
                    case 'login':
                        $rules = [
                            'email' => 'required|valid_email',
                            'password' => 'required',
                        ];
                        $messages = [
                            'email' => [
                                'required' => 'Email không được để trống',
                                'valid_email' => 'Vui lòng nhập email hợp lệ'
                            ],
                            'password' => [
                                'required' => 'Mật khẩu không được để trống'
                            ]
                        ];
                        break;
                }
                break;

            case 'StoryModel':
                switch ($scenario) {
                    case 'create':
                        $rules = [
                            'title' => 'required|min_length[3]|max_length[255]',
                            'description' => 'required|min_length[10]',
                            'author' => 'required|min_length[2]|max_length[100]',
                            'country' => 'required|alpha_dash|max_length[2]',
                            'year' => 'required|numeric|less_than_equal_to[' . date('Y') . ']|greater_than[1900]',
                            'categories' => 'required',
                            'status' => 'required|in_list[ongoing,completed,dropped,hiatus]',
                        ];
                        $messages = [
                            'title' => [
                                'required' => 'Tiêu đề truyện không được để trống',
                                'min_length' => 'Tiêu đề truyện phải có ít nhất 3 ký tự',
                                'max_length' => 'Tiêu đề truyện không được vượt quá 255 ký tự'
                            ],
                            'description' => [
                                'required' => 'Mô tả truyện không được để trống',
                                'min_length' => 'Mô tả truyện phải có ít nhất 10 ký tự'
                            ],
                            'author' => [
                                'required' => 'Tác giả không được để trống',
                                'min_length' => 'Tên tác giả phải có ít nhất 2 ký tự',
                                'max_length' => 'Tên tác giả không được vượt quá 100 ký tự'
                            ],
                            'country' => [
                                'required' => 'Quốc gia không được để trống',
                                'alpha_dash' => 'Mã quốc gia chỉ được chứa chữ cái, số, dấu gạch ngang và gạch dưới',
                                'max_length' => 'Mã quốc gia không được vượt quá 2 ký tự'
                            ],
                            'year' => [
                                'required' => 'Năm xuất bản không được để trống',
                                'numeric' => 'Năm xuất bản phải là số',
                                'less_than_equal_to' => 'Năm xuất bản không được lớn hơn năm hiện tại',
                                'greater_than' => 'Năm xuất bản phải lớn hơn 1900'
                            ],
                            'categories' => [
                                'required' => 'Vui lòng chọn ít nhất một thể loại'
                            ],
                            'status' => [
                                'required' => 'Trạng thái truyện không được để trống',
                                'in_list' => 'Trạng thái truyện không hợp lệ'
                            ]
                        ];
                        break;
                    case 'update':
                        // Tương tự rules cho create nhưng có thể bỏ một số ràng buộc
                        $rules = [
                            'title' => 'required|min_length[3]|max_length[255]',
                            'description' => 'required|min_length[10]',
                            'author' => 'required|min_length[2]|max_length[100]',
                            'country' => 'required|alpha_dash|max_length[2]',
                            'year' => 'required|numeric|less_than_equal_to[' . date('Y') . ']|greater_than[1900]',
                            'categories' => 'required',
                            'status' => 'required|in_list[ongoing,completed,dropped,hiatus]',
                        ];
                        // Sử dụng cùng messages như create
                        $messages = [
                            'title' => [
                                'required' => 'Tiêu đề truyện không được để trống',
                                'min_length' => 'Tiêu đề truyện phải có ít nhất 3 ký tự',
                                'max_length' => 'Tiêu đề truyện không được vượt quá 255 ký tự'
                            ],
                            'description' => [
                                'required' => 'Mô tả truyện không được để trống',
                                'min_length' => 'Mô tả truyện phải có ít nhất 10 ký tự'
                            ],
                            'author' => [
                                'required' => 'Tác giả không được để trống',
                                'min_length' => 'Tên tác giả phải có ít nhất 2 ký tự',
                                'max_length' => 'Tên tác giả không được vượt quá 100 ký tự'
                            ],
                            'country' => [
                                'required' => 'Quốc gia không được để trống',
                                'alpha_dash' => 'Mã quốc gia chỉ được chứa chữ cái, số, dấu gạch ngang và gạch dưới',
                                'max_length' => 'Mã quốc gia không được vượt quá 2 ký tự'
                            ],
                            'year' => [
                                'required' => 'Năm xuất bản không được để trống',
                                'numeric' => 'Năm xuất bản phải là số',
                                'less_than_equal_to' => 'Năm xuất bản không được lớn hơn năm hiện tại',
                                'greater_than' => 'Năm xuất bản phải lớn hơn 1900'
                            ],
                            'categories' => [
                                'required' => 'Vui lòng chọn ít nhất một thể loại'
                            ],
                            'status' => [
                                'required' => 'Trạng thái truyện không được để trống',
                                'in_list' => 'Trạng thái truyện không hợp lệ'
                            ]
                        ];
                        break;
                }
                break;

            // Thêm các rules cho các model khác ở đây
        }

        return [
            'rules' => $rules,
            'messages' => $messages
        ];
    }
}
