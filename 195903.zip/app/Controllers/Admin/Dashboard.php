<?php
namespace App\Controllers\Admin;

use App\Controllers\BaseController;

class Dashboard extends BaseController
{
    public function index()
    {
        $db = \Config\Database::connect();

        // Lấy thống kê
        $stats = [
            'total_stories' => $db->table('stories')->countAllResults(),
            'total_chapters' => $db->table('chapters')->countAllResults(),
            'total_users' => $db->table('users')->countAllResults(),
            'total_views' => $db->table('stories')->selectSum('views')->get()->getRow()->views ?? 0
        ];

        // Lấy các hoạt động gần đây
        $recentActivities = $db->table('activities')
                                ->select('activities.*, users.username, users.avatar')
                                ->join('users', 'users.id = activities.user_id')
                                ->orderBy('activities.created_at', 'DESC')
                                ->limit(10)
                                ->get()
                                ->getResultArray();

        // Xử lý các hoạt động để lấy chi tiết mục tiêu
        foreach ($recentActivities as &$activity) {
            if ($activity['details']) {
                $details = json_decode($activity['details'], true);
                $activity = array_merge($activity, $details);
            }
        }

        // Lấy truyện gần đây
        $recentStories = $db->table('stories')
                            ->select('stories.*, users.username as author_name')
                            ->join('users', 'users.id = stories.author_id')
                            ->orderBy('stories.created_at', 'DESC')
                            ->limit(5)
                            ->get()
                            ->getResultArray();

        // Lấy thông tin hệ thống
        $systemInfo = [
            'php_version' => PHP_VERSION,
            'ci_version' => \CodeIgniter\CodeIgniter::CI_VERSION,
            'server' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown',
            'timezone' => date_default_timezone_get(),
            'uptime' => $this->getServerUptime()
        ];

        // Đặt trang hiện tại để đánh dấu điều hướng
        $this->twig->addGlobal('current_page', 'dashboard');

        return view('admin/dashboard.html', [
            'stats' => $stats,
            'recent_activities' => $recentActivities,
            'recent_stories' => $recentStories,
            'system_info' => $systemInfo
        ]);
    }

    /**
     * Hiển thị thống kê và hiệu quả của các thuật toán tự động
     */
    public function algorithmStats()
    {
        $storyModel = new \App\Models\StoryModel();
        $logModel = new \App\Models\LogModel();

        // Lấy các thống kê về truyện
        $totalPublished = $storyModel->where('status', 'published')->countAllResults();
        $totalHot = $storyModel->where('is_hot', true)->countAllResults();
        $totalFeatured = $storyModel->where('is_featured', true)->countAllResults();
        $totalRecommended = $storyModel->where('is_recommended', true)->countAllResults();
        $totalCompleted = $storyModel->where('is_completed', true)->countAllResults();

        // Lấy log gần đây liên quan đến các thuật toán
        $recentLogs = $logModel->where('message LIKE', '%cập nhật trạng thái%')
                              ->orWhere('message LIKE', '%truyện nổi bật%')
                              ->orWhere('message LIKE', '%truyện đề xuất%')
                              ->orWhere('message LIKE', '%truyện được đánh dấu là hot%')
                              ->orderBy('created_at', 'DESC')
                              ->limit(20)
                              ->find();

        // Lấy danh sách đề xuất cần phê duyệt
        $reportDir = WRITEPATH . 'reports';
        $statusProposals = [];
        $featuredSuggestions = [];

        if (is_dir($reportDir)) {
            // Tìm file báo cáo đề xuất trạng thái gần nhất
            $statusFiles = glob($reportDir . '/status_proposals_*.json');
            if (!empty($statusFiles)) {
                rsort($statusFiles); // Sắp xếp theo thời gian giảm dần
                $latestStatusFile = $statusFiles[0];
                $statusProposals = json_decode(file_get_contents($latestStatusFile), true);
            }

            // Tìm file báo cáo đề xuất truyện nổi bật gần nhất
            $featuredFiles = glob($reportDir . '/featured_suggestions_*.json');
            if (!empty($featuredFiles)) {
                rsort($featuredFiles); // Sắp xếp theo thời gian giảm dần
                $latestFeaturedFile = $featuredFiles[0];
                $featuredSuggestions = json_decode(file_get_contents($latestFeaturedFile), true);
            }
        }

        // Thống kê hiệu quả của truyện HOT
        $hotStoryStats = [
            'avg_views' => 0,
            'avg_rating' => 0,
            'growth_rate' => 0
        ];

        $hotStories = $storyModel->where('is_hot', true)->find();
        if (!empty($hotStories)) {
            $totalHotViews = array_sum(array_column($hotStories, 'views'));
            $totalHotRatings = array_sum(array_column($hotStories, 'rating'));
            $totalHotViewsDay = array_sum(array_column($hotStories, 'views_day'));
            $totalHotViewsWeek = array_sum(array_column($hotStories, 'views_week'));

            $hotStoryStats['avg_views'] = $totalHotViews / count($hotStories);
            $hotStoryStats['avg_rating'] = $totalHotRatings / count($hotStories);
            $hotStoryStats['avg_views_day'] = $totalHotViewsDay / count($hotStories);
            $hotStoryStats['avg_views_week'] = $totalHotViewsWeek / count($hotStories);
        }

        // Thống kê hiệu quả của truyện Featured
        $featuredStoryStats = [
            'avg_views' => 0,
            'avg_rating' => 0
        ];

        $featuredStories = $storyModel->where('is_featured', true)->find();
        if (!empty($featuredStories)) {
            $totalFeaturedViews = array_sum(array_column($featuredStories, 'views'));
            $totalFeaturedRatings = array_sum(array_column($featuredStories, 'rating'));

            $featuredStoryStats['avg_views'] = $totalFeaturedViews / count($featuredStories);
            $featuredStoryStats['avg_rating'] = $totalFeaturedRatings / count($featuredStories);
        }

        // Thống kê hiệu quả của truyện Recommended
        $recommendedStoryStats = [
            'avg_views' => 0,
            'avg_rating' => 0
        ];

        $recommendedStories = $storyModel->where('is_recommended', true)->find();
        if (!empty($recommendedStories)) {
            $totalRecommendedViews = array_sum(array_column($recommendedStories, 'views'));
            $totalRecommendedRatings = array_sum(array_column($recommendedStories, 'rating'));

            $recommendedStoryStats['avg_views'] = $totalRecommendedViews / count($recommendedStories);
            $recommendedStoryStats['avg_rating'] = $totalRecommendedRatings / count($recommendedStories);
        }

        // So sánh hiệu quả của thuật toán
        $normalStories = $storyModel->where('is_hot', false)
                                   ->where('is_featured', false)
                                   ->where('is_recommended', false)
                                   ->where('status', 'published')
                                   ->find();

        $normalStoryStats = [
            'avg_views' => 0,
            'avg_rating' => 0
        ];

        if (!empty($normalStories)) {
            $totalNormalViews = array_sum(array_column($normalStories, 'views'));
            $totalNormalRatings = array_sum(array_column($normalStories, 'rating'));

            $normalStoryStats['avg_views'] = $totalNormalViews / count($normalStories);
            $normalStoryStats['avg_rating'] = $totalNormalRatings / count($normalStories);
        }

        return view('admin/dashboard/algorithm_stats', [
            'total_published' => $totalPublished,
            'total_hot' => $totalHot,
            'total_featured' => $totalFeatured,
            'total_recommended' => $totalRecommended,
            'total_completed' => $totalCompleted,
            'recent_logs' => $recentLogs,
            'status_proposals' => $statusProposals['proposals'] ?? [],
            'featured_suggestions' => $featuredSuggestions['suggestions'] ?? [],
            'hot_story_stats' => $hotStoryStats,
            'featured_story_stats' => $featuredStoryStats,
            'recommended_story_stats' => $recommendedStoryStats,
            'normal_story_stats' => $normalStoryStats
        ]);
    }

    /**
     * Hiển thị trang thống kê lượt xem
     */
    public function viewStats()
    {
        $db = \Config\Database::connect();
        $storyModel = new \App\Models\StoryModel();

        // Lấy thống kê về lượt xem
        $viewStats = [
            'total_views' => $db->table('stories')->selectSum('views')->get()->getRow()->views ?? 0,
            'daily_views' => $db->table('stories')->selectSum('views_day')->get()->getRow()->views_day ?? 0,
            'weekly_views' => $db->table('stories')->selectSum('views_week')->get()->getRow()->views_week ?? 0,
            'monthly_views' => $db->table('stories')->selectSum('views_month')->get()->getRow()->views_month ?? 0
        ];

        // Lấy top truyện xem nhiều nhất theo ngày
        $topDailyStories = $storyModel->where('status', 'published')
                                     ->orderBy('views_day', 'DESC')
                                     ->limit(10)
                                     ->find();

        // Lấy top truyện xem nhiều nhất theo tuần
        $topWeeklyStories = $storyModel->where('status', 'published')
                                      ->orderBy('views_week', 'DESC')
                                      ->limit(10)
                                      ->find();

        // Lấy top truyện xem nhiều nhất theo tháng
        $topMonthlyStories = $storyModel->where('status', 'published')
                                       ->orderBy('views_month', 'DESC')
                                       ->limit(10)
                                       ->find();

        // Lấy top truyện xem nhiều nhất mọi thời đại
        $topAllTimeStories = $storyModel->where('status', 'published')
                                       ->orderBy('views', 'DESC')
                                       ->limit(10)
                                       ->find();

        // Đặt trang hiện tại để đánh dấu điều hướng
        $this->twig->addGlobal('current_page', 'view_stats');

        return view('admin/dashboard/view_stats.html', [
            'view_stats' => $viewStats,
            'top_daily_stories' => $topDailyStories,
            'top_weekly_stories' => $topWeeklyStories,
            'top_monthly_stories' => $topMonthlyStories,
            'top_all_time_stories' => $topAllTimeStories,
        ]);
    }

    /**
     * Lấy dữ liệu lượt xem cho biểu đồ
     */
    public function getViewChartData()
    {
        $period = $this->request->getGet('period') ?? 'daily';
        $db = \Config\Database::connect();
        $storyModel = new \App\Models\StoryModel();

        switch($period) {
            case 'weekly':
                // Lấy dữ liệu 7 ngày gần nhất
                $data = [];
                $labels = [];
                for ($i = 6; $i >= 0; $i--) {
                    $date = date('Y-m-d', strtotime("-$i days"));
                    $labels[] = date('d/m', strtotime("-$i days"));

                    // Lấy tổng lượt xem theo ngày
                    $query = $db->query(
                        "SELECT SUM(daily_views) as total FROM (
                            SELECT views_day as daily_views FROM story_view_logs
                            WHERE DATE(log_date) = ?
                        ) as views",
                        [$date]
                    );

                    $data[] = (int)($query->getRow()->total ?? 0);
                }
                break;

            case 'monthly':
                // Lấy dữ liệu 30 ngày gần nhất
                $data = [];
                $labels = [];
                for ($i = 29; $i >= 0; $i--) {
                    $date = date('Y-m-d', strtotime("-$i days"));
                    $labels[] = date('d/m', strtotime("-$i days"));

                    // Lấy tổng lượt xem theo ngày
                    $query = $db->query(
                        "SELECT SUM(daily_views) as total FROM (
                            SELECT views_day as daily_views FROM story_view_logs
                            WHERE DATE(log_date) = ?
                        ) as views",
                        [$date]
                    );

                    $data[] = (int)($query->getRow()->total ?? 0);
                }
                break;

            default: // daily - 24 giờ gần nhất
                // Lấy dữ liệu theo giờ
                $data = [];
                $labels = [];
                for ($i = 23; $i >= 0; $i--) {
                    $hour = date('Y-m-d H:00:00', strtotime("-$i hours"));
                    $labels[] = date('H:00', strtotime("-$i hours"));

                    // Lấy tổng lượt xem theo giờ
                    $query = $db->query(
                        "SELECT COUNT(*) as total FROM activities
                        WHERE action IN ('viewed_story', 'viewed_chapter')
                        AND created_at BETWEEN ? AND ?",
                        [$hour, date('Y-m-d H:59:59', strtotime("-$i hours"))]
                    );

                    $data[] = (int)($query->getRow()->total ?? 0);
                }
                break;
        }

        return $this->response->setJSON([
            'success' => true,
            'labels' => $labels,
            'data' => $data
        ]);
    }

    /**
     * Lấy thống kê so sánh giữa các truyện
     */
    public function compareStories()
    {
        $storyIds = $this->request->getGet('stories');
        if (!$storyIds) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Không có truyện nào được chọn để so sánh'
            ]);
        }

        $storyIds = explode(',', $storyIds);
        $storyModel = new \App\Models\StoryModel();

        $stories = $storyModel->whereIn('id', $storyIds)->findAll();
        $data = [];

        foreach ($stories as $story) {
            $data[] = [
                'id' => $story['id'],
                'title' => $story['title'],
                'views' => [
                    'total' => (int)$story['views'],
                    'daily' => (int)$story['views_day'],
                    'weekly' => (int)$story['views_week'],
                    'monthly' => (int)$story['views_month']
                ]
            ];
        }

        return $this->response->setJSON([
            'success' => true,
            'stories' => $data
        ]);
    }

    /**
     * Lấy thống kê cho biểu đồ trang quản trị
     */
    public function stats()
    {
        $db = \Config\Database::connect();

        // Lấy lượt xem hàng ngày trong 7 ngày qua
        $visitsData = [];
        for ($i = 6; $i >= 0; $i--) {
            $date = date('Y-m-d', strtotime("-$i days"));

            // Truy vấn để lấy lượt xem cho ngày này
            $query = $db->query(
                "SELECT SUM(views_count) as total FROM (
                    SELECT COUNT(*) as views_count FROM activities
                    WHERE action = 'viewed_story' AND DATE(created_at) = ?
                    UNION ALL
                    SELECT COUNT(*) as views_count FROM activities
                    WHERE action = 'viewed_chapter' AND DATE(created_at) = ?
                ) as combined_views",
                [$date, $date]
            );

            $visitsData[] = (int)($query->getRow()->total ?? 0);
        }

        return $this->response->setJSON([
            'success' => true,
            'visits_data' => $visitsData
        ]);
    }

    /**
     * Lấy top truyện theo lượt xem
     */
    public function topStories()
    {
        $db = \Config\Database::connect();

        // Lấy top 10 truyện theo lượt xem
        $topStories = $db->table('stories')
                         ->select('stories.id, stories.title, stories.slug, stories.views, users.username as author_name')
                         ->join('users', 'users.id = stories.author_id')
                         ->orderBy('stories.views', 'DESC')
                         ->limit(10)
                         ->get()
                         ->getResultArray();

        return $this->response->setJSON([
            'success' => true,
            'stories' => $topStories
        ]);
    }

    /**
     * Lấy top người dùng theo số lượng truyện
     */
    public function topUsers()
    {
        $db = \Config\Database::connect();

        // Lấy top 10 người dùng theo số lượng truyện
        $topUsers = $db->table('users')
                       ->select('users.id, users.username, users.avatar, COUNT(stories.id) as story_count')
                       ->join('stories', 'stories.author_id = users.id', 'left')
                       ->groupBy('users.id')
                       ->orderBy('story_count', 'DESC')
                       ->limit(10)
                       ->get()
                       ->getResultArray();

        return $this->response->setJSON([
            'success' => true,
            'users' => $topUsers
        ]);
    }

    /**
     * Lấy thời gian hoạt động của máy chủ ở định dạng thân thiện
     */
    private function getServerUptime()
    {
        if (stristr(PHP_OS, 'win')) {
            // Hệ thống Windows - không hỗ trợ
            return 'Không khả dụng (Windows)';
        } else {
            // Hệ thống Linux/Unix
            $uptime = shell_exec('uptime -p');
            if ($uptime) {
                // dịch sang tiếng Việt
                $uptime = str_replace('up ', '', $uptime);
                $uptime = str_replace(' days', ' ngày', $uptime);
                $uptime = str_replace(' day', ' ngày', $uptime);
                $uptime = str_replace(' hours', ' giờ', $uptime);
                $uptime = str_replace(' hour', ' giờ', $uptime);
                $uptime = str_replace(' minutes', ' phút', $uptime);
                $uptime = str_replace(' minute', ' phút', $uptime);
                return $uptime;
            }
            return 'Không xác định';
        }
    }
}
