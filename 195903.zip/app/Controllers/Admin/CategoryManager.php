<?php
namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\CategoryModel;

class CategoryManager extends BaseController
{
    protected $categoryModel;

    public function __construct()
    {
        $this->categoryModel = new CategoryModel();
    }

    /**
     * Danh sách thể loại
     */
    public function index()
    {
        // Kiểm tra quyền admin
        $adminCheck = $this->requireAdmin();
        if ($adminCheck !== true) {
            return $adminCheck;
        }

        $page = $this->request->getGet('page') ?? 1;
        $limit = 20;
        $offset = ($page - 1) * $limit;

        // Filters
        $search = $this->request->getGet('search');

        // Lấy danh sách thể loại với phân trang
        $categories = $this->categoryModel->getAdminCategoriesList($limit, $offset, $search);
        $total = $this->categoryModel->getAdminCategoriesCount($search);

        return view('admin/category/index.html', [
            'categories' => $categories,
            'search' => $search,
            'pager' => [
                'current' => $page,
                'total' => ceil($total / $limit)
            ],
            'total' => $total
        ]);
    }

    /**
     * Tạo thể loại mới
     */
    public function create()
    {
        // Kiểm tra quyền admin
        $adminCheck = $this->requireAdmin();
        if ($adminCheck !== true) {
            return $adminCheck;
        }

        return view('admin/category/create.html');
    }

    /**
     * Lưu thể loại mới
     */
    public function save()
    {
        // Kiểm tra quyền admin
        $adminCheck = $this->requireAdmin();
        if ($adminCheck !== true) {
            return $adminCheck;
        }

        // Lấy dữ liệu từ form
        $data = [
            'name' => $this->request->getPost('name'),
            'slug' => $this->request->getPost('slug'),
            'description' => $this->request->getPost('description'),
            'status' => $this->request->getPost('status') ?? 'active'
        ];

        // Validate dữ liệu
        if (empty($data['name'])) {
            $this->session->setFlashdata('error', 'Tên thể loại không được để trống');
            return redirect()->back()->withInput();
        }

        // Tạo slug nếu không có
        if (empty($data['slug'])) {
            $data['slug'] = url_title($data['name'], '-', true);
        }

        // Kiểm tra slug đã tồn tại chưa
        $existingCategory = $this->categoryModel->where('slug', $data['slug'])->first();
        if ($existingCategory) {
            $this->session->setFlashdata('error', 'Slug đã tồn tại, vui lòng chọn slug khác');
            return redirect()->back()->withInput();
        }

        // Thêm dữ liệu thời gian
        $data['created_at'] = date('Y-m-d H:i:s');
        $data['updated_at'] = date('Y-m-d H:i:s');

        // Lưu vào database
        try {
            $this->categoryModel->insert($data);

            // Xóa cache categories
            cache()->delete('categories');

            // Log hoạt động
            $this->logModel->info('Tạo thể loại mới', [
                'category_name' => $data['name'],
                'category_slug' => $data['slug'],
                'user_id' => $this->currentUser['id']
            ]);

            $this->session->setFlashdata('success', 'Đã thêm thể loại mới thành công');
            return redirect()->to(base_url('admin/categories'));

        } catch (\Exception $e) {
            $this->session->setFlashdata('error', 'Lỗi: ' . $e->getMessage());
            return redirect()->back()->withInput();
        }
    }

    /**
     * Sửa thể loại
     */
    public function edit($id)
    {
        // Kiểm tra quyền admin
        $adminCheck = $this->requireAdmin();
        if ($adminCheck !== true) {
            return $adminCheck;
        }

        // Lấy thông tin thể loại
        $category = $this->categoryModel->find($id);
        if (!$category) {
            $this->session->setFlashdata('error', 'Không tìm thấy thể loại');
            return redirect()->to(base_url('admin/categories'));
        }

        return view('admin/category/edit.html', [
            'category' => $category
        ]);
    }

    /**
     * Cập nhật thể loại
     */
    public function update($id)
    {
        // Kiểm tra quyền admin
        $adminCheck = $this->requireAdmin();
        if ($adminCheck !== true) {
            return $adminCheck;
        }

        // Lấy thông tin thể loại hiện tại
        $category = $this->categoryModel->find($id);
        if (!$category) {
            $this->session->setFlashdata('error', 'Không tìm thấy thể loại');
            return redirect()->to(base_url('admin/categories'));
        }

        // Lấy dữ liệu từ form
        $data = [
            'name' => $this->request->getPost('name'),
            'slug' => $this->request->getPost('slug'),
            'description' => $this->request->getPost('description'),
            'status' => $this->request->getPost('status') ?? 'active',
            'updated_at' => date('Y-m-d H:i:s')
        ];

        // Validate dữ liệu
        if (empty($data['name'])) {
            $this->session->setFlashdata('error', 'Tên thể loại không được để trống');
            return redirect()->back()->withInput();
        }

        // Tạo slug nếu không có
        if (empty($data['slug'])) {
            $data['slug'] = url_title($data['name'], '-', true);
        }

        // Kiểm tra slug đã tồn tại chưa (nếu thay đổi)
        if ($data['slug'] != $category['slug']) {
            $existingCategory = $this->categoryModel->where('slug', $data['slug'])
                ->where('id !=', $id)
                ->first();

            if ($existingCategory) {
                $this->session->setFlashdata('error', 'Slug đã tồn tại, vui lòng chọn slug khác');
                return redirect()->back()->withInput();
            }
        }

        // Lưu vào database
        try {
            $this->categoryModel->update($id, $data);

            // Xóa cache categories
            cache()->delete('categories');

            // Log hoạt động
            $this->logModel->info('Cập nhật thể loại', [
                'category_id' => $id,
                'category_name' => $data['name'],
                'category_slug' => $data['slug'],
                'user_id' => $this->currentUser['id']
            ]);

            $this->session->setFlashdata('success', 'Đã cập nhật thể loại thành công');
            return redirect()->to(base_url('admin/categories'));

        } catch (\Exception $e) {
            $this->session->setFlashdata('error', 'Lỗi: ' . $e->getMessage());
            return redirect()->back()->withInput();
        }
    }

    /**
     * Xóa thể loại (AJAX)
     */
    public function delete()
    {
        // Kiểm tra quyền admin
        if (!$this->isAdmin()) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Không có quyền truy cập'
            ]);
        }

        $id = $this->request->getPost('id');
        if (!$id) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'ID không hợp lệ'
            ]);
        }

        // Lấy thông tin thể loại
        $category = $this->categoryModel->find($id);
        if (!$category) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Không tìm thấy thể loại'
            ]);
        }

        // Kiểm tra xem thể loại đã được sử dụng chưa
        $storyCategoryModel = new \App\Models\StoryCategoryModel();
        $usedCount = $storyCategoryModel->where('category_id', $id)->countAllResults();

        if ($usedCount > 0) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Không thể xóa thể loại đã được gán cho ' . $usedCount . ' truyện'
            ]);
        }

        try {
            // Xóa thể loại
            $this->categoryModel->delete($id);

            // Xóa cache categories
            cache()->delete('categories');

            // Log hoạt động
            $this->logModel->warning('Xóa thể loại', [
                'category_id' => $id,
                'category_name' => $category['name'],
                'category_slug' => $category['slug'],
                'user_id' => $this->currentUser['id']
            ]);

            return $this->response->setJSON([
                'success' => true,
                'message' => 'Đã xóa thể loại thành công'
            ]);

        } catch (\Exception $e) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Lỗi: ' . $e->getMessage()
            ]);
        }
    }
}
