/**
 * Hệ thống Truyện yêu thích (Favorites)
 *
 * Module này xử lý các truyện yêu thích, sử dụng localStorage cho lưu trữ client-side.
 * Các thông tin được tối ưu để tiết kiệm dung lượng lưu trữ.
 */
const ClientFavorite = {
    // Cài đặt mặc định
    config: {
        maxItems: 50,                      // Số lượng truyện yêu thích tối đa
        maxStorageMB: 1,                   // Dung lượng tối đa (MB)
        cleanupInterval: 30 * 24 * 60 * 60, // Thời gian tự động dọn dẹp (30 ngày)
        storageKey: 'favorites',           // Key để lưu trong localStorage
        lastCleanupKey: 'favorite_cleanup' // Key lưu thời gian dọn dẹp gần nhất
    },

    /**
     * Khởi tạo hệ thống truyện yêu thích
     */
    init: function() {
        // Kiểm tra nếu localStorage khả dụng
        if (!this.isLocalStorageAvailable()) {
            console.warn('localStorage không khả dụng. Truyện yêu thích sẽ không được lưu.');
            return;
        }

        // Khởi tạo localStorage nếu cần
        if (!localStorage.getItem(this.config.storageKey)) {
            localStorage.setItem(this.config.storageKey, JSON.stringify({}));
        }

        // Tối ưu dữ liệu hiện tại để giảm dung lượng
        this.optimizeStorage();

        // Dọn dẹp truyện yêu thích cũ nếu cần
        this.performCleanupIfNeeded();
    },

    /**
     * Thêm hoặc chuyển đổi trạng thái yêu thích
     *
     * @param {number} storyId - ID của truyện cần đánh dấu
     * @param {object} storyData - Dữ liệu bổ sung của truyện (tiêu đề, v.v.)
     * @returns {object} Trạng thái của thao tác
     */
    toggle: function(storyId, storyData) {
        let favorites = this.getAll();
        let action = '';
        let message = '';

        if (favorites[storyId]) {
            // Xóa truyện yêu thích nếu đã tồn tại
            delete favorites[storyId];
            action = 'removed';
            message = 'Đã bỏ yêu thích';

            // Giảm số lượt yêu thích (gửi yêu cầu AJAX)
            this.updateFavoritesCount(storyId, -1);
        } else {
            // Thêm truyện yêu thích mới với dữ liệu tối ưu
            favorites[storyId] = this.createOptimizedFavorite(storyId, storyData);
            action = 'added';
            message = 'Đã thêm vào danh sách yêu thích';

            // Tăng số lượt yêu thích (gửi yêu cầu AJAX)
            this.updateFavoritesCount(storyId, 1);

            // Kiểm tra giới hạn lưu trữ sau khi thêm
            this.enforceStorageLimits();
        }

        // Lưu vào localStorage
        this.saveAll(favorites);

        return {
            action: action,
            message: message
        };
    },

    /**
     * Cập nhật số lượng yêu thích cho truyện trên server
     *
     * @param {number} storyId - ID của truyện
     * @param {number} delta - Số lượng thay đổi (1: tăng, -1: giảm)
     */
    updateFavoritesCount: function(storyId, delta) {
        // Lấy CSRF token từ meta tag
        const csrfToken = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content');

        // Gửi yêu cầu AJAX để cập nhật số lượng yêu thích
        fetch('/story/update-favorites-count', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Requested-With': 'XMLHttpRequest',
                'X-CSRF-TOKEN': csrfToken
            },
            body: `story_id=${storyId}&delta=${delta}&csrf_token_name=${csrfToken}`
        })
        .catch(error => {
            console.error('Lỗi khi cập nhật số lượng yêu thích:', error);
        });
    },

    /**
     * Tạo thông tin truyện yêu thích với dữ liệu tối ưu để tiết kiệm dung lượng
     *
     * @param {number} storyId - ID truyện
     * @param {object} storyData - Dữ liệu truyện
     * @returns {object} Thông tin truyện yêu thích đã được tối ưu
     */
    createOptimizedFavorite: function(storyId, storyData) {
        // Chỉ lưu các thông tin cần thiết: ID và slug
        return {
            i: parseInt(storyId),                   // ID (i thay vì id)
            s: (storyData.slug || '').substr(0, 50),    // Lưu slug để truy vấn
            d: Math.floor(Date.now() / 1000)            // Date (Unix timestamp thay vì ISO string)
        };
    },

    /**
     * Kiểm tra nếu một truyện đã được yêu thích
     *
     * @param {number} storyId - ID truyện cần kiểm tra
     * @returns {boolean} True nếu đã yêu thích
     */
    isFavorited: function(storyId) {
        const favorites = this.getAll();
        return !!favorites[storyId];
    },

    /**
     * Lấy tất cả truyện yêu thích dưới dạng đối tượng
     *
     * @returns {object} Tất cả truyện yêu thích
     */
    getAll: function() {
        const data = localStorage.getItem(this.config.storageKey);
        return data ? JSON.parse(data) : {};
    },

    /**
     * Lấy tất cả truyện yêu thích dưới dạng mảng (để hiển thị)
     *
     * @returns {array} Mảng các đối tượng truyện yêu thích
     */
    getAllAsArray: function() {
        const favorites = this.getAll();
        const result = [];

        for (const id in favorites) {
            if (favorites.hasOwnProperty(id)) {
                const favorite = favorites[id];
                // Chuyển từ định dạng tối ưu sang định dạng đầy đủ
                result.push({
                    id: favorite.i || parseInt(id),
                    slug: favorite.s || '',
                    time: favorite.d ? new Date(favorite.d * 1000).toISOString() : new Date().toISOString()
                });
            }
        }

        // Sắp xếp theo thời gian gần nhất trước
        return result.sort((a, b) => {
            return new Date(b.time) - new Date(a.time);
        });
    },

    /**
     * Lưu tất cả truyện yêu thích vào localStorage
     *
     * @param {object} favorites - Đối tượng truyện yêu thích
     */
    saveAll: function(favorites) {
        try {
            localStorage.setItem(this.config.storageKey, JSON.stringify(favorites));
        } catch (e) {
            console.error('Lỗi khi lưu truyện yêu thích:', e);
            // Nếu lỗi do vượt quá dung lượng, giảm số lượng truyện yêu thích
            if (e.name === 'QuotaExceededError' || e.name === 'NS_ERROR_DOM_QUOTA_REACHED') {
                this.enforceStorageLimits(true);
            }
        }
    },

    /**
     * Xóa tất cả truyện yêu thích
     */
    clearAll: function() {
        localStorage.setItem(this.config.storageKey, JSON.stringify({}));
    },

    /**
     * Thực hiện việc dọn dẹp truyện yêu thích cũ nếu cần thiết
     */
    performCleanupIfNeeded: function() {
        const lastCleanup = localStorage.getItem(this.config.lastCleanupKey);
        const now = Math.floor(Date.now() / 1000);

        // Nếu chưa có thời gian dọn dẹp gần nhất hoặc đã quá hạn dọn dẹp
        if (!lastCleanup || (now - parseInt(lastCleanup)) > this.config.cleanupInterval) {
            this.optimizeStorage();
            this.enforceStorageLimits();
            localStorage.setItem(this.config.lastCleanupKey, now.toString());
        }
    },

    /**
     * Tối ưu dữ liệu lưu trữ để giảm dung lượng
     */
    optimizeStorage: function() {
        const favorites = this.getAll();
        const optimizedFavorites = {};

        // Chuyển đổi tất cả truyện yêu thích sang định dạng tối ưu
        for (const storyId in favorites) {
            if (favorites.hasOwnProperty(storyId)) {
                const favorite = favorites[storyId];

                // Nếu đã ở định dạng tối ưu (có trường i), giữ nguyên
                if (favorite.i !== undefined) {
                    optimizedFavorites[storyId] = favorite;
                    continue;
                }

                // Nếu đang ở định dạng cũ, chuyển đổi sang định dạng tối ưu
                optimizedFavorites[storyId] = this.createOptimizedFavorite(
                    parseInt(storyId),
                    {
                        slug: favorite.slug || ''
                    }
                );

                // Giữ lại thời gian gốc nếu có
                if (favorite.time) {
                    try {
                        optimizedFavorites[storyId].d = Math.floor(new Date(favorite.time).getTime() / 1000);
                    } catch (e) {
                        // Nếu lỗi, sử dụng thời gian hiện tại
                        optimizedFavorites[storyId].d = Math.floor(Date.now() / 1000);
                    }
                }
            }
        }

        // Lưu trạng thái đã tối ưu
        this.saveAll(optimizedFavorites);
    },

    /**
     * Thực thi các giới hạn lưu trữ để không vượt quá dung lượng cho phép
     *
     * @param {boolean} forceReduce - Có bắt buộc giảm dung lượng không
     */
    enforceStorageLimits: function(forceReduce = false) {
        const favorites = this.getAll();
        const favoriteCount = Object.keys(favorites).length;

        // Kiểm tra giới hạn số lượng
        if (favoriteCount > this.config.maxItems || forceReduce) {
            const favoritesArray = [];

            // Chuyển sang mảng để sắp xếp
            for (const id in favorites) {
                if (favorites.hasOwnProperty(id)) {
                    const item = favorites[id];
                    favoritesArray.push({
                        id: id,
                        data: item,
                        time: item.d || 0
                    });
                }
            }

            // Sắp xếp theo thời gian, mới nhất trước
            favoritesArray.sort((a, b) => b.time - a.time);

            // Giữ lại chỉ số lượng tối đa
            const keepCount = forceReduce ? Math.floor(this.config.maxItems * 0.7) : this.config.maxItems;
            const keptFavorites = {};

            favoritesArray.slice(0, keepCount).forEach(item => {
                keptFavorites[item.id] = item.data;
            });

            // Lưu lại danh sách đã giảm
            this.saveAll(keptFavorites);
        }

        // Kiểm tra dung lượng nếu có thể
        this.checkStorageSize();
    },

    /**
     * Kiểm tra kích thước lưu trữ và hiển thị thông báo nếu gần đầy
     */
    checkStorageSize: function() {
        try {
            // Ước tính kích thước localStorage
            let totalSize = 0;
            for (let i = 0; i < localStorage.length; i++) {
                const key = localStorage.key(i);
                const value = localStorage.getItem(key);
                totalSize += (key.length + value.length) * 2; // Ký tự UTF-16 = 2 byte
            }

            const sizeMB = totalSize / (1024 * 1024);

            // Nếu gần đạt giới hạn, hiển thị thông báo nếu cần
            if (sizeMB > this.config.maxStorageMB * 0.9) {
                console.warn(`Dung lượng lưu trữ gần đầy: ${sizeMB.toFixed(2)}MB/${this.config.maxStorageMB}MB`);

                // Có thể hiển thị thông báo cho người dùng nếu cần
            }
        } catch (e) {
            console.error('Lỗi khi kiểm tra kích thước lưu trữ:', e);
        }
    },

    /**
     * Kiểm tra liệu localStorage có khả dụng không
     *
     * @returns {boolean} True nếu localStorage khả dụng
     */
    isLocalStorageAvailable: function() {
        try {
            const test = 'test';
            localStorage.setItem(test, test);
            localStorage.removeItem(test);
            return true;
        } catch (e) {
            return false;
        }
    }
};

// Khởi tạo hệ thống truyện yêu thích khi trang tải xong
document.addEventListener('DOMContentLoaded', function() {
    ClientFavorite.init();

    // Thêm event listeners cho các nút yêu thích nếu tồn tại
    const favoriteButtons = document.querySelectorAll('.favorite-button, .js-favorite-btn');

    favoriteButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();

            const storyId = parseInt(this.dataset.storyId);
            const storySlug = this.dataset.storySlug || '';

            const result = ClientFavorite.toggle(storyId, {
                slug: storySlug
            });

            // Cập nhật giao diện dựa trên kết quả
            if (result.action === 'added') {
                this.classList.add('active');
                this.title = 'Bỏ yêu thích';
                if (this.querySelector('.favorite-text')) {
                    this.querySelector('.favorite-text').textContent = 'Đã thích';
                }

                // Cập nhật số lượng hiển thị nếu có
                const countDisplay = document.querySelector('.favorite-count[data-story-id="' + storyId + '"]');
                if (countDisplay) {
                    let count = parseInt(countDisplay.textContent);
                    countDisplay.textContent = (count + 1).toString();
                }
            } else {
                this.classList.remove('active');
                this.title = 'Yêu thích';
                if (this.querySelector('.favorite-text')) {
                    this.querySelector('.favorite-text').textContent = 'Yêu thích';
                }

                // Cập nhật số lượng hiển thị nếu có
                const countDisplay = document.querySelector('.favorite-count[data-story-id="' + storyId + '"]');
                if (countDisplay) {
                    let count = parseInt(countDisplay.textContent);
                    if (count > 0) {
                        countDisplay.textContent = (count - 1).toString();
                    }
                }
            }

            // Hiển thị thông báo nếu có
            if (window.showNotification) {
                window.showNotification(result.message);
            }
        });
    });

    // Khởi tạo trạng thái các nút yêu thích
    favoriteButtons.forEach(button => {
        const storyId = parseInt(button.dataset.storyId);
        if (ClientFavorite.isFavorited(storyId)) {
            button.classList.add('active');
            button.title = 'Bỏ yêu thích';
            if (button.querySelector('.favorite-text')) {
                button.querySelector('.favorite-text').textContent = 'Đã thích';
            }
        }
    });
});
