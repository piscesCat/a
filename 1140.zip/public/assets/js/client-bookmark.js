/**
 * Client-side Bookmark System
 *
 * This module handles bookmarks entirely on the client-side using localStorage.
 * No server-side storage is used.
 */
const ClientBookmark = {
    /**
     * Initialize the bookmark system
     */
    init: function() {
        // Check if localStorage is available
        if (!this.isLocalStorageAvailable()) {
            console.warn('localStorage không khả dụng. Đánh dấu truyện sẽ không thể lưu trữ.');
            return;
        }

        // Initialize localStorage if needed
        if (!localStorage.getItem('bookmarks')) {
            localStorage.setItem('bookmarks', JSON.stringify({}));
        }

        // Set up event listeners for bookmark buttons
        this.setupEventListeners();

        // Initialize bookmark button states
        this.updateBookmarkButtonStates();
    },

    /**
     * Set up event listeners for bookmark buttons
     */
    setupEventListeners: function() {
        const bookmarkButtons = document.querySelectorAll('.bookmark-button, .js-bookmark-btn');

        bookmarkButtons.forEach(button => {
            button.addEventListener('click', function(e) {
                e.preventDefault();

                const storyId = parseInt(this.dataset.storyId);
                const chapterId = this.dataset.chapterId ? parseInt(this.dataset.chapterId) : null;
                const storyTitle = this.dataset.storyTitle || '';
                const storySlug = this.dataset.storySlug || '';
                const coverImage = this.dataset.coverImage || '';
                const authorName = this.dataset.authorName || '';

                const result = ClientBookmark.toggle(storyId, {
                    title: storyTitle,
                    slug: storySlug,
                    cover_image: coverImage,
                    author_name: authorName
                }, chapterId);

                // Update UI based on result
                if (result.action === 'added') {
                    this.classList.add('active');
                    this.title = 'Đã lưu vào tủ truyện';
                    if (this.querySelector('.bookmark-text')) {
                        this.querySelector('.bookmark-text').textContent = 'Đã lưu';
                    }
                } else {
                    this.classList.remove('active');
                    this.title = 'Lưu vào tủ truyện';
                    if (this.querySelector('.bookmark-text')) {
                        this.querySelector('.bookmark-text').textContent = 'Lưu truyện';
                    }
                }

                // Show notification if available
                if (window.showNotification) {
                    window.showNotification(result.message);
                }
            });
        });
    },

    /**
     * Update all bookmark button states based on localStorage
     */
    updateBookmarkButtonStates: function() {
        const bookmarkButtons = document.querySelectorAll('.bookmark-button, .js-bookmark-btn');

        bookmarkButtons.forEach(button => {
            const storyId = parseInt(button.dataset.storyId);
            if (this.isBookmarked(storyId)) {
                button.classList.add('active');
                button.title = 'Đã lưu vào tủ truyện';
                if (button.querySelector('.bookmark-text')) {
                    button.querySelector('.bookmark-text').textContent = 'Đã lưu';
                }
            }
        });
    },

    /**
     * Add or toggle a bookmark
     *
     * @param {number} storyId - ID của truyện cần đánh dấu
     * @param {object} storyData - Dữ liệu bổ sung của truyện (tiêu đề, v.v.)
     * @param {number|null} chapterId - ID của chương (nếu có)
     * @returns {object} Trạng thái của thao tác
     */
    toggle: function(storyId, storyData, chapterId = null) {
        let bookmarks = this.getAll();
        let action = '';
        let message = '';

        if (bookmarks[storyId]) {
            // Xóa đánh dấu nếu đã tồn tại
            delete bookmarks[storyId];
            action = 'removed';
            message = 'Đã xóa khỏi danh sách theo dõi';
        } else {
            // Giới hạn số lượng bookmark (tối đa 100)
            const maxBookmarks = 100;
            const bookmarkArray = Object.values(bookmarks);

            if (bookmarkArray.length >= maxBookmarks) {
                // Sắp xếp theo thời gian, xóa bookmark cũ nhất
                bookmarkArray.sort((a, b) => new Date(a.time) - new Date(b.time));
                delete bookmarks[bookmarkArray[0].id];
            }

            // Thêm đánh dấu mới
            bookmarks[storyId] = {
                id: storyId,
                title: storyData.title || '',
                slug: storyData.slug || '',
                cover_image: storyData.cover_image || '',
                author_name: storyData.author_name || '',
                chapter_id: chapterId,
                time: new Date().toISOString()
            };
            action = 'added';
            message = 'Đã thêm vào danh sách theo dõi';
        }

        // Lưu vào localStorage
        this.saveAll(bookmarks);

        return {
            action: action,
            message: message
        };
    },

    /**
     * Cập nhật thông tin chương cho truyện đã đánh dấu
     *
     * @param {number} storyId - ID của truyện
     * @param {number} chapterId - ID của chương
     * @returns {boolean} Trạng thái thành công
     */
    updateChapter: function(storyId, chapterId) {
        let bookmarks = this.getAll();

        if (!bookmarks[storyId]) {
            // Nếu truyện chưa được đánh dấu, hàm này không làm gì
            return false;
        }

        // Cập nhật ID chương và thời gian
        bookmarks[storyId].chapter_id = chapterId;
        bookmarks[storyId].time = new Date().toISOString();

        // Lưu vào localStorage
        this.saveAll(bookmarks);

        return true;
    },

    /**
     * Kiểm tra xem một truyện đã được đánh dấu hay chưa
     *
     * @param {number} storyId - ID của truyện cần kiểm tra
     * @returns {boolean} True nếu đã được đánh dấu
     */
    isBookmarked: function(storyId) {
        const bookmarks = this.getAll();
        return !!bookmarks[storyId];
    },

    /**
     * Lấy thông tin một đánh dấu cụ thể
     *
     * @param {number} storyId - ID của truyện
     * @returns {object|null} Dữ liệu đánh dấu hoặc null
     */
    get: function(storyId) {
        const bookmarks = this.getAll();
        return bookmarks[storyId] || null;
    },

    /**
     * Lấy tất cả đánh dấu dưới dạng đối tượng
     *
     * @returns {object} Tất cả đánh dấu
     */
    getAll: function() {
        const data = localStorage.getItem('bookmarks');
        return data ? JSON.parse(data) : {};
    },

    /**
     * Lấy tất cả đánh dấu dưới dạng mảng (để hiển thị)
     *
     * @returns {array} Mảng các đối tượng đánh dấu
     */
    getAllAsArray: function() {
        const bookmarks = this.getAll();
        return Object.values(bookmarks).sort((a, b) => {
            return new Date(b.time) - new Date(a.time);
        });
    },

    /**
     * Lưu tất cả đánh dấu vào localStorage
     *
     * @param {object} bookmarks - Đối tượng đánh dấu
     */
    saveAll: function(bookmarks) {
        localStorage.setItem('bookmarks', JSON.stringify(bookmarks));
    },

    /**
     * Xóa tất cả đánh dấu
     */
    clearAll: function() {
        localStorage.setItem('bookmarks', JSON.stringify({}));
    },

    /**
     * Kiểm tra xem localStorage có khả dụng không
     *
     * @returns {boolean} True nếu localStorage khả dụng
     */
    isLocalStorageAvailable: function() {
        try {
            const test = 'test';
            localStorage.setItem(test, test);
            localStorage.removeItem(test);
            return true;
        } catch (e) {
            return false;
        }
    },

    /**
     * Xuất đánh dấu ra file JSON
     */
    exportBookmarks: function() {
        const bookmarks = this.getAll();
        const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(bookmarks));
        const downloadAnchorNode = document.createElement('a');
        downloadAnchorNode.setAttribute("href", dataStr);
        downloadAnchorNode.setAttribute("download", "bookmarks_" + new Date().toISOString().split('T')[0] + ".json");
        document.body.appendChild(downloadAnchorNode);
        downloadAnchorNode.click();
        downloadAnchorNode.remove();
    },

    /**
     * Nhập đánh dấu từ file JSON
     *
     * @param {File} file - File JSON để nhập
     * @returns {Promise} Promise với kết quả nhập
     */
    importBookmarks: function(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();

            reader.onload = (event) => {
                try {
                    const bookmarks = JSON.parse(event.target.result);
                    this.saveAll(bookmarks);
                    this.updateBookmarkButtonStates();
                    resolve({
                        success: true,
                        count: Object.keys(bookmarks).length
                    });
                } catch (e) {
                    reject({
                        success: false,
                        error: 'File JSON không hợp lệ'
                    });
                }
            };

            reader.onerror = () => {
                reject({
                    success: false,
                    error: 'Không thể đọc file'
                });
            };

            reader.readAsText(file);
        });
    }
};

// Khởi tạo hệ thống đánh dấu khi trang tải xong
document.addEventListener('DOMContentLoaded', function() {
    ClientBookmark.init();
});
