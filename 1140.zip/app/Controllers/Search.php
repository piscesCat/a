<?php
namespace App\Controllers;

use App\Models\StoryModel;
use App\Models\CategoryModel;

class Search extends BaseController
{
    protected $storyModel;
    protected $categoryModel;

    public function __construct()
    {
        $this->storyModel = new StoryModel();
        $this->categoryModel = new CategoryModel();
    }

    /**
     * Display search results with enhanced filters
     */
    public function index()
    {
        $query = $this->request->getGet('q') ?? '';

        if (empty($query)) {
            return redirect()->to(base_url());
        }

        $page = $this->request->getGet('page') ?? 1;
        $limit = 24;
        $offset = ($page - 1) * $limit;

        // Lấy các bộ lọc từ query string
        $filters = [
            'sort' => $this->request->getGet('sort') ?? 'relevance',
            'status' => $this->request->getGet('status') ?? '',
            'category' => $this->request->getGet('category') ?? '',
            'country' => $this->request->getGet('country') ?? '',
            'year' => $this->request->getGet('year') ?? '',
        ];

        // Lấy kết quả tìm kiếm với bộ lọc
        $result = $this->storyModel->searchStories($query, $limit, $offset, $filters);
        $stories = $result['stories'];
        $totalResults = $result['total'];

        $totalPages = ceil($totalResults / $limit);

        // Lấy danh sách thể loại để lọc
        $categories = $this->categoryModel->findAll();

        // Lấy danh sách quốc gia để lọc
        $countries = $this->storyModel->getAllCountries();

        // Lấy từ khóa tìm kiếm thịnh hành
        $trendingSearchTerms = $this->getTrendingSearchTerms();

        // Lưu từ khóa tìm kiếm để thống kê
        $this->saveSearchQuery($query);

        // Lấy các năm phát hành để tạo bộ lọc
        $years = $this->getYearsList();

        return $this->renderView('search/results.html', [
            'query' => $query,
            'stories' => $stories,
            'current_page' => (int)$page,
            'total_pages' => $totalPages,
            'total_results' => $totalResults,
            'filters' => $filters,
            'categories' => $categories,
            'countries' => $countries,
            'years' => $years,
            'trending_search_terms' => $trendingSearchTerms
        ]);
    }

    /**
     * API gợi ý tìm kiếm được cải thiện
     */
    public function suggestions()
    {
        if (!$this->request->isAJAX()) {
            return $this->response->setStatusCode(403);
        }

        $query = $this->request->getGet('q') ?? '';

        if (empty($query) || strlen($query) < 2) {
            return $this->response->setJSON(['suggestions' => []]);
        }

        // Lấy gợi ý tìm kiếm từ model
        $suggestions = $this->storyModel->getSearchSuggestions($query, 10);

        // Lưu từ khóa tìm kiếm
        $this->saveSearchQuery($query, 'suggestion');

        return $this->response->setJSON(['suggestions' => $suggestions]);
    }

    /**
     * Lưu từ khóa tìm kiếm vào database
     */
    protected function saveSearchQuery($query, $type = 'search')
    {
        // Bỏ qua các truy vấn ngắn hoặc chỉ chứa ký tự đặc biệt
        if (strlen($query) < 2 || !preg_match('/[a-zA-Z0-9\p{L}]/u', $query)) {
            return false;
        }

        $db = \Config\Database::connect();

        // Kiểm tra xem từ khóa đã tồn tại chưa
        $existing = $db->table('search_queries')
            ->where('query', $query)
            ->get()
            ->getRow();

        $currentTime = date('Y-m-d H:i:s');
        $userId = session()->get('isLoggedIn') ? session()->get('user')['id'] : null;
        $ipAddress = $this->request->getIPAddress();

        if ($existing) {
            // Cập nhật số lượt tìm và thời gian
            return $db->table('search_queries')
                ->where('query', $query)
                ->update([
                    'count' => $existing->count + 1,
                    'last_searched' => $currentTime,
                    'user_id' => $userId,
                    'ip_address' => $ipAddress,
                    'search_type' => $type
                ]);
        } else {
            // Thêm từ khóa mới
            return $db->table('search_queries')
                ->insert([
                    'query' => $query,
                    'count' => 1,
                    'last_searched' => $currentTime,
                    'created_at' => $currentTime,
                    'user_id' => $userId,
                    'ip_address' => $ipAddress,
                    'search_type' => $type
                ]);
        }
    }

    /**
     * Lấy từ khóa tìm kiếm phổ biến
     */
    protected function getTrendingSearchTerms($limit = 10)
    {
        $db = \Config\Database::connect();

        // Lấy từ khóa tìm kiếm nhiều nhất trong 7 ngày qua
        $result = $db->table('search_queries')
            ->select('query, count')
            ->where('last_searched >=', date('Y-m-d H:i:s', strtotime('-7 days')))
            ->where('search_type', 'search')
            ->orderBy('count', 'DESC')
            ->limit($limit)
            ->get()
            ->getResultArray();

        return $result;
    }

    /**
     * Lấy danh sách các năm phát hành để tạo bộ lọc
     */
    protected function getYearsList()
    {
        $db = \Config\Database::connect();

        // Lấy danh sách các năm phát hành từ database
        $result = $db->table('stories')
            ->select('release_year')
            ->distinct()
            ->where('release_year IS NOT NULL')
            ->orderBy('release_year', 'DESC')
            ->get()
            ->getResultArray();

        return array_column($result, 'release_year');
    }
}
