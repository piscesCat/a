<?php

namespace App\Services;

use CodeIgniter\HTTP\ResponseInterface;
use Config\Services;

class ErrorService
{
    protected $response;
    protected $request;
    protected $logger;
    protected $logModel;

    public function __construct()
    {
        $this->response = Services::response();
        $this->request = Services::request();
        $this->logger = Services::logger();

        // Tạo LogModel nếu table đã tồn tại
        if ($this->tableExists('logs')) {
            $this->logModel = new \App\Models\LogModel();
        }
    }

    /**
     * Xử lý và trả về lỗi cho API call
     *
     * @param string $message Thông báo lỗi
     * @param int $code Mã lỗi HTTP
     * @param array $data Dữ liệu bổ sung
     * @param bool $logError Có lưu vào log không
     * @return ResponseInterface
     */
    public function handleApiError(string $message, int $code = 400, array $data = [], bool $logError = true): ResponseInterface
    {
        if ($logError) {
            $this->logError('API Error: ' . $message, [
                'code' => $code,
                'data' => $data,
                'uri' => (string)$this->request->getUri(),
                'method' => $this->request->getMethod(),
                'ip' => $this->request->getIPAddress(),
                'user_agent' => $this->request->getUserAgent()->getAgentString()
            ]);
        }

        return $this->response->setStatusCode($code)->setJSON([
            'success' => false,
            'message' => $message,
            'data' => $data
        ]);
    }

    /**
     * Xử lý và trả về thành công cho API call
     *
     * @param string $message Thông báo thành công
     * @param array $data Dữ liệu kèm theo
     * @return ResponseInterface
     */
    public function handleApiSuccess(string $message, array $data = []): ResponseInterface
    {
        return $this->response->setJSON([
            'success' => true,
            'message' => $message,
            'data' => $data
        ]);
    }

    /**
     * Xử lý các lỗi database
     *
     * @param \Exception $e Exception
     * @param string $operation Mô tả thao tác
     * @param bool $isApi Lỗi từ API hay không
     * @return ResponseInterface|string
     */
    public function handleDatabaseError(\Exception $e, string $operation, bool $isApi = false)
    {
        $errorMessage = 'Lỗi cơ sở dữ liệu trong thao tác: ' . $operation;
        $errorData = [
            'error_message' => $e->getMessage(),
            'error_code' => $e->getCode(),
            'file' => $e->getFile(),
            'line' => $e->getLine()
        ];

        // Ghi log
        $this->logError($errorMessage, $errorData);

        // Trả về phản hồi tùy theo loại yêu cầu
        if ($isApi) {
            return $this->handleApiError('Lỗi cơ sở dữ liệu', 500, [
                'operation' => $operation
            ], false); // Log đã được gọi ở trên
        }

        return 'Đã xảy ra lỗi cơ sở dữ liệu. Vui lòng thử lại sau.';
    }

    /**
     * Ghi log lỗi
     *
     * @param string $message Thông báo lỗi
     * @param array $context Dữ liệu bổ sung
     * @return void
     */
    public function logError(string $message, array $context = []): void
    {
        // Ghi log bằng LogModel nếu có
        if (isset($this->logModel)) {
            $this->logModel->error($message, $context);
        }

        // Ghi log bằng Logger của CodeIgniter
        $this->logger->error($message, $context);
    }

    /**
     * Ghi log cảnh báo
     *
     * @param string $message Thông báo cảnh báo
     * @param array $context Dữ liệu bổ sung
     * @return void
     */
    public function logWarning(string $message, array $context = []): void
    {
        // Ghi log bằng LogModel nếu có
        if (isset($this->logModel)) {
            $this->logModel->warning($message, $context);
        }

        // Ghi log bằng Logger của CodeIgniter
        $this->logger->warning($message, $context);
    }

    /**
     * Ghi log thông tin
     *
     * @param string $message Thông báo
     * @param array $context Dữ liệu bổ sung
     * @return void
     */
    public function logInfo(string $message, array $context = []): void
    {
        // Ghi log bằng LogModel nếu có
        if (isset($this->logModel)) {
            $this->logModel->info($message, $context);
        }

        // Ghi log bằng Logger của CodeIgniter
        $this->logger->info($message, $context);
    }

    /**
     * Kiểm tra xem table có tồn tại không
     *
     * @param string $tableName Tên bảng
     * @return bool
     */
    private function tableExists(string $tableName): bool
    {
        $db = \Config\Database::connect();

        try {
            if ($db->tableExists($tableName)) {
                return true;
            }
        } catch (\Exception $e) {
            // Bỏ qua lỗi, trả về false
        }

        return false;
    }
}
