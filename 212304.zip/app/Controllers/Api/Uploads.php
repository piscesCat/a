<?php

namespace App\Controllers\Api;

use App\Controllers\BaseController;
use App\Models\MediaModel;
use App\Libraries\ImgurClient;
use App\Services\AuthService;
use Psr\Http\Message\ResponseInterface;

class Uploads extends BaseController
{
    protected $mediaModel;
    protected $imgurClient;
    protected $authService;

    public function __construct()
    {
        $this->mediaModel = new MediaModel();
        $this->imgurClient = new ImgurClient();
        $this->authService = new AuthService();
    }

    /**
     * API upload ảnh - Endpoint chung cho cả Local và Imgur
     */
    public function uploadImage()
    {
        // Kiểm tra xác thực API (token) và quyền truy cập
        $user = $this->authService->checkApiPermission();

        // Nếu kết quả là đối tượng Response (không có quyền), trả về nó
        if ($user instanceof ResponseInterface) {
            return $user;
        }

        // Kiểm tra nếu có URL được cung cấp (cho upload từ URL)
        $url = $this->request->getPost('url');
        if (!empty($url) && filter_var($url, FILTER_VALIDATE_URL)) {
            // Upload từ URL (chỉ hỗ trợ Imgur)
            $uploadType = $this->request->getPost('upload_type') ?? 'imgur';
            if ($uploadType === 'imgur') {
                // Kiểm tra Imgur Client ID
                $settingsModel = new \App\Models\SettingsModel();
                $clientId = $settingsModel->getSetting('imgur_client_id', '');

                if (empty($clientId)) {
                    return $this->response->setStatusCode(400)->setJSON([
                        'success' => false,
                        'message' => 'Imgur Client ID chưa được cấu hình'
                    ]);
                }

                // Validate URL có phải là ảnh không
                $validUrlTypes = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'];
                $urlPath = parse_url($url, PHP_URL_PATH);
                $urlExtension = strtolower(pathinfo($urlPath, PATHINFO_EXTENSION));

                if (!in_array($urlExtension, $validUrlTypes)) {
                    return $this->response->setStatusCode(400)->setJSON([
                        'success' => false,
                        'message' => 'URL không phải là ảnh hợp lệ. Chỉ chấp nhận: ' . implode(', ', $validUrlTypes)
                    ]);
                }

                // Upload lên Imgur từ URL
                $result = $this->imgurClient->uploadImageFromUrl($url);

                if ($result['success']) {
                    // Lưu thông tin vào database
                    $mediaData = [
                        'file_name' => basename($url),
                        'file_path' => $result['data']['link'],
                        'file_type' => 'image/' . $urlExtension,
                        'file_size' => 0, // Không thể xác định kích thước trước
                        'user_id' => $user['id'],
                        'uploaded_at' => date('Y-m-d H:i:s'),
                        'is_external' => 1,
                        'external_type' => 'imgur',
                        'external_id' => $result['data']['id'] ?? '',
                        'external_delete_hash' => $result['data']['deletehash'] ?? ''
                    ];

                    $mediaId = $this->mediaModel->insert($mediaData);

                    return $this->response->setJSON([
                        'success' => true,
                        'message' => 'URL đã được tải lên Imgur thành công',
                        'data' => [
                            'id' => $mediaId,
                            'url' => $result['data']['link'],
                            'delete_hash' => $result['data']['deletehash'] ?? '',
                            'type' => 'imgur'
                        ]
                    ]);
                } else {
                    // Nếu upload lên Imgur thất bại, thông báo lỗi
                    return $this->response->setStatusCode(500)->setJSON([
                        'success' => false,
                        'message' => 'Không thể upload URL lên Imgur: ' . ($result['error'] ?? 'Lỗi không xác định')
                    ]);
                }
            } else {
                return $this->response->setStatusCode(400)->setJSON([
                    'success' => false,
                    'message' => 'Upload từ URL chỉ hỗ trợ Imgur'
                ]);
            }
        }

        // Kiểm tra có file được upload không
        $file = $this->request->getFile('file');
        if (!$file || !$file->isValid() || $file->hasMoved()) {
            return $this->response->setStatusCode(400)->setJSON([
                'success' => false,
                'message' => 'Vui lòng upload một file hợp lệ hoặc cung cấp URL hợp lệ'
            ]);
        }

        // Kiểm tra loại file (chỉ chấp nhận ảnh)
        $mimeType = $file->getMimeType();
        $extension = $file->getClientExtension();
        $tempPath = $file->getTempName();

        // Kiểm tra MIME type từ fileinfo
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $detectedType = finfo_file($finfo, $tempPath);
        finfo_close($finfo);

        // Validate file type more thoroughly
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/svg+xml'];
        $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'];

        // Kiểm tra cả MIME type và phần mở rộng
        if (!in_array($mimeType, $allowedTypes) || !in_array(strtolower($extension), $allowedExtensions)) {
            return $this->response->setStatusCode(400)->setJSON([
                'success' => false,
                'message' => 'Chỉ chấp nhận file ảnh. MIME: ' . $mimeType . ', Extension: ' . $extension
            ]);
        }

        // Additional check - detected type should match with allowed types
        if (!in_array($detectedType, $allowedTypes)) {
            log_message('error', 'File type mismatch: Reported {mime}, Detected {detected}', [
                'mime' => $mimeType,
                'detected' => $detectedType
            ]);
            return $this->response->setStatusCode(400)->setJSON([
                'success' => false,
                'message' => 'File không khớp với loại khai báo. Detected: ' . $detectedType
            ]);
        }

        // Kiểm tra kích thước file (tối đa 5MB)
        $maxSize = 5 * 1024 * 1024; // 5MB
        if ($file->getSize() > $maxSize) {
            return $this->response->setStatusCode(400)->setJSON([
                'success' => false,
                'message' => 'Kích thước file không được vượt quá 5MB'
            ]);
        }

        // Kiểm tra tùy chọn upload (local hoặc imgur)
        $uploadType = $this->request->getPost('upload_type') ?? 'local';

        // Nếu chọn Imgur, thực hiện upload lên Imgur
        if ($uploadType === 'imgur') {
            // Kiểm tra Imgur Client ID
            $settingsModel = new \App\Models\SettingsModel();
            $clientId = $settingsModel->getSetting('imgur_client_id', '');

            if (empty($clientId)) {
                return $this->response->setStatusCode(400)->setJSON([
                    'success' => false,
                    'message' => 'Imgur Client ID chưa được cấu hình'
                ]);
            }

            // Đọc nội dung file
            $fileData = file_get_contents($file->getTempName());

            // Upload lên Imgur
            $result = $this->imgurClient->uploadImage($fileData);

            if ($result['success']) {
                // Lưu thông tin vào database
                $mediaData = [
                    'file_name' => $file->getClientName(),
                    'file_path' => $result['data']['link'],
                    'file_type' => $detectedType,
                    'file_size' => $file->getSize(),
                    'user_id' => $user['id'],
                    'uploaded_at' => date('Y-m-d H:i:s'),
                    'is_external' => 1,
                    'external_type' => 'imgur',
                    'external_id' => $result['data']['id'] ?? '',
                    'external_delete_hash' => $result['data']['deletehash'] ?? ''
                ];

                $mediaId = $this->mediaModel->insert($mediaData);

                return $this->response->setJSON([
                    'success' => true,
                    'message' => 'File đã được tải lên Imgur thành công',
                    'data' => [
                        'id' => $mediaId,
                        'url' => $result['data']['link'],
                        'delete_hash' => $result['data']['deletehash'] ?? '',
                        'type' => 'imgur'
                    ]
                ]);
            } else {
                // Nếu upload lên Imgur thất bại, thông báo lỗi
                return $this->response->setStatusCode(500)->setJSON([
                    'success' => false,
                    'message' => 'Không thể upload lên Imgur: ' . ($result['error'] ?? 'Lỗi không xác định')
                ]);
            }
        }

        // Mặc định upload lên server local
        try {
            // Lưu file và thông tin vào database
            $mediaId = $this->mediaModel->saveMedia($file, $user['id']);

            if (!$mediaId) {
                return $this->response->setStatusCode(500)->setJSON([
                    'success' => false,
                    'message' => 'Không thể lưu file'
                ]);
            }

            // Lấy thông tin media đã lưu
            $media = $this->mediaModel->find($mediaId);

            return $this->response->setJSON([
                'success' => true,
                'message' => 'File đã được tải lên thành công',
                'data' => [
                    'id' => $media['id'],
                    'file_name' => $media['file_name'],
                    'file_path' => $media['file_path'],
                    'file_type' => $media['file_type'],
                    'file_size' => $media['file_size'],
                    'url' => base_url($media['file_path']),
                    'type' => 'local'
                ]
            ]);
        } catch (\Exception $e) {
            return $this->response->setStatusCode(500)->setJSON([
                'success' => false,
                'message' => 'Đã xảy ra lỗi: ' . $e->getMessage()
            ]);
        }
    }

    /**
     * API xóa ảnh
     */
    public function deleteImage($id)
    {
        // Kiểm tra xác thực API (token) và quyền truy cập
        $user = $this->authService->checkApiPermission();

        // Nếu kết quả là đối tượng Response (không có quyền), trả về nó
        if ($user instanceof ResponseInterface) {
            return $user;
        }

        // Lấy thông tin file
        $media = $this->mediaModel->find($id);
        if (!$media) {
            return $this->response->setStatusCode(404)->setJSON([
                'success' => false,
                'message' => 'Không tìm thấy file'
            ]);
        }

        // Kiểm tra quyền xoá (chỉ người tải lên, admin, hoặc người sáng lập mới có quyền xoá)
        if ($user['id'] != $media['user_id'] && $user['role'] < 2) {
            return $this->response->setStatusCode(403)->setJSON([
                'success' => false,
                'message' => 'Bạn không có quyền xóa file này'
            ]);
        }

        // Xóa file
        $result = $this->mediaModel->deleteMedia($id);

        if ($result) {
            return $this->response->setJSON([
                'success' => true,
                'message' => 'File đã được xóa thành công'
            ]);
        } else {
            return $this->response->setStatusCode(500)->setJSON([
                'success' => false,
                'message' => 'Không thể xóa file'
            ]);
        }
    }

    /**
     * API lấy danh sách ảnh đã uploads
     */
    public function getImages()
    {
        // Kiểm tra xác thực API (token) và quyền truy cập
        $user = $this->authService->checkApiPermission();

        // Nếu kết quả là đối tượng Response (không có quyền), trả về nó
        if ($user instanceof ResponseInterface) {
            return $user;
        }

        // Tham số phân trang
        $page = $this->request->getGet('page') ?? 1;
        $limit = $this->request->getGet('limit') ?? 20;
        $offset = ($page - 1) * $limit;

        // Lọc theo loại file (mặc định là ảnh)
        $type = $this->request->getGet('type') ?? 'image/%';

        // Lọc theo user_id nếu không phải admin
        $userId = ($user['role'] >= 2) ? null : $user['id'];

        // Lấy danh sách file
        $media = $this->mediaModel->getMedia($limit, $offset, $userId, $type);
        $total = $this->mediaModel->countMedia($userId, $type);

        // Format kết quả
        $formattedMedia = [];
        foreach ($media as $item) {
            $formattedMedia[] = [
                'id' => $item['id'],
                'file_name' => $item['file_name'],
                'file_path' => $item['file_path'],
                'file_type' => $item['file_type'],
                'file_size' => $item['file_size'],
                'url' => isset($item['is_external']) && $item['is_external'] ? $item['file_path'] : base_url($item['file_path']),
                'created_at' => $item['uploaded_at'] ?? $item['created_at'] ?? null,
                'is_external' => $item['is_external'] ?? 0,
                'external_type' => $item['external_type'] ?? null
            ];
        }

        return $this->response->setJSON([
            'success' => true,
            'data' => $formattedMedia,
            'pagination' => [
                'current_page' => (int)$page,
                'total_pages' => ceil($total / $limit),
                'total_items' => $total,
                'per_page' => (int)$limit
            ]
        ]);
    }
}
