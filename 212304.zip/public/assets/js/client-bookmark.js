/**
 * Hệ thống Bookmark
 *
 * Module này xử lý các bookmarks, sử dụng localStorage cho lưu trữ client-side.
 * Các thông tin được tối ưu để tiết kiệm dung lượng lưu trữ.
 */
const ClientBookmark = {
    // Cài đặt mặc định
    config: {
        maxItems: 50,                      // Số lượng bookmark tối đa
        maxStorageMB: 2,                   // Dung lượng tối đa (MB)
        cleanupInterval: 7 * 24 * 60 * 60, // Thời gian tự động dọn dẹp (7 ngày)
        storageKey: 'bookmarks',           // Key để lưu trong localStorage
        lastCleanupKey: 'bookmark_cleanup' // Key lưu thời gian dọn dẹp gần nhất
    },

    /**
     * Khởi tạo hệ thống bookmark
     */
    init: function() {
        // Kiểm tra nếu localStorage khả dụng
        if (!this.isLocalStorageAvailable()) {
            console.warn('localStorage không khả dụng. Bookmarks sẽ không được lưu.');
            return;
        }

        // Khởi tạo localStorage nếu cần
        if (!localStorage.getItem(this.config.storageKey)) {
            localStorage.setItem(this.config.storageKey, JSON.stringify({}));
        }

        // Tối ưu dữ liệu hiện tại để giảm dung lượng
        this.optimizeStorage();

        // Dọn dẹp bookmark cũ nếu cần
        this.performCleanupIfNeeded();
    },

    /**
     * Thêm hoặc chuyển đổi trạng thái bookmark
     *
     * @param {number} storyId - ID của truyện cần đánh dấu
     * @param {object} storyData - Dữ liệu bổ sung của truyện (tiêu đề, v.v.)
     * @param {number|null} chapterId - ID chương (nếu có)
     * @returns {object} Trạng thái của thao tác
     */
    toggle: function(storyId, storyData, chapterId = null) {
        let bookmarks = this.getAll();
        let action = '';
        let message = '';

        if (bookmarks[storyId]) {
            // Xóa bookmark nếu đã tồn tại
            delete bookmarks[storyId];
            action = 'removed';
            message = 'Đã xóa khỏi danh sách bookmark';
        } else {
            // Thêm bookmark mới với dữ liệu tối ưu
            bookmarks[storyId] = this.createOptimizedBookmark(storyId, storyData, chapterId);
            action = 'added';
            message = 'Đã thêm vào danh sách bookmark';

            // Kiểm tra giới hạn lưu trữ sau khi thêm
            this.enforceStorageLimits();
        }

        // Lưu vào localStorage
        this.saveAll(bookmarks);

        return {
            action: action,
            message: message
        };
    },

    /**
     * Tạo bookmark với dữ liệu tối ưu để tiết kiệm dung lượng
     *
     * @param {number} storyId - ID truyện
     * @param {object} storyData - Dữ liệu truyện
     * @param {number|null} chapterId - ID chương
     * @returns {object} Bookmark đã được tối ưu
     */
    createOptimizedBookmark: function(storyId, storyData, chapterId) {
        // Chỉ lưu các thông tin cần thiết: ID và slug
        const bookmark = {
            i: parseInt(storyId),                   // ID (i thay vì id)
            s: (storyData.slug || '').substr(0, 50),    // Lưu slug để truy vấn
            c: chapterId ? parseInt(chapterId) : null,  // Chapter ID
            d: Math.floor(Date.now() / 1000)            // Date (Unix timestamp thay vì ISO string)
        };

        return bookmark;
    },

    /**
     * Cập nhật thông tin chương cho một truyện đã đánh dấu
     *
     * @param {number} storyId - ID truyện
     * @param {number} chapterId - ID chương
     * @returns {boolean} Trạng thái thành công
     */
    updateChapter: function(storyId, chapterId) {
        let bookmarks = this.getAll();

        if (!bookmarks[storyId]) {
            // Nếu truyện chưa được đánh dấu, thêm với thông tin tối thiểu
            bookmarks[storyId] = {
                i: parseInt(storyId),
                c: parseInt(chapterId),
                d: Math.floor(Date.now() / 1000)
            };
            this.saveAll(bookmarks);
            this.enforceStorageLimits();
            return true;
        }

        // Cập nhật ID chương và thời gian
        bookmarks[storyId].c = parseInt(chapterId);
        bookmarks[storyId].d = Math.floor(Date.now() / 1000);

        // Lưu vào localStorage
        this.saveAll(bookmarks);
        return true;
    },

    /**
     * Kiểm tra nếu một truyện đã được đánh dấu
     *
     * @param {number} storyId - ID truyện cần kiểm tra
     * @returns {boolean} True nếu đã đánh dấu
     */
    isBookmarked: function(storyId) {
        const bookmarks = this.getAll();
        return !!bookmarks[storyId];
    },

    /**
     * Lấy một bookmark cụ thể
     *
     * @param {number} storyId - ID truyện
     * @returns {object|null} Dữ liệu bookmark hoặc null
     */
    get: function(storyId) {
        const bookmarks = this.getAll();
        const bookmark = bookmarks[storyId];

        if (!bookmark) return null;

        // Chuyển đổi từ định dạng tối ưu sang định dạng đầy đủ
        return {
            id: bookmark.i || parseInt(storyId),
            slug: bookmark.s || '',
            chapter_id: bookmark.c || null,
            time: bookmark.d ? new Date(bookmark.d * 1000).toISOString() : new Date().toISOString()
        };
    },

    /**
     * Lấy tất cả bookmarks dưới dạng đối tượng
     *
     * @returns {object} Tất cả bookmark
     */
    getAll: function() {
        const data = localStorage.getItem(this.config.storageKey);
        return data ? JSON.parse(data) : {};
    },

    /**
     * Lấy tất cả bookmarks dưới dạng mảng (để hiển thị)
     *
     * @returns {array} Mảng các đối tượng bookmark
     */
    getAllAsArray: function() {
        const bookmarks = this.getAll();
        const result = [];

        for (const id in bookmarks) {
            if (bookmarks.hasOwnProperty(id)) {
                const bookmark = bookmarks[id];
                // Chuyển từ định dạng tối ưu sang định dạng đầy đủ
                // Chỉ trả về thông tin cần thiết, các thông tin khác sẽ được truy vấn từ server
                result.push({
                    id: bookmark.i || parseInt(id),
                    slug: bookmark.s || '',
                    chapter_id: bookmark.c || null,
                    time: bookmark.d ? new Date(bookmark.d * 1000).toISOString() : new Date().toISOString()
                });
            }
        }

        // Sắp xếp theo thời gian gần nhất trước
        return result.sort((a, b) => {
            return new Date(b.time) - new Date(a.time);
        });
    },

    /**
     * Hiển thị danh sách bookmark trong trang bookmark
     *
     * @param {string} containerId - ID của container để hiển thị bookmarks
     * @param {string} emptyMessageId - ID của phần tử hiển thị khi không có bookmark
     */
    renderBookmarks: function(containerId, emptyMessageId) {
        const container = document.getElementById(containerId);
        const emptyMessage = document.getElementById(emptyMessageId);

        if (!container) {
            console.error('Không tìm thấy container để hiển thị bookmarks');
            return;
        }

        const bookmarks = this.getAllAsArray();

        // Hiển thị thông báo nếu không có bookmark
        if (bookmarks.length === 0) {
            if (emptyMessage) {
                emptyMessage.style.display = 'block';
            }
            container.innerHTML = '';
            return;
        }

        if (emptyMessage) {
            emptyMessage.style.display = 'none';
        }

        // Kiểm tra xem container có lớp loading không
        const hasLoading = container.classList.contains('loading');
        if (hasLoading) {
            container.innerHTML = '<div class="loading-spinner">Đang tải...</div>';
        }

        // Tạo khung HTML cơ bản với dữ liệu tối thiểu
        let html = '<div class="row bookmark-list">';

        bookmarks.forEach((bookmark) => {
            html += `
                <div class="col-md-4 col-sm-6 mb-4" data-bookmark-id="${bookmark.id}" data-bookmark-slug="${bookmark.slug || ''}">
                    <div class="card h-100 bookmark-item">
                        <div class="placeholder-img card-img-top"></div>
                        <div class="card-body">
                            <h5 class="card-title placeholder-text">Đang tải...</h5>
                            <p class="card-text small placeholder-text">Đang tải thông tin...</p>
                        </div>
                        <div class="card-footer d-flex justify-content-between">
                            <small class="text-muted">Đã lưu ${this.formatDate(bookmark.time)}</small>
                            <button class="btn btn-sm btn-danger remove-bookmark" data-id="${bookmark.id}">Xóa</button>
                        </div>
                    </div>
                </div>
            `;
        });

        html += '</div>';
        container.innerHTML = html;

        // Thêm event listener cho các nút xóa
        const removeButtons = container.querySelectorAll('.remove-bookmark');
        removeButtons.forEach(button => {
            button.addEventListener('click', (e) => {
                e.preventDefault();
                const id = button.getAttribute('data-id');
                if (id) {
                    this.toggle(parseInt(id), {});
                    this.renderBookmarks(containerId, emptyMessageId);
                }
            });
        });

        // Lấy thông tin đầy đủ từ server
        this.fetchBookmarkData(bookmarks)
            .then(stories => {
                // Cập nhật thông tin hiển thị với dữ liệu đầy đủ
                stories.forEach(story => {
                    const bookmarkElements = container.querySelectorAll(`[data-bookmark-id="${story.id}"]`);

                    bookmarkElements.forEach(element => {
                        const imgContainer = element.querySelector('.placeholder-img');
                        const title = element.querySelector('.card-title');
                        const text = element.querySelector('.card-text');

                        // Cập nhật ảnh bìa
                        if (imgContainer) {
                            imgContainer.innerHTML = `<img src="${story.cover_image || '/assets/img/no-cover.jpg'}" alt="${story.title}" class="card-img-top">`;
                            imgContainer.classList.remove('placeholder-img');
                        }

                        // Cập nhật tiêu đề và link
                        if (title) {
                            title.innerHTML = `<a href="/story/${story.slug}">${story.title}</a>`;
                            title.classList.remove('placeholder-text');
                        }

                        // Cập nhật thông tin phụ
                        if (text) {
                            text.innerHTML = `<strong>Tác giả:</strong> ${story.author_name || 'Không xác định'}<br>
                            <strong>Trạng thái:</strong> ${story.is_completed ? 'Hoàn thành' : 'Đang cập nhật'}`;
                            text.classList.remove('placeholder-text');
                        }
                    });
                });

                // Xử lý cho các bookmark không tìm thấy thông tin
                bookmarks.forEach(bookmark => {
                    const found = stories.some(story => story.id === bookmark.id);
                    if (!found) {
                        const bookmarkElements = container.querySelectorAll(`[data-bookmark-id="${bookmark.id}"]`);

                        bookmarkElements.forEach(element => {
                            const imgContainer = element.querySelector('.placeholder-img');
                            const title = element.querySelector('.card-title');
                            const text = element.querySelector('.card-text');

                            if (imgContainer) {
                                imgContainer.innerHTML = `<img src="/assets/img/no-cover.jpg" alt="Không tìm thấy" class="card-img-top">`;
                                imgContainer.classList.remove('placeholder-img');
                            }

                            if (title) {
                                if (bookmark.slug) {
                                    title.innerHTML = `<a href="/story/${bookmark.slug}">Truyện #${bookmark.id}</a>`;
                                } else {
                                    title.textContent = `Truyện #${bookmark.id}`;
                                }
                                title.classList.remove('placeholder-text');
                            }

                            if (text) {
                                text.textContent = 'Không tìm thấy thông tin truyện này. Có thể truyện đã bị xóa hoặc di chuyển.';
                                text.classList.remove('placeholder-text');
                            }
                        });
                    }
                });
            })
            .catch(error => {
                console.error('Lỗi khi lấy thông tin truyện:', error);

                // Nếu không thể lấy dữ liệu từ server, hiển thị phiên bản offline
                bookmarks.forEach(bookmark => {
                    const bookmarkElements = container.querySelectorAll(`[data-bookmark-id="${bookmark.id}"]`);

                    bookmarkElements.forEach(element => {
                        const imgContainer = element.querySelector('.placeholder-img');
                        const title = element.querySelector('.card-title');
                        const text = element.querySelector('.card-text');

                        if (imgContainer) {
                            imgContainer.innerHTML = `<div class="offline-img">Offline</div>`;
                            imgContainer.classList.remove('placeholder-img');
                        }

                        if (title) {
                            if (bookmark.slug) {
                                title.innerHTML = `<a href="/story/${bookmark.slug}">Truyện #${bookmark.id}</a>`;
                            } else {
                                title.textContent = `Truyện #${bookmark.id}`;
                            }
                            title.classList.remove('placeholder-text');
                        }

                        if (text) {
                            text.innerHTML = 'Đang ở chế độ offline. Kết nối internet để xem thông tin đầy đủ.';
                            text.classList.remove('placeholder-text');
                        }
                    });
                });
            });
    },

    /**
     * Định dạng ngày tháng để hiển thị thân thiện
     *
     * @param {string} isoDate - Ngày dạng ISO
     * @return {string} Chuỗi ngày đã định dạng
     */
    formatDate: function(isoDate) {
        const date = new Date(isoDate);
        const now = new Date();
        const diffMs = now - date;
        const diffSec = Math.floor(diffMs / 1000);
        const diffMin = Math.floor(diffSec / 60);
        const diffHour = Math.floor(diffMin / 60);
        const diffDay = Math.floor(diffHour / 24);

        if (diffDay > 30) {
            return `${date.getDate()}/${date.getMonth() + 1}/${date.getFullYear()}`;
        } else if (diffDay === 1) {
            return 'hôm qua';
        } else if (diffDay > 1) {
            return `${diffDay} ngày trước`;
        } else if (diffHour >= 1) {
            return `${diffHour} giờ trước`;
        } else if (diffMin >= 1) {
            return `${diffMin} phút trước`;
        } else {
            return 'vài giây trước';
        }
    },

    /**
     * Lưu tất cả bookmark vào localStorage
     *
     * @param {object} bookmarks - Đối tượng bookmarks
     */
    saveAll: function(bookmarks) {
        try {
            localStorage.setItem(this.config.storageKey, JSON.stringify(bookmarks));
        } catch (e) {
            console.error('Lỗi khi lưu bookmark:', e);
            // Nếu lỗi do vượt quá dung lượng, giảm số lượng bookmark
            if (e.name === 'QuotaExceededError' || e.name === 'NS_ERROR_DOM_QUOTA_REACHED') {
                this.enforceStorageLimits(true);
            }
        }
    },

    /**
     * Xóa tất cả bookmark
     */
    clearAll: function() {
        localStorage.setItem(this.config.storageKey, JSON.stringify({}));
    },

    /**
     * Xuất bookmarks ra file JSON
     */
    exportBookmarks: function() {
        const bookmarks = this.getAllAsArray(); // Lấy dạng đầy đủ để export
        const dataStr = JSON.stringify(bookmarks, null, 2);
        const dataUri = 'data:application/json;charset=utf-8,' + encodeURIComponent(dataStr);

        const exportFileDefaultName = 'bookmarks-' + new Date().toISOString().slice(0, 10) + '.json';

        const linkElement = document.createElement('a');
        linkElement.setAttribute('href', dataUri);
        linkElement.setAttribute('download', exportFileDefaultName);
        linkElement.click();
    },

    /**
     * Nhập bookmarks từ file JSON
     *
     * @param {File} file - File JSON cần nhập
     * @returns {Promise} Promise với kết quả
     */
    importBookmarks: function(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();

            reader.onload = (e) => {
                try {
                    const importedData = JSON.parse(e.target.result);

                    if (!Array.isArray(importedData) && typeof importedData !== 'object') {
                        throw new Error('Định dạng dữ liệu không hợp lệ');
                    }

                    const currentBookmarks = this.getAll();
                    let count = 0;

                    // Xử lý cả hai định dạng có thể có: mảng hoặc đối tượng
                    if (Array.isArray(importedData)) {
                        importedData.forEach(item => {
                            const storyId = item.id || item.i;
                            if (storyId) {
                                currentBookmarks[storyId] = this.createOptimizedBookmark(
                                    storyId,
                                    {
                                        slug: item.slug || item.s || ''
                                    },
                                    item.chapter_id || item.c || null
                                );
                                count++;
                            }
                        });
                    } else {
                        // Xử lý định dạng đối tượng
                        for (const key in importedData) {
                            if (importedData.hasOwnProperty(key)) {
                                const item = importedData[key];
                                const storyId = parseInt(key);
                                currentBookmarks[storyId] = this.createOptimizedBookmark(
                                    storyId,
                                    {
                                        slug: item.slug || item.s || ''
                                    },
                                    item.chapter_id || item.c || null
                                );
                                count++;
                            }
                        }
                    }

                    this.saveAll(currentBookmarks);
                    this.enforceStorageLimits(); // Đảm bảo không vượt quá giới hạn

                    resolve({
                        success: true,
                        count: count
                    });
                } catch (error) {
                    reject({
                        success: false,
                        error: 'Lỗi khi nhập dữ liệu: ' + error.message
                    });
                }
            };

            reader.onerror = () => {
                reject({
                    success: false,
                    error: 'Không thể đọc tệp dữ liệu'
                });
            };

            reader.readAsText(file);
        });
    },

    /**
     * Lấy thông tin đầy đủ của các bookmark từ server
     *
     * @param {Array} bookmarkArray - Mảng các bookmark đơn giản (chỉ có id và slug)
     * @returns {Promise} Promise với dữ liệu đầy đủ từ server
     */
    fetchBookmarkData: function(bookmarkArray) {
        return new Promise((resolve, reject) => {
            if (!bookmarkArray || bookmarkArray.length === 0) {
                resolve([]);
                return;
            }

            // Ưu tiên sử dụng slugs nếu có
            const slugs = bookmarkArray
                .filter(bookmark => bookmark.slug)
                .map(bookmark => bookmark.slug);

            const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content'); // Lấy CSRF token từ meta

            if (slugs.length > 0) {
                // Sử dụng slugs để lấy dữ liệu
                fetch('/bookmark/get-by-slug', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                        'X-Requested-With': 'XMLHttpRequest',
                        'X-CSRF-TOKEN': csrfToken
                    },
                    body: 'slugs=' + JSON.stringify(slugs) + '&csrf_token_name=' + csrfToken
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success && data.stories) {
                        resolve(data.stories);
                    } else {
                        reject(data.error || 'Không thể lấy dữ liệu từ server');
                    }
                })
                .catch(error => {
                    console.error('Lỗi khi lấy dữ liệu bookmark từ server:', error);
                    reject(error);
                });
            } else {
                // Sử dụng IDs nếu không có slugs
                const ids = bookmarkArray.map(bookmark => bookmark.id);

                fetch('/bookmark/get-data', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                        'X-Requested-With': 'XMLHttpRequest',
                        'X-CSRF-TOKEN': csrfToken
                    },
                    body: 'ids=' + JSON.stringify(ids) + '&csrf_token_name=' + csrfToken
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success && data.stories) {
                        resolve(data.stories);
                    } else {
                        reject(data.error || 'Không thể lấy dữ liệu từ server');
                    }
                })
                .catch(error => {
                    console.error('Lỗi khi lấy dữ liệu bookmark từ server:', error);
                    reject(error);
                });
            }
        });
    },

    /**
     * Hiển thị thông báo về việc gần đầy bộ nhớ bookmark
     *
     * @param {string} currentSize - Kích thước hiện tại của localStorage (MB)
     */
    showStorageWarning: function(currentSize) {
        // Kiểm tra nếu đã có phương thức showStorageWarning toàn cục
        if (window.showStorageWarning) {
            window.showStorageWarning(currentSize);
            return;
        }

        // Hiển thị thông báo với tùy chọn
        const warningDiv = document.createElement('div');
        warningDiv.className = 'storage-warning';
        warningDiv.style.cssText = 'position:fixed;top:20px;right:20px;background:#fff8dc;border:1px solid #e6db55;border-radius:4px;padding:15px;box-shadow:0 0 10px rgba(0,0,0,0.1);z-index:9999;max-width:350px;';

        warningDiv.innerHTML = `
            <h4 style="margin-top:0;color:#9f6000;">Cảnh báo bộ nhớ bookmark</h4>
            <p>Bộ nhớ lưu trữ bookmark đã gần đầy (${currentSize}MB/${this.config.maxStorageMB}MB).</p>
            <p>Bạn có thể:</p>
            <button id="clearOldBookmarks" style="background:#5cb85c;color:white;border:none;padding:5px 10px;border-radius:3px;margin-right:10px;cursor:pointer;">Xóa bookmark cũ</button>
            <button id="exportBookmarks" style="background:#337ab7;color:white;border:none;padding:5px 10px;border-radius:3px;margin-right:10px;cursor:pointer;">Xuất bookmark</button>
            <button id="dismissWarning" style="background:#f0ad4e;color:white;border:none;padding:5px 10px;border-radius:3px;cursor:pointer;">Bỏ qua</button>
        `;

        document.body.appendChild(warningDiv);

        // Thêm các sự kiện xử lý
        document.getElementById('clearOldBookmarks').addEventListener('click', () => {
            this.enforceStorageLimits(true);
            warningDiv.remove();
        });

        document.getElementById('exportBookmarks').addEventListener('click', () => {
            this.exportBookmarks();
            warningDiv.remove();
        });

        document.getElementById('dismissWarning').addEventListener('click', () => {
            warningDiv.remove();
        });

        // Tự động ẩn sau 30 giây
        setTimeout(() => {
            if (document.body.contains(warningDiv)) {
                warningDiv.remove();
            }
        }, 30000);
    },

    /**
     * Thực hiện việc dọn dẹp bookmark cũ nếu cần thiết
     */
    performCleanupIfNeeded: function() {
        const lastCleanup = localStorage.getItem(this.config.lastCleanupKey);
        const now = Math.floor(Date.now() / 1000);

        // Nếu chưa có thời gian dọn dẹp gần nhất hoặc đã quá hạn dọn dẹp
        if (!lastCleanup || (now - parseInt(lastCleanup)) > this.config.cleanupInterval) {
            this.optimizeStorage();
            this.enforceStorageLimits();
            localStorage.setItem(this.config.lastCleanupKey, now.toString());
        }
    },

    /**
     * Tối ưu dữ liệu lưu trữ để giảm dung lượng
     */
    optimizeStorage: function() {
        const bookmarks = this.getAll();
        const optimizedBookmarks = {};

        // Chuyển đổi tất cả bookmark sang định dạng tối ưu
        for (const storyId in bookmarks) {
            if (bookmarks.hasOwnProperty(storyId)) {
                const bookmark = bookmarks[storyId];

                // Nếu đã ở định dạng tối ưu (có trường i), giữ nguyên
                if (bookmark.i !== undefined) {
                    optimizedBookmarks[storyId] = bookmark;
                    continue;
                }

                // Nếu đang ở định dạng cũ, chuyển đổi sang định dạng tối ưu
                optimizedBookmarks[storyId] = this.createOptimizedBookmark(
                    parseInt(storyId),
                    {
                        slug: bookmark.slug || ''
                    },
                    bookmark.chapter_id || null
                );

                // Giữ lại thời gian gốc nếu có
                if (bookmark.time) {
                    try {
                        optimizedBookmarks[storyId].d = Math.floor(new Date(bookmark.time).getTime() / 1000);
                    } catch (e) {
                        // Nếu lỗi, sử dụng thời gian hiện tại
                        optimizedBookmarks[storyId].d = Math.floor(Date.now() / 1000);
                    }
                }
            }
        }

        // Lưu trạng thái đã tối ưu
        this.saveAll(optimizedBookmarks);
    },

    /**
     * Thực thi các giới hạn lưu trữ để không vượt quá dung lượng cho phép
     *
     * @param {boolean} forceReduce - Có bắt buộc giảm dung lượng không
     */
    enforceStorageLimits: function(forceReduce = false) {
        const bookmarks = this.getAll();
        const bookmarkCount = Object.keys(bookmarks).length;

        // Kiểm tra giới hạn số lượng
        if (bookmarkCount > this.config.maxItems || forceReduce) {
            const bookmarksArray = [];

            // Chuyển sang mảng để sắp xếp
            for (const id in bookmarks) {
                if (bookmarks.hasOwnProperty(id)) {
                    const item = bookmarks[id];
                    bookmarksArray.push({
                        id: id,
                        data: item,
                        time: item.d || 0
                    });
                }
            }

            // Sắp xếp theo thời gian, mới nhất trước
            bookmarksArray.sort((a, b) => b.time - a.time);

            // Giữ lại chỉ số lượng tối đa
            const keepCount = forceReduce ? Math.floor(this.config.maxItems * 0.7) : this.config.maxItems;
            const keptBookmarks = {};

            bookmarksArray.slice(0, keepCount).forEach(item => {
                keptBookmarks[item.id] = item.data;
            });

            // Lưu lại danh sách đã giảm
            this.saveAll(keptBookmarks);
        }

        // Kiểm tra dung lượng nếu có thể
        this.checkStorageSize();
    },

    /**
     * Kiểm tra kích thước lưu trữ và hiển thị thông báo nếu gần đầy
     */
    checkStorageSize: function() {
        try {
            // Ước tính kích thước localStorage
            let totalSize = 0;
            for (let i = 0; i < localStorage.length; i++) {
                const key = localStorage.key(i);
                const value = localStorage.getItem(key);
                totalSize += (key.length + value.length) * 2; // Ký tự UTF-16 = 2 byte
            }

            const sizeMB = totalSize / (1024 * 1024);

            // Nếu gần đạt giới hạn, hiển thị thông báo cho người dùng lựa chọn
            if (sizeMB > this.config.maxStorageMB * 0.9) {
                // Sử dụng phương thức showStorageWarning
                this.showStorageWarning(sizeMB.toFixed(2));
            }
        } catch (e) {
            console.error('Lỗi khi kiểm tra kích thước lưu trữ:', e);
        }
    },

    /**
     * Kiểm tra liệu localStorage có khả dụng không
     *
     * @returns {boolean} True nếu localStorage khả dụng
     */
    isLocalStorageAvailable: function() {
        try {
            const test = 'test';
            localStorage.setItem(test, test);
            localStorage.removeItem(test);
            return true;
        } catch (e) {
            return false;
        }
    }
};

// Khởi tạo hệ thống bookmark khi trang tải xong
document.addEventListener('DOMContentLoaded', function() {
    ClientBookmark.init();

    // Thêm event listeners cho các nút bookmark nếu tồn tại
    const bookmarkButtons = document.querySelectorAll('.bookmark-button, .js-bookmark-btn');

    bookmarkButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();

            const storyId = parseInt(this.dataset.storyId);
            const chapterId = this.dataset.chapterId ? parseInt(this.dataset.chapterId) : null;
            const storySlug = this.dataset.storySlug || '';

            const result = ClientBookmark.toggle(storyId, {
                slug: storySlug
            }, chapterId);

            // Cập nhật giao diện dựa trên kết quả
            if (result.action === 'added') {
                this.classList.add('active');
                this.title = 'Đã lưu vào tủ truyện';
                if (this.querySelector('.bookmark-text')) {
                    this.querySelector('.bookmark-text').textContent = 'Đã lưu';
                }
            } else {
                this.classList.remove('active');
                this.title = 'Lưu vào tủ truyện';
                if (this.querySelector('.bookmark-text')) {
                    this.querySelector('.bookmark-text').textContent = 'Lưu truyện';
                }
            }

            // Hiển thị thông báo nếu có
            if (window.showNotification) {
                window.showNotification(result.message);
            }
        });
    });

    // Khởi tạo trạng thái các nút bookmark
    bookmarkButtons.forEach(button => {
        const storyId = parseInt(button.dataset.storyId);
        if (ClientBookmark.isBookmarked(storyId)) {
            button.classList.add('active');
            button.title = 'Đã lưu vào tủ truyện';
            if (button.querySelector('.bookmark-text')) {
                button.querySelector('.bookmark-text').textContent = 'Đã lưu';
            }
        }
    });
});
