<?php
// app/Controllers/BaseController.php
namespace App\Controllers;

use CodeIgniter\Controller;
use CodeIgniter\HTTP\CLIRequest;
use CodeIgniter\HTTP\IncomingRequest;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use Config\Services;
use Psr\Log\LoggerInterface;
use App\Models\SettingsModel;
use App\Models\UserModel;
use App\Models\CategoryModel;
use App\Models\LogModel;

/**
 * Class BaseController
 *
 * BaseController provides a convenient place for loading components
 * and performing functions that are needed by all your controllers.
 */
abstract class BaseController extends Controller
{
    /**
     * Instance of the main Request object.
     *
     * @var CLIRequest|IncomingRequest
     */
    protected $request;

    /**
     * An array of helpers to be loaded automatically upon
     * class instantiation. These helpers will be available
     * to all other controllers that extend BaseController.
     *
     * @var array
     */
    protected $helpers = ['url', 'form', 'text', 'date', 'cookie', 'security'];

    /**
     * Session instance
     */
    protected $session;

    /**
     * Models
     */
    protected $userModel;
    protected $settingsModel;
    protected $logModel;

    /**
     * Current logged in user
     */
    protected $currentUser;

    /**
     * Database instance
     */
    protected $db;

    /**
     * Is the system installed
     */
    protected $isInstalled = false;

    /**
     * View data
     */
    protected $viewData = [];

    /**
     * Settings cache
     */
    protected static $settingsCache = null;

    /**
     * Constructor.
     */
    public function initController(RequestInterface $request, ResponseInterface $response, LoggerInterface $logger)
    {
        // Do Not Edit This Line
        parent::initController($request, $response, $logger);

        // Initialize database
        $this->db = \Config\Database::connect();

        // Initialize session
        $this->session = Services::session();

        // Check if system is installed
        $this->isInstalled = file_exists(ROOTPATH . 'installed.txt');

        // Check CSRF for POST requests
        $this->validateCSRF();

        // Initialize models
        $this->initModels();

        // Get current user from session
        $this->loadCurrentUser();

        // Share common data with all views
        $this->shareCommonData();
    }

    /**
     * Initialize models
     */
    protected function initModels()
    {
        if ($this->isInstalled) {
            $this->userModel = new UserModel();
            $this->settingsModel = new SettingsModel();
            $this->logModel = new LogModel();
        }
    }

    /**
     * Validate CSRF token for POST, PUT, DELETE requests
     */
    protected function validateCSRF()
    {
        // Skip for installation or for GET requests
        if (!$this->isInstalled || $this->request->getMethod() === 'get') {
            return;
        }

        // Check CSRF token
        if (!$this->request->isAJAX() && ($this->request->getMethod() === 'post' || $this->request->getMethod() === 'put' || $this->request->getMethod() === 'delete')) {
            if (!csrf_verify($this->request)) {
                // Log the CSRF attack attempt
                if (isset($this->logModel)) {
                    $this->logModel->error('CSRF validation failed', [
                        'ip' => $this->request->getIPAddress(),
                        'uri' => $this->request->getUri(),
                        'user_agent' => $this->request->getUserAgent()
                    ]);
                }

                // Redirect with error
                $this->session->setFlashdata('error', 'Xác thực bảo mật thất bại. Vui lòng thử lại.');

                // If it's AJAX, return JSON
                if ($this->request->isAJAX()) {
                    $response = Services::response();
                    return $response->setJSON([
                        'success' => false,
                        'message' => 'CSRF validation failed'
                    ])->setStatusCode(403);
                }

                // Otherwise redirect
                return redirect()->back();
            }
        }
    }

    /**
     * Load current user from session
     */
    protected function loadCurrentUser()
    {
        if ($this->isInstalled && $this->session->has('user_id')) {
            $userId = (int) $this->session->get('user_id');

            if ($userId > 0) {
                $this->currentUser = $this->userModel->find($userId);

                // If user not found or inactive, log them out
                if (empty($this->currentUser) || $this->currentUser['status'] !== 'active') {
                    $this->session->remove(['user_id', 'username', 'role']);
                    $this->currentUser = null;

                    // Regenerate session ID for security
                    $this->session->regenerate(true);
                }
            }
        }
    }

    /**
     * Share common data with all views
     */
    protected function shareCommonData()
    {
        // Common data for all views
        if ($this->isInstalled) {
            try {
                // Load categories (with caching)
                $categoryModel = new CategoryModel();
                $categories = cache('categories') ?? $categoryModel->findAll();

                if (empty(cache('categories'))) {
                    cache()->save('categories', $categories, 300); // Cache for 5 minutes
                }

                // Get site settings
                $settings = $this->getSettings();

                // Prepare flash messages
                $flashMessages = [];

                if ($this->session->getFlashdata('success')) {
                    $flashMessages['success'] = $this->session->getFlashdata('success');
                }

                if ($this->session->getFlashdata('error')) {
                    $flashMessages['error'] = $this->session->getFlashdata('error');
                }

                if ($this->session->getFlashdata('warning')) {
                    $flashMessages['warning'] = $this->session->getFlashdata('warning');
                }

                if ($this->session->getFlashdata('info')) {
                    $flashMessages['info'] = $this->session->getFlashdata('info');
                }

                // Include the bookmark migration message if present
                $bookmarkMessage = $this->session->getFlashdata('bookmark_message');

                // Share data with views
                $this->viewData = [
                    'current_user' => $this->currentUser,
                    'categories' => $categories,
                    'settings' => $settings,
                    'current_url' => current_url(),
                    'is_installed' => $this->isInstalled,
                    'flash_messages' => $flashMessages,
                    'bookmark_message' => $bookmarkMessage
                ];
            } catch (\Exception $e) {
                log_message('error', 'Error loading common data: ' . $e->getMessage());

                // Minimal data set for error cases
                $this->viewData = [
                    'current_url' => current_url(),
                    'is_installed' => $this->isInstalled
                ];
            }
        } else {
            // Basic data for installation
            $this->viewData = [
                'current_url' => current_url(),
                'is_installed' => $this->isInstalled
            ];
        }
    }

    /**
     * Get settings from database with caching
     */
    protected function getSettings()
    {
        // Return cached settings if available
        if (self::$settingsCache !== null) {
            return self::$settingsCache;
        }

        // Check for cache
        $cachedSettings = cache('site_settings');
        if ($cachedSettings !== null) {
            self::$settingsCache = $cachedSettings;
            return $cachedSettings;
        }

        // Default settings as fallback
        $defaultSettings = [
            'site_name' => 'Web Truyện Hay',
            'site_description' => 'Trang web truyện hay, cập nhật thông tin truyện mới nhất',
            'story_title_template' => '[title] - [year] | [country]',
            'story_description_template' => 'Truyện [title] [year] - [country] thuộc thể loại [categories]. Truyện do [author] đánh giá.',
            'chapter_title_template' => 'Chương [number]: [title] - [story_title]',
            'chapter_description_template' => 'Đọc chương [number]: [title] của truyện [story_title]',
            'default_meta_title' => 'Đọc truyện online - Web truyện hay',
            'default_meta_description' => 'Đọc truyện online, truyện chữ, truyện full, truyện hay, truyện hot, truyện mới cập nhật',
            'default_meta_keywords' => 'đọc truyện, truyện online, truyện hay, truyện chữ, truyện full'
        ];

        if (!$this->isInstalled) {
            return $defaultSettings;
        }

        try {
            // Use SettingsModel to get settings
            $settings = $this->settingsModel->getAllSettings();

            if (empty($settings)) {
                return $defaultSettings;
            }

            // Merge default settings with the ones from DB to ensure all keys exist
            $settings = array_merge($defaultSettings, $settings);

            // Cache the settings
            cache()->save('site_settings', $settings, 3600); // Cache for 1 hour
            self::$settingsCache = $settings;

            return $settings;
        } catch (\Exception $e) {
            log_message('error', 'Error loading settings: ' . $e->getMessage());
            return $defaultSettings;
        }
    }

    /**
     * Clear the settings cache
     */
    protected function clearSettingsCache()
    {
        self::$settingsCache = null;
        cache()->delete('site_settings');
        cache()->delete('categories');
    }

    /**
     * Render a view with common data and optimized caching
     */
    protected function renderView(string $view, array $data = [])
    {
        // Merge common data with view data
        $mergedData = array_merge($this->viewData, $data);

        // Check if this is an AJAX request
        $isAjaxRequest = $this->request->isAJAX();

        // For AJAX requests, only return the view content without the layout
        if ($isAjaxRequest) {
            // If it's an AJAX request and the view includes a layout,
            // we need to set a flag to prevent layout rendering
            $mergedData['ajax_request'] = true;

            // Render the view
            return view($view, $mergedData);
        }

        // For normal requests, render with layout as usual
        return view($view, $mergedData);
    }

    /**
     * Check if user is logged in
     */
    protected function isLoggedIn()
    {
        return !empty($this->currentUser);
    }

    /**
     * Check if user is admin (role 2) or founder (role 3)
     */
    protected function isAdmin()
    {
        if (empty($this->currentUser)) {
            return false;
        }

        return $this->currentUser['role'] >= 2; // Admin (2) or Founder (3)
    }

    /**
     * Check if user is a founder (role 3)
     */
    protected function isFounder()
    {
        if (empty($this->currentUser)) {
            return false;
        }

        return $this->currentUser['role'] == 3; // Founder (3)
    }

    /**
     * Check if user is at least a contributor (role 1)
     */
    protected function isContributor()
    {
        if (empty($this->currentUser)) {
            return false;
        }

        return $this->currentUser['role'] >= 1; // Contributor (1), Admin (2), or Founder (3)
    }

    /**
     * Check if user has a role equal to or higher than the required role
     *
     * @param int $requiredRole The minimum required role (1=Contributor, 2=Admin, 3=Founder)
     * @return bool True if user has the required role or higher
     */
    protected function hasRole($requiredRole)
    {
        if (empty($this->currentUser)) {
            return false;
        }

        return $this->currentUser['role'] >= $requiredRole;
    }

    /**
     * Redirect to login page if not logged in
     */
    protected function requireLogin()
    {
        if (!$this->isLoggedIn()) {
            // Log the unauthorized access attempt
            if (isset($this->logModel)) {
                $this->logModel->warning('Unauthorized access attempt', [
                    'ip' => $this->request->getIPAddress(),
                    'uri' => $this->request->getUri(),
                    'user_agent' => $this->request->getUserAgent()
                ]);
            }

            $this->session->setFlashdata('error', 'Vui lòng đăng nhập để tiếp tục.');
            return redirect()->to(base_url('login?redirect=' . current_url()));
        }

        return true;
    }

    /**
     * Redirect to home page if not admin or founder
     */
    protected function requireAdmin()
    {
        // First check login
        $loginCheck = $this->requireLogin();
        if ($loginCheck !== true) {
            return $loginCheck;
        }

        if (!$this->isAdmin()) {
            // Log the unauthorized admin access attempt
            if (isset($this->logModel)) {
                $this->logModel->warning('Unauthorized admin access attempt', [
                    'user_id' => $this->currentUser['id'] ?? null,
                    'username' => $this->currentUser['username'] ?? 'unknown',
                    'ip' => $this->request->getIPAddress(),
                    'uri' => $this->request->getUri()
                ]);
            }

            $this->session->setFlashdata('error', 'Bạn không có quyền truy cập trang này.');
            return redirect()->to(base_url());
        }

        return true;
    }

    /**
     * Redirect to home page if not founder
     */
    protected function requireFounder()
    {
        // First check login
        $loginCheck = $this->requireLogin();
        if ($loginCheck !== true) {
            return $loginCheck;
        }

        if (!$this->isFounder()) {
            // Log the unauthorized founder access attempt
            if (isset($this->logModel)) {
                $this->logModel->warning('Unauthorized founder access attempt', [
                    'user_id' => $this->currentUser['id'] ?? null,
                    'username' => $this->currentUser['username'] ?? 'unknown',
                    'ip' => $this->request->getIPAddress(),
                    'uri' => $this->request->getUri()
                ]);
            }

            $this->session->setFlashdata('error', 'Bạn không có quyền Người sáng lập để truy cập trang này.');
            return redirect()->to(base_url());
        }

        return true;
    }

    /**
     * Require a minimum role level to access a resource
     *
     * @param int $requiredRole The minimum required role (1=Contributor, 2=Admin, 3=Founder)
     * @return bool|redirect True if allowed, redirect response if not
     */
    protected function requireRole($requiredRole)
    {
        // First check login
        $loginCheck = $this->requireLogin();
        if ($loginCheck !== true) {
            return $loginCheck;
        }

        if (!$this->hasRole($requiredRole)) {
            // Log the unauthorized role access attempt
            if (isset($this->logModel)) {
                $this->logModel->warning('Unauthorized role access attempt', [
                    'user_id' => $this->currentUser['id'] ?? null,
                    'username' => $this->currentUser['username'] ?? 'unknown',
                    'required_role' => $requiredRole,
                    'user_role' => $this->currentUser['role'] ?? 'unknown',
                    'ip' => $this->request->getIPAddress(),
                    'uri' => $this->request->getUri()
                ]);
            }

            $this->session->setFlashdata('error', 'Bạn không có đủ quyền để truy cập trang này.');
            return redirect()->to(base_url());
        }

        return true;
    }

    /**
     * Redirect to installation if not installed
     */
    protected function requireInstalled()
    {
        if (!$this->isInstalled) {
            return redirect()->to(base_url('install'));
        }

        return true;
    }

    /**
     * Protect against maintenance mode
     */
    protected function checkMaintenanceMode()
    {
        if (!$this->isInstalled) {
            return true;
        }

        $settings = $this->getSettings();

        // Check if maintenance mode is on and user is not admin
        if (isset($settings['maintenance_mode']) && $settings['maintenance_mode'] === 'on' && !$this->isAdmin()) {
            return view('maintenance');
        }

        return true;
    }

    /**
     * Format date to human readable
     */
    protected function formatDate($date, $format = 'd/m/Y H:i')
    {
        if (empty($date)) {
            return '';
        }

        return date($format, strtotime($date));
    }

    /**
     * Calculate time ago from a date
     */
    protected function timeAgo($datetime, $full = false)
    {
        $now = new \DateTime;
        $ago = new \DateTime($datetime);
        $diff = $now->diff($ago);

        $diff->w = floor($diff->d / 7);
        $diff->d -= $diff->w * 7;

        $string = [
            'y' => 'năm',
            'm' => 'tháng',
            'w' => 'tuần',
            'd' => 'ngày',
            'h' => 'giờ',
            'i' => 'phút',
            's' => 'giây',
        ];

        foreach ($string as $k => &$v) {
            if ($diff->$k) {
                $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? '' : '');
            } else {
                unset($string[$k]);
            }
        }

        if (!$full) $string = array_slice($string, 0, 1);
        return $string ? implode(', ', $string) . ' trước' : 'vừa xong';
    }

    /**
     * Check if the current user owns a resource
     *
     * @param string $model The model to use (e.g., 'StoryModel')
     * @param int $resourceId The ID of the resource to check
     * @param string $ownerColumn The column that indicates ownership (default: 'uploader_id')
     * @return bool True if user owns the resource, false otherwise
     */
    protected function isResourceOwner($model, $resourceId, $ownerColumn = 'uploader_id')
    {
        if (empty($this->currentUser)) {
            return false;
        }

        // Founder and admin always have access to all resources
        if ($this->currentUser['role'] >= 2) {
            return true;
        }

        // Create the model instance if it doesn't exist
        $modelClass = "\\App\\Models\\{$model}";
        $modelInstance = new $modelClass();

        // Find the resource
        $resource = $modelInstance->find($resourceId);
        if (!$resource) {
            return false;
        }

        // Check if current user is the owner
        return isset($resource[$ownerColumn]) && $resource[$ownerColumn] == $this->currentUser['id'];
    }

    /**
     * Check ownership of a resource and redirect if not the owner
     *
     * @param string $model The model to use (e.g., 'StoryModel')
     * @param int $resourceId The ID of the resource to check
     * @param string $ownerColumn The column that indicates ownership (default: 'uploader_id')
     * @return bool|redirect True if allowed, redirect response if not
     */
    protected function requireResourceOwnership($model, $resourceId, $ownerColumn = 'uploader_id')
    {
        // Kiểm tra đăng nhập
        $loginCheck = $this->requireLogin();
        if ($loginCheck !== true) {
            return $loginCheck;
        }

        // Không bypass tự động cho admin, chỉ kiểm tra quyền sở hữu
        if (!$this->isResourceOwner($model, $resourceId, $ownerColumn)) {
            // Log the unauthorized access attempt
            if (isset($this->logModel)) {
                $this->logModel->warning('Unauthorized resource access attempt', [
                    'user_id' => $this->currentUser['id'] ?? null,
                    'username' => $this->currentUser['username'] ?? 'unknown',
                    'model' => $model,
                    'resource_id' => $resourceId,
                    'ip' => $this->request->getIPAddress(),
                    'uri' => $this->request->getUri()
                ]);
            }

            // Nếu là admin/founder, cho phép truy cập nhưng vẫn ghi log
            if ($this->currentUser['role'] >= 2) {
                if (isset($this->logModel)) {
                    $this->logModel->info('Admin/Founder accessing resource', [
                        'user_id' => $this->currentUser['id'],
                        'username' => $this->currentUser['username'],
                        'model' => $model,
                        'resource_id' => $resourceId
                    ]);
                }
                return true;
            }

            // If this is an AJAX request, return JSON
            if ($this->request->isAJAX()) {
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'Bạn không có quyền truy cập tài nguyên này'
                ])->setStatusCode(403);
            }

            // Otherwise, redirect with error message
            $this->session->setFlashdata('error', 'Bạn không có quyền truy cập tài nguyên này');
            return redirect()->back();
        }

        return true;
    }
}
