<?php
namespace App\Models;

use CodeIgniter\Model;

class StoryModel extends Model
{
    protected $table = 'stories';
    protected $primaryKey = 'id';
    protected $returnType = 'array';

    protected $allowedFields = [
        'title', 'slug', 'description', 'cover_image',
        'author_id', 'author_name', 'uploader_id', 'status', 'type', 'release_year',
        'country', 'views', 'views_day', 'views_week', 'views_month',
        'rating', 'total_ratings', 'total_favorites', 'created_at',
        'updated_at', 'is_featured', 'is_completed', 'search_vector', 'is_recommended'
    ];

    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    /**
     * Lấy thông tin truyện kèm theo thông tin liên quan
     */
    public function getStory($slug)
    {
        $builder = $this->db->table('stories s')
            ->select('s.*')
            ->where('s.slug', $slug);

        $story = $builder->get()->getRowArray();

        if (!$story) {
            return null;
        }

        // Lấy danh sách thể loại của truyện
        $story['categories'] = $this->getStoryCategories($story['id']);

        // Lấy danh sách chương
        $chapterModel = new ChapterModel();
        $story['chapters'] = $chapterModel->where('story_id', $story['id'])
            ->orderBy('chapter_number', 'ASC')
            ->findAll();

        // Lấy thông tin chương mới nhất
        $story['latest_chapter'] = !empty($story['chapters'])
            ? $story['chapters'][count($story['chapters']) - 1]
            : null;

        return $story;
    }

    /**
     * Lấy danh sách các thể loại của truyện
     */
    public function getStoryCategories($storyId)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('story_categories sc')
            ->select('c.*')
            ->join('categories c', 'c.id = sc.category_id')
            ->where('sc.story_id', $storyId);

        return $builder->get()->getResultArray();
    }

    /**
     * Lấy danh sách quốc gia có truyện trong hệ thống
     * Bây giờ lấy trực tiếp từ trường country
     */
    public function getCountries()
    {
        $db = \Config\Database::connect();
        $builder = $db->table('stories')
            ->select('country, COUNT(*) as story_count')
            ->where('country IS NOT NULL')
            ->where('country !=', '')
            ->where('status', 'published')
            ->groupBy('country')
            ->orderBy('country', 'ASC');

        return $builder->get()->getResultArray();
    }

    /**
     * Lấy truyện theo quốc gia
     */
    public function getStoriesByCountry($country, $limit = 12, $offset = 0)
    {
        return $this->where('country', $country)
            ->where('status', 'published')
            ->orderBy('created_at', 'DESC')
            ->limit($limit, $offset)
            ->findAll();
    }

    /**
     * Đếm số lượng truyện theo quốc gia
     */
    public function countStoriesByCountry($country)
    {
        return $this->where('country', $country)
            ->where('status', 'published')
            ->countAllResults();
    }

    // ... Keep the rest of the StoryModel.php methods unchanged ...
}
