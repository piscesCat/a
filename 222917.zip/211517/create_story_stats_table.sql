-- Script tạo bảng story_stats nếu chưa tồn tại
-- Bảng này lưu trữ thống kê lượt xem hàng ngày của truyện
-- Dùng để phân tích xu hướng và cung cấp dữ liệu cho các thuật toán

-- Kiểm tra nếu bảng đã tồn tại
CREATE TABLE IF NOT EXISTS story_stats (
    id SERIAL PRIMARY KEY,
    story_id INTEGER NOT NULL REFERENCES stories(id) ON DELETE CASCADE,
    date DATE NOT NULL,
    views INTEGER DEFAULT 0,
    views_daily INTEGER DEFAULT 0,
    views_weekly INTEGER DEFAULT 0,
    views_monthly INTEGER DEFAULT 0,
    ratings_count INTEGER DEFAULT 0,
    ratings_avg DECIMAL(3,2) DEFAULT 0,
    favorites_count INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (story_id, date)
);

-- Tạo index cho truy vấn nhanh
CREATE INDEX IF NOT EXISTS idx_story_stats_story_id ON story_stats(story_id);
CREATE INDEX IF NOT EXISTS idx_story_stats_date ON story_stats(date);

-- Thêm trường is_hot và hot_marked_at vào bảng stories nếu chưa có
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'stories' AND column_name = 'is_hot') THEN
        ALTER TABLE stories ADD COLUMN is_hot BOOLEAN DEFAULT FALSE;
    END IF;

    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'stories' AND column_name = 'hot_marked_at') THEN
        ALTER TABLE stories ADD COLUMN hot_marked_at TIMESTAMP;
    END IF;
END
$$;

-- Thêm các cài đặt mặc định cho thuật toán
INSERT INTO settings (id, value, description)
VALUES
    ('last_reset_daily', NULL, 'Thời gian reset lượt xem theo ngày gần nhất'),
    ('last_reset_weekly', NULL, 'Thời gian reset lượt xem theo tuần gần nhất'),
    ('last_reset_monthly', NULL, 'Thời gian reset lượt xem theo tháng gần nhất'),
    ('algorithm_hot_min_daily_views', '100', 'Số lượt xem tối thiểu trong ngày để đánh dấu là hot'),
    ('algorithm_hot_growth_rate', '30', 'Tỷ lệ tăng trưởng tối thiểu so với ngày trước (%)'),
    ('algorithm_hot_min_new_ratings', '10', 'Số lượng đánh giá mới tối thiểu trong 24h'),
    ('algorithm_hot_cooldown_days', '3', 'Số ngày tự động loại bỏ trạng thái hot')
ON CONFLICT (id) DO NOTHING;

-- Ghi nhận việc tạo bảng
INSERT INTO system_changes (change_type, description, sql_query, created_at)
VALUES ('structure', 'Created story_stats table for daily statistics tracking', 'Created story_stats table and related settings', CURRENT_TIMESTAMP);
