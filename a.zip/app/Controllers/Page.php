<?php
namespace App\Controllers;

use App\Models\SettingsModel;

class Page extends BaseController
{
    protected $settingsModel;

    public function __construct()
    {
        $this->settingsModel = new SettingsModel();
    }

    /**
     * Trang giới thiệu
     */
    public function about()
    {
        $siteName = $this->settingsModel->getSetting('site_name', 'Web Truyện');
        $siteDescription = $this->settingsModel->getSetting('site_description', 'Trang web truyện hay, cập nhật thông tin truyện mới nhất');

        return $this->renderView('page/about.html', [
            'title' => 'Giới Thiệu',
            'site_name' => $siteName,
            'site_description' => $siteDescription
        ]);
    }

    /**
     * Trang liên hệ
     */
    public function contact()
    {
        return $this->renderView('page/contact.html', [
            'title' => 'Liên Hệ'
        ]);
    }

    /**
     * Xử lý gửi liên hệ
     */
    public function sendContact()
    {
        // Validate form input
        $rules = [
            'name' => 'required|min_length[3]|max_length[50]',
            'email' => 'required|valid_email',
            'subject' => 'required|min_length[5]|max_length[100]',
            'message' => 'required|min_length[10]'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $data = [
            'name' => $this->request->getPost('name'),
            'email' => $this->request->getPost('email'),
            'subject' => $this->request->getPost('subject'),
            'message' => $this->request->getPost('message'),
            'created_at' => date('Y-m-d H:i:s')
        ];

        // Insert into database
        $db = \Config\Database::connect();
        $result = $db->table('contacts')->insert($data);

        if ($result) {
            // Gửi email thông báo (có thể bổ sung sau)

            return redirect()->to(base_url('/lien-he'))->with('success', 'Cảm ơn bạn đã liên hệ với chúng tôi. Chúng tôi sẽ phản hồi sớm nhất có thể!');
        } else {
            return redirect()->to(base_url('/lien-he'))->with('error', 'Có lỗi xảy ra khi gửi liên hệ. Vui lòng thử lại sau.');
        }
    }

    /**
     * Trang chính sách bảo mật
     */
    public function privacy()
    {
        $siteName = $this->settingsModel->getSetting('site_name', 'Web Truyện');

        return $this->renderView('page/privacy.html', [
            'title' => 'Chính Sách Bảo Mật',
            'site_name' => $siteName
        ]);
    }

    /**
     * Trang điều khoản sử dụng
     */
    public function terms()
    {
        $siteName = $this->settingsModel->getSetting('site_name', 'Web Truyện');

        return $this->renderView('page/terms.html', [
            'title' => 'Điều Khoản Sử Dụng',
            'site_name' => $siteName
        ]);
    }
}
