# Tài liệu Database Schema

## Giới thiệu

File `unified_schema.sql` là kết quả của việc hợp nhất các file SQL riêng lẻ thành một file duy nhất. Việc hợp nhất này giúp dễ dàng quản lý và triển khai cơ sở dữ liệu, đồng thời đảm bảo tính nhất quán giữa các môi trường.

## Các file nguồn đã hợp nhất

File `unified_schema.sql` được tạo bằng cách hợp nhất các file sau:

1. **schema.sql**: Cấu trúc cơ bản của cơ sở dữ liệu, bao gồm các bảng chính và dữ liệu mẫu
2. **update_stories_table.sql**: Cập nhật bảng stories để thêm trường author_name và uploader_id
3. **create_guest_bookmarks_table.sql**: Tạo bảng guest_bookmarks để lưu bookmark cho khách

## Các cải tiến và thay đổi trong file hợp nhất

Trong quá trình hợp nhất, một số cải tiến và thay đổi đã được thực hiện:

1. **Chuẩn hóa hệ quản trị cơ sở dữ liệu**: Đã thống nhất cú pháp cho PostgreSQL, loại bỏ các cú pháp riêng của MySQL như `AUTO_INCREMENT`, `TINYINT(1)`, v.v.

2. **Bổ sung các thuộc tính thiếu**: Đã thêm các trường còn thiếu trong các bảng:
   - Thêm `chapter_id` vào bảng `bookmarks`
   - Thêm `updated_at` vào các bảng cần theo dõi thời gian cập nhật

3. **Tổ chức cấu trúc**: Đã phân nhóm các bảng theo chức năng:
   - Core tables: Các bảng chính (users, countries, categories, stories, chapters)
   - User interaction tables: Các bảng liên quan đến tương tác người dùng (bookmarks, comments)
   - System tables: Các bảng hệ thống (settings, logs, backups)

4. **Bổ sung indexes**: Đã bổ sung các chỉ mục để tăng hiệu suất truy vấn:
   - Thêm index cho trường `is_recommended` trong bảng `stories`
   - Thêm các index cho các bảng mới như `guest_bookmarks`

5. **Bổ sung triggers**: Đã bổ sung các trigger để tự động cập nhật:
   - Trigger cập nhật `updated_at` cho tất cả các bảng
   - Trigger cập nhật `search_vector` cho bảng `stories`

6. **Bổ sung cấu hình mới**: Đã thêm các cấu hình mới vào bảng `settings`:
   - Thêm `max_guest_bookmarks` để giới hạn số lượng bookmark cho khách
   - Thêm `imgur_client_id` để lưu trữ Imgur API key

7. **Thêm bảng theo dõi thay đổi**: Đã thêm bảng `system_changes` để theo dõi các thay đổi cấu trúc hệ thống

## Cách sử dụng

### Triển khai cơ sở dữ liệu mới

Để triển khai cơ sở dữ liệu mới, sử dụng lệnh sau:

```bash
psql -U username -d database_name -f database/unified_schema.sql
```

### Cập nhật cơ sở dữ liệu hiện có

Nếu bạn đã có cơ sở dữ liệu và chỉ muốn cập nhật, bạn nên sao lưu trước khi thực hiện:

```bash
# Sao lưu
pg_dump -U username -d database_name > backup.sql

# Cập nhật
psql -U username -d database_name -f database/unified_schema.sql
```

## Lưu ý quan trọng

1. **Kiểm tra tính tương thích**: File SQL đã được viết cho PostgreSQL. Nếu bạn sử dụng hệ quản trị khác, có thể cần điều chỉnh cú pháp.

2. **Dữ liệu mẫu**: File chứa dữ liệu mẫu cho một số bảng như `users`, `countries`, `categories` và `settings`. Nếu không muốn sử dụng dữ liệu mẫu, hãy xóa các câu lệnh INSERT tương ứng.

3. **Kiểm tra lỗi**: Nếu gặp lỗi khi triển khai, hãy kiểm tra lỗi và sửa lỗi trong file SQL hoặc sử dụng các câu lệnh SQL riêng lẻ để triển khai từng phần.

4. **Bảo mật**: Mật khẩu mặc định cho tài khoản admin là `admin123`. Nhớ thay đổi sau khi triển khai.

## Cấu trúc cơ sở dữ liệu

### Bảng chính
- `users`: Lưu thông tin người dùng
- `stories`: Lưu thông tin truyện
- `chapters`: Lưu thông tin chương
- `categories`: Lưu thông tin thể loại
- `countries`: Lưu thông tin quốc gia

### Bảng quan hệ
- `story_categories`: Quan hệ nhiều-nhiều giữa truyện và thể loại
- `bookmarks`: Đánh dấu truyện của người dùng
- `guest_bookmarks`: Đánh dấu truyện của khách
- `reading_progress`: Tiến độ đọc truyện của người dùng
- `ratings`: Đánh giá truyện của người dùng
- `comments`: Bình luận của người dùng và khách

### Bảng hệ thống
- `settings`: Cài đặt trang web
- `tokens`: API tokens
- `media`: Quản lý files media
- `backups`: Quản lý backups
- `logs`: Nhật ký hệ thống
- `system_changes`: Theo dõi thay đổi cấu trúc hệ thống

## Các tính năng nổi bật

1. **Hỗ trợ tìm kiếm Full-Text**: Sử dụng `search_vector` và trigger để tự động cập nhật vector tìm kiếm.

2. **Bookmark cho khách**: Cho phép khách không đăng nhập vẫn có thể lưu truyện yêu thích.

3. **Phân biệt tác giả và người đăng**: Lưu trữ riêng biệt thông tin tác giả thật và người đăng truyện.

4. **API Token Authentication**: Hỗ trợ xác thực API bằng tokens.

5. **Truyện đề xuất**: Truyện được đề xuất dựa trên các tiêu chí khác nhau.

6. **Hệ thống phân quyền**: Hỗ trợ 3 cấp phân quyền: Cộng tác viên, Admin, Người sáng lập.
