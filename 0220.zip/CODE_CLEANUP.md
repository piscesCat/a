# Phân tích và xóa bỏ mã nguồn thừa

## Tổng quan
Tài liệu này liệt kê chi tiết các đoạn mã nguồn cần được xóa bỏ hoặc tối ưu hóa để cải thiện hiệu suất và bảo trì của hệ thống.

## 1. Mã nguồn thừa trong StoryModel.php

### 1.1 Phương thức getHotStories() (Loại bỏ)
- **Vị trí**: StoryModel.php, dòng 709-717
- **Lý do loại bỏ**: Đã được đánh dấu là deprecated và thay thế bằng getRecommendedStories()
- **Đoạn mã cần xóa**:
```php
/**
 * Lấy truyện hot dựa trên hot_score (phương thức cũ)
 * @deprecated Dùng getRecommendedStories thay thế
 */
public function getHotStories($limit = 10)
{
    // Đảm bảo hot_score được cập nhật
    $this->calculateHotScore();

    return $this->orderBy('hot_score', 'DESC')
        ->limit($limit)
        ->find();
}
```

### 1.2 Phương thức calculateHotScore() (Loại bỏ)
- **Vị trí**: StoryModel.php, dòng 558-600
- **Lý do loại bỏ**: Chỉ được sử dụng bởi phương thức deprecated getHotStories()
- **Đoạn mã cần xóa**:
```php
/**
 * Tính điểm hot cho truyện
 * Công thức: (lượt xem tuần * 0.5) + (số bình luận * 2) + (lượt yêu thích * 3) + (đánh giá * 10) + recency_bonus
 */
public function calculateHotScore()
{
    // Tính số bình luận cho mỗi truyện
    $commentCounts = $this->db->table('comments')
        ->select('story_id, COUNT(*) as comment_count')
        ->where('created_at >=', date('Y-m-d H:i:s', strtotime('-30 days')))
        ->groupBy('story_id')
        ->get()
        ->getResultArray();

    // Tạo map để lookup nhanh số bình luận
    $commentMap = [];
    foreach ($commentCounts as $item) {
        $commentMap[$item['story_id']] = $item['comment_count'];
    }

    // Lấy danh sách tất cả truyện
    $stories = $this->findAll();

    // Tính hot_score cho từng truyện
    foreach ($stories as $story) {
        $storyId = $story['id'];
        $commentCount = $commentMap[$storyId] ?? 0;

        // Tính recency_bonus dựa trên thời gian cập nhật
        $updatedTimestamp = strtotime($story['updated_at']);
        $currentTimestamp = time();
        $daysDiff = ($currentTimestamp - $updatedTimestamp) / (60 * 60 * 24);

        // Truyện càng mới càng được ưu tiên, tối đa 50 điểm cho truyện cập nhật trong ngày
        $recencyBonus = max(0, 50 - ($daysDiff * 5));

        // Tính hot_score theo công thức
        $hotScore = ($story['views_week'] * 0.5) +
                    ($commentCount * 2) +
                    ($story['total_favorites'] * 3) +
                    ($story['rating'] * 10) +
                    $recencyBonus;

        // Cập nhật hot_score
        $this->update($storyId, ['hot_score' => $hotScore]);
    }
}
```

### 1.3 Phương thức getStoriesByAuthor() (Cập nhật)
- **Vị trí**: StoryModel.php, dòng 404-422
- **Vấn đề**: Phương thức này sử dụng cột `author` thay vì `author_name`
- **Cách sửa**: Thay đổi tham chiếu từ `author` thành `author_name`
- **Mã nguồn cập nhật**:
```php
/**
 * Lấy truyện theo tác giả
 */
public function getStoriesByAuthor($author, $limit = 20, $offset = 0)
{
    $builder = $this->db->table('stories s')
        ->select('s.*, c.name as country_name')
        ->join('countries c', 's.country_id = c.id', 'left')
        ->where('s.author_name', $author);

    $total = $builder->countAllResults(false);

    $result = $builder->orderBy('s.views', 'DESC')
        ->limit($limit, $offset)
        ->get()
        ->getResultArray();

    return [
        'total' => $total,
        'stories' => $result
    ];
}
```

## 2. Templates và Controller thừa cho chức năng quốc gia

### 2.1 Templates dư thừa cần xóa
- `app/Views/admin/country/create.html`
- `app/Views/admin/country/edit.html`

### 2.2 Phương thức dư thừa trong CountryManager.php
Chỉ giữ lại các phương thức xem danh sách quốc gia, loại bỏ các phương thức tạo/sửa/xóa:

- **Vị trí**: app/Controllers/Admin/CountryManager.php
- **Phương pháp**: Giữ lại phương thức `index()` và `view()`, loại bỏ các phương thức khác liên quan đến CRUD quốc gia nếu còn sót lại.

## 3. Tối ưu BaseController.php

### 3.1 Cải thiện cơ chế cache settings
- **Vị trí**: BaseController.php, dòng 294
- **Vấn đề**: Thời gian cache quá ngắn (300 giây = 5 phút)
- **Đề xuất sửa đổi**:
```php
// Cache for 1 hour instead of 5 minutes
cache()->save('site_settings', $settings, 3600);
```

### 3.2 Cải thiện phương thức requireResourceOwnership
- **Vị trí**: BaseController.php, dòng 630-664
- **Vấn đề**: Bypass kiểm tra cho admin/founder có thể gây ra lỗ hổng
- **Đề xuất sửa đổi**:
```php
protected function requireResourceOwnership($model, $resourceId, $ownerColumn = 'uploader_id')
{
    // Kiểm tra đăng nhập
    $loginCheck = $this->requireLogin();
    if ($loginCheck !== true) {
        return $loginCheck;
    }

    // Không bypass tự động cho admin, chỉ kiểm tra quyền sở hữu
    if (!$this->isResourceOwner($model, $resourceId, $ownerColumn)) {
        // Log the unauthorized access attempt
        if (isset($this->logModel)) {
            $this->logModel->warning('Unauthorized resource access attempt', [
                'user_id' => $this->currentUser['id'] ?? null,
                'username' => $this->currentUser['username'] ?? 'unknown',
                'model' => $model,
                'resource_id' => $resourceId,
                'ip' => $this->request->getIPAddress(),
                'uri' => $this->request->getUri()
            ]);
        }

        // Nếu là admin/founder, cho phép truy cập nhưng vẫn ghi log
        if ($this->currentUser['role'] >= 2) {
            $this->logModel->info('Admin/Founder accessing resource', [
                'user_id' => $this->currentUser['id'],
                'username' => $this->currentUser['username'],
                'model' => $model,
                'resource_id' => $resourceId
            ]);
            return true;
        }

        // If this is an AJAX request, return JSON
        if ($this->request->isAJAX()) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Bạn không có quyền truy cập tài nguyên này'
            ])->setStatusCode(403);
        }

        // Otherwise, redirect with error message
        $this->session->setFlashdata('error', 'Bạn không có quyền truy cập tài nguyên này');
        return redirect()->back();
    }

    return true;
}
```

## 4. Tối ưu ImgurClient

### 4.1 Thêm cơ chế dự phòng trong ImgurClient
- **Vị trí**: app/Libraries/ImgurClient.php
- **Đề xuất cải tiến**: Thêm cơ chế lưu trữ cục bộ khi Imgur API không khả dụng

### 4.2 Tăng cường bảo mật trong upload
- **Vị trí**: app/Controllers/Api/Uploads.php
- **Đề xuất cải tiến**: Thêm kiểm tra loại file và kích thước trước khi upload

## 5. Chuẩn hóa kiểm tra quyền trong các controller

### 5.1 Áp dụng kiểm tra quyền cho các controller còn lại
- **Áp dụng cho**: Tất cả các controller trong `app/Controllers/` và `app/Controllers/Admin/`
- **Mô hình**:
```php
public function methodName()
{
    // Kiểm tra quyền phù hợp
    $check = $this->requireRole(1); // hoặc requireAdmin(), requireFounder() tùy trường hợp
    if ($check !== true) {
        return $check;
    }

    // Phần còn lại của method
}
```

## 6. Tình trạng triển khai

Việc thực hiện các khuyến nghị xóa và tối ưu code ở trên sẽ giúp cải thiện mã nguồn theo các khía cạnh sau:

1. **Giảm kích thước codebase**: Loại bỏ ~150-200 dòng code thừa
2. **Tăng hiệu suất**: Giảm bộ nhớ và thời gian xử lý
3. **Dễ bảo trì hơn**: Mã nguồn sạch sẽ và nhất quán hơn
4. **An toàn hơn**: Kiểm tra quyền chặt chẽ hơn

Các mục tiêu ưu tiên:
1. Loại bỏ các phương thức thừa trong StoryModel
2. Chuẩn hóa kiểm tra quyền
3. Tối ưu cơ chế cache
