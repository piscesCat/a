// app/Config/Routes.php
namespace Config;

use CodeIgniter\Router\RouteCollection;

$routes = Services::routes();

if (file_exists(SYSTEMPATH . 'Config/Routes.php')) {
    require SYSTEMPATH . 'Config/Routes.php';
}

$routes->setDefaultNamespace('App\\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
$routes->setAutoRoute(true);

// =========================================
// MAIN ROUTES WITH SEO FRIENDLY URLS
// =========================================
$routes->get('/', 'Home::index');

// Story listing routes
$routes->group('', function($routes) {
    $routes->get('truyen-de-cu', 'Story::recommended');
    $routes->get('truyen-moi', 'Story::latest');
    $routes->get('truyen-hoan-thanh', 'Story::completed');
    $routes->get('truyen-hot', 'Story::hot');
    $routes->get('truyen-cap-nhat', 'Story::recentlyUpdated');
    $routes->get('bang-xep-hang', 'Story::rankings');
});

// Story and chapter view
$routes->get('truyen/(:segment)', 'Story::view/$1');
$routes->get('truyen/(:segment)/chuong-(:num)', 'Chapter::view/$1/$2');

// Categories
$routes->get('the-loai', 'Story::categories');
$routes->get('the-loai/(:segment)', 'Story::category/$1');

// Filtering
$routes->get('quoc-gia/(:segment)', 'Story::country/$1');
$routes->get('nam-phat-hanh/(:num)', 'Story::byYear/$1');
$routes->get('tac-gia/(:segment)', 'Story::author/$1');
$routes->get('tim-kiem', 'Story::search');

// Comment routes
$routes->group('comments', function($routes) {
    $routes->post('story', 'Comment::addStoryComment');
    $routes->post('chapter', 'Comment::addChapterComment');
    $routes->post('delete', 'Comment::deleteComment');
    $routes->get('load-more', 'Comment::loadMoreComments');
});

// Search suggestions
$routes->get('search/suggestions', 'Story::searchSuggestions');

// Bookmarks (optimized client-side implementation)
$routes->group('bookmarks', function($routes) {
    $routes->get('/', 'Bookmark::index');
    $routes->get('check', 'Bookmark::checkStatus');
    $routes->get('chapter', 'Bookmark::checkChapter');
});

// Static pages
$routes->group('', function($routes) {
    $routes->get('gioi-thieu', 'Page::about');
    $routes->get('lien-he', 'Page::contact');
    $routes->post('lien-he', 'Page::sendContact');
    $routes->get('chinh-sach-bao-mat', 'Page::privacy');
    $routes->get('dieu-khoan-su-dung', 'Page::terms');
});

// =========================================
// API ENDPOINTS (Authenticated)
// =========================================
$routes->group('api', ['filter' => 'api-auth'], function($routes) {
    // Stories API
    $routes->post('stories', 'Api\\Stories::create');
    $routes->put('stories/(:num)', 'Api\\Stories::update/$1');

    // Chapters API
    $routes->post('chapters', 'Api\\Chapters::create');
    $routes->put('chapters/(:num)', 'Api\\Chapters::update/$1');

    // Uploads API
    $routes->post('uploads/image', 'Api\\Uploads::uploadImage');
    $routes->delete('uploads/(:num)', 'Api\\Uploads::deleteImage/$1');
    $routes->get('uploads', 'Api\\Uploads::getImages');

    // Tokens API
    $routes->delete('tokens/revoke/(:num)', 'Api\\ApiTokens::revokeToken/$1');
    $routes->get('tokens', 'Api\\ApiTokens::getTokens');
});

// =========================================
// ADMIN ROUTES
// =========================================
$routes->group('admin', ['namespace' => 'App\\Controllers\\Admin'], function($routes) {
    $routes->get('/', 'Dashboard::index');

    // Story management
    $routes->group('stories', function($routes) {
        $routes->get('/', 'StoryManager::index');
        $routes->get('new', 'StoryManager::create');
        $routes->post('save', 'StoryManager::save');
        $routes->get('edit/(:num)', 'StoryManager::edit/$1');
        $routes->post('update/(:num)', 'StoryManager::update/$1');
        $routes->post('ajax-delete', 'StoryManager::delete');
    });

    // Chapter management
    $routes->group('chapters', function($routes) {
        $routes->get('/', 'ChapterManager::index');
        $routes->get('new', 'ChapterManager::create');
        $routes->post('save', 'ChapterManager::save');
        $routes->get('edit/(:num)', 'ChapterManager::edit/$1');
        $routes->post('update/(:num)', 'ChapterManager::update/$1');
        $routes->post('ajax-delete', 'ChapterManager::delete');
    });

    // Category management
    $routes->group('categories', function($routes) {
        $routes->get('/', 'CategoryManager::index');
        $routes->get('new', 'CategoryManager::create');
        $routes->post('save', 'CategoryManager::save');
        $routes->get('edit/(:num)', 'CategoryManager::edit/$1');
        $routes->post('update/(:num)', 'CategoryManager::update/$1');
        $routes->post('ajax-delete', 'CategoryManager::delete');
    });

    // Comment management
    $routes->group('comments', function($routes) {
        $routes->get('/', 'CommentManager::index');
        $routes->post('delete/(:num)', 'CommentManager::delete/$1');
        $routes->post('bulk-delete', 'CommentManager::bulkDelete');
        $routes->get('reply/(:num)', 'CommentManager::reply/$1');
        $routes->post('send-reply/(:num)', 'CommentManager::sendReply/$1');
    });

    // User management
    $routes->group('users', function($routes) {
        $routes->get('/', 'UserManager::index');
        $routes->get('new', 'UserManager::create');
        $routes->post('save', 'UserManager::save');
        $routes->get('edit/(:num)', 'UserManager::edit/$1');
        $routes->post('update/(:num)', 'UserManager::update/$1');
        $routes->post('delete', 'UserManager::delete');
        $routes->post('update-status', 'UserManager::updateStatus');
    });

    // Settings
    $routes->group('settings', function($routes) {
        $routes->get('/', 'Settings::index');
        $routes->post('save', 'Settings::save');
        $routes->get('seo', 'Settings::seo');
        $routes->post('save-seo', 'Settings::saveSeo');
        $routes->post('clear-cache', 'Settings::clearCache');
        $routes->get('templates', 'Settings::templates');
        $routes->post('save-templates', 'Settings::saveTemplates');
        $routes->get('styles', 'Settings::styles');
        $routes->post('save-styles', 'Settings::saveStyles');
        $routes->get('email', 'Settings::email');
        $routes->post('save-email', 'Settings::saveEmail');
        $routes->post('test-email', 'Settings::testEmail');
        $routes->get('social', 'Settings::social');
        $routes->post('save-social', 'Settings::saveSocial');
    });

    // API Token management
    $routes->group('api-tokens', function($routes) {
        $routes->get('/', 'ApiTokens::index');
        $routes->post('create', 'ApiTokens::create');
        $routes->post('revoke/(:num)', 'ApiTokens::revoke/$1');
    });

    // Reports
    $routes->group('reports', function($routes) {
        $routes->get('/', 'Reports::index');
        $routes->get('export/(:segment)', 'Reports::export/$1');
    });

    // File uploads
    $routes->group('uploads', function($routes) {
        $routes->get('/', 'Uploads::index');
        $routes->post('upload', 'Uploads::upload');
        $routes->post('upload-image', 'Uploads::uploadImage');
        $routes->post('ajax-delete', 'Uploads::delete');
        $routes->get('list', 'Uploads::listFiles');
        $routes->post('delete-file', 'Uploads::deleteFile');
    });

    // Dashboard data
    $routes->group('dashboard', function($routes) {
        $routes->get('stats', 'Dashboard::stats');
        $routes->get('top-stories', 'Dashboard::topStories');
        $routes->get('top-users', 'Dashboard::topUsers');
    });

    // Backup management
    $routes->group('backups', function($routes) {
        $routes->get('/', 'Backups::index');
        $routes->post('createDatabase', 'Backups::createDatabase');
        $routes->post('createFiles', 'Backups::createFiles');
        $routes->get('download/(:num)', 'Backups::download/$1');
        $routes->post('delete', 'Backups::delete');
        $routes->get('restore/(:num)', 'Backups::restore/$1');
        $routes->get('cleanup', 'Backups::cleanup');
        $routes->post('performCleanup', 'Backups::performCleanup');
    });

    // Database maintenance
    $routes->group('maintenance', function($routes) {
        $routes->get('cleanup', 'DatabaseMaintenance::cleanup');
        $routes->get('reset-stats/(:segment)', 'DatabaseMaintenance::resetStats/$1');
        $routes->get('update-recommended', 'DatabaseMaintenance::updateRecommendedStories');
    });
});
