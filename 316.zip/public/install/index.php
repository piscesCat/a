<?php
/**
 * Web Truyện - Installer
 * File cài đặt độc lập giúp khởi tạo hệ thống một cách dễ dàng
 */

// Định nghĩa các đường dẫn quan trọng
define('INSTALLER_VERSION', '1.0');
define('ROOTPATH', realpath(dirname(dirname(__FILE__)) . '/../') . '/');
define('APPPATH', ROOTPATH . 'app/');
define('VIEWPATH', APPPATH . 'Views/');
define('WRITEPATH', ROOTPATH . 'writable/');
define('INSTALL_PATH', __DIR__ . '/');

// Khởi tạo session
session_start();

// Thiết lập header và error reporting
header('Content-Type: text/html; charset=UTF-8');
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Định nghĩa các URL và route
$base_url = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == "on") ? "https" : "http");
$base_url .= "://" . $_SERVER['HTTP_HOST'];
$base_url .= str_replace(basename($_SERVER['SCRIPT_NAME']), "", $_SERVER['SCRIPT_NAME']);
define('BASE_URL', $base_url);

// Xác định route hiện tại
$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$uri = str_replace('install/', '', $uri);
$uri = trim($uri, '/');
$segments = explode('/', $uri);
$route = isset($segments[1]) ? $segments[1] : 'index';

// Kiểm tra xem hệ thống đã được cài đặt chưa
function isInstalled() {
    return file_exists(ROOTPATH . 'installed.txt');
}

// Kiểm tra yêu cầu hệ thống
function checkRequirements() {
    return [
        [
            'name' => 'PHP Version',
            'required' => '7.4 or higher',
            'current' => PHP_VERSION,
            'status' => version_compare(PHP_VERSION, '7.4.0', '>=')
        ],
        [
            'name' => 'PDO PostgreSQL Extension',
            'required' => 'Enabled',
            'current' => extension_loaded('pdo_pgsql') ? 'Enabled' : 'Disabled',
            'status' => extension_loaded('pdo_pgsql')
        ],
        [
            'name' => 'Fileinfo Extension',
            'required' => 'Enabled',
            'current' => extension_loaded('fileinfo') ? 'Enabled' : 'Disabled',
            'status' => extension_loaded('fileinfo')
        ],
        [
            'name' => 'CURL Extension',
            'required' => 'Enabled',
            'current' => extension_loaded('curl') ? 'Enabled' : 'Disabled',
            'status' => extension_loaded('curl')
        ],
        [
            'name' => 'GD Extension',
            'required' => 'Enabled',
            'current' => extension_loaded('gd') ? 'Enabled' : 'Disabled',
            'status' => extension_loaded('gd')
        ],
        [
            'name' => 'JSON Extension',
            'required' => 'Enabled',
            'current' => extension_loaded('json') ? 'Enabled' : 'Disabled',
            'status' => extension_loaded('json')
        ]
    ];
}

// Kiểm tra quyền thư mục
function checkPermissions() {
    return [
        [
            'name' => 'writable/',
            'required' => 'Writable',
            'current' => is_writable(WRITEPATH) ? 'Writable' : 'Not Writable',
            'status' => is_writable(WRITEPATH)
        ],
        [
            'name' => 'writable/cache/',
            'required' => 'Writable',
            'current' => is_writable(WRITEPATH . 'cache') ? 'Writable' : 'Not Writable',
            'status' => is_writable(WRITEPATH . 'cache')
        ],
        [
            'name' => 'writable/logs/',
            'required' => 'Writable',
            'current' => is_writable(WRITEPATH . 'logs') ? 'Writable' : 'Not Writable',
            'status' => is_writable(WRITEPATH . 'logs')
        ],
        [
            'name' => 'writable/uploads/',
            'required' => 'Writable',
            'current' => is_writable(WRITEPATH . 'uploads') ? 'Writable' : 'Not Writable',
            'status' => is_writable(WRITEPATH . 'uploads')
        ],
        [
            'name' => 'app/Config/Database.php',
            'required' => 'Writable',
            'current' => is_writable(APPPATH . 'Config/Database.php') ? 'Writable' : 'Not Writable',
            'status' => is_writable(APPPATH . 'Config/Database.php')
        ]
    ];
}

// Lưu cấu hình database
function saveDatabaseConfig($hostname, $database, $username, $password, $port) {
    $configPath = APPPATH . 'Config/Database.php';
    $config = file_get_contents($configPath);

    // Replace database settings in config file
    $config = preg_replace("/'hostname' => '.*?'/", "'hostname' => '$hostname'", $config);
    $config = preg_replace("/'database' => '.*?'/", "'database' => '$database'", $config);
    $config = preg_replace("/'username' => '.*?'/", "'username' => '$username'", $config);
    $config = preg_replace("/'password' => '.*?'/", "'password' => '$password'", $config);
    $config = preg_replace("/'port' => .*?,/", "'port' => $port,", $config);

    // Save updated config file
    file_put_contents($configPath, $config);

    // Create a flag file to indicate database is configured
    file_put_contents(ROOTPATH . 'database_configured.txt', date('Y-m-d H:i:s'));
}

// Tạo file .env từ cấu hình người dùng đã nhập
function createEnvFile($appName, $appUrl, $appKey, $imgurClientId, $imgurClientSecret, $dbHostname, $dbPort, $dbName, $dbUsername, $dbPassword) {
    $envContent = "# Tệp cấu hình môi trường (Environment Configuration)
# Được tạo tự động bởi quá trình cài đặt

# Thông tin ứng dụng
APP_NAME=\"$appName\"
APP_ENV=production
APP_KEY=$appKey
APP_DEBUG=false
APP_URL=$appUrl

# Cấu hình Cơ sở dữ liệu
DB_CONNECTION=pgsql
DB_HOST=$dbHostname
DB_PORT=$dbPort
DB_DATABASE=$dbName
DB_USERNAME=$dbUsername
DB_PASSWORD=$dbPassword

# Cấu hình API Imgur
IMGUR_CLIENT_ID=$imgurClientId
IMGUR_CLIENT_SECRET=$imgurClientSecret

# Thời gian JWT Token hết hạn (phút)
JWT_EXPIRE=60

# Các thiết lập khác
DEFAULT_LOCALE=vi
LOG_LEVEL=error
CACHE_DRIVER=file
SESSION_DRIVER=file
COOKIE_SECURE=false
";

    // Lưu file .env vào thư mục gốc
    file_put_contents(ROOTPATH . '.env', $envContent);

    // Tạo file .env.example nếu chưa có
    if (!file_exists(ROOTPATH . '.env.example')) {
        file_put_contents(ROOTPATH . '.env.example', $envContent);
    }

    return true;
}

// Import database schema
function importDatabaseSchema() {
    try {
        // Kết nối đến database
        $configPath = APPPATH . 'Config/Database.php';
        if (!file_exists($configPath)) {
            throw new Exception('Database configuration file not found.');
        }

        // Parse database config file để lấy thông tin kết nối
        $config = file_get_contents($configPath);
        preg_match("/'hostname' => '(.*?)'/", $config, $hostname);
        preg_match("/'database' => '(.*?)'/", $config, $database);
        preg_match("/'username' => '(.*?)'/", $config, $username);
        preg_match("/'password' => '(.*?)'/", $config, $password);
        preg_match("/'port' => (.*?),/", $config, $port);

        // Kết nối database
        $dsn = "pgsql:host={$hostname[1]};port={$port[1]};dbname={$database[1]}";
        $pdo = new PDO($dsn, $username[1], $password[1]);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Đọc schema thống nhất từ thư mục cài đặt
        $schema = file_get_contents(INSTALL_PATH . 'setup.sql');

        // Thực thi SQL statement
        $pdo->exec($schema);

        return true;
    } catch (PDOException $e) {
        $_SESSION['error'] = 'Database import error: ' . $e->getMessage();
        return false;
    } catch (Exception $e) {
        $_SESSION['error'] = 'Error: ' . $e->getMessage();
        return false;
    }
}

// Tạo tài khoản admin
function createAdminUser($username, $email, $password) {
    try {
        // Kết nối đến database
        $configPath = APPPATH . 'Config/Database.php';
        $config = file_get_contents($configPath);
        preg_match("/'hostname' => '(.*?)'/", $config, $hostname);
        preg_match("/'database' => '(.*?)'/", $config, $database);
        preg_match("/'username' => '(.*?)'/", $config, $username_db);
        preg_match("/'password' => '(.*?)'/", $config, $password_db);
        preg_match("/'port' => (.*?),/", $config, $port);

        // Kết nối database
        $dsn = "pgsql:host={$hostname[1]};port={$port[1]};dbname={$database[1]}";
        $pdo = new PDO($dsn, $username_db[1], $password_db[1]);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Hash mật khẩu
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Kiểm tra xem người dùng sáng lập đã tồn tại chưa
        $stmt = $pdo->prepare("SELECT * FROM users WHERE role = 3");
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            // Cập nhật người dùng sáng lập nếu đã tồn tại
            $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ?, password = ? WHERE role = 3");
            $stmt->execute([$username, $email, $hashed_password]);
        } else {
            // Tạo người dùng sáng lập mới
            $stmt = $pdo->prepare("INSERT INTO users (username, email, password, role, status, created_at, updated_at) VALUES (?, ?, ?, 3, 'active', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)");
            $stmt->execute([$username, $email, $hashed_password]);
        }

        return true;
    } catch (PDOException $e) {
        $_SESSION['error'] = 'Database error: ' . $e->getMessage();
        return false;
    } catch (Exception $e) {
        $_SESSION['error'] = 'Error: ' . $e->getMessage();
        return false;
    }
}

// Lưu cài đặt trang web
function saveSiteSettings($siteName, $siteDescription) {
    try {
        // Kết nối đến database
        $configPath = APPPATH . 'Config/Database.php';
        $config = file_get_contents($configPath);
        preg_match("/'hostname' => '(.*?)'/", $config, $hostname);
        preg_match("/'database' => '(.*?)'/", $config, $database);
        preg_match("/'username' => '(.*?)'/", $config, $username);
        preg_match("/'password' => '(.*?)'/", $config, $password);
        preg_match("/'port' => (.*?),/", $config, $port);

        // Kết nối database
        $dsn = "pgsql:host={$hostname[1]};port={$port[1]};dbname={$database[1]}";
        $pdo = new PDO($dsn, $username[1], $password[1]);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Lưu settings
        $settings = [
            'site_name' => $siteName,
            'site_description' => $siteDescription,
            'installed_at' => date('Y-m-d H:i:s')
        ];

        foreach ($settings as $name => $value) {
            // Check if setting exists
            $stmt = $pdo->prepare("SELECT id FROM settings WHERE name = ?");
            $stmt->execute([$name]);

            if ($stmt->rowCount() > 0) {
                // Update existing setting
                $stmt = $pdo->prepare("UPDATE settings SET value = ? WHERE name = ?");
                $stmt->execute([$value, $name]);
            } else {
                // Insert new setting
                $stmt = $pdo->prepare("INSERT INTO settings (name, value) VALUES (?, ?)");
                $stmt->execute([$name, $value]);
            }
        }

        return true;
    } catch (PDOException $e) {
        $_SESSION['error'] = 'Database error: ' . $e->getMessage();
        return false;
    } catch (Exception $e) {
        $_SESSION['error'] = 'Error: ' . $e->getMessage();
        return false;
    }
}

// Hoàn thành cài đặt
function completeInstallation($siteName = null, $siteDescription = null) {
    // Tạo flag file để đánh dấu cài đặt hoàn tất
    file_put_contents(ROOTPATH . 'installed.txt', date('Y-m-d H:i:s'));

    // Xóa file chỉ báo cấu hình database nếu tồn tại
    if (file_exists(ROOTPATH . 'database_configured.txt')) {
        @unlink(ROOTPATH . 'database_configured.txt');
    }

    // Cập nhật file .env nếu có thông tin trang web
    if ($siteName && file_exists(ROOTPATH . '.env')) {
        $envContent = file_get_contents(ROOTPATH . '.env');

        // Cập nhật tên ứng dụng
        $envContent = preg_replace('/APP_NAME=".*?"/', 'APP_NAME="' . addslashes($siteName) . '"', $envContent);

        // Đặt lại chế độ debug thành false cho môi trường sản xuất
        $envContent = preg_replace('/APP_DEBUG=.*/', 'APP_DEBUG=false', $envContent);

        // Lưu file .env đã cập nhật
        file_put_contents(ROOTPATH . '.env', $envContent);
    }

    return true;
}

// Xóa file cài đặt
function removeInstallationFiles() {
    // Danh sách file cần xóa
    $filesToRemove = [
        APPPATH . 'Controllers/Install.php',
        APPPATH . 'Views/install/admin.html',
        APPPATH . 'Views/install/complete.html',
        APPPATH . 'Views/install/database.html',
        APPPATH . 'Views/install/index.html',
        ROOTPATH . 'public/install.php',
        ROOTPATH . 'public/install/index.php',
        ROOTPATH . 'public/install/templates/index.php',
        ROOTPATH . 'public/install/templates/database.php',
        ROOTPATH . 'public/install/templates/admin.php',
        ROOTPATH . 'public/install/templates/complete.php',
        ROOTPATH . 'public/install/templates/header.php',
        ROOTPATH . 'public/install/templates/footer.php',
    ];

    // Xóa các file
    foreach ($filesToRemove as $file) {
        if (file_exists($file)) {
            @unlink($file);
        }
    }

    // Xóa thư mục
    @rmdir(APPPATH . 'Views/install');
    @rmdir(ROOTPATH . 'public/install/templates');
    @rmdir(ROOTPATH . 'public/install');

    // Xóa các đường dẫn cài đặt từ Routes.php
    removeInstallRoutes();

    return true;
}

// Xóa các route cài đặt
function removeInstallRoutes() {
    $routesFile = APPPATH . 'Config/Routes.php';

    if (file_exists($routesFile)) {
        $content = file_get_contents($routesFile);

        // Tìm và xóa phần route cài đặt
        $pattern = "/\/\/ Installation routes.*?\/\/ Main routes/s";
        $replacement = "// Main routes";

        $updatedContent = preg_replace($pattern, $replacement, $content);

        // Lưu nội dung đã cập nhật
        file_put_contents($routesFile, $updatedContent);
    }

    return true;
}

// Chuyển hướng tới URL
function redirect($url) {
    header('Location: ' . $url);
    exit;
}

// Hiển thị template
function view($template, $data = []) {
    extract($data);

    // Template header
    include INSTALL_PATH . 'templates/header.php';

    // Nội dung chính
    include INSTALL_PATH . 'templates/' . $template . '.php';

    // Template footer
    include INSTALL_PATH . 'templates/footer.php';
}

// Tạo thư mục templates nếu chưa có
if (!is_dir(INSTALL_PATH . 'templates')) {
    mkdir(INSTALL_PATH . 'templates', 0755, true);
}

// Route handling
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['step'])) {
        $step = $_POST['step'];

        if ($step == '1' && isset($_POST['proceed'])) {
            // Redirect to database configuration step
            redirect(BASE_URL . 'install/database');
        }
        else if ($step == '2' && isset($_POST['db_hostname'])) {
            // Process database configuration
            $hostname = $_POST['db_hostname'];
            $database = $_POST['db_name'];
            $username = $_POST['db_username'];
            $password = $_POST['db_password'];
            $port = $_POST['db_port'];

            // Thông tin cho file .env
            $appName = $_POST['app_name'] ?? 'WebTruyen';
            $appUrl = $_POST['app_url'] ?? rtrim(BASE_URL, '/');
            $appKey = $_POST['app_key'] ?? bin2hex(random_bytes(16));
            $imgurClientId = $_POST['imgur_client_id'] ?? '';
            $imgurClientSecret = $_POST['imgur_client_secret'] ?? '';

            // Lưu input vào session để phục vụ trường hợp reload form
            $_SESSION['input'] = $_POST;

            // Lưu cấu hình database
            saveDatabaseConfig($hostname, $database, $username, $password, $port);

            // Tạo file .env
            createEnvFile($appName, $appUrl, $appKey, $imgurClientId, $imgurClientSecret, $hostname, $port, $database, $username, $password);

            // Import database schema
            if (importDatabaseSchema()) {
                // Update settings for Imgur in database
                try {
                    $dsn = "pgsql:host={$hostname};port={$port};dbname={$database}";
                    $pdo = new PDO($dsn, $username, $password);
                    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                    // Insert Imgur settings
                    $stmt = $pdo->prepare("INSERT INTO settings (name, value) VALUES (?, ?) ON CONFLICT (name) DO UPDATE SET value = EXCLUDED.value");
                    $stmt->execute(['imgur_client_id', $imgurClientId]);
                    $stmt->execute(['imgur_enabled', !empty($imgurClientId) ? 'on' : 'off']);
                } catch (Exception $e) {
                    // Log error but continue
                    error_log('Error setting Imgur values: ' . $e->getMessage());
                }

                redirect(BASE_URL . 'install/admin');
            } else {
                redirect(BASE_URL . 'install/database');
            }
        }
        else if ($step == '3' && isset($_POST['username'])) {
            // Process admin account setup
            $username = $_POST['username'];
            $email = $_POST['email'];
            $password = $_POST['password'];
            $siteName = $_POST['site_name'];
            $siteDescription = $_POST['site_description'] ?? '';

            if (createAdminUser($username, $email, $password) &&
                saveSiteSettings($siteName, $siteDescription)) {
                completeInstallation($siteName, $siteDescription);
                $_SESSION['success'] = 'Cài đặt hệ thống thành công!';
                redirect(BASE_URL . 'install/complete');
            } else {
                redirect(BASE_URL . 'install/admin');
            }
        }
    }
} else {
    // GET request handling
    switch ($route) {
        case 'database':
            // Check requirements first
            $requirements = checkRequirements();
            $permissions = checkPermissions();
            $canProceed = true;

            foreach ($requirements as $requirement) {
                if (!$requirement['status']) {
                    $canProceed = false;
                    break;
                }
            }

            foreach ($permissions as $permission) {
                if (!$permission['status']) {
                    $canProceed = false;
                    break;
                }
            }

            if (!$canProceed) {
                $_SESSION['error'] = 'Kiểm tra lại các yêu cầu hệ thống.';
                redirect(BASE_URL . 'install');
            }

            view('database', [
                'title' => 'Cài đặt hệ thống - Cấu hình Cơ sở dữ liệu',
                'step' => 2
            ]);
            break;

        case 'admin':
            // Check if database is configured
            if (!file_exists(ROOTPATH . 'database_configured.txt')) {
                $_SESSION['error'] = 'Bạn phải cấu hình cơ sở dữ liệu trước.';
                redirect(BASE_URL . 'install/database');
            }

            view('admin', [
                'title' => 'Cài đặt hệ thống - Tạo tài khoản quản trị',
                'step' => 3
            ]);
            break;

        case 'complete':
            // Check if installation is complete
            if (!$_SESSION['success'] && !isInstalled()) {
                redirect(BASE_URL . 'install');
            }

            view('complete', [
                'title' => 'Cài đặt hoàn tất',
                'step' => 4
            ]);
            break;

        default:
            // Check if already installed
            if (isInstalled()) {
                redirect(BASE_URL);
            }

            // Default: system requirements check
            view('index', [
                'title' => 'Cài đặt hệ thống',
                'step' => 1,
                'requirements' => checkRequirements(),
                'permissions' => checkPermissions()
            ]);
            break;
    }
}
