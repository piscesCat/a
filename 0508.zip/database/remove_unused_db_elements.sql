-- Script để loại bỏ các bảng và trường thừa trong database
-- Kịch bản này nên được chạy sau khi đã sao lưu database

-- Bắt đầu transaction để đảm bảo an toàn
BEGIN;

-- 1. Xóa trường hot_score từ bảng stories (đã bị thay thế bởi is_recommended)
-- Trước tiên, kiểm tra xem cột có tồn tại không
DO $$
BEGIN
    IF EXISTS (
        SELECT 1
        FROM information_schema.columns
        WHERE table_name = 'stories' AND column_name = 'hot_score'
    ) THEN
        ALTER TABLE stories DROP COLUMN hot_score;
        RAISE NOTICE 'Đã xóa cột hot_score từ bảng stories';
    ELSE
        RAISE NOTICE 'Cột hot_score không tồn tại trong bảng stories';
    END IF;
END $$;

-- 2. Loại bỏ cột author_id từ bảng stories (đã bị thay thế bởi author_name và uploader_id)
-- Kiểm tra xem có ràng buộc khóa ngoại không
DO $$
BEGIN
    IF EXISTS (
        SELECT 1
        FROM information_schema.columns
        WHERE table_name = 'stories' AND column_name = 'author_id'
    ) THEN
        -- Xóa ràng buộc khóa ngoại nếu tồn tại
        IF EXISTS (
            SELECT 1
            FROM information_schema.table_constraints tc
            JOIN information_schema.constraint_column_usage ccu ON tc.constraint_name = ccu.constraint_name
            WHERE tc.constraint_type = 'FOREIGN KEY'
            AND tc.table_name = 'stories'
            AND ccu.column_name = 'author_id'
        ) THEN
            EXECUTE (
                SELECT 'ALTER TABLE stories DROP CONSTRAINT ' || tc.constraint_name
                FROM information_schema.table_constraints tc
                JOIN information_schema.constraint_column_usage ccu ON tc.constraint_name = ccu.constraint_name
                WHERE tc.constraint_type = 'FOREIGN KEY'
                AND tc.table_name = 'stories'
                AND ccu.column_name = 'author_id'
                LIMIT 1
            );
        END IF;

        -- Xóa cột
        ALTER TABLE stories DROP COLUMN author_id;
        RAISE NOTICE 'Đã xóa cột author_id từ bảng stories';
    ELSE
        RAISE NOTICE 'Cột author_id không tồn tại trong bảng stories';
    END IF;
END $$;

-- 3. Tinh giản bảng countries (loại bỏ các trường thừa vì chỉ sử dụng làm bảng tham chiếu)
DO $$
BEGIN
    -- Kiểm tra và xóa status (vì không cần thiết nữa)
    IF EXISTS (
        SELECT 1
        FROM information_schema.columns
        WHERE table_name = 'countries' AND column_name = 'status'
    ) THEN
        ALTER TABLE countries DROP COLUMN status;
        RAISE NOTICE 'Đã xóa cột status từ bảng countries';
    END IF;
END $$;

-- 4. Kiểm tra và xử lý thông tin thừa trong các bảng khác

-- Cập nhật cấu trúc vector tìm kiếm để phản ánh việc thay đổi cột
-- Cập nhật trigger stories_vector_update() để không sử dụng author_id nữa
CREATE OR REPLACE FUNCTION stories_vector_update() RETURNS TRIGGER AS $$
BEGIN
    NEW.search_vector := to_tsvector('english',
        coalesce(NEW.title, '') || ' ' ||
        coalesce(NEW.description, '') || ' ' ||
        coalesce(NEW.author_name, '')
    );
    RETURN NEW;
END
$$ LANGUAGE plpgsql;

-- 5. Kiểm tra và cập nhật các cột liên quan đến phân quyền nếu cần

-- 6. Ghi lại thay đổi vào bảng system_changes
INSERT INTO system_changes (change_type, description, sql_query, created_at)
VALUES (
    'structure',
    'Removed unused database elements',
    'Removed hot_score from stories, author_id from stories, status from countries',
    CURRENT_TIMESTAMP
);

-- Kết thúc transaction
COMMIT;

-- Vacuum để khôi phục không gian
VACUUM FULL stories;
VACUUM FULL countries;
