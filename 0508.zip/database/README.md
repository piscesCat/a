# Database Management Files

This directory contains SQL files that are used by the admin panel for database management. These files should **not** be executed directly via command line.

## Files Overview

### unified_schema.sql
- Contains the complete database schema in one file
- Used during initial installation to create all tables and relationships
- Contains all necessary indexes and constraints

### cleanup.sql
- Contains SQL commands to clean up old or redundant data
- Executes routine database maintenance tasks like:
  - Removing old guest bookmarks
  - Deleting expired tokens
  - Removing old logs
  - Cleaning up orphaned records
  - Limiting guest bookmarks per guest ID
  - And more...

### remove_unused_db_elements.sql
- Contains SQL commands to remove unused database elements
- Removes deprecated fields and optimizes the database structure
- Only used when specifically requested through the admin panel

## Usage

All database management tasks should be performed through the admin panel:

1. Login to the admin panel
2. Navigate to "Sao lưu" (Backups) section
3. Use the "Dọn dẹp Database" (Database Cleanup) feature to manage the database

## Important Notes

- Always create a backup before performing any database cleanup operations
- Database cleanup operations are logged in the system
- Only users with Founder role (level 3) can perform database cleanup operations
- The cleanup.sql and remove_unused_db_elements.sql files are automatically executed by the admin panel when a cleanup is requested

## Folder Structure

```
database/
├── unified_schema.sql    # Complete database schema
├── cleanup.sql           # Database cleanup operations
├── remove_unused_db_elements.sql  # Removes deprecated database elements
└── README.md             # This file
```
