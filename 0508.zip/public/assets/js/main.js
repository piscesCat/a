// Theme Toggle Functionality
document.addEventListener('DOMContentLoaded', function() {
    // Kiểm tra theme từ localStorage
    const currentTheme = localStorage.getItem('theme');
    if (currentTheme) {
        document.documentElement.setAttribute('data-theme', currentTheme);
    }

    // Xử lý sự kiện click vào nút chuyển đổi
    const themeToggle = document.getElementById('theme-toggle');
    if (themeToggle) {
        themeToggle.addEventListener('click', function() {
            // Lấy theme hiện tại
            const currentTheme = document.documentElement.getAttribute('data-theme');

            // Chuyển đổi theme
            let targetTheme = 'dark';
            if (currentTheme !== 'light') {
                targetTheme = 'light';
            }

            // Áp dụng theme mới
            document.documentElement.setAttribute('data-theme', targetTheme);

            // Lưu theme vào localStorage
            localStorage.setItem('theme', targetTheme);
        });
    }
});

// Search Suggestions
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('search-input');
    const suggestionsContainer = document.getElementById('search-suggestions');

    if (!searchInput || !suggestionsContainer) return;

    let debounceTimer;

    searchInput.addEventListener('input', function() {
        clearTimeout(debounceTimer);

        const query = this.value.trim();

        if (query.length < 2) {
            suggestionsContainer.style.display = 'none';
            return;
        }

        debounceTimer = setTimeout(function() {
            fetch(`${baseUrl}/search/suggestions?q=${encodeURIComponent(query)}`)
                .then(response => response.json())
                .then(data => {
                    if (data.suggestions && data.suggestions.length > 0) {
                        suggestionsContainer.innerHTML = '';

                        data.suggestions.forEach(suggestion => {
                            const item = document.createElement('div');
                            item.className = 'suggestion-item';

                            const link = document.createElement('a');
                            link.href = `${baseUrl}/truyen/${suggestion.slug}`;
                            link.textContent = suggestion.title;

                            item.appendChild(link);
                            suggestionsContainer.appendChild(item);
                        });

                        suggestionsContainer.style.display = 'block';
                    } else {
                        suggestionsContainer.style.display = 'none';
                    }
                })
                .catch(error => {
                    console.error('Error fetching suggestions:', error);
                    suggestionsContainer.style.display = 'none';
                });
        }, 300);
    });

    // Hide suggestions when clicking outside
    document.addEventListener('click', function(event) {
        if (!searchInput.contains(event.target) && !suggestionsContainer.contains(event.target)) {
            suggestionsContainer.style.display = 'none';
        }
    });

    // Show suggestions when input is focused
    searchInput.addEventListener('focus', function() {
        if (this.value.trim().length >= 2) {
            suggestionsContainer.style.display = 'block';
        }
    });
});

// Bookmark Toggle
function toggleBookmark(storyId, button) {
    if (!userId) {
        window.location.href = `${baseUrl}/dang-nhap`;
        return;
    }

    fetch(`${baseUrl}/bookmarks/toggle`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-Requested-With': 'XMLHttpRequest'
        },
        body: `story_id=${storyId}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            if (data.status === 'added') {
                button.classList.remove('btn-outline-danger');
                button.classList.add('btn-danger');
                button.querySelector('i').classList.remove('far');
                button.querySelector('i').classList.add('fas');
            } else {
                button.classList.remove('btn-danger');
                button.classList.add('btn-outline-danger');
                button.querySelector('i').classList.remove('fas');
                button.querySelector('i').classList.add('far');
            }

            // Hiển thị thông báo thành công
            showToast(data.message, 'success');
        } else {
            // Hiển thị thông báo lỗi
            showToast(data.message, 'error');

            if (data.redirect) {
                setTimeout(() => {
                    window.location.href = data.redirect;
                }, 1000);
            }
        }
    })
    .catch(error => {
        console.error('Error toggling bookmark:', error);
        showToast('Đã xảy ra lỗi khi thực hiện.', 'error');
    });
}

// Toast Notification
function showToast(message, type = 'info') {
    // Create toast container if not exists
    let toastContainer = document.getElementById('toast-container');
    if (!toastContainer) {
        toastContainer = document.createElement('div');
        toastContainer.id = 'toast-container';
        toastContainer.className = 'toast-container position-fixed bottom-0 end-0 p-3';
        document.body.appendChild(toastContainer);
    }

    // Create a unique ID for the toast
    const toastId = 'toast-' + Date.now();

    // Determine background color based on type
    let bgColor = 'bg-info';
    if (type === 'success') bgColor = 'bg-success';
    if (type === 'error') bgColor = 'bg-danger';
    if (type === 'warning') bgColor = 'bg-warning';

    // Create toast HTML
    const toastHtml = `
        <div id="${toastId}" class="toast align-items-center ${bgColor} text-white border-0" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="d-flex">
                <div class="toast-body">
                    ${message}
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
        </div>
    `;

    // Add toast to container
    toastContainer.insertAdjacentHTML('beforeend', toastHtml);

    // Initialize and show the toast
    const toastElement = document.getElementById(toastId);
    const toast = new bootstrap.Toast(toastElement, { autohide: true, delay: 3000 });
    toast.show();

    // Remove the toast after it's hidden
    toastElement.addEventListener('hidden.bs.toast', function() {
        toastElement.remove();
    });
}

// Comment submission handlers
document.addEventListener('DOMContentLoaded', function() {
    const storyCommentForm = document.getElementById('story-comment-form');
    const chapterCommentForm = document.getElementById('chapter-comment-form');

    if (storyCommentForm) {
        storyCommentForm.addEventListener('submit', function(e) {
            e.preventDefault();
            submitComment(this, 'story');
        });
    }

    if (chapterCommentForm) {
        chapterCommentForm.addEventListener('submit', function(e) {
            e.preventDefault();
            submitComment(this, 'chapter');
        });
    }

    // Delete comment buttons
    document.querySelectorAll('.delete-comment').forEach(button => {
        button.addEventListener('click', function() {
            const commentId = this.getAttribute('data-id');
            if (confirm('Bạn có chắc chắn muốn xóa bình luận này?')) {
                deleteComment(commentId);
            }
        });
    });

    // Load more comments button
    const loadMoreBtn = document.getElementById('load-more-comments');
    if (loadMoreBtn) {
        loadMoreBtn.addEventListener('click', function() {
            const storyId = this.getAttribute('data-story-id');
            const chapterId = this.getAttribute('data-chapter-id');
            const offset = parseInt(this.getAttribute('data-offset'), 10);

            loadMoreComments(storyId, chapterId, offset);
        });
    }
});

function submitComment(form, type) {
    const formData = new FormData(form);
    const submitBtn = form.querySelector('button[type="submit"]');
    const originalBtnText = submitBtn.innerHTML;

    // Disable button and show loading
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Đang gửi...';

    // Send request
    fetch(`${baseUrl}/comments/${type}`, {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        // Reset button
        submitBtn.disabled = false;
        submitBtn.innerHTML = originalBtnText;

        if (data.status === 'success') {
            // Clear form
            form.reset();

            // Show success message
            showToast(data.message, 'success');

            // Redirect if needed
            if (data.redirect) {
                setTimeout(() => {
                    window.location.href = data.redirect;
                }, 1000);
            }
        } else {
            // Show error message
            showToast(data.message, 'error');
        }
    })
    .catch(error => {
        // Reset button
        submitBtn.disabled = false;
        submitBtn.innerHTML = originalBtnText;

        // Show error message
        console.error('Error submitting comment:', error);
        showToast('Đã xảy ra lỗi khi gửi bình luận.', 'error');
    });
}

function deleteComment(commentId) {
    fetch(`${baseUrl}/comments/delete`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-Requested-With': 'XMLHttpRequest'
        },
        body: `comment_id=${commentId}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            // Remove comment from DOM
            const commentElement = document.getElementById(`comment-${commentId}`);
            if (commentElement) {
                commentElement.remove();
            }

            // Show success message
            showToast(data.message, 'success');
        } else {
            // Show error message
            showToast(data.message, 'error');
        }
    })
    .catch(error => {
        console.error('Error deleting comment:', error);
        showToast('Đã xảy ra lỗi khi xóa bình luận.', 'error');
    });
}

function loadMoreComments(storyId, chapterId, offset) {
    const loadMoreBtn = document.getElementById('load-more-comments');
    const commentsContainer = document.getElementById('comments-container');

    if (!loadMoreBtn || !commentsContainer) return;

    // Show loading
    loadMoreBtn.disabled = true;
    loadMoreBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Đang tải...';

    // Build query parameters
    let params = `story_id=${storyId}&offset=${offset}`;
    if (chapterId) {
        params += `&chapter_id=${chapterId}`;
    }

    // Fetch more comments
    fetch(`${baseUrl}/comments/load-more?${params}`)
        .then(response => response.json())
        .then(data => {
            // Reset button
            loadMoreBtn.disabled = false;
            loadMoreBtn.innerHTML = 'Xem thêm bình luận';

            if (data.status === 'success') {
                // Append new comments
                commentsContainer.insertAdjacentHTML('beforeend', data.html);

                // Update offset
                loadMoreBtn.setAttribute('data-offset', offset + 10);

                // Hide button if no more comments
                if (!data.hasMore) {
                    loadMoreBtn.style.display = 'none';
                }

                // Add event listeners to new delete buttons
                document.querySelectorAll('.delete-comment').forEach(button => {
                    button.addEventListener('click', function() {
                        const commentId = this.getAttribute('data-id');
                        if (confirm('Bạn có chắc chắn muốn xóa bình luận này?')) {
                            deleteComment(commentId);
                        }
                    });
                });
            } else {
                // Show error message
                showToast('Không thể tải thêm bình luận.', 'error');
            }
        })
        .catch(error => {
            // Reset button
            loadMoreBtn.disabled = false;
            loadMoreBtn.innerHTML = 'Xem thêm bình luận';

            // Show error message
            console.error('Error loading more comments:', error);
            showToast('Đã xảy ra lỗi khi tải bình luận.', 'error');
        });
}
