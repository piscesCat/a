<?php
namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\UserModel;
use App\Models\LogModel;

class UserManager extends BaseController
{
    protected $userModel;
    protected $logModel;
    protected $currentUser;

    public function __construct()
    {
        $this->userModel = new UserModel();
        $this->logModel = new LogModel();
        $this->currentUser = session()->get('user');

        // Chỉ người sáng lập (role=3) và admin (role=2) mới có quyền quản lý người dùng
        if (!$this->currentUser || $this->currentUser['role'] < 2) {
            return redirect()->to('/')->with('error', 'Bạn không có quyền truy cập trang này');
        }
    }

    public function index()
    {
        $page = $this->request->getGet('page') ?? 1;
        $limit = 20;
        $offset = ($page - 1) * $limit;

        $users = $this->userModel->findAll($limit, $offset);
        $total = $this->userModel->countAllResults();

        // Lọc người dùng theo quyền
        // Người sáng lập (role=3) thấy tất cả người dùng
        // Admin (role=2) chỉ thấy cộng tác viên (role=1) và chính bản thân
        $filteredUsers = [];
        foreach ($users as $user) {
            if ($this->currentUser['role'] == 3 || // Người sáng lập thấy tất cả
                $user['id'] == $this->currentUser['id'] || // Người dùng luôn thấy chính mình
                $user['role'] < $this->currentUser['role']) { // Admin thấy cộng tác viên, không thấy admin khác

                // Thêm thông tin hiển thị cho vai trò
                $user['role_text'] = $this->userModel->getRoleText($user['role']);
                $user['role_color'] = $this->userModel->getRoleColor($user['role']);

                $filteredUsers[] = $user;
            }
        }

        return view('admin/user/index.html', [
            'users' => $filteredUsers,
            'current_user' => $this->currentUser,
            'pager' => [
                'current' => $page,
                'total' => ceil($total / $limit)
            ]
        ]);
    }

    public function create()
    {
        $roleOptions = $this->getRoleOptions();

        return view('admin/user/create.html', [
            'roles' => $roleOptions,
            'current_user' => $this->currentUser
        ]);
    }

    public function save()
    {
        // Validate input
        $rules = [
            'username' => 'required|min_length[3]|max_length[50]|is_unique[users.username]',
            'email' => 'required|valid_email|is_unique[users.email]',
            'password' => 'required|min_length[6]',
            'display_name' => 'required|min_length[3]|max_length[100]',
            'role' => 'required|integer|in_list[1,2,3]'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()
                ->withInput()
                ->with('error', implode('<br>', $this->validator->getErrors()));
        }

        // Kiểm tra quyền tạo người dùng (không thể tạo người dùng với quyền cao hơn mình)
        $requestedRole = (int)$this->request->getPost('role');
        if ($requestedRole > $this->currentUser['role']) {
            return redirect()->back()
                ->withInput()
                ->with('error', 'Bạn không thể tạo người dùng với quyền cao hơn bạn');
        }

        // Admin (role=2) không thể tạo admin khác, chỉ tạo được cộng tác viên
        if ($this->currentUser['role'] == 2 && $requestedRole == 2) {
            return redirect()->back()
                ->withInput()
                ->with('error', 'Chỉ người sáng lập mới có thể tạo admin mới');
        }

        // Tạo người dùng mới
        $data = [
            'username' => $this->request->getPost('username'),
            'email' => $this->request->getPost('email'),
            'password' => $this->request->getPost('password'), // Model sẽ hash password
            'display_name' => $this->request->getPost('display_name'),
            'role' => $requestedRole,
            'status' => 'active',
            'bio' => $this->request->getPost('bio', FILTER_SANITIZE_STRING),
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];

        $userId = $this->userModel->insert($data);

        // Log hành động
        $this->logModel->info('Tạo người dùng mới', [
            'user_id' => $this->currentUser['id'],
            'target_id' => $userId,
            'username' => $data['username'],
            'role' => $data['role']
        ]);

        return redirect()->to('/admin/users')
            ->with('success', 'Người dùng mới đã được tạo thành công');
    }

    public function edit($id)
    {
        $user = $this->userModel->find($id);
        if (!$user) {
            return redirect()->to('/admin/users')
                ->with('error', 'Không tìm thấy người dùng');
        }

        // Kiểm tra quyền chỉnh sửa
        if (!$this->canEditUser($user)) {
            return redirect()->to('/admin/users')
                ->with('error', 'Bạn không có quyền chỉnh sửa người dùng này');
        }

        $roleOptions = $this->getRoleOptions();

        return view('admin/user/edit.html', [
            'user' => $user,
            'roles' => $roleOptions,
            'current_user' => $this->currentUser
        ]);
    }

    public function update($id)
    {
        $user = $this->userModel->find($id);
        if (!$user) {
            return redirect()->to('/admin/users')
                ->with('error', 'Không tìm thấy người dùng');
        }

        // Kiểm tra quyền cập nhật
        if (!$this->canEditUser($user)) {
            return redirect()->to('/admin/users')
                ->with('error', 'Bạn không có quyền cập nhật người dùng này');
        }

        // Validate input
        $rules = [
            'username' => "required|min_length[3]|max_length[50]|is_unique[users.username,id,$id]",
            'email' => "required|valid_email|is_unique[users.email,id,$id]",
            'display_name' => 'required|min_length[3]|max_length[100]',
            'status' => 'required|in_list[active,inactive,banned]'
        ];

        // Chỉ người sáng lập (role=3) và admin (role=2) có thể thay đổi vai trò,
        // nhưng admin chỉ có thể thay đổi vai trò của cộng tác viên
        $canChangeRole = $this->currentUser['role'] == 3 ||
                        ($this->currentUser['role'] == 2 && $user['role'] == 1);

        if ($canChangeRole) {
            $rules['role'] = 'required|integer|in_list[1,2,3]';
        }

        if ($this->request->getPost('password')) {
            $rules['password'] = 'min_length[6]';
        }

        if (!$this->validate($rules)) {
            return redirect()->back()
                ->withInput()
                ->with('error', implode('<br>', $this->validator->getErrors()));
        }

        // Chuẩn bị dữ liệu cập nhật
        $data = [
            'username' => $this->request->getPost('username'),
            'email' => $this->request->getPost('email'),
            'display_name' => $this->request->getPost('display_name'),
            'status' => $this->request->getPost('status'),
            'bio' => $this->request->getPost('bio', FILTER_SANITIZE_STRING),
            'updated_at' => date('Y-m-d H:i:s')
        ];

        // Cập nhật role nếu có quyền
        if ($canChangeRole) {
            $requestedRole = (int)$this->request->getPost('role');

            // Không cho phép set role cao hơn người dùng hiện tại
            if ($requestedRole > $this->currentUser['role']) {
                return redirect()->back()
                    ->withInput()
                    ->with('error', 'Bạn không thể set quyền cao hơn quyền của bạn');
            }

            // Admin không thể nâng cấp cộng tác viên thành admin
            if ($this->currentUser['role'] == 2 && $requestedRole == 2) {
                return redirect()->back()
                    ->withInput()
                    ->with('error', 'Chỉ người sáng lập mới có thể phong ai đó làm Admin');
            }

            $data['role'] = $requestedRole;
        }

        // Cập nhật mật khẩu nếu có
        if ($this->request->getPost('password')) {
            $data['password'] = $this->request->getPost('password');
        }

        $this->userModel->update($id, $data);

        // Log hành động
        $this->logModel->info('Cập nhật thông tin người dùng', [
            'user_id' => $this->currentUser['id'],
            'target_id' => $id,
            'username' => $data['username']
        ]);

        return redirect()->to('/admin/users')
            ->with('success', 'Thông tin người dùng đã được cập nhật thành công');
    }

    public function delete()
    {
        $id = $this->request->getPost('id');
        if (!$id) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'ID không hợp lệ'
            ]);
        }

        $user = $this->userModel->find($id);
        if (!$user) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Không tìm thấy người dùng'
            ]);
        }

        // Không thể xóa chính mình
        if ($id == $this->currentUser['id']) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Bạn không thể xóa tài khoản của chính mình'
            ]);
        }

        // Kiểm tra quyền xóa (chỉ có thể xóa người dùng có quyền thấp hơn)
        if ($user['role'] >= $this->currentUser['role']) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Bạn không có quyền xóa người dùng này'
            ]);
        }

        // Admin chỉ có thể xóa cộng tác viên
        if ($this->currentUser['role'] == 2 && $user['role'] != 1) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Admin chỉ có thể xóa tài khoản Cộng tác viên'
            ]);
        }

        // Log trước khi xóa
        $this->logModel->info('Xóa người dùng', [
            'user_id' => $this->currentUser['id'],
            'target_id' => $id,
            'username' => $user['username'],
            'email' => $user['email']
        ]);

        $this->userModel->delete($id);

        return $this->response->setJSON([
            'success' => true,
            'message' => 'Người dùng đã được xóa thành công'
        ]);
    }

    public function updateStatus()
    {
        $id = $this->request->getPost('id');
        $status = $this->request->getPost('status');

        if (!$id || !in_array($status, ['active', 'inactive', 'banned'])) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Dữ liệu không hợp lệ'
            ]);
        }

        $user = $this->userModel->find($id);
        if (!$user) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Không tìm thấy người dùng'
            ]);
        }

        // Kiểm tra quyền cập nhật (chỉ có thể cập nhật người dùng có quyền thấp hơn)
        if ($user['role'] > $this->currentUser['role']) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Bạn không có quyền thay đổi trạng thái của người dùng này'
            ]);
        }

        // Admin chỉ có thể thay đổi trạng thái của cộng tác viên và chính mình
        if ($this->currentUser['role'] == 2 && $user['role'] == 2 && $id != $this->currentUser['id']) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Bạn không có quyền thay đổi trạng thái của admin khác'
            ]);
        }

        $this->userModel->update($id, ['status' => $status]);

        // Log hành động
        $this->logModel->info('Cập nhật trạng thái người dùng', [
            'user_id' => $this->currentUser['id'],
            'target_id' => $id,
            'status' => $status
        ]);

        return $this->response->setJSON([
            'success' => true,
            'message' => 'Trạng thái người dùng đã được cập nhật thành công'
        ]);
    }

    /**
     * Kiểm tra quyền chỉnh sửa người dùng
     */
    private function canEditUser($user)
    {
        // Người dùng luôn có thể chỉnh sửa chính mình
        if ($user['id'] == $this->currentUser['id']) {
            return true;
        }

        // Người sáng lập (role=3) có thể chỉnh sửa tất cả
        if ($this->currentUser['role'] == 3) {
            return true;
        }

        // Admin (role=2) chỉ có thể chỉnh sửa cộng tác viên (role=1)
        if ($this->currentUser['role'] == 2 && $user['role'] == 1) {
            return true;
        }

        return false;
    }

    /**
     * Lấy danh sách quyền người dùng theo quyền hiện tại
     */
    private function getRoleOptions()
    {
        $roles = [
            '1' => 'Cộng tác viên',
            '2' => 'Admin',
            '3' => 'Người sáng lập'
        ];

        // Người sáng lập (role=3) có thể tạo tất cả các loại người dùng
        if ($this->currentUser['role'] == 3) {
            return $roles;
        }

        // Admin (role=2) chỉ có thể tạo cộng tác viên (role=1)
        if ($this->currentUser['role'] == 2) {
            return ['1' => 'Cộng tác viên'];
        }

        // Mặc định chỉ trả về cộng tác viên
        return ['1' => 'Cộng tác viên'];
    }
}
