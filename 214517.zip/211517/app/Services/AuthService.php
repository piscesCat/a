<?php
namespace App\Services;

class AuthService
{
    protected $tokenModel;
    protected $userModel;
    protected $session;

    public function __construct()
    {
        $this->tokenModel = new \App\Models\TokenModel();
        $this->userModel = new \App\Models\UserModel();
        $this->session = session();
    }

    /**
     * Kiểm tra xác thực qua session
     *
     * @return array|null User info hoặc null nếu không có session
     */
    public function checkSessionAuth()
    {
        $user = $this->session->get('user');
        if (!$user) {
            return null;
        }

        // Kiểm tra xem người dùng còn tồn tại và active không
        $currentUser = $this->userModel->find($user['id']);
        if (!$currentUser || $currentUser['status'] !== 'active') {
            $this->session->remove('user');
            return null;
        }

        return $user;
    }

    /**
     * Kiểm tra xác thực qua API token
     *
     * @param string $authHeader Chuỗi Authorization header
     * @return array|null User info hoặc null nếu token không hợp lệ
     */
    public function checkTokenAuth($authHeader)
    {
        if (empty($authHeader) || !preg_match('/Bearer\\s+(.*)$/i', $authHeader, $matches)) {
            return null;
        }

        $token = $matches[1];
        $user = $this->tokenModel->getUserFromToken($token);

        // Kiểm tra xem người dùng còn tồn tại và active không
        if ($user && $user['status'] === 'active') {
            return $user;
        }

        return null;
    }

    /**
     * Kiểm tra quyền truy cập
     *
     * @param array|null $user Thông tin người dùng
     * @param int $requiredRole Vai trò tối thiểu được yêu cầu
     * @return bool True nếu người dùng có quyền
     */
    public function hasPermission($user, $requiredRole)
    {
        if (!$user) {
            return false;
        }

        return $user['role'] >= $requiredRole;
    }

    /**
     * Đăng nhập người dùng và lưu session
     *
     * @param string $username Username hoặc email
     * @param string $password Mật khẩu
     * @return array Mảng với kết quả đăng nhập
     */
    public function login($username, $password)
    {
        // Kiểm tra đầu vào
        if (empty($username) || empty($password)) {
            return [
                'success' => false,
                'message' => 'Vui lòng nhập tên đăng nhập và mật khẩu'
            ];
        }

        // Tìm người dùng theo username hoặc email
        $user = $this->userModel->where('username', $username)
                              ->orWhere('email', $username)
                              ->first();

        // Kiểm tra người dùng tồn tại
        if (!$user) {
            return [
                'success' => false,
                'message' => 'Tên đăng nhập hoặc mật khẩu không đúng'
            ];
        }

        // Kiểm tra trạng thái người dùng
        if ($user['status'] !== 'active') {
            return [
                'success' => false,
                'message' => 'Tài khoản của bạn đã bị khóa hoặc chưa kích hoạt'
            ];
        }

        // Kiểm tra mật khẩu
        if (!password_verify($password, $user['password'])) {
            return [
                'success' => false,
                'message' => 'Tên đăng nhập hoặc mật khẩu không đúng'
            ];
        }

        // Loại bỏ mật khẩu trước khi lưu vào session
        unset($user['password']);

        // Lưu thông tin người dùng vào session
        $this->session->set('user', $user);

        // Lưu log đăng nhập
        $logModel = new \App\Models\LogModel();
        $logModel->info('Đăng nhập thành công', [
            'user_id' => $user['id'],
            'ip' => $_SERVER['REMOTE_ADDR'] ?? '',
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? ''
        ]);

        return [
            'success' => true,
            'message' => 'Đăng nhập thành công',
            'user' => $user
        ];
    }

    /**
     * Đăng xuất người dùng
     *
     * @return array Mảng với kết quả đăng xuất
     */
    public function logout()
    {
        $user = $this->session->get('user');

        if ($user) {
            // Lưu log đăng xuất
            $logModel = new \App\Models\LogModel();
            $logModel->info('Đăng xuất', [
                'user_id' => $user['id']
            ]);
        }

        $this->session->remove('user');

        return [
            'success' => true,
            'message' => 'Đăng xuất thành công'
        ];
    }

    /**
     * Tạo API token cho người dùng
     *
     * @param int $userId ID người dùng
     * @param string $name Tên token
     * @param int $expireDays Số ngày token có hiệu lực (0 = không hết hạn)
     * @return array Mảng với thông tin token
     */
    public function createApiToken($userId, $name, $expireDays = 30)
    {
        $token = bin2hex(random_bytes(32)); // Generate a secure random token

        $data = [
            'user_id' => $userId,
            'token' => $token,
            'name' => $name,
            'created_at' => date('Y-m-d H:i:s'),
            'last_used_at' => null
        ];

        if ($expireDays > 0) {
            $data['expires_at'] = date('Y-m-d H:i:s', strtotime("+$expireDays days"));
        }

        $tokenId = $this->tokenModel->insert($data);

        if ($tokenId) {
            return [
                'success' => true,
                'token' => $token,
                'token_id' => $tokenId,
                'expires_at' => $data['expires_at'] ?? null
            ];
        }

        return [
            'success' => false,
            'message' => 'Không thể tạo token'
        ];
    }
}
