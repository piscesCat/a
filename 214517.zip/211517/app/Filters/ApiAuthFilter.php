<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

class ApiAuthFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        $tokenModel = new \App\Models\TokenModel();
        $authHeader = $request->getServer('HTTP_AUTHORIZATION');

        // Kiểm tra header Authorization có tồn tại không
        if (empty($authHeader)) {
            return service('response')->setJSON([
                'success' => false,
                'message' => 'Thiếu token xác thực. Vui lòng cung cấp token trong header Authorization.'
            ])->setStatusCode(401);
        }

        // Kiểm tra định dạng Bearer token
        if (!preg_match('/Bearer\s+(.*)$/i', $authHeader, $matches)) {
            return service('response')->setJSON([
                'success' => false,
                'message' => 'Định dạng token không hợp lệ. Sử dụng: Bearer {token}'
            ])->setStatusCode(401);
        }

        $token = $matches[1];

        // Kiểm tra token có hợp lệ không
        if (empty($token)) {
            return service('response')->setJSON([
                'success' => false,
                'message' => 'Token không được để trống'
            ])->setStatusCode(401);
        }

        // Xác thực token từ database
        $user = $tokenModel->getUserFromToken($token);
        if (!$user) {
            return service('response')->setJSON([
                'success' => false,
                'message' => 'Token không hợp lệ hoặc đã hết hạn'
            ])->setStatusCode(401);
        }

        // Lưu thông tin người dùng vào request để sử dụng sau này
        $request->user = $user;
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // Không cần thực hiện hành động sau khi xử lý
    }
}
