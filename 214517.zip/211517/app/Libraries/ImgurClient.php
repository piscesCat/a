<?php

namespace App\Libraries;

class ImgurClient
{
    protected $clientId;
    protected $clientSecret;
    protected $caPath;
    protected $timeout = 30;
    protected $retryCount = 2;

    public function __construct()
    {
        // Lấy client ID từ cấu hình hoặc biến môi trường
        $this->clientId = getenv('IMGUR_CLIENT_ID') ?: '';
        $this->clientSecret = getenv('IMGUR_CLIENT_SECRET') ?: '';

        // Đường dẫn đến CA certificate
        $this->caPath = ROOTPATH . 'cacert.pem';

        // Kiểm tra và tạo cacert.pem nếu không tồn tại
        if (!file_exists($this->caPath)) {
            $this->downloadCABundle();
        }
    }

    /**
     * Tải xuống CA bundle từ curl.haxx.se
     */
    protected function downloadCABundle()
    {
        $caBundleUrl = 'https://curl.se/ca/cacert.pem';
        $caBundleContent = @file_get_contents($caBundleUrl);

        if ($caBundleContent !== false) {
            @file_put_contents($this->caPath, $caBundleContent);
        }
    }

    /**
     * Thiết lập chung cho cURL
     */
    protected function setupCurl($url, $method = 'POST', $data = [])
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, $this->timeout);

        // Bật xác thực SSL
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);

        // Sử dụng CA bundle
        if (file_exists($this->caPath)) {
            curl_setopt($ch, CURLOPT_CAINFO, $this->caPath);
        }

        // Headers
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Client-ID ' . $this->clientId
        ]);

        // Thiết lập phương thức
        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        } elseif ($method === 'DELETE') {
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'DELETE');
        }

        return $ch;
    }

    /**
     * Xử lý kết quả cURL
     */
    protected function processCurlResponse($ch, $retryCount = 0)
    {
        $response = curl_exec($ch);
        $error = curl_error($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $errorNo = curl_errno($ch);
        curl_close($ch);

        // Kiểm tra lỗi cURL
        if ($error) {
            // Nếu là lỗi mạng và còn cơ hội retry
            if (in_array($errorNo, [6, 7, 28, 35, 52, 56]) && $retryCount < $this->retryCount) {
                // Thử lại sau 1 giây
                sleep(1);
                return $this->processCurlResponse($ch, $retryCount + 1);
            }

            return [
                'success' => false,
                'error' => 'cURL Error (' . $errorNo . '): ' . $error,
                'status' => 500
            ];
        }

        // Parse response JSON
        $result = json_decode($response, true);

        // Kiểm tra JSON validity
        if (json_last_error() !== JSON_ERROR_NONE) {
            return [
                'success' => false,
                'error' => 'Invalid JSON response: ' . json_last_error_msg(),
                'status' => $httpCode,
                'raw_response' => $response
            ];
        }

        // Kiểm tra và trả về kết quả
        if (isset($result['success']) && $result['success']) {
            return [
                'success' => true,
                'data' => $result['data'] ?? [],
                'status' => $httpCode
            ];
        }

        // Trả về lỗi chi tiết hơn
        $errorMessage = 'Lỗi không xác định';
        if (isset($result['data']['error']['message'])) {
            $errorMessage = $result['data']['error']['message'];
        } elseif (isset($result['data']['error'])) {
            $errorMessage = $result['data']['error'];
        }

        return [
            'success' => false,
            'error' => $errorMessage,
            'code' => $result['data']['error']['code'] ?? '',
            'status' => $httpCode
        ];
    }

    /**
     * Upload ảnh lên Imgur
     *
     * @param string $imageData Dữ liệu ảnh (base64 hoặc binary)
     * @param bool $isBase64 Cờ xác định imageData đã là base64 hay chưa
     * @return array Kết quả từ Imgur API
     */
    public function uploadImage($imageData, $isBase64 = false)
    {
        // Kiểm tra client ID
        if (empty($this->clientId)) {
            return [
                'success' => false,
                'error' => 'Không tìm thấy Imgur Client ID. Vui lòng cấu hình trong .env',
                'status' => 400
            ];
        }

        // Chuyển đổi dữ liệu thành base64 nếu cần
        $base64Image = $isBase64 ? $imageData : base64_encode($imageData);

        // Kiểm tra kích thước ảnh
        $decodedSize = strlen(base64_decode($base64Image));
        if ($decodedSize > 10 * 1024 * 1024) { // 10MB
            return [
                'success' => false,
                'error' => 'Kích thước ảnh quá lớn. Giới hạn là 10MB.',
                'status' => 400
            ];
        }

        // Thiết lập cURL request
        $ch = $this->setupCurl('https://api.imgur.com/3/image', 'POST', [
            'image' => $base64Image
        ]);

        // Thực hiện request và xử lý kết quả
        $result = $this->processCurlResponse($ch);

        // Định dạng kết quả để tương thích với phiên bản cũ
        if ($result['success'] && isset($result['data'])) {
            $result['data'] = [
                'link' => $result['data']['link'] ?? '',
                'deletehash' => $result['data']['deletehash'] ?? '',
                'id' => $result['data']['id'] ?? '',
                'type' => $result['data']['type'] ?? ''
            ];
        }

        return $result;
    }

    /**
     * Upload ảnh từ URL
     *
     * @param string $imageUrl URL của ảnh cần upload
     * @return array Kết quả từ Imgur API
     */
    public function uploadImageFromUrl($imageUrl)
    {
        // Kiểm tra client ID
        if (empty($this->clientId)) {
            return [
                'success' => false,
                'error' => 'Không tìm thấy Imgur Client ID. Vui lòng cấu hình trong .env',
                'status' => 400
            ];
        }

        // Xác thực URL
        if (!filter_var($imageUrl, FILTER_VALIDATE_URL)) {
            return [
                'success' => false,
                'error' => 'URL ảnh không hợp lệ',
                'status' => 400
            ];
        }

        // Thiết lập cURL request
        $ch = $this->setupCurl('https://api.imgur.com/3/image', 'POST', [
            'image' => $imageUrl,
            'type' => 'url'
        ]);

        // Thực hiện request và xử lý kết quả
        $result = $this->processCurlResponse($ch);

        // Định dạng kết quả để tương thích với phiên bản cũ
        if ($result['success'] && isset($result['data'])) {
            $result['data'] = [
                'link' => $result['data']['link'] ?? '',
                'deletehash' => $result['data']['deletehash'] ?? '',
                'id' => $result['data']['id'] ?? '',
                'type' => $result['data']['type'] ?? ''
            ];
        }

        return $result;
    }

    /**
     * Xóa ảnh từ Imgur
     *
     * @param string $deleteHash Delete hash của ảnh cần xóa
     * @return array Kết quả từ Imgur API
     */
    public function deleteImage($deleteHash)
    {
        // Kiểm tra client ID
        if (empty($this->clientId)) {
            return [
                'success' => false,
                'error' => 'Không tìm thấy Imgur Client ID. Vui lòng cấu hình trong .env',
                'status' => 400
            ];
        }

        // Kiểm tra deleteHash
        if (empty($deleteHash)) {
            return [
                'success' => false,
                'error' => 'Delete hash không được để trống',
                'status' => 400
            ];
        }

        // Thiết lập cURL request
        $ch = $this->setupCurl('https://api.imgur.com/3/image/' . $deleteHash, 'DELETE');

        // Thực hiện request và xử lý kết quả
        return $this->processCurlResponse($ch);
    }
}
