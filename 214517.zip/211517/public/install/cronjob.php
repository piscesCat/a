<?php include 'templates/header.php'; ?>

<div class="container mt-4">
    <div class="card">
        <div class="card-header bg-primary text-white">
            <h2>Hướng dẫn cài đặt Cronjob</h2>
        </div>
        <div class="card-body">
            <p class="lead">
                Hệ thống sử dụng nhiều tác vụ tự động được chạy theo lịch để cập nhật dữ liệu và đảm bảo trang web hoạt động hiệu quả.
                Dưới đây là hướng dẫn cài đặt các cronjob cần thiết.
            </p>

            <h3 class="mt-4">Danh sách các Cronjob cần thiết</h3>

            <div class="card mb-3">
                <div class="card-header">
                    1. Cập nhật truyện Hot (UpdateHotStories)
                </div>
                <div class="card-body">
                    <p>Cập nhật danh sách truyện hot dựa vào các tiêu chí như lượt xem, đánh giá, bình luận mới.</p>
                    <pre class="bg-light p-2"><code>0 */3 * * * php /đường/dẫn/đến/website/public/index.php stories:update-hot</code></pre>
                    <p class="small text-muted">Cú pháp này sẽ chạy cứ mỗi 3 giờ (vào đầu giờ).</p>
                </div>
            </div>

            <div class="card mb-3">
                <div class="card-header">
                    2. Cập nhật truyện Đề xuất (UpdateRecommendedStories)
                </div>
                <div class="card-body">
                    <p>Cập nhật danh sách truyện được đề xuất dựa trên thuật toán thông minh.</p>
                    <pre class="bg-light p-2"><code>0 */6 * * * php /đường/dẫn/đến/website/public/index.php stories:update-recommended</code></pre>
                    <p class="small text-muted">Cú pháp này sẽ chạy cứ mỗi 6 giờ (vào đầu giờ).</p>
                </div>
            </div>

            <div class="card mb-3">
                <div class="card-header">
                    3. Cập nhật trạng thái truyện (UpdateStoryStatus)
                </div>
                <div class="card-body">
                    <p>Cập nhật trạng thái hoàn thành/đang tiến hành của truyện dựa vào thời gian cập nhật.</p>
                    <pre class="bg-light p-2"><code>0 0 * * * php /đường/dẫn/đến/website/public/index.php stories:update-status</code></pre>
                    <p class="small text-muted">Cú pháp này sẽ chạy mỗi ngày vào lúc 00:00.</p>
                </div>
            </div>

            <div class="card mb-3">
                <div class="card-header">
                    4. Đề xuất truyện nổi bật (SuggestFeaturedStories)
                </div>
                <div class="card-body">
                    <p>Tạo danh sách đề xuất truyện nổi bật cho admin.</p>
                    <pre class="bg-light p-2"><code>0 0 * * 1 php /đường/dẫn/đến/website/public/index.php stories:suggest-featured</code></pre>
                    <p class="small text-muted">Cú pháp này sẽ chạy mỗi tuần vào thứ 2 lúc 00:00.</p>
                </div>
            </div>

            <div class="card mb-3">
                <div class="card-header">
                    5. Reset lượt xem (ResetViews)
                </div>
                <div class="card-body">
                    <p>Reset lượt xem theo ngày, tuần, tháng.</p>
                    <pre class="bg-light p-2"><code>0 0 * * * php /đường/dẫn/đến/website/public/index.php stories:reset-daily-views
0 0 * * 0 php /đường/dẫn/đến/website/public/index.php stories:reset-weekly-views
0 0 1 * * php /đường/dẫn/đến/website/public/index.php stories:reset-monthly-views</code></pre>
                    <ul class="small text-muted">
                        <li>Cú pháp đầu tiên sẽ chạy mỗi ngày vào lúc 00:00.</li>
                        <li>Cú pháp thứ hai sẽ chạy mỗi Chủ nhật vào lúc 00:00.</li>
                        <li>Cú pháp thứ ba sẽ chạy vào ngày đầu tiên của mỗi tháng lúc 00:00.</li>
                    </ul>
                </div>
            </div>

            <div class="card mb-3">
                <div class="card-header">
                    6. Bảo trì hệ thống (Maintenance)
                </div>
                <div class="card-body">
                    <p>Thực hiện các tác vụ bảo trì hệ thống như dọn dẹp file tạm, tối ưu database.</p>
                    <pre class="bg-light p-2"><code>0 3 * * 0 php /đường/dẫn/đến/website/public/index.php maintenance:run</code></pre>
                    <p class="small text-muted">Cú pháp này sẽ chạy mỗi Chủ nhật lúc 3 giờ sáng.</p>
                </div>
            </div>

            <h3 class="mt-4">Cài đặt Cronjob</h3>

            <div class="card mb-3">
                <div class="card-header">
                    Trên Linux/Unix (VPS hoặc Dedicated Server)
                </div>
                <div class="card-body">
                    <ol>
                        <li>Đăng nhập vào server qua SSH</li>
                        <li>Mở crontab để chỉnh sửa:
                            <pre class="bg-light p-2 mt-2"><code>crontab -e</code></pre>
                        </li>
                        <li>Thêm các dòng cronjob ở trên, thay thế <code>/đường/dẫn/đến/website</code> bằng đường dẫn thực tế tới thư mục gốc của trang web.<br>
                            <span class="text-muted">ví dụ: <code>/var/www/html/tenwebsite</code></span>
                        </li>
                        <li>Lưu và thoát bằng cách nhấn <code>Ctrl + X</code>, sau đó nhấn <code>Y</code> và <code>Enter</code>.</li>
                        <li>Kiểm tra xem cronjob đã được cài đặt chưa:
                            <pre class="bg-light p-2 mt-2"><code>crontab -l</code></pre>
                        </li>
                    </ol>
                </div>
            </div>

            <div class="card mb-3">
                <div class="card-header">
                    Trên Shared Hosting
                </div>
                <div class="card-body">
                    <ol>
                        <li>Đăng nhập vào Control Panel (cPanel, Plesk, DirectAdmin...)</li>
                        <li>Tìm phần quản lý Cronjob/Scheduled Tasks/Cron Jobs</li>
                        <li>Thêm các cronjob theo hướng dẫn trên giao diện, sử dụng các lệnh đã cung cấp</li>
                        <li>Đối với cPanel:
                            <ul>
                                <li>Chọn "Cron Jobs" từ dashboard</li>
                                <li>Chọn tần suất từ menu dropdown hoặc nhập biểu thức cron thủ công</li>
                                <li>Trong phần command, nhập lệnh PHP phù hợp với đường dẫn đến website của bạn</li>
                            </ul>
                        </li>
                    </ol>
                </div>
            </div>

            <div class="card mb-3">
                <div class="card-header">
                    Thử nghiệm Cronjob
                </div>
                <div class="card-body">
                    <p>Để kiểm tra xem cronjob có hoạt động đúng không, bạn có thể chạy lệnh thủ công và kiểm tra kết quả:</p>
                    <pre class="bg-light p-2"><code>php /đường/dẫn/đến/website/public/index.php stories:update-hot</code></pre>
                    <p>Nếu lệnh chạy thành công, bạn sẽ thấy kết quả tương ứng.</p>
                </div>
            </div>

            <div class="card mb-3">
                <div class="card-header bg-info text-white">
                    Sử dụng Master Cronjob (Đề xuất)
                </div>
                <div class="card-body">
                    <p>Để đơn giản hóa việc quản lý, bạn có thể sử dụng master cronjob để tự động chạy tất cả các tác vụ cần thiết:</p>
                    <pre class="bg-light p-2"><code>* * * * * php /đường/dẫn/đến/website/public/index.php master-cron</code></pre>
                    <p>MasterCron sẽ tự động quản lý việc chạy các tác vụ con theo lịch phù hợp, giảm thiểu số lượng cronjob cần cài đặt.</p>

                    <h5 class="mt-3">Cài đặt thông qua Master Cronjob</h5>
                    <ol>
                        <li>Chỉ cần thêm một dòng cronjob duy nhất như trên vào crontab</li>
                        <li>MasterCron sẽ tự động kiểm tra và chạy các tác vụ cần thiết dựa trên cài đặt thời gian trong cơ sở dữ liệu</li>
                        <li>Bạn có thể thay đổi lịch chạy các tác vụ thông qua giao diện quản trị mà không cần chỉnh sửa crontab</li>
                    </ol>
                </div>
            </div>

            <div class="card mb-3">
                <div class="card-header">
                    Xử lý lỗi thường gặp
                </div>
                <div class="card-body">
                    <dl>
                        <dt>Permission Denied</dt>
                        <dd>Đảm bảo rằng người dùng chạy cronjob có quyền thực thi các file PHP
                            <pre class="bg-light p-2 mt-2"><code>chmod +x /đường/dẫn/đến/website/public/index.php</code></pre>
                        </dd>

                        <dt class="mt-3">Command Not Found</dt>
                        <dd>Đảm bảo rằng đường dẫn đến PHP và file index.php là chính xác
                            <pre class="bg-light p-2 mt-2"><code>which php  # để tìm đường dẫn chính xác đến PHP</code></pre>
                        </dd>

                        <dt class="mt-3">No output</dt>
                        <dd>Thêm đường dẫn để log output
                            <pre class="bg-light p-2 mt-2"><code>* * * * * php /đường/dẫn/đến/website/public/index.php master-cron >> /path/to/logfile.log 2>&1</code></pre>
                        </dd>
                    </dl>

                    <h5 class="mt-4">Ghi chú quan trọng</h5>
                    <ul>
                        <li>Đảm bảo múi giờ server khớp với múi giờ sử dụng trong ứng dụng</li>
                        <li>Kiểm tra log hệ thống nếu cronjob không hoạt động như mong đợi</li>
                        <li>Đối với shared hosting, một số nhà cung cấp có thể giới hạn tần suất chạy cronjob</li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="card-footer">
            <a href="index.php" class="btn btn-secondary">Quay lại</a>
        </div>
    </div>
</div>

<?php include 'templates/footer.php'; ?>
